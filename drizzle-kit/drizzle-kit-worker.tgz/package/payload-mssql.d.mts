import { _ as ZodTypeAny, b as ZodUnion, d as ZodObject, f as ZodOptional, i as ZodBoolean, m as ZodString, t as TypeOf, u as ZodNumber } from "./types-OgqGmnkF.mjs";
import { t as EntitiesFilterConfig } from "./common-BwzqAd3Y.mjs";
import { n as MissingHint, t as Hint } from "./hints-DJq8W2Cc.mjs";
import { t as MissingHintsError } from "./errors-Bs6lFKQd.mjs";
import { MsSqlDatabase } from "drizzle-orm/mssql-core";
//#region src/cli/validations/mssql.d.ts
declare const mssqlCredentials: ZodUnion<[ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>, ZodObject<{
  port: ZodOptional<ZodNumber>;
  user: ZodString;
  password: ZodString;
  database: ZodOptional<ZodString>;
  server: ZodString;
  options: ZodOptional<ZodObject<{
    encrypt: ZodOptional<ZodBoolean>;
    trustServerCertificate: ZodOptional<ZodBoolean>;
  }, "strip", ZodTypeAny, {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  }, {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  }>>;
}, "strip", ZodTypeAny, {
  user: string;
  password: string;
  server: string;
  options?: {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  } | undefined;
  port?: number | undefined;
  database?: string | undefined;
}, {
  user: string;
  password: string;
  server: string;
  options?: {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  } | undefined;
  port?: number | undefined;
  database?: string | undefined;
}>]>;
type MssqlCredentials = TypeOf<typeof mssqlCredentials>;
//#endregion
//#region src/dialects/mssql/snapshot.d.ts
declare const snapshotValidator: {
  shape: {
    version: "2";
    dialect: "mssql";
    id: string;
    prevIds: string[];
    ddl: ({
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      table: string;
      name: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null;
      identity: {
        increment: number;
        seed: number;
      } | null;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      name: string;
      nameExplicit: boolean;
      columns: string[];
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      name: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      name: string;
      nameExplicit: boolean;
      columns: string[];
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      name: string;
      value: string;
      entityType: "checks";
    } | {
      schema: string;
      table: string;
      name: string;
      column: string;
      nameExplicit: boolean;
      default: string | null;
      entityType: "defaults";
    } | {
      schema: string;
      name: string;
      definition: string;
      encryption: boolean | null;
      schemaBinding: boolean | null;
      viewMetadata: boolean | null;
      checkOption: boolean | null;
      entityType: "views";
    })[];
    renames: string[];
  };
  parse: (obj: unknown) => {
    success: boolean;
    data: {
      version: "2";
      dialect: "mssql";
      id: string;
      prevIds: string[];
      ddl: ({
        name: string;
        entityType: "schemas";
      } | {
        schema: string;
        name: string;
        entityType: "tables";
      } | {
        schema: string;
        table: string;
        name: string;
        type: string;
        notNull: boolean;
        generated: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        identity: {
          increment: number;
          seed: number;
        } | null;
        entityType: "columns";
      } | {
        schema: string;
        table: string;
        name: string;
        nameExplicit: boolean;
        columns: string[];
        entityType: "pks";
      } | {
        schema: string;
        table: string;
        name: string;
        columns: string[];
        nameExplicit: boolean;
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        entityType: "fks";
      } | {
        schema: string;
        table: string;
        name: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        entityType: "indexes";
      } | {
        schema: string;
        table: string;
        name: string;
        nameExplicit: boolean;
        columns: string[];
        entityType: "uniques";
      } | {
        schema: string;
        table: string;
        name: string;
        value: string;
        entityType: "checks";
      } | {
        schema: string;
        table: string;
        name: string;
        column: string;
        nameExplicit: boolean;
        default: string | null;
        entityType: "defaults";
      } | {
        schema: string;
        name: string;
        definition: string;
        encryption: boolean | null;
        schemaBinding: boolean | null;
        viewMetadata: boolean | null;
        checkOption: boolean | null;
        entityType: "views";
      })[];
      renames: string[];
    } | null;
    errors?: string[] | undefined;
  };
  strict: (obj: unknown) => {
    version: "2";
    dialect: "mssql";
    id: string;
    prevIds: string[];
    ddl: ({
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      table: string;
      name: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null;
      identity: {
        increment: number;
        seed: number;
      } | null;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      name: string;
      nameExplicit: boolean;
      columns: string[];
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      name: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      name: string;
      nameExplicit: boolean;
      columns: string[];
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      name: string;
      value: string;
      entityType: "checks";
    } | {
      schema: string;
      table: string;
      name: string;
      column: string;
      nameExplicit: boolean;
      default: string | null;
      entityType: "defaults";
    } | {
      schema: string;
      name: string;
      definition: string;
      encryption: boolean | null;
      schemaBinding: boolean | null;
      viewMetadata: boolean | null;
      checkOption: boolean | null;
      entityType: "views";
    })[];
    renames: string[];
  };
};
type MssqlSnapshot = typeof snapshotValidator.shape;
//#endregion
//#region src/dialects/mssql/versions.d.ts
declare const upToV2: (it: Record<string, any>) => {
  snapshot: MssqlSnapshot;
  hints: string[];
};
//#endregion
//#region src/payload/mssql.d.ts
declare const generateDrizzleJson: (imports: Record<string, unknown>, prevId?: string, schemaFilters?: string[]) => Promise<MssqlSnapshot>;
declare const generateMigration: (prev: MssqlSnapshot, cur: MssqlSnapshot, options?: {
  hints?: Hint[];
}) => Promise<string[]>;
declare const pushSchema: (imports: Record<string, unknown>, drizzleInstance: MsSqlDatabase<any, any>, entitiesConfig?: EntitiesFilterConfig, migrationsConfig?: {
  table?: string;
  schema?: string;
}, options?: {
  hints?: Hint[];
}) => Promise<{
  sqlStatements: string[];
  hints: {
    hint: string;
    statement?: string;
  }[];
  apply: () => Promise<void>;
}>;
declare const startStudioServer: (_imports: Record<string, unknown>, _credentials: MssqlCredentials, _options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<never>;
//#endregion
export { type Hint, type MissingHint, type MissingHintsError, generateDrizzleJson, generateMigration, pushSchema, startStudioServer, upToV2 as up };