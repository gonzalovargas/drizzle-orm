import { _ as ZodUnion, d as ZodOptional, h as ZodTypeAny, i as ZodBoolean, l as ZodNumber, p as ZodString, t as TypeOf, u as ZodObject } from "./types-0NRiLQtx.mjs";
import { i as DiffStatement, n as MissingHint, r as Config, t as Hint } from "./hints-By83v2-O.mjs";
import { t as EntitiesFilterConfig } from "./common-CslNwCIw.mjs";
import { t as MissingHintsError } from "./errors-5EF0YvX8.mjs";
import { MsSqlDatabase } from "drizzle-orm/mssql-core";

//#region src/cli/validations/mssql.d.ts
declare const mssqlCredentials: ZodUnion<[ZodObject<{
  port: ZodOptional<ZodNumber>;
  user: ZodString;
  password: ZodString;
  database: ZodOptional<ZodString>;
  server: ZodString;
  options: ZodOptional<ZodObject<{
    encrypt: ZodOptional<ZodBoolean>;
    trustServerCertificate: ZodOptional<ZodBoolean>;
  }, "strip", ZodTypeAny, {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  }, {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  }>>;
}, "strip", ZodTypeAny, {
  user: string;
  password: string;
  server: string;
  options?: {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  } | undefined;
  port?: number | undefined;
  database?: string | undefined;
}, {
  user: string;
  password: string;
  server: string;
  options?: {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  } | undefined;
  port?: number | undefined;
  database?: string | undefined;
}>, ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>]>;
type MssqlCredentials = TypeOf<typeof mssqlCredentials>;
//#endregion
//#region src/dialects/mssql/ddl.d.ts
declare const createDDL: () => {
  readonly _: {
    types: {
      schemas: {
        name: string;
        entityType: "schemas";
      };
      tables: {
        schema: string;
        name: string;
        entityType: "tables";
      };
      columns: {
        schema: string;
        table: string;
        type: string;
        notNull: boolean;
        generated: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        identity: {
          increment: number;
          seed: number;
        } | null;
        name: string;
        entityType: "columns";
      };
      pks: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "pks";
      };
      fks: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        name: string;
        entityType: "fks";
      };
      indexes: {
        schema: string;
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        name: string;
        entityType: "indexes";
      };
      uniques: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "uniques";
      };
      checks: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      defaults: {
        schema: string;
        table: string;
        column: string;
        nameExplicit: boolean;
        default: string | null;
        name: string;
        entityType: "defaults";
      };
      views: {
        schema: string;
        definition: string;
        encryption: boolean | null;
        schemaBinding: boolean | null;
        viewMetadata: boolean | null;
        checkOption: boolean | null;
        name: string;
        entityType: "views";
      };
    };
    definition: {
      schemas: {};
      tables: {
        schema: "required";
      };
      columns: {
        schema: "required";
        table: "required";
        type: "string";
        notNull: "boolean";
        generated: {
          type: ["persisted", "virtual"];
          as: "string";
        };
        identity: {
          increment: "number";
          seed: "number";
        };
      };
      pks: {
        schema: "required";
        table: "required";
        nameExplicit: "boolean";
        columns: "string[]";
      };
      fks: {
        schema: "required";
        table: "required";
        columns: "string[]";
        nameExplicit: "boolean";
        schemaTo: "string";
        tableTo: "string";
        columnsTo: "string[]";
        onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
        onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
      };
      indexes: {
        schema: "required";
        table: "required";
        columns: [{
          value: "string";
          isExpression: "boolean";
        }];
        isUnique: "boolean";
        where: "string?";
      };
      uniques: {
        schema: "required";
        table: "required";
        nameExplicit: "boolean";
        columns: "string[]";
      };
      checks: {
        schema: "required";
        table: "required";
        value: "string";
      };
      defaults: {
        schema: "required";
        table: "required";
        column: "string";
        nameExplicit: "boolean";
        default: "string?";
      };
      views: {
        schema: "required";
        definition: "string";
        encryption: "boolean?";
        schemaBinding: "boolean?";
        viewMetadata: "boolean?";
        checkOption: "boolean?";
      };
    };
    entities: {
      schemas: Config;
      tables: Config;
      columns: Config;
      pks: Config;
      fks: Config;
      indexes: Config;
      uniques: Config;
      checks: Config;
      defaults: Config;
      views: Config;
    };
    diffs: {
      alter: {
        schemas: {
          $diffType: "alter";
          entityType: "schemas";
          name: string;
          $left: {
            name: string;
            entityType: "schemas";
          };
          $right: {
            name: string;
            entityType: "schemas";
          };
        };
        tables: {
          $diffType: "alter";
          entityType: "tables";
          schema: string;
          name: string;
          $left: {
            schema: string;
            name: string;
            entityType: "tables";
          };
          $right: {
            schema: string;
            name: string;
            entityType: "tables";
          };
        };
        columns: {
          $diffType: "alter";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type?: {
            from: string;
            to: string;
          } | undefined;
          notNull?: {
            from: boolean;
            to: boolean;
          } | undefined;
          generated?: {
            from: {
              type: "persisted" | "virtual";
              as: string;
            } | null;
            to: {
              type: "persisted" | "virtual";
              as: string;
            } | null;
          } | undefined;
          identity?: {
            from: {
              increment: number;
              seed: number;
            } | null;
            to: {
              increment: number;
              seed: number;
            } | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            type: string;
            notNull: boolean;
            generated: {
              type: "persisted" | "virtual";
              as: string;
            } | null;
            identity: {
              increment: number;
              seed: number;
            } | null;
            name: string;
            entityType: "columns";
          };
          $right: {
            schema: string;
            table: string;
            type: string;
            notNull: boolean;
            generated: {
              type: "persisted" | "virtual";
              as: string;
            } | null;
            identity: {
              increment: number;
              seed: number;
            } | null;
            name: string;
            entityType: "columns";
          };
        };
        pks: {
          $diffType: "alter";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            name: string;
            entityType: "pks";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            name: string;
            entityType: "pks";
          };
        };
        fks: {
          $diffType: "alter";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          schemaTo?: {
            from: string;
            to: string;
          } | undefined;
          tableTo?: {
            from: string;
            to: string;
          } | undefined;
          columnsTo?: {
            from: string[];
            to: string[];
          } | undefined;
          onUpdate?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          } | undefined;
          onDelete?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          } | undefined;
          $left: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            name: string;
            entityType: "fks";
          };
          $right: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            name: string;
            entityType: "fks";
          };
        };
        indexes: {
          $diffType: "alter";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: {
              value: string;
              isExpression: boolean;
            }[];
            to: {
              value: string;
              isExpression: boolean;
            }[];
          } | undefined;
          isUnique?: {
            from: boolean;
            to: boolean;
          } | undefined;
          where?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            where: string | null;
            name: string;
            entityType: "indexes";
          };
          $right: {
            schema: string;
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            where: string | null;
            name: string;
            entityType: "indexes";
          };
        };
        uniques: {
          $diffType: "alter";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            name: string;
            entityType: "uniques";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            name: string;
            entityType: "uniques";
          };
        };
        checks: {
          $diffType: "alter";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
          $right: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
        };
        defaults: {
          $diffType: "alter";
          entityType: "defaults";
          schema: string;
          table: string;
          name: string;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          column?: {
            from: string;
            to: string;
          } | undefined;
          default?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            column: string;
            nameExplicit: boolean;
            default: string | null;
            name: string;
            entityType: "defaults";
          };
          $right: {
            schema: string;
            table: string;
            column: string;
            nameExplicit: boolean;
            default: string | null;
            name: string;
            entityType: "defaults";
          };
        };
        views: {
          $diffType: "alter";
          entityType: "views";
          schema: string;
          name: string;
          definition?: {
            from: string;
            to: string;
          } | undefined;
          encryption?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          schemaBinding?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          viewMetadata?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          checkOption?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          $left: {
            schema: string;
            definition: string;
            encryption: boolean | null;
            schemaBinding: boolean | null;
            viewMetadata: boolean | null;
            checkOption: boolean | null;
            name: string;
            entityType: "views";
          };
          $right: {
            schema: string;
            definition: string;
            encryption: boolean | null;
            schemaBinding: boolean | null;
            viewMetadata: boolean | null;
            checkOption: boolean | null;
            name: string;
            entityType: "views";
          };
        };
        entities: {
          $diffType: "alter";
          entityType: "schemas";
          name: string;
          $left: {
            name: string;
            entityType: "schemas";
          };
          $right: {
            name: string;
            entityType: "schemas";
          };
        } | {
          $diffType: "alter";
          entityType: "tables";
          schema: string;
          name: string;
          $left: {
            schema: string;
            name: string;
            entityType: "tables";
          };
          $right: {
            schema: string;
            name: string;
            entityType: "tables";
          };
        } | {
          $diffType: "alter";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type?: {
            from: string;
            to: string;
          } | undefined;
          notNull?: {
            from: boolean;
            to: boolean;
          } | undefined;
          generated?: {
            from: {
              type: "persisted" | "virtual";
              as: string;
            } | null;
            to: {
              type: "persisted" | "virtual";
              as: string;
            } | null;
          } | undefined;
          identity?: {
            from: {
              increment: number;
              seed: number;
            } | null;
            to: {
              increment: number;
              seed: number;
            } | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            type: string;
            notNull: boolean;
            generated: {
              type: "persisted" | "virtual";
              as: string;
            } | null;
            identity: {
              increment: number;
              seed: number;
            } | null;
            name: string;
            entityType: "columns";
          };
          $right: {
            schema: string;
            table: string;
            type: string;
            notNull: boolean;
            generated: {
              type: "persisted" | "virtual";
              as: string;
            } | null;
            identity: {
              increment: number;
              seed: number;
            } | null;
            name: string;
            entityType: "columns";
          };
        } | {
          $diffType: "alter";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            name: string;
            entityType: "pks";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            name: string;
            entityType: "pks";
          };
        } | {
          $diffType: "alter";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          schemaTo?: {
            from: string;
            to: string;
          } | undefined;
          tableTo?: {
            from: string;
            to: string;
          } | undefined;
          columnsTo?: {
            from: string[];
            to: string[];
          } | undefined;
          onUpdate?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          } | undefined;
          onDelete?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          } | undefined;
          $left: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            name: string;
            entityType: "fks";
          };
          $right: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
            name: string;
            entityType: "fks";
          };
        } | {
          $diffType: "alter";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: {
              value: string;
              isExpression: boolean;
            }[];
            to: {
              value: string;
              isExpression: boolean;
            }[];
          } | undefined;
          isUnique?: {
            from: boolean;
            to: boolean;
          } | undefined;
          where?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            where: string | null;
            name: string;
            entityType: "indexes";
          };
          $right: {
            schema: string;
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            where: string | null;
            name: string;
            entityType: "indexes";
          };
        } | {
          $diffType: "alter";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            name: string;
            entityType: "uniques";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            name: string;
            entityType: "uniques";
          };
        } | {
          $diffType: "alter";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
          $right: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
        } | {
          $diffType: "alter";
          entityType: "defaults";
          schema: string;
          table: string;
          name: string;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          column?: {
            from: string;
            to: string;
          } | undefined;
          default?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            column: string;
            nameExplicit: boolean;
            default: string | null;
            name: string;
            entityType: "defaults";
          };
          $right: {
            schema: string;
            table: string;
            column: string;
            nameExplicit: boolean;
            default: string | null;
            name: string;
            entityType: "defaults";
          };
        } | {
          $diffType: "alter";
          entityType: "views";
          schema: string;
          name: string;
          definition?: {
            from: string;
            to: string;
          } | undefined;
          encryption?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          schemaBinding?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          viewMetadata?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          checkOption?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          $left: {
            schema: string;
            definition: string;
            encryption: boolean | null;
            schemaBinding: boolean | null;
            viewMetadata: boolean | null;
            checkOption: boolean | null;
            name: string;
            entityType: "views";
          };
          $right: {
            schema: string;
            definition: string;
            encryption: boolean | null;
            schemaBinding: boolean | null;
            viewMetadata: boolean | null;
            checkOption: boolean | null;
            name: string;
            entityType: "views";
          };
        };
      };
      create: {
        schemas: {
          $diffType: "create";
          entityType: "schemas";
          name: string;
        };
        tables: {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
        };
        columns: {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "persisted" | "virtual";
            as: string;
          } | null;
          identity: {
            increment: number;
            seed: number;
          } | null;
        };
        pks: {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        fks: {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        };
        indexes: {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
        };
        uniques: {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        checks: {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        };
        defaults: {
          $diffType: "create";
          entityType: "defaults";
          schema: string;
          table: string;
          name: string;
          nameExplicit: boolean;
          column: string;
          default: string | null;
        };
        views: {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          definition: string;
          encryption: boolean | null;
          schemaBinding: boolean | null;
          viewMetadata: boolean | null;
          checkOption: boolean | null;
        };
        entities: {
          $diffType: "create";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
        } | {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "persisted" | "virtual";
            as: string;
          } | null;
          identity: {
            increment: number;
            seed: number;
          } | null;
        } | {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        } | {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
        } | {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "create";
          entityType: "defaults";
          schema: string;
          table: string;
          name: string;
          nameExplicit: boolean;
          column: string;
          default: string | null;
        } | {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          definition: string;
          encryption: boolean | null;
          schemaBinding: boolean | null;
          viewMetadata: boolean | null;
          checkOption: boolean | null;
        };
      };
      drop: {
        schemas: {
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        };
        tables: {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
        };
        columns: {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "persisted" | "virtual";
            as: string;
          } | null;
          identity: {
            increment: number;
            seed: number;
          } | null;
        };
        pks: {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        fks: {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        };
        indexes: {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
        };
        uniques: {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        checks: {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        };
        defaults: {
          $diffType: "drop";
          entityType: "defaults";
          schema: string;
          table: string;
          name: string;
          nameExplicit: boolean;
          column: string;
          default: string | null;
        };
        views: {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          definition: string;
          encryption: boolean | null;
          schemaBinding: boolean | null;
          viewMetadata: boolean | null;
          checkOption: boolean | null;
        };
        entities: {
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
        } | {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "persisted" | "virtual";
            as: string;
          } | null;
          identity: {
            increment: number;
            seed: number;
          } | null;
        } | {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        } | {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
        } | {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "defaults";
          schema: string;
          table: string;
          name: string;
          nameExplicit: boolean;
          column: string;
          default: string | null;
        } | {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          definition: string;
          encryption: boolean | null;
          schemaBinding: boolean | null;
          viewMetadata: boolean | null;
          checkOption: boolean | null;
        };
      };
      createdrop: {
        schemas: {
          $diffType: "create";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        };
        tables: {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
        } | {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
        };
        columns: {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "persisted" | "virtual";
            as: string;
          } | null;
          identity: {
            increment: number;
            seed: number;
          } | null;
        } | {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "persisted" | "virtual";
            as: string;
          } | null;
          identity: {
            increment: number;
            seed: number;
          } | null;
        };
        pks: {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        fks: {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        } | {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        };
        indexes: {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
        };
        uniques: {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        checks: {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        };
        defaults: {
          $diffType: "create";
          entityType: "defaults";
          schema: string;
          table: string;
          name: string;
          nameExplicit: boolean;
          column: string;
          default: string | null;
        } | {
          $diffType: "drop";
          entityType: "defaults";
          schema: string;
          table: string;
          name: string;
          nameExplicit: boolean;
          column: string;
          default: string | null;
        };
        views: {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          definition: string;
          encryption: boolean | null;
          schemaBinding: boolean | null;
          viewMetadata: boolean | null;
          checkOption: boolean | null;
        } | {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          definition: string;
          encryption: boolean | null;
          schemaBinding: boolean | null;
          viewMetadata: boolean | null;
          checkOption: boolean | null;
        };
        entities: ({
          $diffType: "create";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
        } | {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "persisted" | "virtual";
            as: string;
          } | null;
          identity: {
            increment: number;
            seed: number;
          } | null;
        } | {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        } | {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
        } | {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "create";
          entityType: "defaults";
          schema: string;
          table: string;
          name: string;
          nameExplicit: boolean;
          column: string;
          default: string | null;
        } | {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          definition: string;
          encryption: boolean | null;
          schemaBinding: boolean | null;
          viewMetadata: boolean | null;
          checkOption: boolean | null;
        }) | ({
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
        } | {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "persisted" | "virtual";
            as: string;
          } | null;
          identity: {
            increment: number;
            seed: number;
          } | null;
        } | {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        } | {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
        } | {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "defaults";
          schema: string;
          table: string;
          name: string;
          nameExplicit: boolean;
          column: string;
          default: string | null;
        } | {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          definition: string;
          encryption: boolean | null;
          schemaBinding: boolean | null;
          viewMetadata: boolean | null;
          checkOption: boolean | null;
        });
      };
      all: {
        schemas: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            notNull: "boolean";
            generated: {
              type: ["persisted", "virtual"];
              as: "string";
            };
            identity: {
              increment: "number";
              seed: "number";
            };
          };
          pks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          fks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
            onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
          };
          indexes: {
            schema: "required";
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          defaults: {
            schema: "required";
            table: "required";
            column: "string";
            nameExplicit: "boolean";
            default: "string?";
          };
          views: {
            schema: "required";
            definition: "string";
            encryption: "boolean?";
            schemaBinding: "boolean?";
            viewMetadata: "boolean?";
            checkOption: "boolean?";
          };
        }, "schemas">;
        tables: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            notNull: "boolean";
            generated: {
              type: ["persisted", "virtual"];
              as: "string";
            };
            identity: {
              increment: "number";
              seed: "number";
            };
          };
          pks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          fks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
            onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
          };
          indexes: {
            schema: "required";
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          defaults: {
            schema: "required";
            table: "required";
            column: "string";
            nameExplicit: "boolean";
            default: "string?";
          };
          views: {
            schema: "required";
            definition: "string";
            encryption: "boolean?";
            schemaBinding: "boolean?";
            viewMetadata: "boolean?";
            checkOption: "boolean?";
          };
        }, "tables">;
        columns: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            notNull: "boolean";
            generated: {
              type: ["persisted", "virtual"];
              as: "string";
            };
            identity: {
              increment: "number";
              seed: "number";
            };
          };
          pks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          fks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
            onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
          };
          indexes: {
            schema: "required";
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          defaults: {
            schema: "required";
            table: "required";
            column: "string";
            nameExplicit: "boolean";
            default: "string?";
          };
          views: {
            schema: "required";
            definition: "string";
            encryption: "boolean?";
            schemaBinding: "boolean?";
            viewMetadata: "boolean?";
            checkOption: "boolean?";
          };
        }, "columns">;
        pks: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            notNull: "boolean";
            generated: {
              type: ["persisted", "virtual"];
              as: "string";
            };
            identity: {
              increment: "number";
              seed: "number";
            };
          };
          pks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          fks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
            onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
          };
          indexes: {
            schema: "required";
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          defaults: {
            schema: "required";
            table: "required";
            column: "string";
            nameExplicit: "boolean";
            default: "string?";
          };
          views: {
            schema: "required";
            definition: "string";
            encryption: "boolean?";
            schemaBinding: "boolean?";
            viewMetadata: "boolean?";
            checkOption: "boolean?";
          };
        }, "pks">;
        fks: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            notNull: "boolean";
            generated: {
              type: ["persisted", "virtual"];
              as: "string";
            };
            identity: {
              increment: "number";
              seed: "number";
            };
          };
          pks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          fks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
            onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
          };
          indexes: {
            schema: "required";
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          defaults: {
            schema: "required";
            table: "required";
            column: "string";
            nameExplicit: "boolean";
            default: "string?";
          };
          views: {
            schema: "required";
            definition: "string";
            encryption: "boolean?";
            schemaBinding: "boolean?";
            viewMetadata: "boolean?";
            checkOption: "boolean?";
          };
        }, "fks">;
        indexes: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            notNull: "boolean";
            generated: {
              type: ["persisted", "virtual"];
              as: "string";
            };
            identity: {
              increment: "number";
              seed: "number";
            };
          };
          pks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          fks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
            onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
          };
          indexes: {
            schema: "required";
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          defaults: {
            schema: "required";
            table: "required";
            column: "string";
            nameExplicit: "boolean";
            default: "string?";
          };
          views: {
            schema: "required";
            definition: "string";
            encryption: "boolean?";
            schemaBinding: "boolean?";
            viewMetadata: "boolean?";
            checkOption: "boolean?";
          };
        }, "indexes">;
        uniques: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            notNull: "boolean";
            generated: {
              type: ["persisted", "virtual"];
              as: "string";
            };
            identity: {
              increment: "number";
              seed: "number";
            };
          };
          pks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          fks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
            onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
          };
          indexes: {
            schema: "required";
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          defaults: {
            schema: "required";
            table: "required";
            column: "string";
            nameExplicit: "boolean";
            default: "string?";
          };
          views: {
            schema: "required";
            definition: "string";
            encryption: "boolean?";
            schemaBinding: "boolean?";
            viewMetadata: "boolean?";
            checkOption: "boolean?";
          };
        }, "uniques">;
        checks: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            notNull: "boolean";
            generated: {
              type: ["persisted", "virtual"];
              as: "string";
            };
            identity: {
              increment: "number";
              seed: "number";
            };
          };
          pks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          fks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
            onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
          };
          indexes: {
            schema: "required";
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          defaults: {
            schema: "required";
            table: "required";
            column: "string";
            nameExplicit: "boolean";
            default: "string?";
          };
          views: {
            schema: "required";
            definition: "string";
            encryption: "boolean?";
            schemaBinding: "boolean?";
            viewMetadata: "boolean?";
            checkOption: "boolean?";
          };
        }, "checks">;
        defaults: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            notNull: "boolean";
            generated: {
              type: ["persisted", "virtual"];
              as: "string";
            };
            identity: {
              increment: "number";
              seed: "number";
            };
          };
          pks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          fks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
            onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
          };
          indexes: {
            schema: "required";
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          defaults: {
            schema: "required";
            table: "required";
            column: "string";
            nameExplicit: "boolean";
            default: "string?";
          };
          views: {
            schema: "required";
            definition: "string";
            encryption: "boolean?";
            schemaBinding: "boolean?";
            viewMetadata: "boolean?";
            checkOption: "boolean?";
          };
        }, "defaults">;
        views: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            notNull: "boolean";
            generated: {
              type: ["persisted", "virtual"];
              as: "string";
            };
            identity: {
              increment: "number";
              seed: "number";
            };
          };
          pks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          fks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
            onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
          };
          indexes: {
            schema: "required";
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          defaults: {
            schema: "required";
            table: "required";
            column: "string";
            nameExplicit: "boolean";
            default: "string?";
          };
          views: {
            schema: "required";
            definition: "string";
            encryption: "boolean?";
            schemaBinding: "boolean?";
            viewMetadata: "boolean?";
            checkOption: "boolean?";
          };
        }, "views">;
        entities: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            notNull: "boolean";
            generated: {
              type: ["persisted", "virtual"];
              as: "string";
            };
            identity: {
              increment: "number";
              seed: "number";
            };
          };
          pks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          fks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
            onDelete: ["NO ACTION", "CASCADE", "SET NULL", "SET DEFAULT"];
          };
          indexes: {
            schema: "required";
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          defaults: {
            schema: "required";
            table: "required";
            column: "string";
            nameExplicit: "boolean";
            default: "string?";
          };
          views: {
            schema: "required";
            definition: "string";
            encryption: "boolean?";
            schemaBinding: "boolean?";
            viewMetadata: "boolean?";
            checkOption: "boolean?";
          };
        }, "entities">;
      };
    };
    store: {
      collection: Record<string, any>[];
    };
  };
  entities: {
    push: (input: {
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      name: string;
      entityType: "tables";
    } | {
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null | undefined;
      identity: {
        increment: number;
        seed: number;
      } | null | undefined;
      schema: string;
      table: string;
      type: string;
      notNull: boolean;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      name: string;
      entityType: "fks";
    } | {
      where: string | null | undefined;
      schema: string;
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      default: string | null | undefined;
      schema: string;
      table: string;
      column: string;
      nameExplicit: boolean;
      name: string;
      entityType: "defaults";
    } | {
      encryption: boolean | null | undefined;
      schemaBinding: boolean | null | undefined;
      viewMetadata: boolean | null | undefined;
      checkOption: boolean | null | undefined;
      schema: string;
      definition: string;
      name: string;
      entityType: "views";
    }, uniques?: "name"[] | ("schema" | "table" | "name" | "columns" | "nameExplicit")[] | ("schema" | "table" | "name" | "columns" | "nameExplicit" | "schemaTo" | "tableTo" | "columnsTo" | "onUpdate" | "onDelete")[] | ("schema" | "table" | "name" | "value")[] | ("schema" | "name")[] | ("schema" | "table" | "name" | "type" | "notNull" | "generated" | "identity")[] | ("schema" | "table" | "name" | "columns" | "isUnique" | "where")[] | ("schema" | "table" | "name" | "nameExplicit" | "column" | "default")[] | ("schema" | "name" | "definition" | "encryption" | "schemaBinding" | "viewMetadata" | "checkOption")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "schemas";
      } | {
        schema: string;
        name: string;
        entityType: "tables";
      } | {
        schema: string;
        table: string;
        type: string;
        notNull: boolean;
        generated: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        identity: {
          increment: number;
          seed: number;
        } | null;
        name: string;
        entityType: "columns";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "pks";
      } | {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        name: string;
        entityType: "fks";
      } | {
        schema: string;
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        name: string;
        entityType: "indexes";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "uniques";
      } | {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      } | {
        schema: string;
        table: string;
        column: string;
        nameExplicit: boolean;
        default: string | null;
        name: string;
        entityType: "defaults";
      } | {
        schema: string;
        definition: string;
        encryption: boolean | null;
        schemaBinding: boolean | null;
        viewMetadata: boolean | null;
        checkOption: boolean | null;
        name: string;
        entityType: "views";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: ({
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | {
      schema?: string | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      generated?: {
        type: "persisted" | "virtual";
        as: string;
      } | null | undefined;
      identity?: {
        increment: number;
        seed: number;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      column?: string | undefined;
      nameExplicit?: boolean | undefined;
      default?: string | null | undefined;
      name?: string | undefined;
      entityType?: "defaults" | undefined;
    } | {
      schema?: string | undefined;
      definition?: string | undefined;
      encryption?: boolean | null | undefined;
      schemaBinding?: boolean | null | undefined;
      viewMetadata?: boolean | null | undefined;
      checkOption?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    }) | undefined) => ({
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      table: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null;
      identity: {
        increment: number;
        seed: number;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      table: string;
      column: string;
      nameExplicit: boolean;
      default: string | null;
      name: string;
      entityType: "defaults";
    } | {
      schema: string;
      definition: string;
      encryption: boolean | null;
      schemaBinding: boolean | null;
      viewMetadata: boolean | null;
      checkOption: boolean | null;
      name: string;
      entityType: "views";
    })[];
    one: (where?: ({
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | {
      schema?: string | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      generated?: {
        type: "persisted" | "virtual";
        as: string;
      } | null | undefined;
      identity?: {
        increment: number;
        seed: number;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      column?: string | undefined;
      nameExplicit?: boolean | undefined;
      default?: string | null | undefined;
      name?: string | undefined;
      entityType?: "defaults" | undefined;
    } | {
      schema?: string | undefined;
      definition?: string | undefined;
      encryption?: boolean | null | undefined;
      schemaBinding?: boolean | null | undefined;
      viewMetadata?: boolean | null | undefined;
      checkOption?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    }) | undefined) => {
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      table: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null;
      identity: {
        increment: number;
        seed: number;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      table: string;
      column: string;
      nameExplicit: boolean;
      default: string | null;
      name: string;
      entityType: "defaults";
    } | {
      schema: string;
      definition: string;
      encryption: boolean | null;
      schemaBinding: boolean | null;
      viewMetadata: boolean | null;
      checkOption: boolean | null;
      name: string;
      entityType: "views";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        name?: string | undefined;
        entityType?: "schemas" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        name?: string | undefined;
        entityType?: "tables" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: string | ((item: string) => string) | undefined;
        notNull?: boolean | ((item: boolean) => boolean) | undefined;
        generated?: {
          type: "persisted" | "virtual";
          as: string;
        } | ((item: {
          type: "persisted" | "virtual";
          as: string;
        } | null) => {
          type: "persisted" | "virtual";
          as: string;
        } | null) | null | undefined;
        identity?: {
          increment: number;
          seed: number;
        } | ((item: {
          increment: number;
          seed: number;
        } | null) => {
          increment: number;
          seed: number;
        } | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        type?: string | undefined;
        notNull?: boolean | undefined;
        generated?: {
          type: "persisted" | "virtual";
          as: string;
        } | null | undefined;
        identity?: {
          increment: number;
          seed: number;
        } | null | undefined;
        name?: string | undefined;
        entityType?: "columns" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        name?: string | undefined;
        entityType?: "pks" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        schemaTo?: string | ((item: string) => string) | undefined;
        tableTo?: string | ((item: string) => string) | undefined;
        columnsTo?: string[] | ((item: string) => string) | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT") => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT") | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT") => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT") | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nameExplicit?: boolean | undefined;
        schemaTo?: string | undefined;
        tableTo?: string | undefined;
        columnsTo?: string[] | {
          CONTAINS: string;
        } | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
        name?: string | undefined;
        entityType?: "fks" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | ((item: {
          value: string;
          isExpression: boolean;
        }) => {
          value: string;
          isExpression: boolean;
        }) | undefined;
        isUnique?: boolean | ((item: boolean) => boolean) | undefined;
        where?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | {
          CONTAINS: {
            value: string;
            isExpression: boolean;
          };
        } | undefined;
        isUnique?: boolean | undefined;
        where?: string | null | undefined;
        name?: string | undefined;
        entityType?: "indexes" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        name?: string | undefined;
        entityType?: "uniques" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        value?: string | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        value?: string | undefined;
        name?: string | undefined;
        entityType?: "checks" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        column?: string | ((item: string) => string) | undefined;
        default?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        column?: string | undefined;
        nameExplicit?: boolean | undefined;
        default?: string | null | undefined;
        name?: string | undefined;
        entityType?: "defaults" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        definition?: string | ((item: string) => string) | undefined;
        encryption?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        schemaBinding?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        viewMetadata?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        checkOption?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        definition?: string | undefined;
        encryption?: boolean | null | undefined;
        schemaBinding?: boolean | null | undefined;
        viewMetadata?: boolean | null | undefined;
        checkOption?: boolean | null | undefined;
        name?: string | undefined;
        entityType?: "views" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: ({
        name: string;
        entityType: "schemas";
      } | {
        schema: string;
        name: string;
        entityType: "tables";
      } | {
        schema: string;
        table: string;
        type: string;
        notNull: boolean;
        generated: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        identity: {
          increment: number;
          seed: number;
        } | null;
        name: string;
        entityType: "columns";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "pks";
      } | {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        name: string;
        entityType: "fks";
      } | {
        schema: string;
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        name: string;
        entityType: "indexes";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "uniques";
      } | {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      } | {
        schema: string;
        table: string;
        column: string;
        nameExplicit: boolean;
        default: string | null;
        name: string;
        entityType: "defaults";
      } | {
        schema: string;
        definition: string;
        encryption: boolean | null;
        schemaBinding: boolean | null;
        viewMetadata: boolean | null;
        checkOption: boolean | null;
        name: string;
        entityType: "views";
      })[];
    };
    delete: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | {
      schema?: string | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      generated?: {
        type: "persisted" | "virtual";
        as: string;
      } | null | undefined;
      identity?: {
        increment: number;
        seed: number;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      column?: string | undefined;
      nameExplicit?: boolean | undefined;
      default?: string | null | undefined;
      name?: string | undefined;
      entityType?: "defaults" | undefined;
    } | {
      schema?: string | undefined;
      definition?: string | undefined;
      encryption?: boolean | null | undefined;
      schemaBinding?: boolean | null | undefined;
      viewMetadata?: boolean | null | undefined;
      checkOption?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => ({
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      table: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null;
      identity: {
        increment: number;
        seed: number;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      table: string;
      column: string;
      nameExplicit: boolean;
      default: string | null;
      name: string;
      entityType: "defaults";
    } | {
      schema: string;
      definition: string;
      encryption: boolean | null;
      schemaBinding: boolean | null;
      viewMetadata: boolean | null;
      checkOption: boolean | null;
      name: string;
      entityType: "views";
    })[];
    validate: (data: unknown) => data is {
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      table: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null;
      identity: {
        increment: number;
        seed: number;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      table: string;
      column: string;
      nameExplicit: boolean;
      default: string | null;
      name: string;
      entityType: "defaults";
    } | {
      schema: string;
      definition: string;
      encryption: boolean | null;
      schemaBinding: boolean | null;
      viewMetadata: boolean | null;
      checkOption: boolean | null;
      name: string;
      entityType: "views";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "schemas";
      name: string;
      $left: {
        name: string;
        entityType: "schemas";
      };
      $right: {
        name: string;
        entityType: "schemas";
      };
    } | {
      $diffType: "alter";
      entityType: "tables";
      schema: string;
      name: string;
      $left: {
        schema: string;
        name: string;
        entityType: "tables";
      };
      $right: {
        schema: string;
        name: string;
        entityType: "tables";
      };
    } | {
      $diffType: "alter";
      entityType: "columns";
      schema: string;
      table: string;
      name: string;
      type?: {
        from: string;
        to: string;
      } | undefined;
      notNull?: {
        from: boolean;
        to: boolean;
      } | undefined;
      generated?: {
        from: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        to: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
      } | undefined;
      identity?: {
        from: {
          increment: number;
          seed: number;
        } | null;
        to: {
          increment: number;
          seed: number;
        } | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        type: string;
        notNull: boolean;
        generated: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        identity: {
          increment: number;
          seed: number;
        } | null;
        name: string;
        entityType: "columns";
      };
      $right: {
        schema: string;
        table: string;
        type: string;
        notNull: boolean;
        generated: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        identity: {
          increment: number;
          seed: number;
        } | null;
        name: string;
        entityType: "columns";
      };
    } | {
      $diffType: "alter";
      entityType: "pks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "pks";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "pks";
      };
    } | {
      $diffType: "alter";
      entityType: "fks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      schemaTo?: {
        from: string;
        to: string;
      } | undefined;
      tableTo?: {
        from: string;
        to: string;
      } | undefined;
      columnsTo?: {
        from: string[];
        to: string[];
      } | undefined;
      onUpdate?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      } | undefined;
      onDelete?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      } | undefined;
      $left: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        name: string;
        entityType: "fks";
      };
      $right: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        name: string;
        entityType: "fks";
      };
    } | {
      $diffType: "alter";
      entityType: "indexes";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: {
          value: string;
          isExpression: boolean;
        }[];
        to: {
          value: string;
          isExpression: boolean;
        }[];
      } | undefined;
      isUnique?: {
        from: boolean;
        to: boolean;
      } | undefined;
      where?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        name: string;
        entityType: "indexes";
      };
      $right: {
        schema: string;
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        name: string;
        entityType: "indexes";
      };
    } | {
      $diffType: "alter";
      entityType: "uniques";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "uniques";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "uniques";
      };
    } | {
      $diffType: "alter";
      entityType: "checks";
      schema: string;
      table: string;
      name: string;
      value?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      $right: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    } | {
      $diffType: "alter";
      entityType: "defaults";
      schema: string;
      table: string;
      name: string;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      column?: {
        from: string;
        to: string;
      } | undefined;
      default?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        column: string;
        nameExplicit: boolean;
        default: string | null;
        name: string;
        entityType: "defaults";
      };
      $right: {
        schema: string;
        table: string;
        column: string;
        nameExplicit: boolean;
        default: string | null;
        name: string;
        entityType: "defaults";
      };
    } | {
      $diffType: "alter";
      entityType: "views";
      schema: string;
      name: string;
      definition?: {
        from: string;
        to: string;
      } | undefined;
      encryption?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      schemaBinding?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      viewMetadata?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      checkOption?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      $left: {
        schema: string;
        definition: string;
        encryption: boolean | null;
        schemaBinding: boolean | null;
        viewMetadata: boolean | null;
        checkOption: boolean | null;
        name: string;
        entityType: "views";
      };
      $right: {
        schema: string;
        definition: string;
        encryption: boolean | null;
        schemaBinding: boolean | null;
        viewMetadata: boolean | null;
        checkOption: boolean | null;
        name: string;
        entityType: "views";
      };
    }) => boolean;
  };
  schemas: {
    push: (input: {
      name: string;
    }, uniques?: "name"[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "schemas";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | undefined) => {
      name: string;
      entityType: "schemas";
    }[];
    one: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | undefined) => {
      name: string;
      entityType: "schemas";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        name?: string | undefined;
        entityType?: "schemas" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "schemas";
      }[];
    };
    delete: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | undefined) => {
      name: string;
      entityType: "schemas";
    }[];
    validate: (data: unknown) => data is {
      name: string;
      entityType: "schemas";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "schemas";
      name: string;
      $left: {
        name: string;
        entityType: "schemas";
      };
      $right: {
        name: string;
        entityType: "schemas";
      };
    }) => boolean;
  };
  tables: {
    push: (input: {
      schema: string;
      name: string;
    }, uniques?: ("schema" | "name")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        name: string;
        entityType: "tables";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      schema: string;
      name: string;
      entityType: "tables";
    }[];
    one: (where?: {
      schema?: string | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      schema: string;
      name: string;
      entityType: "tables";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        name?: string | undefined;
        entityType?: "tables" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        name: string;
        entityType: "tables";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      schema: string;
      name: string;
      entityType: "tables";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      name: string;
      entityType: "tables";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "tables";
      schema: string;
      name: string;
      $left: {
        schema: string;
        name: string;
        entityType: "tables";
      };
      $right: {
        schema: string;
        name: string;
        entityType: "tables";
      };
    }) => boolean;
  };
  columns: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null | undefined;
      identity: {
        increment: number;
        seed: number;
      } | null | undefined;
    }, uniques?: ("schema" | "table" | "name" | "type" | "notNull" | "generated" | "identity")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        type: string;
        notNull: boolean;
        generated: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        identity: {
          increment: number;
          seed: number;
        } | null;
        name: string;
        entityType: "columns";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      generated?: {
        type: "persisted" | "virtual";
        as: string;
      } | null | undefined;
      identity?: {
        increment: number;
        seed: number;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null;
      identity: {
        increment: number;
        seed: number;
      } | null;
      name: string;
      entityType: "columns";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      generated?: {
        type: "persisted" | "virtual";
        as: string;
      } | null | undefined;
      identity?: {
        increment: number;
        seed: number;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null;
      identity: {
        increment: number;
        seed: number;
      } | null;
      name: string;
      entityType: "columns";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: string | ((item: string) => string) | undefined;
        notNull?: boolean | ((item: boolean) => boolean) | undefined;
        generated?: {
          type: "persisted" | "virtual";
          as: string;
        } | ((item: {
          type: "persisted" | "virtual";
          as: string;
        } | null) => {
          type: "persisted" | "virtual";
          as: string;
        } | null) | null | undefined;
        identity?: {
          increment: number;
          seed: number;
        } | ((item: {
          increment: number;
          seed: number;
        } | null) => {
          increment: number;
          seed: number;
        } | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        type?: string | undefined;
        notNull?: boolean | undefined;
        generated?: {
          type: "persisted" | "virtual";
          as: string;
        } | null | undefined;
        identity?: {
          increment: number;
          seed: number;
        } | null | undefined;
        name?: string | undefined;
        entityType?: "columns" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        type: string;
        notNull: boolean;
        generated: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        identity: {
          increment: number;
          seed: number;
        } | null;
        name: string;
        entityType: "columns";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      generated?: {
        type: "persisted" | "virtual";
        as: string;
      } | null | undefined;
      identity?: {
        increment: number;
        seed: number;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null;
      identity: {
        increment: number;
        seed: number;
      } | null;
      name: string;
      entityType: "columns";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "persisted" | "virtual";
        as: string;
      } | null;
      identity: {
        increment: number;
        seed: number;
      } | null;
      name: string;
      entityType: "columns";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "columns";
      schema: string;
      table: string;
      name: string;
      type?: {
        from: string;
        to: string;
      } | undefined;
      notNull?: {
        from: boolean;
        to: boolean;
      } | undefined;
      generated?: {
        from: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        to: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
      } | undefined;
      identity?: {
        from: {
          increment: number;
          seed: number;
        } | null;
        to: {
          increment: number;
          seed: number;
        } | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        type: string;
        notNull: boolean;
        generated: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        identity: {
          increment: number;
          seed: number;
        } | null;
        name: string;
        entityType: "columns";
      };
      $right: {
        schema: string;
        table: string;
        type: string;
        notNull: boolean;
        generated: {
          type: "persisted" | "virtual";
          as: string;
        } | null;
        identity: {
          increment: number;
          seed: number;
        } | null;
        name: string;
        entityType: "columns";
      };
    }) => boolean;
  };
  pks: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
    }, uniques?: ("schema" | "table" | "name" | "columns" | "nameExplicit")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "pks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "pks";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "pks";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        name?: string | undefined;
        entityType?: "pks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "pks";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "pks";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "pks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "pks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "pks";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "pks";
      };
    }) => boolean;
  };
  fks: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
    }, uniques?: ("schema" | "table" | "name" | "columns" | "nameExplicit" | "schemaTo" | "tableTo" | "columnsTo" | "onUpdate" | "onDelete")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        name: string;
        entityType: "fks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      name: string;
      entityType: "fks";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      name: string;
      entityType: "fks";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        schemaTo?: string | ((item: string) => string) | undefined;
        tableTo?: string | ((item: string) => string) | undefined;
        columnsTo?: string[] | ((item: string) => string) | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT") => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT") | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT") => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT") | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nameExplicit?: boolean | undefined;
        schemaTo?: string | undefined;
        tableTo?: string | undefined;
        columnsTo?: string[] | {
          CONTAINS: string;
        } | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
        name?: string | undefined;
        entityType?: "fks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        name: string;
        entityType: "fks";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      name: string;
      entityType: "fks";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      name: string;
      entityType: "fks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "fks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      schemaTo?: {
        from: string;
        to: string;
      } | undefined;
      tableTo?: {
        from: string;
        to: string;
      } | undefined;
      columnsTo?: {
        from: string[];
        to: string[];
      } | undefined;
      onUpdate?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      } | undefined;
      onDelete?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
      } | undefined;
      $left: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        name: string;
        entityType: "fks";
      };
      $right: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT";
        name: string;
        entityType: "fks";
      };
    }) => boolean;
  };
  indexes: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null | undefined;
    }, uniques?: ("schema" | "table" | "name" | "columns" | "isUnique" | "where")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        name: string;
        entityType: "indexes";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      name: string;
      entityType: "indexes";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      name: string;
      entityType: "indexes";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | ((item: {
          value: string;
          isExpression: boolean;
        }) => {
          value: string;
          isExpression: boolean;
        }) | undefined;
        isUnique?: boolean | ((item: boolean) => boolean) | undefined;
        where?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | {
          CONTAINS: {
            value: string;
            isExpression: boolean;
          };
        } | undefined;
        isUnique?: boolean | undefined;
        where?: string | null | undefined;
        name?: string | undefined;
        entityType?: "indexes" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        name: string;
        entityType: "indexes";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      name: string;
      entityType: "indexes";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      name: string;
      entityType: "indexes";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "indexes";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: {
          value: string;
          isExpression: boolean;
        }[];
        to: {
          value: string;
          isExpression: boolean;
        }[];
      } | undefined;
      isUnique?: {
        from: boolean;
        to: boolean;
      } | undefined;
      where?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        name: string;
        entityType: "indexes";
      };
      $right: {
        schema: string;
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        name: string;
        entityType: "indexes";
      };
    }) => boolean;
  };
  uniques: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
    }, uniques?: ("schema" | "table" | "name" | "columns" | "nameExplicit")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "uniques";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "uniques";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "uniques";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        name?: string | undefined;
        entityType?: "uniques" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "uniques";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "uniques";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      name: string;
      entityType: "uniques";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "uniques";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "uniques";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        name: string;
        entityType: "uniques";
      };
    }) => boolean;
  };
  checks: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      value: string;
    }, uniques?: ("schema" | "table" | "name" | "value")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        value?: string | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        value?: string | undefined;
        name?: string | undefined;
        entityType?: "checks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "checks";
      schema: string;
      table: string;
      name: string;
      value?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      $right: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    }) => boolean;
  };
  defaults: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      nameExplicit: boolean;
      column: string;
      default: string | null | undefined;
    }, uniques?: ("schema" | "table" | "name" | "nameExplicit" | "column" | "default")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        column: string;
        nameExplicit: boolean;
        default: string | null;
        name: string;
        entityType: "defaults";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      column?: string | undefined;
      nameExplicit?: boolean | undefined;
      default?: string | null | undefined;
      name?: string | undefined;
      entityType?: "defaults" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      column: string;
      nameExplicit: boolean;
      default: string | null;
      name: string;
      entityType: "defaults";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      column?: string | undefined;
      nameExplicit?: boolean | undefined;
      default?: string | null | undefined;
      name?: string | undefined;
      entityType?: "defaults" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      column: string;
      nameExplicit: boolean;
      default: string | null;
      name: string;
      entityType: "defaults";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        column?: string | ((item: string) => string) | undefined;
        default?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        column?: string | undefined;
        nameExplicit?: boolean | undefined;
        default?: string | null | undefined;
        name?: string | undefined;
        entityType?: "defaults" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        column: string;
        nameExplicit: boolean;
        default: string | null;
        name: string;
        entityType: "defaults";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      column?: string | undefined;
      nameExplicit?: boolean | undefined;
      default?: string | null | undefined;
      name?: string | undefined;
      entityType?: "defaults" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      column: string;
      nameExplicit: boolean;
      default: string | null;
      name: string;
      entityType: "defaults";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      column: string;
      nameExplicit: boolean;
      default: string | null;
      name: string;
      entityType: "defaults";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "defaults";
      schema: string;
      table: string;
      name: string;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      column?: {
        from: string;
        to: string;
      } | undefined;
      default?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        column: string;
        nameExplicit: boolean;
        default: string | null;
        name: string;
        entityType: "defaults";
      };
      $right: {
        schema: string;
        table: string;
        column: string;
        nameExplicit: boolean;
        default: string | null;
        name: string;
        entityType: "defaults";
      };
    }) => boolean;
  };
  views: {
    push: (input: {
      schema: string;
      name: string;
      definition: string;
      encryption: boolean | null | undefined;
      schemaBinding: boolean | null | undefined;
      viewMetadata: boolean | null | undefined;
      checkOption: boolean | null | undefined;
    }, uniques?: ("schema" | "name" | "definition" | "encryption" | "schemaBinding" | "viewMetadata" | "checkOption")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        definition: string;
        encryption: boolean | null;
        schemaBinding: boolean | null;
        viewMetadata: boolean | null;
        checkOption: boolean | null;
        name: string;
        entityType: "views";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      definition?: string | undefined;
      encryption?: boolean | null | undefined;
      schemaBinding?: boolean | null | undefined;
      viewMetadata?: boolean | null | undefined;
      checkOption?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      schema: string;
      definition: string;
      encryption: boolean | null;
      schemaBinding: boolean | null;
      viewMetadata: boolean | null;
      checkOption: boolean | null;
      name: string;
      entityType: "views";
    }[];
    one: (where?: {
      schema?: string | undefined;
      definition?: string | undefined;
      encryption?: boolean | null | undefined;
      schemaBinding?: boolean | null | undefined;
      viewMetadata?: boolean | null | undefined;
      checkOption?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      schema: string;
      definition: string;
      encryption: boolean | null;
      schemaBinding: boolean | null;
      viewMetadata: boolean | null;
      checkOption: boolean | null;
      name: string;
      entityType: "views";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        definition?: string | ((item: string) => string) | undefined;
        encryption?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        schemaBinding?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        viewMetadata?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        checkOption?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        definition?: string | undefined;
        encryption?: boolean | null | undefined;
        schemaBinding?: boolean | null | undefined;
        viewMetadata?: boolean | null | undefined;
        checkOption?: boolean | null | undefined;
        name?: string | undefined;
        entityType?: "views" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        definition: string;
        encryption: boolean | null;
        schemaBinding: boolean | null;
        viewMetadata: boolean | null;
        checkOption: boolean | null;
        name: string;
        entityType: "views";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      definition?: string | undefined;
      encryption?: boolean | null | undefined;
      schemaBinding?: boolean | null | undefined;
      viewMetadata?: boolean | null | undefined;
      checkOption?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      schema: string;
      definition: string;
      encryption: boolean | null;
      schemaBinding: boolean | null;
      viewMetadata: boolean | null;
      checkOption: boolean | null;
      name: string;
      entityType: "views";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      definition: string;
      encryption: boolean | null;
      schemaBinding: boolean | null;
      viewMetadata: boolean | null;
      checkOption: boolean | null;
      name: string;
      entityType: "views";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "views";
      schema: string;
      name: string;
      definition?: {
        from: string;
        to: string;
      } | undefined;
      encryption?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      schemaBinding?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      viewMetadata?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      checkOption?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      $left: {
        schema: string;
        definition: string;
        encryption: boolean | null;
        schemaBinding: boolean | null;
        viewMetadata: boolean | null;
        checkOption: boolean | null;
        name: string;
        entityType: "views";
      };
      $right: {
        schema: string;
        definition: string;
        encryption: boolean | null;
        schemaBinding: boolean | null;
        viewMetadata: boolean | null;
        checkOption: boolean | null;
        name: string;
        entityType: "views";
      };
    }) => boolean;
  };
};
type MssqlDDL = ReturnType<typeof createDDL>;
type MssqlEntities = MssqlDDL['_']['types'];
type MssqlEntity = MssqlEntities[keyof MssqlEntities];
//#endregion
//#region src/dialects/mssql/snapshot.d.ts
declare const snapshotValidator: {
  shape: {
    version: "2";
    dialect: "mssql";
    id: string;
    prevIds: string[];
    ddl: MssqlEntity[];
    renames: string[];
  };
  parse: (obj: unknown) => {
    success: boolean;
    data: {
      version: "2";
      dialect: "mssql";
      id: string;
      prevIds: string[];
      ddl: MssqlEntity[];
      renames: string[];
    } | null;
    errors?: string[] | undefined;
  };
  strict: (obj: unknown) => {
    version: "2";
    dialect: "mssql";
    id: string;
    prevIds: string[];
    ddl: MssqlEntity[];
    renames: string[];
  };
};
type MssqlSnapshot = typeof snapshotValidator.shape;
//#endregion
//#region src/dialects/mssql/versions.d.ts
declare const upToV2: (it: Record<string, any>) => {
  snapshot: MssqlSnapshot;
  hints: string[];
};
//#endregion
//#region src/payload/mssql.d.ts
declare const generateDrizzleJson: (imports: Record<string, unknown>, prevId?: string, schemaFilters?: string[]) => Promise<MssqlSnapshot>;
declare const generateMigration: (prev: MssqlSnapshot, cur: MssqlSnapshot, options?: {
  hints?: Hint[];
}) => Promise<string[]>;
declare const pushSchema: (imports: Record<string, unknown>, drizzleInstance: MsSqlDatabase<any, any>, entitiesConfig?: EntitiesFilterConfig, migrationsConfig?: {
  table?: string;
  schema?: string;
}) => Promise<{
  sqlStatements: string[];
  hints: {
    hint: string;
    statement?: string;
  }[];
  apply: () => Promise<void>;
}>;
declare const startStudioServer: (_imports: Record<string, unknown>, _credentials: MssqlCredentials, _options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<never>;
//#endregion
export { type Hint, type MissingHint, type MissingHintsError, generateDrizzleJson, generateMigration, pushSchema, startStudioServer, upToV2 as up };