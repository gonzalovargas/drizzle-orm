import { t as MysqlCredentials } from "./mysql-BMCPSAUS.mjs";
import { i as DiffStatement, n as MissingHint, r as Config, t as Hint } from "./hints-By83v2-O.mjs";
import { t as MissingHintsError } from "./errors-5EF0YvX8.mjs";
import { t as DB } from "./index-D5xy3jz2.mjs";

//#region src/dialects/mysql/ddl.d.ts
declare const createDDL: () => {
  readonly _: {
    types: {
      tables: {
        name: string;
        entityType: "tables";
      };
      columns: {
        table: string;
        type: string;
        notNull: boolean;
        autoIncrement: boolean;
        default: string | null;
        onUpdateNow: boolean;
        onUpdateNowFsp: number | null;
        charSet: string | null;
        collation: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
      pks: {
        table: string;
        columns: string[];
        name: string;
        entityType: "pks";
      };
      fks: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
      indexes: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        using: "btree" | "hash" | null;
        algorithm: "default" | "inplace" | "copy" | null;
        lock: "default" | "none" | "shared" | "exclusive" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "indexes";
      };
      checks: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      views: {
        definition: string;
        algorithm: "undefined" | "merge" | "temptable";
        sqlSecurity: "definer" | "invoker";
        withCheckOption: "local" | "cascaded" | null;
        name: string;
        entityType: "views";
      };
    };
    definition: {
      tables: {};
      columns: {
        table: "required";
        type: "string";
        notNull: "boolean";
        autoIncrement: "boolean";
        default: "string?";
        onUpdateNow: "boolean";
        onUpdateNowFsp: "number?";
        charSet: "string?";
        collation: "string?";
        generated: {
          type: ["stored", "virtual"];
          as: "string";
        };
      };
      pks: {
        table: "required";
        columns: "string[]";
      };
      fks: {
        table: "required";
        columns: "string[]";
        tableTo: "string";
        columnsTo: "string[]";
        onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
        onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
        nameExplicit: "boolean";
      };
      indexes: {
        table: "required";
        columns: [{
          value: "string";
          isExpression: "boolean";
        }];
        isUnique: "boolean";
        using: ["btree", "hash", null];
        algorithm: ["default", "inplace", "copy", null];
        lock: ["default", "none", "shared", "exclusive", null];
        nameExplicit: "boolean";
      };
      checks: {
        table: "required";
        value: "string";
      };
      views: {
        definition: "string";
        algorithm: ["undefined", "merge", "temptable"];
        sqlSecurity: ["definer", "invoker"];
        withCheckOption: ["local", "cascaded", null];
      };
    };
    entities: {
      tables: Config;
      columns: Config;
      pks: Config;
      fks: Config;
      indexes: Config;
      checks: Config;
      views: Config;
    };
    diffs: {
      alter: {
        tables: {
          $diffType: "alter";
          entityType: "tables";
          name: string;
          $left: {
            name: string;
            entityType: "tables";
          };
          $right: {
            name: string;
            entityType: "tables";
          };
        };
        columns: {
          $diffType: "alter";
          entityType: "columns";
          table: string;
          name: string;
          type?: {
            from: string;
            to: string;
          } | undefined;
          notNull?: {
            from: boolean;
            to: boolean;
          } | undefined;
          generated?: {
            from: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            to: {
              type: "virtual" | "stored";
              as: string;
            } | null;
          } | undefined;
          default?: {
            from: string | null;
            to: string | null;
          } | undefined;
          autoIncrement?: {
            from: boolean;
            to: boolean;
          } | undefined;
          onUpdateNow?: {
            from: boolean;
            to: boolean;
          } | undefined;
          onUpdateNowFsp?: {
            from: number | null;
            to: number | null;
          } | undefined;
          charSet?: {
            from: string | null;
            to: string | null;
          } | undefined;
          collation?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            table: string;
            type: string;
            notNull: boolean;
            autoIncrement: boolean;
            default: string | null;
            onUpdateNow: boolean;
            onUpdateNowFsp: number | null;
            charSet: string | null;
            collation: string | null;
            generated: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            name: string;
            entityType: "columns";
          };
          $right: {
            table: string;
            type: string;
            notNull: boolean;
            autoIncrement: boolean;
            default: string | null;
            onUpdateNow: boolean;
            onUpdateNowFsp: number | null;
            charSet: string | null;
            collation: string | null;
            generated: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            name: string;
            entityType: "columns";
          };
        };
        pks: {
          $diffType: "alter";
          entityType: "pks";
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          $left: {
            table: string;
            columns: string[];
            name: string;
            entityType: "pks";
          };
          $right: {
            table: string;
            columns: string[];
            name: string;
            entityType: "pks";
          };
        };
        fks: {
          $diffType: "alter";
          entityType: "fks";
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          tableTo?: {
            from: string;
            to: string;
          } | undefined;
          columnsTo?: {
            from: string[];
            to: string[];
          } | undefined;
          onUpdate?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          } | undefined;
          onDelete?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          } | undefined;
          $left: {
            table: string;
            columns: string[];
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            nameExplicit: boolean;
            name: string;
            entityType: "fks";
          };
          $right: {
            table: string;
            columns: string[];
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            nameExplicit: boolean;
            name: string;
            entityType: "fks";
          };
        };
        indexes: {
          $diffType: "alter";
          entityType: "indexes";
          table: string;
          name: string;
          columns?: {
            from: {
              value: string;
              isExpression: boolean;
            }[];
            to: {
              value: string;
              isExpression: boolean;
            }[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          isUnique?: {
            from: boolean;
            to: boolean;
          } | undefined;
          using?: {
            from: "btree" | "hash" | null;
            to: "btree" | "hash" | null;
          } | undefined;
          algorithm?: {
            from: "default" | "inplace" | "copy" | null;
            to: "default" | "inplace" | "copy" | null;
          } | undefined;
          lock?: {
            from: "default" | "none" | "shared" | "exclusive" | null;
            to: "default" | "none" | "shared" | "exclusive" | null;
          } | undefined;
          $left: {
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            using: "btree" | "hash" | null;
            algorithm: "default" | "inplace" | "copy" | null;
            lock: "default" | "none" | "shared" | "exclusive" | null;
            nameExplicit: boolean;
            name: string;
            entityType: "indexes";
          };
          $right: {
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            using: "btree" | "hash" | null;
            algorithm: "default" | "inplace" | "copy" | null;
            lock: "default" | "none" | "shared" | "exclusive" | null;
            nameExplicit: boolean;
            name: string;
            entityType: "indexes";
          };
        };
        checks: {
          $diffType: "alter";
          entityType: "checks";
          table: string;
          name: string;
          value?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
          $right: {
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
        };
        views: {
          $diffType: "alter";
          entityType: "views";
          name: string;
          definition?: {
            from: string;
            to: string;
          } | undefined;
          algorithm?: {
            from: "undefined" | "merge" | "temptable";
            to: "undefined" | "merge" | "temptable";
          } | undefined;
          sqlSecurity?: {
            from: "definer" | "invoker";
            to: "definer" | "invoker";
          } | undefined;
          withCheckOption?: {
            from: "local" | "cascaded" | null;
            to: "local" | "cascaded" | null;
          } | undefined;
          $left: {
            definition: string;
            algorithm: "undefined" | "merge" | "temptable";
            sqlSecurity: "definer" | "invoker";
            withCheckOption: "local" | "cascaded" | null;
            name: string;
            entityType: "views";
          };
          $right: {
            definition: string;
            algorithm: "undefined" | "merge" | "temptable";
            sqlSecurity: "definer" | "invoker";
            withCheckOption: "local" | "cascaded" | null;
            name: string;
            entityType: "views";
          };
        };
        entities: {
          $diffType: "alter";
          entityType: "tables";
          name: string;
          $left: {
            name: string;
            entityType: "tables";
          };
          $right: {
            name: string;
            entityType: "tables";
          };
        } | {
          $diffType: "alter";
          entityType: "columns";
          table: string;
          name: string;
          type?: {
            from: string;
            to: string;
          } | undefined;
          notNull?: {
            from: boolean;
            to: boolean;
          } | undefined;
          generated?: {
            from: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            to: {
              type: "virtual" | "stored";
              as: string;
            } | null;
          } | undefined;
          default?: {
            from: string | null;
            to: string | null;
          } | undefined;
          autoIncrement?: {
            from: boolean;
            to: boolean;
          } | undefined;
          onUpdateNow?: {
            from: boolean;
            to: boolean;
          } | undefined;
          onUpdateNowFsp?: {
            from: number | null;
            to: number | null;
          } | undefined;
          charSet?: {
            from: string | null;
            to: string | null;
          } | undefined;
          collation?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            table: string;
            type: string;
            notNull: boolean;
            autoIncrement: boolean;
            default: string | null;
            onUpdateNow: boolean;
            onUpdateNowFsp: number | null;
            charSet: string | null;
            collation: string | null;
            generated: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            name: string;
            entityType: "columns";
          };
          $right: {
            table: string;
            type: string;
            notNull: boolean;
            autoIncrement: boolean;
            default: string | null;
            onUpdateNow: boolean;
            onUpdateNowFsp: number | null;
            charSet: string | null;
            collation: string | null;
            generated: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            name: string;
            entityType: "columns";
          };
        } | {
          $diffType: "alter";
          entityType: "pks";
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          $left: {
            table: string;
            columns: string[];
            name: string;
            entityType: "pks";
          };
          $right: {
            table: string;
            columns: string[];
            name: string;
            entityType: "pks";
          };
        } | {
          $diffType: "alter";
          entityType: "fks";
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          tableTo?: {
            from: string;
            to: string;
          } | undefined;
          columnsTo?: {
            from: string[];
            to: string[];
          } | undefined;
          onUpdate?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          } | undefined;
          onDelete?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          } | undefined;
          $left: {
            table: string;
            columns: string[];
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            nameExplicit: boolean;
            name: string;
            entityType: "fks";
          };
          $right: {
            table: string;
            columns: string[];
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            nameExplicit: boolean;
            name: string;
            entityType: "fks";
          };
        } | {
          $diffType: "alter";
          entityType: "indexes";
          table: string;
          name: string;
          columns?: {
            from: {
              value: string;
              isExpression: boolean;
            }[];
            to: {
              value: string;
              isExpression: boolean;
            }[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          isUnique?: {
            from: boolean;
            to: boolean;
          } | undefined;
          using?: {
            from: "btree" | "hash" | null;
            to: "btree" | "hash" | null;
          } | undefined;
          algorithm?: {
            from: "default" | "inplace" | "copy" | null;
            to: "default" | "inplace" | "copy" | null;
          } | undefined;
          lock?: {
            from: "default" | "none" | "shared" | "exclusive" | null;
            to: "default" | "none" | "shared" | "exclusive" | null;
          } | undefined;
          $left: {
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            using: "btree" | "hash" | null;
            algorithm: "default" | "inplace" | "copy" | null;
            lock: "default" | "none" | "shared" | "exclusive" | null;
            nameExplicit: boolean;
            name: string;
            entityType: "indexes";
          };
          $right: {
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            using: "btree" | "hash" | null;
            algorithm: "default" | "inplace" | "copy" | null;
            lock: "default" | "none" | "shared" | "exclusive" | null;
            nameExplicit: boolean;
            name: string;
            entityType: "indexes";
          };
        } | {
          $diffType: "alter";
          entityType: "checks";
          table: string;
          name: string;
          value?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
          $right: {
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
        } | {
          $diffType: "alter";
          entityType: "views";
          name: string;
          definition?: {
            from: string;
            to: string;
          } | undefined;
          algorithm?: {
            from: "undefined" | "merge" | "temptable";
            to: "undefined" | "merge" | "temptable";
          } | undefined;
          sqlSecurity?: {
            from: "definer" | "invoker";
            to: "definer" | "invoker";
          } | undefined;
          withCheckOption?: {
            from: "local" | "cascaded" | null;
            to: "local" | "cascaded" | null;
          } | undefined;
          $left: {
            definition: string;
            algorithm: "undefined" | "merge" | "temptable";
            sqlSecurity: "definer" | "invoker";
            withCheckOption: "local" | "cascaded" | null;
            name: string;
            entityType: "views";
          };
          $right: {
            definition: string;
            algorithm: "undefined" | "merge" | "temptable";
            sqlSecurity: "definer" | "invoker";
            withCheckOption: "local" | "cascaded" | null;
            name: string;
            entityType: "views";
          };
        };
      };
      create: {
        tables: {
          $diffType: "create";
          entityType: "tables";
          name: string;
        };
        columns: {
          $diffType: "create";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoIncrement: boolean;
          onUpdateNow: boolean;
          onUpdateNowFsp: number | null;
          charSet: string | null;
          collation: string | null;
        };
        pks: {
          $diffType: "create";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
        };
        fks: {
          $diffType: "create";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        };
        indexes: {
          $diffType: "create";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          nameExplicit: boolean;
          isUnique: boolean;
          using: "btree" | "hash" | null;
          algorithm: "default" | "inplace" | "copy" | null;
          lock: "default" | "none" | "shared" | "exclusive" | null;
        };
        checks: {
          $diffType: "create";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        };
        views: {
          $diffType: "create";
          entityType: "views";
          name: string;
          definition: string;
          algorithm: "undefined" | "merge" | "temptable";
          sqlSecurity: "definer" | "invoker";
          withCheckOption: "local" | "cascaded" | null;
        };
        entities: {
          $diffType: "create";
          entityType: "tables";
          name: string;
        } | {
          $diffType: "create";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoIncrement: boolean;
          onUpdateNow: boolean;
          onUpdateNowFsp: number | null;
          charSet: string | null;
          collation: string | null;
        } | {
          $diffType: "create";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
        } | {
          $diffType: "create";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        } | {
          $diffType: "create";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          nameExplicit: boolean;
          isUnique: boolean;
          using: "btree" | "hash" | null;
          algorithm: "default" | "inplace" | "copy" | null;
          lock: "default" | "none" | "shared" | "exclusive" | null;
        } | {
          $diffType: "create";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "create";
          entityType: "views";
          name: string;
          definition: string;
          algorithm: "undefined" | "merge" | "temptable";
          sqlSecurity: "definer" | "invoker";
          withCheckOption: "local" | "cascaded" | null;
        };
      };
      drop: {
        tables: {
          $diffType: "drop";
          entityType: "tables";
          name: string;
        };
        columns: {
          $diffType: "drop";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoIncrement: boolean;
          onUpdateNow: boolean;
          onUpdateNowFsp: number | null;
          charSet: string | null;
          collation: string | null;
        };
        pks: {
          $diffType: "drop";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
        };
        fks: {
          $diffType: "drop";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        };
        indexes: {
          $diffType: "drop";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          nameExplicit: boolean;
          isUnique: boolean;
          using: "btree" | "hash" | null;
          algorithm: "default" | "inplace" | "copy" | null;
          lock: "default" | "none" | "shared" | "exclusive" | null;
        };
        checks: {
          $diffType: "drop";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        };
        views: {
          $diffType: "drop";
          entityType: "views";
          name: string;
          definition: string;
          algorithm: "undefined" | "merge" | "temptable";
          sqlSecurity: "definer" | "invoker";
          withCheckOption: "local" | "cascaded" | null;
        };
        entities: {
          $diffType: "drop";
          entityType: "tables";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoIncrement: boolean;
          onUpdateNow: boolean;
          onUpdateNowFsp: number | null;
          charSet: string | null;
          collation: string | null;
        } | {
          $diffType: "drop";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
        } | {
          $diffType: "drop";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          nameExplicit: boolean;
          isUnique: boolean;
          using: "btree" | "hash" | null;
          algorithm: "default" | "inplace" | "copy" | null;
          lock: "default" | "none" | "shared" | "exclusive" | null;
        } | {
          $diffType: "drop";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "views";
          name: string;
          definition: string;
          algorithm: "undefined" | "merge" | "temptable";
          sqlSecurity: "definer" | "invoker";
          withCheckOption: "local" | "cascaded" | null;
        };
      };
      createdrop: {
        tables: {
          $diffType: "create";
          entityType: "tables";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "tables";
          name: string;
        };
        columns: {
          $diffType: "create";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoIncrement: boolean;
          onUpdateNow: boolean;
          onUpdateNowFsp: number | null;
          charSet: string | null;
          collation: string | null;
        } | {
          $diffType: "drop";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoIncrement: boolean;
          onUpdateNow: boolean;
          onUpdateNowFsp: number | null;
          charSet: string | null;
          collation: string | null;
        };
        pks: {
          $diffType: "create";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
        } | {
          $diffType: "drop";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
        };
        fks: {
          $diffType: "create";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        } | {
          $diffType: "drop";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        };
        indexes: {
          $diffType: "create";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          nameExplicit: boolean;
          isUnique: boolean;
          using: "btree" | "hash" | null;
          algorithm: "default" | "inplace" | "copy" | null;
          lock: "default" | "none" | "shared" | "exclusive" | null;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          nameExplicit: boolean;
          isUnique: boolean;
          using: "btree" | "hash" | null;
          algorithm: "default" | "inplace" | "copy" | null;
          lock: "default" | "none" | "shared" | "exclusive" | null;
        };
        checks: {
          $diffType: "create";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        };
        views: {
          $diffType: "create";
          entityType: "views";
          name: string;
          definition: string;
          algorithm: "undefined" | "merge" | "temptable";
          sqlSecurity: "definer" | "invoker";
          withCheckOption: "local" | "cascaded" | null;
        } | {
          $diffType: "drop";
          entityType: "views";
          name: string;
          definition: string;
          algorithm: "undefined" | "merge" | "temptable";
          sqlSecurity: "definer" | "invoker";
          withCheckOption: "local" | "cascaded" | null;
        };
        entities: ({
          $diffType: "create";
          entityType: "tables";
          name: string;
        } | {
          $diffType: "create";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoIncrement: boolean;
          onUpdateNow: boolean;
          onUpdateNowFsp: number | null;
          charSet: string | null;
          collation: string | null;
        } | {
          $diffType: "create";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
        } | {
          $diffType: "create";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        } | {
          $diffType: "create";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          nameExplicit: boolean;
          isUnique: boolean;
          using: "btree" | "hash" | null;
          algorithm: "default" | "inplace" | "copy" | null;
          lock: "default" | "none" | "shared" | "exclusive" | null;
        } | {
          $diffType: "create";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "create";
          entityType: "views";
          name: string;
          definition: string;
          algorithm: "undefined" | "merge" | "temptable";
          sqlSecurity: "definer" | "invoker";
          withCheckOption: "local" | "cascaded" | null;
        }) | ({
          $diffType: "drop";
          entityType: "tables";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoIncrement: boolean;
          onUpdateNow: boolean;
          onUpdateNowFsp: number | null;
          charSet: string | null;
          collation: string | null;
        } | {
          $diffType: "drop";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
        } | {
          $diffType: "drop";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          nameExplicit: boolean;
          isUnique: boolean;
          using: "btree" | "hash" | null;
          algorithm: "default" | "inplace" | "copy" | null;
          lock: "default" | "none" | "shared" | "exclusive" | null;
        } | {
          $diffType: "drop";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "views";
          name: string;
          definition: string;
          algorithm: "undefined" | "merge" | "temptable";
          sqlSecurity: "definer" | "invoker";
          withCheckOption: "local" | "cascaded" | null;
        });
      };
      all: {
        tables: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoIncrement: "boolean";
            default: "string?";
            onUpdateNow: "boolean";
            onUpdateNowFsp: "number?";
            charSet: "string?";
            collation: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          pks: {
            table: "required";
            columns: "string[]";
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            nameExplicit: "boolean";
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            using: ["btree", "hash", null];
            algorithm: ["default", "inplace", "copy", null];
            lock: ["default", "none", "shared", "exclusive", null];
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string";
            algorithm: ["undefined", "merge", "temptable"];
            sqlSecurity: ["definer", "invoker"];
            withCheckOption: ["local", "cascaded", null];
          };
        }, "tables">;
        columns: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoIncrement: "boolean";
            default: "string?";
            onUpdateNow: "boolean";
            onUpdateNowFsp: "number?";
            charSet: "string?";
            collation: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          pks: {
            table: "required";
            columns: "string[]";
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            nameExplicit: "boolean";
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            using: ["btree", "hash", null];
            algorithm: ["default", "inplace", "copy", null];
            lock: ["default", "none", "shared", "exclusive", null];
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string";
            algorithm: ["undefined", "merge", "temptable"];
            sqlSecurity: ["definer", "invoker"];
            withCheckOption: ["local", "cascaded", null];
          };
        }, "columns">;
        pks: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoIncrement: "boolean";
            default: "string?";
            onUpdateNow: "boolean";
            onUpdateNowFsp: "number?";
            charSet: "string?";
            collation: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          pks: {
            table: "required";
            columns: "string[]";
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            nameExplicit: "boolean";
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            using: ["btree", "hash", null];
            algorithm: ["default", "inplace", "copy", null];
            lock: ["default", "none", "shared", "exclusive", null];
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string";
            algorithm: ["undefined", "merge", "temptable"];
            sqlSecurity: ["definer", "invoker"];
            withCheckOption: ["local", "cascaded", null];
          };
        }, "pks">;
        fks: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoIncrement: "boolean";
            default: "string?";
            onUpdateNow: "boolean";
            onUpdateNowFsp: "number?";
            charSet: "string?";
            collation: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          pks: {
            table: "required";
            columns: "string[]";
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            nameExplicit: "boolean";
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            using: ["btree", "hash", null];
            algorithm: ["default", "inplace", "copy", null];
            lock: ["default", "none", "shared", "exclusive", null];
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string";
            algorithm: ["undefined", "merge", "temptable"];
            sqlSecurity: ["definer", "invoker"];
            withCheckOption: ["local", "cascaded", null];
          };
        }, "fks">;
        indexes: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoIncrement: "boolean";
            default: "string?";
            onUpdateNow: "boolean";
            onUpdateNowFsp: "number?";
            charSet: "string?";
            collation: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          pks: {
            table: "required";
            columns: "string[]";
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            nameExplicit: "boolean";
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            using: ["btree", "hash", null];
            algorithm: ["default", "inplace", "copy", null];
            lock: ["default", "none", "shared", "exclusive", null];
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string";
            algorithm: ["undefined", "merge", "temptable"];
            sqlSecurity: ["definer", "invoker"];
            withCheckOption: ["local", "cascaded", null];
          };
        }, "indexes">;
        checks: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoIncrement: "boolean";
            default: "string?";
            onUpdateNow: "boolean";
            onUpdateNowFsp: "number?";
            charSet: "string?";
            collation: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          pks: {
            table: "required";
            columns: "string[]";
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            nameExplicit: "boolean";
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            using: ["btree", "hash", null];
            algorithm: ["default", "inplace", "copy", null];
            lock: ["default", "none", "shared", "exclusive", null];
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string";
            algorithm: ["undefined", "merge", "temptable"];
            sqlSecurity: ["definer", "invoker"];
            withCheckOption: ["local", "cascaded", null];
          };
        }, "checks">;
        views: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoIncrement: "boolean";
            default: "string?";
            onUpdateNow: "boolean";
            onUpdateNowFsp: "number?";
            charSet: "string?";
            collation: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          pks: {
            table: "required";
            columns: "string[]";
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            nameExplicit: "boolean";
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            using: ["btree", "hash", null];
            algorithm: ["default", "inplace", "copy", null];
            lock: ["default", "none", "shared", "exclusive", null];
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string";
            algorithm: ["undefined", "merge", "temptable"];
            sqlSecurity: ["definer", "invoker"];
            withCheckOption: ["local", "cascaded", null];
          };
        }, "views">;
        entities: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoIncrement: "boolean";
            default: "string?";
            onUpdateNow: "boolean";
            onUpdateNowFsp: "number?";
            charSet: "string?";
            collation: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          pks: {
            table: "required";
            columns: "string[]";
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            nameExplicit: "boolean";
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            using: ["btree", "hash", null];
            algorithm: ["default", "inplace", "copy", null];
            lock: ["default", "none", "shared", "exclusive", null];
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string";
            algorithm: ["undefined", "merge", "temptable"];
            sqlSecurity: ["definer", "invoker"];
            withCheckOption: ["local", "cascaded", null];
          };
        }, "entities">;
      };
    };
    store: {
      collection: Record<string, any>[];
    };
  };
  entities: {
    push: (input: {
      name: string;
      entityType: "tables";
    } | {
      default: string | null | undefined;
      onUpdateNowFsp: number | null | undefined;
      charSet: string | null | undefined;
      collation: string | null | undefined;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      table: string;
      type: string;
      notNull: boolean;
      autoIncrement: boolean;
      onUpdateNow: boolean;
      name: string;
      entityType: "columns";
    } | {
      table: string;
      columns: string[];
      name: string;
      entityType: "pks";
    } | {
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | {
      using: "btree" | "hash" | null | undefined;
      algorithm: "default" | "inplace" | "copy" | null | undefined;
      lock: "default" | "none" | "shared" | "exclusive" | null | undefined;
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      nameExplicit: boolean;
      name: string;
      entityType: "indexes";
    } | {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      withCheckOption: "local" | "cascaded" | null | undefined;
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      name: string;
      entityType: "views";
    }, uniques?: "name"[] | ("table" | "name" | "type" | "notNull" | "generated" | "default" | "autoIncrement" | "onUpdateNow" | "onUpdateNowFsp" | "charSet" | "collation")[] | ("table" | "name" | "columns")[] | ("table" | "name" | "columns" | "nameExplicit" | "tableTo" | "columnsTo" | "onUpdate" | "onDelete")[] | ("table" | "name" | "columns" | "nameExplicit" | "isUnique" | "using" | "algorithm" | "lock")[] | ("table" | "name" | "value")[] | ("name" | "definition" | "algorithm" | "sqlSecurity" | "withCheckOption")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "tables";
      } | {
        table: string;
        type: string;
        notNull: boolean;
        autoIncrement: boolean;
        default: string | null;
        onUpdateNow: boolean;
        onUpdateNowFsp: number | null;
        charSet: string | null;
        collation: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      } | {
        table: string;
        columns: string[];
        name: string;
        entityType: "pks";
      } | {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      } | {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        using: "btree" | "hash" | null;
        algorithm: "default" | "inplace" | "copy" | null;
        lock: "default" | "none" | "shared" | "exclusive" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "indexes";
      } | {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      } | {
        definition: string;
        algorithm: "undefined" | "merge" | "temptable";
        sqlSecurity: "definer" | "invoker";
        withCheckOption: "local" | "cascaded" | null;
        name: string;
        entityType: "views";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: ({
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoIncrement?: boolean | undefined;
      default?: string | null | undefined;
      onUpdateNow?: boolean | undefined;
      onUpdateNowFsp?: number | null | undefined;
      charSet?: string | null | undefined;
      collation?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      using?: "btree" | "hash" | null | undefined;
      algorithm?: "default" | "inplace" | "copy" | null | undefined;
      lock?: "default" | "none" | "shared" | "exclusive" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      definition?: string | undefined;
      algorithm?: "undefined" | "merge" | "temptable" | undefined;
      sqlSecurity?: "definer" | "invoker" | undefined;
      withCheckOption?: "local" | "cascaded" | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    }) | undefined) => ({
      name: string;
      entityType: "tables";
    } | {
      table: string;
      type: string;
      notNull: boolean;
      autoIncrement: boolean;
      default: string | null;
      onUpdateNow: boolean;
      onUpdateNowFsp: number | null;
      charSet: string | null;
      collation: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      table: string;
      columns: string[];
      name: string;
      entityType: "pks";
    } | {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      using: "btree" | "hash" | null;
      algorithm: "default" | "inplace" | "copy" | null;
      lock: "default" | "none" | "shared" | "exclusive" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "indexes";
    } | {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      withCheckOption: "local" | "cascaded" | null;
      name: string;
      entityType: "views";
    })[];
    one: (where?: ({
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoIncrement?: boolean | undefined;
      default?: string | null | undefined;
      onUpdateNow?: boolean | undefined;
      onUpdateNowFsp?: number | null | undefined;
      charSet?: string | null | undefined;
      collation?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      using?: "btree" | "hash" | null | undefined;
      algorithm?: "default" | "inplace" | "copy" | null | undefined;
      lock?: "default" | "none" | "shared" | "exclusive" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      definition?: string | undefined;
      algorithm?: "undefined" | "merge" | "temptable" | undefined;
      sqlSecurity?: "definer" | "invoker" | undefined;
      withCheckOption?: "local" | "cascaded" | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    }) | undefined) => {
      name: string;
      entityType: "tables";
    } | {
      table: string;
      type: string;
      notNull: boolean;
      autoIncrement: boolean;
      default: string | null;
      onUpdateNow: boolean;
      onUpdateNowFsp: number | null;
      charSet: string | null;
      collation: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      table: string;
      columns: string[];
      name: string;
      entityType: "pks";
    } | {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      using: "btree" | "hash" | null;
      algorithm: "default" | "inplace" | "copy" | null;
      lock: "default" | "none" | "shared" | "exclusive" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "indexes";
    } | {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      withCheckOption: "local" | "cascaded" | null;
      name: string;
      entityType: "views";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        name?: string | undefined;
        entityType?: "tables" | undefined;
      } | undefined;
    } | {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: string | ((item: string) => string) | undefined;
        notNull?: boolean | ((item: boolean) => boolean) | undefined;
        generated?: {
          type: "virtual" | "stored";
          as: string;
        } | ((item: {
          type: "virtual" | "stored";
          as: string;
        } | null) => {
          type: "virtual" | "stored";
          as: string;
        } | null) | null | undefined;
        default?: string | ((item: string | null) => string | null) | null | undefined;
        autoIncrement?: boolean | ((item: boolean) => boolean) | undefined;
        onUpdateNow?: boolean | ((item: boolean) => boolean) | undefined;
        onUpdateNowFsp?: number | ((item: number | null) => number | null) | null | undefined;
        charSet?: string | ((item: string | null) => string | null) | null | undefined;
        collation?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        table?: string | undefined;
        type?: string | undefined;
        notNull?: boolean | undefined;
        autoIncrement?: boolean | undefined;
        default?: string | null | undefined;
        onUpdateNow?: boolean | undefined;
        onUpdateNowFsp?: number | null | undefined;
        charSet?: string | null | undefined;
        collation?: string | null | undefined;
        generated?: {
          type: "virtual" | "stored";
          as: string;
        } | null | undefined;
        name?: string | undefined;
        entityType?: "columns" | undefined;
      } | undefined;
    } | {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        name?: string | undefined;
        entityType?: "pks" | undefined;
      } | undefined;
    } | {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        tableTo?: string | ((item: string) => string) | undefined;
        columnsTo?: string[] | ((item: string) => string) | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) | null | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) | null | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        tableTo?: string | undefined;
        columnsTo?: string[] | {
          CONTAINS: string;
        } | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "fks" | undefined;
      } | undefined;
    } | {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | ((item: {
          value: string;
          isExpression: boolean;
        }) => {
          value: string;
          isExpression: boolean;
        }) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        isUnique?: boolean | ((item: boolean) => boolean) | undefined;
        using?: "btree" | "hash" | ((item: "btree" | "hash" | null) => "btree" | "hash" | null) | null | undefined;
        algorithm?: "default" | "inplace" | "copy" | ((item: "default" | "inplace" | "copy" | null) => "default" | "inplace" | "copy" | null) | null | undefined;
        lock?: "default" | "none" | "shared" | "exclusive" | ((item: "default" | "none" | "shared" | "exclusive" | null) => "default" | "none" | "shared" | "exclusive" | null) | null | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | {
          CONTAINS: {
            value: string;
            isExpression: boolean;
          };
        } | undefined;
        isUnique?: boolean | undefined;
        using?: "btree" | "hash" | null | undefined;
        algorithm?: "default" | "inplace" | "copy" | null | undefined;
        lock?: "default" | "none" | "shared" | "exclusive" | null | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "indexes" | undefined;
      } | undefined;
    } | {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        value?: string | ((item: string) => string) | undefined;
      };
      where?: {
        table?: string | undefined;
        value?: string | undefined;
        name?: string | undefined;
        entityType?: "checks" | undefined;
      } | undefined;
    } | {
      set: {
        name?: string | ((item: string) => string) | undefined;
        definition?: string | ((item: string) => string) | undefined;
        algorithm?: "undefined" | "merge" | "temptable" | ((item: "undefined" | "merge" | "temptable") => "undefined" | "merge" | "temptable") | undefined;
        sqlSecurity?: "definer" | "invoker" | ((item: "definer" | "invoker") => "definer" | "invoker") | undefined;
        withCheckOption?: "local" | "cascaded" | ((item: "local" | "cascaded" | null) => "local" | "cascaded" | null) | null | undefined;
      };
      where?: {
        definition?: string | undefined;
        algorithm?: "undefined" | "merge" | "temptable" | undefined;
        sqlSecurity?: "definer" | "invoker" | undefined;
        withCheckOption?: "local" | "cascaded" | null | undefined;
        name?: string | undefined;
        entityType?: "views" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: ({
        name: string;
        entityType: "tables";
      } | {
        table: string;
        type: string;
        notNull: boolean;
        autoIncrement: boolean;
        default: string | null;
        onUpdateNow: boolean;
        onUpdateNowFsp: number | null;
        charSet: string | null;
        collation: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      } | {
        table: string;
        columns: string[];
        name: string;
        entityType: "pks";
      } | {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      } | {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        using: "btree" | "hash" | null;
        algorithm: "default" | "inplace" | "copy" | null;
        lock: "default" | "none" | "shared" | "exclusive" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "indexes";
      } | {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      } | {
        definition: string;
        algorithm: "undefined" | "merge" | "temptable";
        sqlSecurity: "definer" | "invoker";
        withCheckOption: "local" | "cascaded" | null;
        name: string;
        entityType: "views";
      })[];
    };
    delete: (where?: {
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoIncrement?: boolean | undefined;
      default?: string | null | undefined;
      onUpdateNow?: boolean | undefined;
      onUpdateNowFsp?: number | null | undefined;
      charSet?: string | null | undefined;
      collation?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      using?: "btree" | "hash" | null | undefined;
      algorithm?: "default" | "inplace" | "copy" | null | undefined;
      lock?: "default" | "none" | "shared" | "exclusive" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      definition?: string | undefined;
      algorithm?: "undefined" | "merge" | "temptable" | undefined;
      sqlSecurity?: "definer" | "invoker" | undefined;
      withCheckOption?: "local" | "cascaded" | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => ({
      name: string;
      entityType: "tables";
    } | {
      table: string;
      type: string;
      notNull: boolean;
      autoIncrement: boolean;
      default: string | null;
      onUpdateNow: boolean;
      onUpdateNowFsp: number | null;
      charSet: string | null;
      collation: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      table: string;
      columns: string[];
      name: string;
      entityType: "pks";
    } | {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      using: "btree" | "hash" | null;
      algorithm: "default" | "inplace" | "copy" | null;
      lock: "default" | "none" | "shared" | "exclusive" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "indexes";
    } | {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      withCheckOption: "local" | "cascaded" | null;
      name: string;
      entityType: "views";
    })[];
    validate: (data: unknown) => data is {
      name: string;
      entityType: "tables";
    } | {
      table: string;
      type: string;
      notNull: boolean;
      autoIncrement: boolean;
      default: string | null;
      onUpdateNow: boolean;
      onUpdateNowFsp: number | null;
      charSet: string | null;
      collation: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      table: string;
      columns: string[];
      name: string;
      entityType: "pks";
    } | {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      using: "btree" | "hash" | null;
      algorithm: "default" | "inplace" | "copy" | null;
      lock: "default" | "none" | "shared" | "exclusive" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "indexes";
    } | {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      withCheckOption: "local" | "cascaded" | null;
      name: string;
      entityType: "views";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "tables";
      name: string;
      $left: {
        name: string;
        entityType: "tables";
      };
      $right: {
        name: string;
        entityType: "tables";
      };
    } | {
      $diffType: "alter";
      entityType: "columns";
      table: string;
      name: string;
      type?: {
        from: string;
        to: string;
      } | undefined;
      notNull?: {
        from: boolean;
        to: boolean;
      } | undefined;
      generated?: {
        from: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        to: {
          type: "virtual" | "stored";
          as: string;
        } | null;
      } | undefined;
      default?: {
        from: string | null;
        to: string | null;
      } | undefined;
      autoIncrement?: {
        from: boolean;
        to: boolean;
      } | undefined;
      onUpdateNow?: {
        from: boolean;
        to: boolean;
      } | undefined;
      onUpdateNowFsp?: {
        from: number | null;
        to: number | null;
      } | undefined;
      charSet?: {
        from: string | null;
        to: string | null;
      } | undefined;
      collation?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        table: string;
        type: string;
        notNull: boolean;
        autoIncrement: boolean;
        default: string | null;
        onUpdateNow: boolean;
        onUpdateNowFsp: number | null;
        charSet: string | null;
        collation: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
      $right: {
        table: string;
        type: string;
        notNull: boolean;
        autoIncrement: boolean;
        default: string | null;
        onUpdateNow: boolean;
        onUpdateNowFsp: number | null;
        charSet: string | null;
        collation: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
    } | {
      $diffType: "alter";
      entityType: "pks";
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      $left: {
        table: string;
        columns: string[];
        name: string;
        entityType: "pks";
      };
      $right: {
        table: string;
        columns: string[];
        name: string;
        entityType: "pks";
      };
    } | {
      $diffType: "alter";
      entityType: "fks";
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      tableTo?: {
        from: string;
        to: string;
      } | undefined;
      columnsTo?: {
        from: string[];
        to: string[];
      } | undefined;
      onUpdate?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      } | undefined;
      onDelete?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      } | undefined;
      $left: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
      $right: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
    } | {
      $diffType: "alter";
      entityType: "indexes";
      table: string;
      name: string;
      columns?: {
        from: {
          value: string;
          isExpression: boolean;
        }[];
        to: {
          value: string;
          isExpression: boolean;
        }[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      isUnique?: {
        from: boolean;
        to: boolean;
      } | undefined;
      using?: {
        from: "btree" | "hash" | null;
        to: "btree" | "hash" | null;
      } | undefined;
      algorithm?: {
        from: "default" | "inplace" | "copy" | null;
        to: "default" | "inplace" | "copy" | null;
      } | undefined;
      lock?: {
        from: "default" | "none" | "shared" | "exclusive" | null;
        to: "default" | "none" | "shared" | "exclusive" | null;
      } | undefined;
      $left: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        using: "btree" | "hash" | null;
        algorithm: "default" | "inplace" | "copy" | null;
        lock: "default" | "none" | "shared" | "exclusive" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "indexes";
      };
      $right: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        using: "btree" | "hash" | null;
        algorithm: "default" | "inplace" | "copy" | null;
        lock: "default" | "none" | "shared" | "exclusive" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "indexes";
      };
    } | {
      $diffType: "alter";
      entityType: "checks";
      table: string;
      name: string;
      value?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      $right: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    } | {
      $diffType: "alter";
      entityType: "views";
      name: string;
      definition?: {
        from: string;
        to: string;
      } | undefined;
      algorithm?: {
        from: "undefined" | "merge" | "temptable";
        to: "undefined" | "merge" | "temptable";
      } | undefined;
      sqlSecurity?: {
        from: "definer" | "invoker";
        to: "definer" | "invoker";
      } | undefined;
      withCheckOption?: {
        from: "local" | "cascaded" | null;
        to: "local" | "cascaded" | null;
      } | undefined;
      $left: {
        definition: string;
        algorithm: "undefined" | "merge" | "temptable";
        sqlSecurity: "definer" | "invoker";
        withCheckOption: "local" | "cascaded" | null;
        name: string;
        entityType: "views";
      };
      $right: {
        definition: string;
        algorithm: "undefined" | "merge" | "temptable";
        sqlSecurity: "definer" | "invoker";
        withCheckOption: "local" | "cascaded" | null;
        name: string;
        entityType: "views";
      };
    }) => boolean;
  };
  tables: {
    push: (input: {
      name: string;
    }, uniques?: "name"[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "tables";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      name: string;
      entityType: "tables";
    }[];
    one: (where?: {
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      name: string;
      entityType: "tables";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        name?: string | undefined;
        entityType?: "tables" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "tables";
      }[];
    };
    delete: (where?: {
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      name: string;
      entityType: "tables";
    }[];
    validate: (data: unknown) => data is {
      name: string;
      entityType: "tables";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "tables";
      name: string;
      $left: {
        name: string;
        entityType: "tables";
      };
      $right: {
        name: string;
        entityType: "tables";
      };
    }) => boolean;
  };
  columns: {
    push: (input: {
      table: string;
      name: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      default: string | null | undefined;
      autoIncrement: boolean;
      onUpdateNow: boolean;
      onUpdateNowFsp: number | null | undefined;
      charSet: string | null | undefined;
      collation: string | null | undefined;
    }, uniques?: ("table" | "name" | "type" | "notNull" | "generated" | "default" | "autoIncrement" | "onUpdateNow" | "onUpdateNowFsp" | "charSet" | "collation")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        type: string;
        notNull: boolean;
        autoIncrement: boolean;
        default: string | null;
        onUpdateNow: boolean;
        onUpdateNowFsp: number | null;
        charSet: string | null;
        collation: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoIncrement?: boolean | undefined;
      default?: string | null | undefined;
      onUpdateNow?: boolean | undefined;
      onUpdateNowFsp?: number | null | undefined;
      charSet?: string | null | undefined;
      collation?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      table: string;
      type: string;
      notNull: boolean;
      autoIncrement: boolean;
      default: string | null;
      onUpdateNow: boolean;
      onUpdateNowFsp: number | null;
      charSet: string | null;
      collation: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    }[];
    one: (where?: {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoIncrement?: boolean | undefined;
      default?: string | null | undefined;
      onUpdateNow?: boolean | undefined;
      onUpdateNowFsp?: number | null | undefined;
      charSet?: string | null | undefined;
      collation?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      table: string;
      type: string;
      notNull: boolean;
      autoIncrement: boolean;
      default: string | null;
      onUpdateNow: boolean;
      onUpdateNowFsp: number | null;
      charSet: string | null;
      collation: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    } | null;
    update: (config: {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: string | ((item: string) => string) | undefined;
        notNull?: boolean | ((item: boolean) => boolean) | undefined;
        generated?: {
          type: "virtual" | "stored";
          as: string;
        } | ((item: {
          type: "virtual" | "stored";
          as: string;
        } | null) => {
          type: "virtual" | "stored";
          as: string;
        } | null) | null | undefined;
        default?: string | ((item: string | null) => string | null) | null | undefined;
        autoIncrement?: boolean | ((item: boolean) => boolean) | undefined;
        onUpdateNow?: boolean | ((item: boolean) => boolean) | undefined;
        onUpdateNowFsp?: number | ((item: number | null) => number | null) | null | undefined;
        charSet?: string | ((item: string | null) => string | null) | null | undefined;
        collation?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        table?: string | undefined;
        type?: string | undefined;
        notNull?: boolean | undefined;
        autoIncrement?: boolean | undefined;
        default?: string | null | undefined;
        onUpdateNow?: boolean | undefined;
        onUpdateNowFsp?: number | null | undefined;
        charSet?: string | null | undefined;
        collation?: string | null | undefined;
        generated?: {
          type: "virtual" | "stored";
          as: string;
        } | null | undefined;
        name?: string | undefined;
        entityType?: "columns" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        type: string;
        notNull: boolean;
        autoIncrement: boolean;
        default: string | null;
        onUpdateNow: boolean;
        onUpdateNowFsp: number | null;
        charSet: string | null;
        collation: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      }[];
    };
    delete: (where?: {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoIncrement?: boolean | undefined;
      default?: string | null | undefined;
      onUpdateNow?: boolean | undefined;
      onUpdateNowFsp?: number | null | undefined;
      charSet?: string | null | undefined;
      collation?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      table: string;
      type: string;
      notNull: boolean;
      autoIncrement: boolean;
      default: string | null;
      onUpdateNow: boolean;
      onUpdateNowFsp: number | null;
      charSet: string | null;
      collation: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    }[];
    validate: (data: unknown) => data is {
      table: string;
      type: string;
      notNull: boolean;
      autoIncrement: boolean;
      default: string | null;
      onUpdateNow: boolean;
      onUpdateNowFsp: number | null;
      charSet: string | null;
      collation: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "columns";
      table: string;
      name: string;
      type?: {
        from: string;
        to: string;
      } | undefined;
      notNull?: {
        from: boolean;
        to: boolean;
      } | undefined;
      generated?: {
        from: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        to: {
          type: "virtual" | "stored";
          as: string;
        } | null;
      } | undefined;
      default?: {
        from: string | null;
        to: string | null;
      } | undefined;
      autoIncrement?: {
        from: boolean;
        to: boolean;
      } | undefined;
      onUpdateNow?: {
        from: boolean;
        to: boolean;
      } | undefined;
      onUpdateNowFsp?: {
        from: number | null;
        to: number | null;
      } | undefined;
      charSet?: {
        from: string | null;
        to: string | null;
      } | undefined;
      collation?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        table: string;
        type: string;
        notNull: boolean;
        autoIncrement: boolean;
        default: string | null;
        onUpdateNow: boolean;
        onUpdateNowFsp: number | null;
        charSet: string | null;
        collation: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
      $right: {
        table: string;
        type: string;
        notNull: boolean;
        autoIncrement: boolean;
        default: string | null;
        onUpdateNow: boolean;
        onUpdateNowFsp: number | null;
        charSet: string | null;
        collation: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
    }) => boolean;
  };
  pks: {
    push: (input: {
      table: string;
      name: string;
      columns: string[];
    }, uniques?: ("table" | "name" | "columns")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: string[];
        name: string;
        entityType: "pks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      name: string;
      entityType: "pks";
    }[];
    one: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      name: string;
      entityType: "pks";
    } | null;
    update: (config: {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        name?: string | undefined;
        entityType?: "pks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: string[];
        name: string;
        entityType: "pks";
      }[];
    };
    delete: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      name: string;
      entityType: "pks";
    }[];
    validate: (data: unknown) => data is {
      table: string;
      columns: string[];
      name: string;
      entityType: "pks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "pks";
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      $left: {
        table: string;
        columns: string[];
        name: string;
        entityType: "pks";
      };
      $right: {
        table: string;
        columns: string[];
        name: string;
        entityType: "pks";
      };
    }) => boolean;
  };
  fks: {
    push: (input: {
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
    }, uniques?: ("table" | "name" | "columns" | "nameExplicit" | "tableTo" | "columnsTo" | "onUpdate" | "onDelete")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    }[];
    one: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | null;
    update: (config: {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        tableTo?: string | ((item: string) => string) | undefined;
        columnsTo?: string[] | ((item: string) => string) | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) | null | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) | null | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        tableTo?: string | undefined;
        columnsTo?: string[] | {
          CONTAINS: string;
        } | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "fks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      }[];
    };
    delete: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    }[];
    validate: (data: unknown) => data is {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "fks";
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      tableTo?: {
        from: string;
        to: string;
      } | undefined;
      columnsTo?: {
        from: string[];
        to: string[];
      } | undefined;
      onUpdate?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      } | undefined;
      onDelete?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      } | undefined;
      $left: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
      $right: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
    }) => boolean;
  };
  indexes: {
    push: (input: {
      table: string;
      name: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      nameExplicit: boolean;
      isUnique: boolean;
      using: "btree" | "hash" | null | undefined;
      algorithm: "default" | "inplace" | "copy" | null | undefined;
      lock: "default" | "none" | "shared" | "exclusive" | null | undefined;
    }, uniques?: ("table" | "name" | "columns" | "nameExplicit" | "isUnique" | "using" | "algorithm" | "lock")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        using: "btree" | "hash" | null;
        algorithm: "default" | "inplace" | "copy" | null;
        lock: "default" | "none" | "shared" | "exclusive" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "indexes";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      using?: "btree" | "hash" | null | undefined;
      algorithm?: "default" | "inplace" | "copy" | null | undefined;
      lock?: "default" | "none" | "shared" | "exclusive" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      using: "btree" | "hash" | null;
      algorithm: "default" | "inplace" | "copy" | null;
      lock: "default" | "none" | "shared" | "exclusive" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "indexes";
    }[];
    one: (where?: {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      using?: "btree" | "hash" | null | undefined;
      algorithm?: "default" | "inplace" | "copy" | null | undefined;
      lock?: "default" | "none" | "shared" | "exclusive" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      using: "btree" | "hash" | null;
      algorithm: "default" | "inplace" | "copy" | null;
      lock: "default" | "none" | "shared" | "exclusive" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "indexes";
    } | null;
    update: (config: {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | ((item: {
          value: string;
          isExpression: boolean;
        }) => {
          value: string;
          isExpression: boolean;
        }) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        isUnique?: boolean | ((item: boolean) => boolean) | undefined;
        using?: "btree" | "hash" | ((item: "btree" | "hash" | null) => "btree" | "hash" | null) | null | undefined;
        algorithm?: "default" | "inplace" | "copy" | ((item: "default" | "inplace" | "copy" | null) => "default" | "inplace" | "copy" | null) | null | undefined;
        lock?: "default" | "none" | "shared" | "exclusive" | ((item: "default" | "none" | "shared" | "exclusive" | null) => "default" | "none" | "shared" | "exclusive" | null) | null | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | {
          CONTAINS: {
            value: string;
            isExpression: boolean;
          };
        } | undefined;
        isUnique?: boolean | undefined;
        using?: "btree" | "hash" | null | undefined;
        algorithm?: "default" | "inplace" | "copy" | null | undefined;
        lock?: "default" | "none" | "shared" | "exclusive" | null | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "indexes" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        using: "btree" | "hash" | null;
        algorithm: "default" | "inplace" | "copy" | null;
        lock: "default" | "none" | "shared" | "exclusive" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "indexes";
      }[];
    };
    delete: (where?: {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      using?: "btree" | "hash" | null | undefined;
      algorithm?: "default" | "inplace" | "copy" | null | undefined;
      lock?: "default" | "none" | "shared" | "exclusive" | null | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      using: "btree" | "hash" | null;
      algorithm: "default" | "inplace" | "copy" | null;
      lock: "default" | "none" | "shared" | "exclusive" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "indexes";
    }[];
    validate: (data: unknown) => data is {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      using: "btree" | "hash" | null;
      algorithm: "default" | "inplace" | "copy" | null;
      lock: "default" | "none" | "shared" | "exclusive" | null;
      nameExplicit: boolean;
      name: string;
      entityType: "indexes";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "indexes";
      table: string;
      name: string;
      columns?: {
        from: {
          value: string;
          isExpression: boolean;
        }[];
        to: {
          value: string;
          isExpression: boolean;
        }[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      isUnique?: {
        from: boolean;
        to: boolean;
      } | undefined;
      using?: {
        from: "btree" | "hash" | null;
        to: "btree" | "hash" | null;
      } | undefined;
      algorithm?: {
        from: "default" | "inplace" | "copy" | null;
        to: "default" | "inplace" | "copy" | null;
      } | undefined;
      lock?: {
        from: "default" | "none" | "shared" | "exclusive" | null;
        to: "default" | "none" | "shared" | "exclusive" | null;
      } | undefined;
      $left: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        using: "btree" | "hash" | null;
        algorithm: "default" | "inplace" | "copy" | null;
        lock: "default" | "none" | "shared" | "exclusive" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "indexes";
      };
      $right: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        using: "btree" | "hash" | null;
        algorithm: "default" | "inplace" | "copy" | null;
        lock: "default" | "none" | "shared" | "exclusive" | null;
        nameExplicit: boolean;
        name: string;
        entityType: "indexes";
      };
    }) => boolean;
  };
  checks: {
    push: (input: {
      table: string;
      name: string;
      value: string;
    }, uniques?: ("table" | "name" | "value")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    }[];
    one: (where?: {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | null;
    update: (config: {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        value?: string | ((item: string) => string) | undefined;
      };
      where?: {
        table?: string | undefined;
        value?: string | undefined;
        name?: string | undefined;
        entityType?: "checks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      }[];
    };
    delete: (where?: {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    }[];
    validate: (data: unknown) => data is {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "checks";
      table: string;
      name: string;
      value?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      $right: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    }) => boolean;
  };
  views: {
    push: (input: {
      name: string;
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      withCheckOption: "local" | "cascaded" | null | undefined;
    }, uniques?: ("name" | "definition" | "algorithm" | "sqlSecurity" | "withCheckOption")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        definition: string;
        algorithm: "undefined" | "merge" | "temptable";
        sqlSecurity: "definer" | "invoker";
        withCheckOption: "local" | "cascaded" | null;
        name: string;
        entityType: "views";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      definition?: string | undefined;
      algorithm?: "undefined" | "merge" | "temptable" | undefined;
      sqlSecurity?: "definer" | "invoker" | undefined;
      withCheckOption?: "local" | "cascaded" | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      withCheckOption: "local" | "cascaded" | null;
      name: string;
      entityType: "views";
    }[];
    one: (where?: {
      definition?: string | undefined;
      algorithm?: "undefined" | "merge" | "temptable" | undefined;
      sqlSecurity?: "definer" | "invoker" | undefined;
      withCheckOption?: "local" | "cascaded" | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      withCheckOption: "local" | "cascaded" | null;
      name: string;
      entityType: "views";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
        definition?: string | ((item: string) => string) | undefined;
        algorithm?: "undefined" | "merge" | "temptable" | ((item: "undefined" | "merge" | "temptable") => "undefined" | "merge" | "temptable") | undefined;
        sqlSecurity?: "definer" | "invoker" | ((item: "definer" | "invoker") => "definer" | "invoker") | undefined;
        withCheckOption?: "local" | "cascaded" | ((item: "local" | "cascaded" | null) => "local" | "cascaded" | null) | null | undefined;
      };
      where?: {
        definition?: string | undefined;
        algorithm?: "undefined" | "merge" | "temptable" | undefined;
        sqlSecurity?: "definer" | "invoker" | undefined;
        withCheckOption?: "local" | "cascaded" | null | undefined;
        name?: string | undefined;
        entityType?: "views" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        definition: string;
        algorithm: "undefined" | "merge" | "temptable";
        sqlSecurity: "definer" | "invoker";
        withCheckOption: "local" | "cascaded" | null;
        name: string;
        entityType: "views";
      }[];
    };
    delete: (where?: {
      definition?: string | undefined;
      algorithm?: "undefined" | "merge" | "temptable" | undefined;
      sqlSecurity?: "definer" | "invoker" | undefined;
      withCheckOption?: "local" | "cascaded" | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      withCheckOption: "local" | "cascaded" | null;
      name: string;
      entityType: "views";
    }[];
    validate: (data: unknown) => data is {
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      withCheckOption: "local" | "cascaded" | null;
      name: string;
      entityType: "views";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "views";
      name: string;
      definition?: {
        from: string;
        to: string;
      } | undefined;
      algorithm?: {
        from: "undefined" | "merge" | "temptable";
        to: "undefined" | "merge" | "temptable";
      } | undefined;
      sqlSecurity?: {
        from: "definer" | "invoker";
        to: "definer" | "invoker";
      } | undefined;
      withCheckOption?: {
        from: "local" | "cascaded" | null;
        to: "local" | "cascaded" | null;
      } | undefined;
      $left: {
        definition: string;
        algorithm: "undefined" | "merge" | "temptable";
        sqlSecurity: "definer" | "invoker";
        withCheckOption: "local" | "cascaded" | null;
        name: string;
        entityType: "views";
      };
      $right: {
        definition: string;
        algorithm: "undefined" | "merge" | "temptable";
        sqlSecurity: "definer" | "invoker";
        withCheckOption: "local" | "cascaded" | null;
        name: string;
        entityType: "views";
      };
    }) => boolean;
  };
};
type MysqlDDL = ReturnType<typeof createDDL>;
type MysqlEntities = MysqlDDL['_']['types'];
type MysqlEntity = MysqlEntities[keyof MysqlEntities];
//#endregion
//#region src/dialects/mysql/snapshot.d.ts
declare const snapshotValidator: {
  shape: {
    version: "6";
    dialect: "mysql";
    id: string;
    prevIds: string[];
    ddl: MysqlEntity[];
    renames: string[];
  };
  parse: (obj: unknown) => {
    success: boolean;
    data: {
      version: "6";
      dialect: "mysql";
      id: string;
      prevIds: string[];
      ddl: MysqlEntity[];
      renames: string[];
    } | null;
    errors?: string[] | undefined;
  };
  strict: (obj: unknown) => {
    version: "6";
    dialect: "mysql";
    id: string;
    prevIds: string[];
    ddl: MysqlEntity[];
    renames: string[];
  };
};
type MysqlSnapshot = typeof snapshotValidator.shape;
//#endregion
//#region src/cli/commands/up-mysql.d.ts
declare const upToV6: (it: Record<string, any>) => MysqlSnapshot;
//#endregion
//#region src/payload/mysql.d.ts
declare const generateDrizzleJson: (imports: Record<string, unknown>, prevId?: string) => Promise<MysqlSnapshot>;
declare const generateMigration: (prev: MysqlSnapshot, cur: MysqlSnapshot, options?: {
  hints?: Hint[];
}) => Promise<string[]>;
declare const pushSchema: (imports: Record<string, unknown>, db: DB, database: string, migrationsConfig?: {
  table?: string;
  schema?: string;
}) => Promise<{
  sqlStatements: string[];
  hints: {
    hint: string;
    statement?: string;
  }[];
  apply: () => Promise<void>;
}>;
declare const startStudioServer: (imports: Record<string, unknown>, credentials: MysqlCredentials, options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<void>;
//#endregion
export { type Hint, type MissingHint, type MissingHintsError, generateDrizzleJson, generateMigration, pushSchema, startStudioServer, upToV6 as up };