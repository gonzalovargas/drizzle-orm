import { t as MysqlCredentials } from "./mysql-jrt3JFHE.mjs";
import { n as MissingHint, t as Hint } from "./hints-DJq8W2Cc.mjs";
import { t as MissingHintsError } from "./errors-Bs6lFKQd.mjs";
import { t as DB } from "./index-yxkYOa2C.mjs";
//#region src/dialects/mysql/snapshot.d.ts
declare const snapshotValidator: {
  shape: {
    version: "6";
    dialect: "mysql";
    id: string;
    prevIds: string[];
    ddl: ({
      name: string;
      entityType: "tables";
    } | {
      table: string;
      name: string;
      type: string;
      notNull: boolean;
      autoIncrement: boolean;
      default: string | null;
      onUpdateNow: boolean;
      onUpdateNowFsp: number | null;
      charSet: string | null;
      collation: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      entityType: "columns";
    } | {
      table: string;
      name: string;
      columns: string[];
      entityType: "pks";
    } | {
      table: string;
      name: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      nameExplicit: boolean;
      entityType: "fks";
    } | {
      table: string;
      name: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      using: "btree" | "hash" | null;
      algorithm: "default" | "inplace" | "copy" | null;
      lock: "default" | "none" | "shared" | "exclusive" | null;
      nameExplicit: boolean;
      entityType: "indexes";
    } | {
      table: string;
      name: string;
      value: string;
      entityType: "checks";
    } | {
      name: string;
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      withCheckOption: "local" | "cascaded" | null;
      entityType: "views";
    })[];
    renames: string[];
  };
  parse: (obj: unknown) => {
    success: boolean;
    data: {
      version: "6";
      dialect: "mysql";
      id: string;
      prevIds: string[];
      ddl: ({
        name: string;
        entityType: "tables";
      } | {
        table: string;
        name: string;
        type: string;
        notNull: boolean;
        autoIncrement: boolean;
        default: string | null;
        onUpdateNow: boolean;
        onUpdateNowFsp: number | null;
        charSet: string | null;
        collation: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        entityType: "columns";
      } | {
        table: string;
        name: string;
        columns: string[];
        entityType: "pks";
      } | {
        table: string;
        name: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        nameExplicit: boolean;
        entityType: "fks";
      } | {
        table: string;
        name: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        using: "btree" | "hash" | null;
        algorithm: "default" | "inplace" | "copy" | null;
        lock: "default" | "none" | "shared" | "exclusive" | null;
        nameExplicit: boolean;
        entityType: "indexes";
      } | {
        table: string;
        name: string;
        value: string;
        entityType: "checks";
      } | {
        name: string;
        definition: string;
        algorithm: "undefined" | "merge" | "temptable";
        sqlSecurity: "definer" | "invoker";
        withCheckOption: "local" | "cascaded" | null;
        entityType: "views";
      })[];
      renames: string[];
    } | null;
    errors?: string[] | undefined;
  };
  strict: (obj: unknown) => {
    version: "6";
    dialect: "mysql";
    id: string;
    prevIds: string[];
    ddl: ({
      name: string;
      entityType: "tables";
    } | {
      table: string;
      name: string;
      type: string;
      notNull: boolean;
      autoIncrement: boolean;
      default: string | null;
      onUpdateNow: boolean;
      onUpdateNowFsp: number | null;
      charSet: string | null;
      collation: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      entityType: "columns";
    } | {
      table: string;
      name: string;
      columns: string[];
      entityType: "pks";
    } | {
      table: string;
      name: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      nameExplicit: boolean;
      entityType: "fks";
    } | {
      table: string;
      name: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      using: "btree" | "hash" | null;
      algorithm: "default" | "inplace" | "copy" | null;
      lock: "default" | "none" | "shared" | "exclusive" | null;
      nameExplicit: boolean;
      entityType: "indexes";
    } | {
      table: string;
      name: string;
      value: string;
      entityType: "checks";
    } | {
      name: string;
      definition: string;
      algorithm: "undefined" | "merge" | "temptable";
      sqlSecurity: "definer" | "invoker";
      withCheckOption: "local" | "cascaded" | null;
      entityType: "views";
    })[];
    renames: string[];
  };
};
type MysqlSnapshot = typeof snapshotValidator.shape;
//#endregion
//#region src/cli/commands/up-mysql.d.ts
declare const upToV6: (it: Record<string, any>) => MysqlSnapshot;
//#endregion
//#region src/payload/mysql.d.ts
declare const generateDrizzleJson: (imports: Record<string, unknown>, prevId?: string) => Promise<MysqlSnapshot>;
declare const generateMigration: (prev: MysqlSnapshot, cur: MysqlSnapshot, options?: {
  hints?: Hint[];
}) => Promise<string[]>;
declare const pushSchema: (imports: Record<string, unknown>, db: DB, database: string, migrationsConfig?: {
  table?: string;
  schema?: string;
}, options?: {
  hints?: Hint[];
}) => Promise<{
  sqlStatements: string[];
  hints: {
    hint: string;
    statement?: string;
  }[];
  apply: () => Promise<void>;
}>;
declare const startStudioServer: (imports: Record<string, unknown>, credentials: MysqlCredentials, options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<void>;
//#endregion
export { type Hint, type MissingHint, type MissingHintsError, generateDrizzleJson, generateMigration, pushSchema, startStudioServer, upToV6 as up };