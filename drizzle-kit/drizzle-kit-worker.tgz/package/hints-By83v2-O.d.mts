import { m as ZodTuple, p as ZodString, t as TypeOf } from "./types-0NRiLQtx.mjs";

//#region src/dialects/dialect.d.ts
type DataType = 'string' | 'string[]' | 'number' | 'boolean';
type TypeMap = {
  string: string;
  number: number;
  boolean: boolean;
  'string[]': string[];
};
type Simplify<T> = { [K in keyof T]: T[K] } & {};
type Assume<T, U> = T extends U ? T : U;
type ExtendedType = (`${Exclude<DataType, 'string[]'>}?` | DataType) | 'required' | [string, ...(string | null)[]] | {
  [K: string]: Exclude<ExtendedType, 'required'>;
} | ([{
  [K: string]: Exclude<ExtendedType, 'required'>;
}]);
type InferField<T extends ExtendedType> = T extends (string | null)[] ? T[number] : T extends [Record<string, ExtendedType>] ? { [K in keyof T[0]]: InferField<T[0][K]> }[] : T extends Record<string, ExtendedType> ? { [K in keyof T]: InferField<T[K]> } | null : T extends `${infer Type extends DataType}?` ? TypeMap[Type] | null : T extends DataType ? TypeMap[T] : never;
type Definition = Record<string, Schema>;
type InferSchema<TSchema extends Schema> = Simplify<{ -readonly [K in keyof TSchema]: K extends keyof Common ? Exclude<Common[K], null> : InferField<Assume<TSchema[K], ExtendedType>> }>;
type Schema = Record<string, ExtendedType> & { [K in keyof Common as null extends Common[K] ? K : never]?: 'required' } & { [K in keyof Common as null extends Common[K] ? never : K]?: never } & { [K in `${keyof Common}?`]?: never } & {
  entityType?: never;
  CONTAINS?: never;
};
type Common = {
  schema: string | null;
  table: string | null;
  name: string;
};
type CommonEntity = Common & {
  entityType: string;
};
type Config = {
  [K: string]: `${Exclude<DataType, 'string['>}?` | DataType | [string, ...string[]] | Config | [Config];
};
type ValueOf<T> = T[keyof T];
type DiffCreate<TSchema extends Definition = {}, TType extends keyof TSchema | 'entities' = string, TShape extends Record<string, any> = (TType extends 'entities' ? {} : Simplify<InferSchema<TSchema[TType]> & Omit<Common, keyof TSchema[TType]> & {
  entityType: TType;
}>)> = TType extends 'entities' ? ValueOf<{ [K in keyof TSchema]: DiffCreate<TSchema, K> }> : Simplify<{
  $diffType: 'create';
  entityType: TType;
} & { [K in keyof Common as K extends keyof TShape ? null extends TShape[K] ? never : K : K]: Exclude<Common[K], null> } & Omit<TShape, keyof CommonEntity>>;
type DiffDrop<TSchema extends Definition = {}, TType extends keyof TSchema | 'entities' = string, TShape extends Record<string, any> = (TType extends 'entities' ? {} : Simplify<InferSchema<TSchema[TType]> & Omit<Common, keyof TSchema[TType]> & {
  entityType: TType;
}>)> = TType extends 'entities' ? ValueOf<{ [K in keyof TSchema]: DiffDrop<TSchema, K> }> : Simplify<{
  $diffType: 'drop';
  entityType: TType;
} & { [K in keyof Common as K extends keyof TShape ? null extends TShape[K] ? never : K : K]: Exclude<Common[K], null> } & Omit<TShape, keyof CommonEntity>>;
type DiffAlter<TSchema extends Definition = {}, TType extends keyof TSchema | 'entities' = string, TShape extends Record<string, any> = (TType extends 'entities' ? {} : Simplify<InferSchema<TSchema[TType]> & Omit<Common, keyof TSchema[TType]> & {
  entityType: TType;
}>), TFullShape extends Record<string, any> = (TType extends 'entities' ? {} : Simplify<InferSchema<TSchema[TType]> & { [C in keyof Common as C extends keyof TSchema[TType] ? never : null extends Common[C] ? never : C]: Common[C] } & {
  entityType: TType;
}>)> = TType extends 'entities' ? ValueOf<{ [K in keyof TSchema]: DiffAlter<TSchema, K> }> : Simplify<{
  $diffType: 'alter';
  entityType: TType;
} & { [K in keyof Common as K extends keyof TShape ? null extends TShape[K] ? never : K : K]: Exclude<Common[K], null> } & { [K in Exclude<keyof TShape, keyof CommonEntity>]?: {
  from: TShape[K];
  to: TShape[K];
} } & {
  $left: TFullShape;
  $right: TFullShape;
}>;
type DiffStatement<TSchema extends Definition, TType extends keyof TSchema | 'entities'> = DiffCreate<TSchema, TType> | DiffDrop<TSchema, TType> | DiffAlter<TSchema, TType>;
//#endregion
//#region src/cli/hints.d.ts
declare const renameCreateEntitySchemas: readonly [{
  readonly kind: "table";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "column";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "default";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "schema";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "enum";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "sequence";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "view";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "policy";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "role";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "privilege";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "check";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "index";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "unique";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "primary_key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "foreign key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}];
type RenameCreateHintKind = typeof renameCreateEntitySchemas[number]['kind'];
declare const confirmEntitySchemas: readonly [{
  readonly kind: "table";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "column";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "schema";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "view";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "primary_key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "add_not_null";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "add_unique";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}];
type ConfirmEntityKind = typeof confirmEntitySchemas[number]['kind'];
type RenameCreateSchemaFor<K extends RenameCreateHintKind> = Extract<typeof renameCreateEntitySchemas[number], {
  kind: K;
}>['schema'];
type ConfirmSchemaFor<K extends ConfirmEntityKind> = Extract<typeof confirmEntitySchemas[number], {
  kind: K;
}>['schema'];
type IdFor<K extends RenameCreateHintKind> = Readonly<TypeOf<RenameCreateSchemaFor<K>>>;
type ConfirmIdFor<K extends ConfirmEntityKind> = Readonly<TypeOf<ConfirmSchemaFor<K>>>;
type RenameHint = { [K in RenameCreateHintKind]: {
  type: 'rename';
  kind: K;
  from: IdFor<K>;
  to: IdFor<K>;
} }[RenameCreateHintKind];
type CreateHint = { [K in RenameCreateHintKind]: {
  type: 'create';
  kind: K;
  entity: IdFor<K>;
} }[RenameCreateHintKind];
type ConfirmDataLossHint = { [K in ConfirmEntityKind]: {
  type: 'confirm_data_loss';
  kind: K;
  entity: ConfirmIdFor<K>;
} }[ConfirmEntityKind];
type Hint = RenameHint | CreateHint | ConfirmDataLossHint;
type RenameCreateMissingHint<K extends RenameCreateHintKind> = {
  type: 'rename_or_create';
  kind: K;
  entity: IdFor<K>;
};
type ConfirmDataLossReasonDetails = {
  reason: 'non_empty';
} | {
  reason: 'table_recreate';
} | {
  reason: 'type_change';
  reason_details: {
    from: string;
    to: string;
  };
};
type ConfirmDataLossMissingHint<K extends ConfirmEntityKind> = {
  type: 'confirm_data_loss';
  kind: K;
  entity: ConfirmIdFor<K>;
} & ConfirmDataLossReasonDetails;
type MissingHint = { [K in RenameCreateHintKind]: RenameCreateMissingHint<K> }[RenameCreateHintKind] | { [K in ConfirmEntityKind]: ConfirmDataLossMissingHint<K> }[ConfirmEntityKind];
//#endregion
export { DiffStatement as i, MissingHint as n, Config as r, Hint as t };