import { PGlite } from "@electric-sql/pglite";
//#region src/utils/index.d.ts
type DB = {
  query: <T extends any = any>(sql: string, params?: any[]) => Promise<T[]>;
};
interface SQLiteClient {
  query: <T extends any = any>(sql: string, params?: any[]) => Promise<T[]>;
  run(query: string): Promise<void>;
  batch(statements: string[]): Promise<void>;
}
//#endregion
export { SQLiteClient as n, DB as t };