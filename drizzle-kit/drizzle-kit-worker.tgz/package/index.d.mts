import { _ as ZodType, a as pgLiteCredentials, b as ZodUndefined, c as ZodArray, d as ZodLiteral, f as ZodNumber, h as ZodString, i as pgLiteClientCredentials, l as ZodBoolean, m as ZodOptional, n as dsqlCredentials, o as Dialect, p as ZodObject, r as pgDefaultCredentials, s as TypeOf, t as awsDataApiCredentials, u as ZodEffects, v as ZodTypeAny, x as ZodUnion, y as ZodTypeDef } from "./postgres-PsuB9IHg.mjs";
import { ConnectionOptions } from "tls";
//#region src/cli/validations/common.d.ts
declare const sqliteDriver: ZodUnion<[ZodLiteral<"d1-http">, ZodLiteral<"expo">, ZodLiteral<"durable-sqlite">, ZodLiteral<"sqlite-cloud">]>;
declare const postgresDriver: ZodUnion<[ZodLiteral<"aws-data-api">, ZodLiteral<"pglite">, ZodLiteral<"dsql">]>;
declare const driver: ZodUnion<[ZodUnion<[ZodLiteral<"d1-http">, ZodLiteral<"expo">, ZodLiteral<"durable-sqlite">, ZodLiteral<"sqlite-cloud">]>, ZodUnion<[ZodLiteral<"aws-data-api">, ZodLiteral<"pglite">, ZodLiteral<"dsql">]>]>;
declare const drivers: [TypeOf<typeof driver>, ...TypeOf<typeof driver>[]];
type Driver = (typeof drivers)[number];
//#endregion
//#region src/cli/validations/duckdb.d.ts
declare const duckdbCredentials: ZodEffects<ZodObject<{
  driver: ZodUndefined;
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
  driver?: undefined;
}, {
  url: string;
  driver?: undefined;
}>, {
  url: string;
}, {
  url: string;
  driver?: undefined;
}>;
//#endregion
//#region src/cli/validations/libsql.d.ts
declare const libSQLCredentials: ZodObject<{
  url: ZodString;
  authToken: ZodOptional<ZodString>;
}, "strip", ZodTypeAny, {
  url: string;
  authToken?: string | undefined;
}, {
  url: string;
  authToken?: string | undefined;
}>;
//#endregion
//#region src/cli/validations/mysql.d.ts
declare const mysqlCredentials: ZodUnion<[ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>, ZodObject<{
  host: ZodString;
  port: ZodOptional<ZodNumber>;
  user: ZodOptional<ZodString>;
  password: ZodOptional<ZodString>;
  database: ZodString;
  ssl: ZodOptional<ZodUnion<[ZodString, ZodObject<{
    pfx: ZodOptional<ZodString>;
    key: ZodOptional<ZodString>;
    passphrase: ZodOptional<ZodString>;
    cert: ZodOptional<ZodString>;
    ca: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
    crl: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
    ciphers: ZodOptional<ZodString>;
    rejectUnauthorized: ZodOptional<ZodBoolean>;
  }, "strip", ZodTypeAny, {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  }, {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  }>]>>;
}, "strip", ZodTypeAny, {
  host: string;
  database: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: string | {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  } | undefined;
}, {
  host: string;
  database: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: string | {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  } | undefined;
}>]>;
//#endregion
//#region src/cli/validations/singlestore.d.ts
declare const singlestoreCredentials: ZodUnion<[ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>, ZodObject<{
  host: ZodString;
  port: ZodOptional<ZodNumber>;
  user: ZodOptional<ZodString>;
  password: ZodOptional<ZodString>;
  database: ZodString;
  ssl: ZodOptional<ZodUnion<[ZodString, ZodObject<{
    pfx: ZodOptional<ZodString>;
    key: ZodOptional<ZodString>;
    passphrase: ZodOptional<ZodString>;
    cert: ZodOptional<ZodString>;
    ca: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
    crl: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
    ciphers: ZodOptional<ZodString>;
    rejectUnauthorized: ZodOptional<ZodBoolean>;
  }, "strip", ZodTypeAny, {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  }, {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  }>]>>;
}, "strip", ZodTypeAny, {
  host: string;
  database: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: string | {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  } | undefined;
}, {
  host: string;
  database: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: string | {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  } | undefined;
}>]>;
//#endregion
//#region src/cli/validations/sqlite.d.ts
declare const sqliteDefaultCredentials: ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>;
declare const d1HttpCredentials: ZodObject<{
  accountId: ZodString;
  databaseId: ZodString;
  token: ZodString;
}, "strip", ZodTypeAny, {
  accountId: string;
  databaseId: string;
  token: string;
}, {
  accountId: string;
  databaseId: string;
  token: string;
}>;
declare const sqliteCloudCredentials: ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>;
//#endregion
//#region src/cli/validations/cockroach.d.ts
declare const cockroachCredentials: ZodUnion<[ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>, ZodObject<{
  host: ZodString;
  port: ZodOptional<ZodNumber>;
  user: ZodOptional<ZodString>;
  password: ZodOptional<ZodString>;
  database: ZodString;
  ssl: ZodOptional<ZodUnion<[ZodLiteral<"require">, ZodLiteral<"allow">, ZodLiteral<"prefer">, ZodLiteral<"verify-full">, ZodBoolean, ZodType<ConnectionOptions, ZodTypeDef, ConnectionOptions>]>>;
}, "strip", ZodTypeAny, {
  host: string;
  database: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | ConnectionOptions | undefined;
}, {
  host: string;
  database: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | ConnectionOptions | undefined;
}>]>;
//#endregion
//#region src/cli/validations/mssql.d.ts
declare const mssqlCredentials: ZodUnion<[ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>, ZodObject<{
  port: ZodOptional<ZodNumber>;
  user: ZodString;
  password: ZodString;
  database: ZodOptional<ZodString>;
  server: ZodString;
  options: ZodOptional<ZodObject<{
    encrypt: ZodOptional<ZodBoolean>;
    trustServerCertificate: ZodOptional<ZodBoolean>;
  }, "strip", ZodTypeAny, {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  }, {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  }>>;
}, "strip", ZodTypeAny, {
  user: string;
  password: string;
  server: string;
  options?: {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  } | undefined;
  port?: number | undefined;
  database?: string | undefined;
}, {
  user: string;
  password: string;
  server: string;
  options?: {
    encrypt?: boolean | undefined;
    trustServerCertificate?: boolean | undefined;
  } | undefined;
  port?: number | undefined;
  database?: string | undefined;
}>]>;
//#endregion
//#region src/index.d.ts
/**
 * **You are currently using version 0.21.0+ of drizzle-kit. If you have just upgraded to this version, please make sure to read the changelog to understand what changes have been made and what
 * adjustments may be necessary for you. See https://orm.drizzle.team/kit-docs/upgrade-21#how-to-migrate-to-0210**
 *
 * **Config** usage:
 *
 * `dialect` - mandatory and is responsible for explicitly providing a databse dialect you are using for all the commands
 * *Possible values*: `postgresql`, `mysql`, `sqlite`, `singlestore
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#dialect
 *
 * ---
 * `schema` - param lets you define where your schema file/files live.
 * You can have as many separate schema files as you want and define paths to them using glob or array of globs syntax.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#schema
 *
 * ---
 * `out` - allows you to define the folder for your migrations and a folder, where drizzle will introspect the schema and relations
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#out
 *
 * ---
 * `driver` - optional param that is responsible for explicitly providing a driver to use when accessing a database
 * *Possible values*: `aws-data-api`, `d1-http`, `expo`, `turso`, `pglite`
 * If you don't use AWS Data API, D1, Turso or Expo - ypu don't need this driver. You can check a driver strategy choice here: https://orm.drizzle.team/kit-docs/upgrade-21
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#driver
 *
 * ---
 *
 * `dbCredentials` - an object to define your connection to the database. For more info please check the docs
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#dbcredentials
 *
 * ---
 *
 * `migrations` - param let’s you specify a custom table and schema(PostgreSQL only) for migrations.
 * By default, all information about executed migrations will be stored in the database inside
 * the `__drizzle_migrations` table, and for PostgreSQL, inside the drizzle schema.
 * However, you can configure where to store those records.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#migrations
 *
 * ---
 *
 * `breakpoints` - param lets you enable/disable SQL statement breakpoints in generated migrations.
 * It’s optional and true by default, it’s necessary to properly apply migrations on databases,
 * that do not support multiple DDL alternation statements in one transaction(MySQL, SQLite, SingleStore) and
 * Drizzle ORM has to apply them sequentially one by one.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#breakpoints
 *
 * ---
 *
 * `tablesFilters` - param lets you filter tables with glob syntax for db push command.
 * It’s useful when you have only one database avaialable for several separate projects with separate sql schemas.
 *
 * How to define multi-project tables with Drizzle ORM — see https://orm.drizzle.team/docs/goodies#multi-project-schema
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#tablesfilters
 *
 * ---
 *
 * `schemaFilter` - parameter allows you to define which schema in PostgreSQL should be used for either introspect or push commands.
 * This parameter accepts a single schema as a string or an array of schemas as strings.
 * No glob pattern is supported here. By default, drizzle will use the public schema for both commands,
 * but you can add any schema you need.
 *
 * For example, having schemaFilter: ["my_schema"] will only look for tables in both the database and
 * drizzle schema that are a part of the my_schema schema.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#schemafilter
 *
 * ---
 *
 * `verbose` - command is used for drizzle-kit push commands and prints all statements that will be executed.
 *
 * > Note: This command will only print the statements that should be executed.
 * To approve them before applying, please refer to the `strict` command.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#verbose
 *
 * ---
 *
 * `strict` - command is used for drizzle-kit push commands and will always ask for your confirmation,
 * either to execute all statements needed to sync your schema with the database or not.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#strict
 */
type Config<TDialect extends Dialect = Dialect, TDriver extends DialectDriverMap[TDialect] = DialectDriverMap[TDialect]> = TDialect extends Dialect ? TDriver extends DialectDriverMap[TDialect] ? ConfigVariant<TDialect, TDriver> : never : never;
type ConfigVariant<TDialect extends Dialect, TDriver extends DialectDriverMap[TDialect]> = {
  dialect: TDialect;
  out?: string;
  breakpoints?: boolean;
  tablesFilter?: string | string[];
  extensionsFilters?: 'postgis'[];
  schemaFilter?: string | string[];
  schema?: string | string[];
  verbose?: boolean;
  migrations?: {
    table?: string;
    schema?: string;
  };
  introspect?: {
    casing: 'camel' | 'preserve';
  };
  entities?: {
    roles?: boolean | {
      provider?: 'supabase' | 'neon' | string & {};
      exclude?: string[];
      include?: string[];
    };
  };
} & (TDriver extends 'default' ? {
  driver?: undefined;
} : {
  driver: TDriver;
}) & (DialectCredentials[TDialect][TDriver & keyof DialectCredentials[TDialect]] | {});
type ExclusiveUnion<T, TKeys extends PropertyKey = T extends object ? keyof T : never> = T extends object ? { [K in keyof T]: ExclusiveProperty<T[K]>; } & { [K in Exclude<TKeys, keyof T>]?: never; } : T;
type ExclusiveProperty<T> = true extends IsUnion<Extract<T, object>> ? ExclusiveUnion<T> : T;
type IsUnion<T, TAll = T> = T extends unknown ? ([TAll] extends [T] ? false : true) : never;
interface DialectDriverMap extends Record<Dialect, Driver | 'default'> {
  postgresql: 'default' | TypeOf<(typeof postgresDriver)>;
  mysql: 'default';
  sqlite: 'default' | TypeOf<(typeof sqliteDriver)>;
  turso: 'default';
  singlestore: 'default';
  mssql: 'default';
  cockroach: 'default';
  duckdb: 'default';
}
interface DialectCredentials {
  turso: {
    default: {
      dbCredentials: TypeOf<typeof libSQLCredentials>;
    };
  };
  postgresql: {
    default: {
      dbCredentials: ExclusiveUnion<TypeOf<typeof pgDefaultCredentials>>;
    };
    'aws-data-api': {
      dbCredentials: TypeOf<typeof awsDataApiCredentials>;
    };
    pglite: ExclusiveUnion<{
      dbCredentials: TypeOf<typeof pgLiteCredentials>;
    } | TypeOf<typeof pgLiteClientCredentials>>;
    dsql: {
      dbCredentials: TypeOf<typeof dsqlCredentials>;
    };
  };
  mysql: {
    default: {
      dbCredentials: ExclusiveUnion<TypeOf<typeof mysqlCredentials>>;
    };
  };
  sqlite: {
    default: {
      dbCredentials: TypeOf<typeof sqliteDefaultCredentials>;
    };
    'd1-http': {
      dbCredentials: TypeOf<typeof d1HttpCredentials>;
    };
    expo: {};
    'durable-sqlite': {};
    'sqlite-cloud': {
      dbCredentials: TypeOf<typeof sqliteCloudCredentials>;
    };
  };
  singlestore: {
    default: {
      dbCredentials: ExclusiveUnion<TypeOf<typeof singlestoreCredentials>>;
    };
  };
  mssql: {
    default: {
      dbCredentials: ExclusiveUnion<TypeOf<typeof mssqlCredentials>>;
    };
  };
  cockroach: {
    default: {
      dbCredentials: ExclusiveUnion<TypeOf<typeof cockroachCredentials>>;
    };
  };
  duckdb: {
    default: {
      dbCredentials: TypeOf<typeof duckdbCredentials>;
    };
  };
}
/**
 * **You are currently using version 0.21.0+ of drizzle-kit. If you have just upgraded to this version, please make sure to read the changelog to understand what changes have been made and what
 * adjustments may be necessary for you. See https://orm.drizzle.team/kit-docs/upgrade-21#how-to-migrate-to-0210**
 *
 * **Config** usage:
 *
 * `dialect` - mandatory and is responsible for explicitly providing a databse dialect you are using for all the commands
 * *Possible values*: `postgresql`, `mysql`, `sqlite`, `singlestore`, `gel`
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#dialect
 *
 * ---
 * `schema` - param lets you define where your schema file/files live.
 * You can have as many separate schema files as you want and define paths to them using glob or array of globs syntax.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#schema
 *
 * ---
 * `out` - allows you to define the folder for your migrations and a folder, where drizzle will introspect the schema and relations
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#out
 *
 * ---
 * `driver` - optional param that is responsible for explicitly providing a driver to use when accessing a database
 * *Possible values*: `aws-data-api`, `d1-http`, `expo`, `turso`, `pglite`
 * If you don't use AWS Data API, D1, Turso or Expo - ypu don't need this driver. You can check a driver strategy choice here: https://orm.drizzle.team/kit-docs/upgrade-21
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#driver
 *
 * ---
 *
 * `dbCredentials` - an object to define your connection to the database. For more info please check the docs
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#dbcredentials
 *
 * ---
 *
 * `migrations` - param let’s you specify a custom table and schema(PostgreSQL only) for migrations.
 * By default, all information about executed migrations will be stored in the database inside
 * the `__drizzle_migrations` table, and for PostgreSQL, inside the drizzle schema.
 * However, you can configure where to store those records.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#migrations
 *
 * ---
 *
 * `breakpoints` - param lets you enable/disable SQL statement breakpoints in generated migrations.
 * It’s optional and true by default, it’s necessary to properly apply migrations on databases,
 * that do not support multiple DDL alternation statements in one transaction(MySQL, SQLite, SingleStore) and
 * Drizzle ORM has to apply them sequentially one by one.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#breakpoints
 *
 * ---
 *
 * `tablesFilters` - param lets you filter tables with glob syntax for db push command.
 * It’s useful when you have only one database avaialable for several separate projects with separate sql schemas.
 *
 * How to define multi-project tables with Drizzle ORM — see https://orm.drizzle.team/docs/goodies#multi-project-schema
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#tablesfilters
 *
 * ---
 *
 * `schemaFilter` - parameter allows you to define which schema in PostgreSQL should be used for either introspect or push commands.
 * This parameter accepts a single schema as a string or an array of schemas as strings.
 * No glob pattern is supported here. By default, drizzle will use the public schema for both commands,
 * but you can add any schema you need.
 *
 * For example, having schemaFilter: ["my_schema"] will only look for tables in both the database and
 * drizzle schema that are a part of the my_schema schema.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#schemafilter
 *
 * ---
 *
 * `verbose` - command is used for drizzle-kit push commands and prints all statements that will be executed.
 *
 * > Note: This command will only print the statements that should be executed.
 * To approve them before applying, please refer to the `strict` command.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#verbose
 *
 * ---
 *
 * `strict` - command is used for drizzle-kit push commands and will always ask for your confirmation,
 * either to execute all statements needed to sync your schema with the database or not.
 *
 * See https://orm.drizzle.team/kit-docs/config-reference#strict
 */
declare function defineConfig<TDialect extends Dialect, TDriver extends DialectDriverMap[TDialect] = 'default'>(config: Config<TDialect, TDriver>): Config<TDialect, TDriver>;
//#endregion
export { Config, ConfigVariant, DialectCredentials, DialectDriverMap, defineConfig };