//#region src/utils/schemaValidator.d.ts
declare const dialects: readonly ["postgresql", "mysql", "sqlite", "turso", "singlestore", "mssql", "cockroach", "duckdb"];
type Dialect = (typeof dialects)[number];
//#endregion
//#region src/cli/validations/common.d.ts
declare const drivers: readonly ["d1-http", "expo", "aws-data-api", "pglite", "durable-sqlite", "sqlite-cloud"];
type Driver = (typeof drivers)[number];
//#endregion
export { Dialect as n, Driver as t };