import { _ as ZodTypeAny, b as ZodUnion, d as ZodObject, f as ZodOptional, i as ZodBoolean, m as ZodString, r as ZodArray, t as TypeOf, u as ZodNumber } from "./types-OgqGmnkF.mjs";
//#region src/cli/validations/mysql.d.ts
declare const mysqlCredentials: ZodUnion<[ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>, ZodObject<{
  host: ZodString;
  port: ZodOptional<ZodNumber>;
  user: ZodOptional<ZodString>;
  password: ZodOptional<ZodString>;
  database: ZodString;
  ssl: ZodOptional<ZodUnion<[ZodString, ZodObject<{
    pfx: ZodOptional<ZodString>;
    key: ZodOptional<ZodString>;
    passphrase: ZodOptional<ZodString>;
    cert: ZodOptional<ZodString>;
    ca: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
    crl: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
    ciphers: ZodOptional<ZodString>;
    rejectUnauthorized: ZodOptional<ZodBoolean>;
  }, "strip", ZodTypeAny, {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  }, {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  }>]>>;
}, "strip", ZodTypeAny, {
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: string | {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  } | undefined;
}, {
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: string | {
    pfx?: string | undefined;
    key?: string | undefined;
    passphrase?: string | undefined;
    cert?: string | undefined;
    ca?: string | string[] | undefined;
    crl?: string | string[] | undefined;
    ciphers?: string | undefined;
    rejectUnauthorized?: boolean | undefined;
  } | undefined;
}>]>;
type MysqlCredentials = TypeOf<typeof mysqlCredentials>;
//#endregion
export { MysqlCredentials as t };