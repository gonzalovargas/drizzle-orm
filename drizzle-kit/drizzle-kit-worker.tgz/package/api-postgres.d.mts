import { n as MissingHint, t as Hint } from "./hints-By83v2-O.mjs";
import { t as EntitiesFilterConfig } from "./common-CslNwCIw.mjs";
import { t as PostgresSnapshot } from "./snapshot-vvjBNqUU.mjs";
import { t as PostgresCredentials } from "./postgres-DjECk2fw.mjs";
import { t as MissingHintsError } from "./errors-5EF0YvX8.mjs";
import { PGlite } from "@electric-sql/pglite";
import { PgAsyncDatabase } from "drizzle-orm/pg-core/async";

//#region src/ext/api-postgres.d.ts
declare const generateDrizzleJson: (imports: Record<string, unknown>, prevId?: string, schemaFilters?: string[]) => Promise<PostgresSnapshot>;
declare const generateMigration: (prev: PostgresSnapshot, cur: PostgresSnapshot, options?: {
  hints?: Hint[];
}) => Promise<string[]>;
declare const pushSchema: (imports: Record<string, unknown>, drizzleInstance: PgAsyncDatabase<any>, entitiesConfig?: EntitiesFilterConfig, migrationsConfig?: {
  table?: string;
  schema?: string;
}) => Promise<{
  sqlStatements: string[];
  hints: {
    hint: string;
    statement?: string;
  }[];
  apply: () => Promise<void>;
}>;
declare const startStudioServer: (imports: Record<string, unknown>, credentials: PostgresCredentials | {
  driver: "pglite";
  client: PGlite;
}, options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<void>;
declare const up: (it: Record<string, any>) => {
  snapshot: PostgresSnapshot;
  hints: string[];
};
//#endregion
export { type Hint, type MissingHint, type MissingHintsError, generateDrizzleJson, generateMigration, pushSchema, startStudioServer, up };