import { t as PostgresSchemaState } from "./snapshot-5g9UVAog.mjs";
import { t as EntitiesFilterConfig } from "./common-BwzqAd3Y.mjs";
import { n as MissingHint, t as Hint } from "./hints-DJq8W2Cc.mjs";
import { t as PostgresCredentials } from "./postgres-DGJS29rG.mjs";
import { t as MissingHintsError } from "./errors-Bs6lFKQd.mjs";
import { PgAsyncDatabase } from "drizzle-orm/pg-core/async";
//#region src/ext/api-postgres.d.ts
declare const generateDrizzleJson: (imports: Record<string, unknown>, prevId?: string, schemaFilters?: string[]) => Promise<PostgresSchemaState>;
declare const generateMigration: (prev: PostgresSchemaState | Record<string, any>, cur: PostgresSchemaState | Record<string, any>, options?: {
  hints?: Hint[];
}) => Promise<string[]>;
declare const pushSchema: (imports: Record<string, unknown>, drizzleInstance: PgAsyncDatabase<any>, entitiesConfig?: EntitiesFilterConfig, migrationsConfig?: {
  table?: string;
  schema?: string;
}, options?: {
  hints?: Hint[];
}) => Promise<{
  sqlStatements: string[];
  hints: {
    hint: string;
    statement?: string;
  }[];
  apply: () => Promise<void>;
}>;
declare const startStudioServer: (imports: Record<string, unknown>, credentials: PostgresCredentials, options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<void>;
declare const up: (it: Record<string, any>) => {
  snapshot: PostgresSchemaState;
  hints: string[];
};
declare const reconstruct: (files: Record<string, unknown>, id?: string) => Promise<PostgresSchemaState>;
//#endregion
export { type Hint, type MissingHint, type MissingHintsError, generateDrizzleJson, generateMigration, pushSchema, reconstruct, startStudioServer, up };