//#region src/cli/validations/sqlite.d.ts
type SqliteCredentials = {
  driver: 'd1-http';
  accountId: string;
  databaseId: string;
  token: string;
} | {
  driver: 'sqlite-cloud';
  url: string;
} | {
  url: string;
};
//#endregion
export { SqliteCredentials as t };