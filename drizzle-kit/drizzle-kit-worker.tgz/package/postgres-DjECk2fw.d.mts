import { _ as ZodUnion, c as ZodLiteral, d as ZodOptional, g as ZodUndefined, h as ZodTypeAny, i as ZodBoolean, l as ZodNumber, o as ZodEffects, p as ZodString, t as TypeOf, u as ZodObject, v as objectInputType, y as objectOutputType } from "./types-0NRiLQtx.mjs";

//#region src/cli/validations/postgres.d.ts
declare const postgresCredentials: ZodUnion<[ZodEffects<ZodObject<{
  driver: ZodUndefined;
  host: ZodString;
  port: ZodOptional<ZodNumber>;
  user: ZodOptional<ZodString>;
  password: ZodOptional<ZodString>;
  database: ZodString;
  ssl: ZodOptional<ZodUnion<[ZodLiteral<"require">, ZodLiteral<"allow">, ZodLiteral<"prefer">, ZodLiteral<"verify-full">, ZodBoolean, ZodObject<{}, "passthrough", ZodTypeAny, objectOutputType<{}, ZodTypeAny, "passthrough">, objectInputType<{}, ZodTypeAny, "passthrough">>]>>;
}, "strip", ZodTypeAny, {
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  driver?: undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | objectOutputType<{}, ZodTypeAny, "passthrough"> | undefined;
}, {
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  driver?: undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | objectInputType<{}, ZodTypeAny, "passthrough"> | undefined;
}>, Omit<{
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  driver?: undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | objectOutputType<{}, ZodTypeAny, "passthrough"> | undefined;
}, "driver">, {
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  driver?: undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | objectInputType<{}, ZodTypeAny, "passthrough"> | undefined;
}>, ZodEffects<ZodObject<{
  driver: ZodUndefined;
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
  driver?: undefined;
}, {
  url: string;
  driver?: undefined;
}>, {
  url: string;
}, {
  url: string;
  driver?: undefined;
}>, ZodObject<{
  driver: ZodLiteral<"aws-data-api">;
  database: ZodString;
  secretArn: ZodString;
  resourceArn: ZodString;
}, "strip", ZodTypeAny, {
  database: string;
  driver: "aws-data-api";
  secretArn: string;
  resourceArn: string;
}, {
  database: string;
  driver: "aws-data-api";
  secretArn: string;
  resourceArn: string;
}>, ZodObject<{
  driver: ZodLiteral<"pglite">;
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
  driver: "pglite";
}, {
  url: string;
  driver: "pglite";
}>]>;
type PostgresCredentials = TypeOf<typeof postgresCredentials>;
//#endregion
export { PostgresCredentials as t };