import { _ as ZodTypeAny, a as ZodDefault, d as ZodObject, f as ZodOptional, i as ZodBoolean, l as ZodLiteral, m as ZodString, n as ZodAny, p as ZodRecord, r as ZodArray, s as ZodEnum, t as TypeOf } from "./types-OgqGmnkF.mjs";
import { n as MissingHint, t as Hint } from "./hints-DJq8W2Cc.mjs";
import { t as MissingHintsError } from "./errors-Bs6lFKQd.mjs";
import { t as SqliteCredentials } from "./sqlite-ssnQ5YFh.mjs";
import { n as SQLiteClient } from "./index-yxkYOa2C.mjs";
//#region src/dialects/sqlite/snapshot.d.ts
declare const schemaV6: ZodObject<{
  version: ZodLiteral<"6">;
  dialect: ZodEnum<["sqlite"]>;
  tables: ZodRecord<ZodString, ZodObject<{
    name: ZodString;
    columns: ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      type: ZodString;
      typeSchema: ZodOptional<ZodString>;
      primaryKey: ZodBoolean;
      notNull: ZodBoolean;
      autoincrement: ZodOptional<ZodBoolean>;
      default: ZodOptional<ZodString>;
      generated: ZodOptional<ZodObject<{
        type: ZodEnum<["stored", "virtual"]>;
        as: ZodString;
      }, "strip", ZodTypeAny, {
        type: "virtual" | "stored";
        as: string;
      }, {
        type: "virtual" | "stored";
        as: string;
      }>>;
    }, "strict", ZodTypeAny, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>>;
    indexes: ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      columns: ZodArray<ZodString, "many">;
      where: ZodOptional<ZodString>;
      isUnique: ZodBoolean;
    }, "strict", ZodTypeAny, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }>>;
    foreignKeys: ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      tableFrom: ZodString;
      columnsFrom: ZodArray<ZodString, "many">;
      tableTo: ZodString;
      columnsTo: ZodArray<ZodString, "many">;
      onUpdate: ZodOptional<ZodString>;
      onDelete: ZodOptional<ZodString>;
    }, "strict", ZodTypeAny, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }>>;
    compositePrimaryKeys: ZodRecord<ZodString, ZodObject<{
      columns: ZodArray<ZodString, "many">;
      name: ZodOptional<ZodString>;
    }, "strict", ZodTypeAny, {
      columns: string[];
      name?: string | undefined;
    }, {
      columns: string[];
      name?: string | undefined;
    }>>;
    uniqueConstraints: ZodDefault<ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      columns: ZodArray<ZodString, "many">;
    }, "strict", ZodTypeAny, {
      name: string;
      columns: string[];
    }, {
      name: string;
      columns: string[];
    }>>>;
    checkConstraints: ZodDefault<ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      value: ZodString;
    }, "strict", ZodTypeAny, {
      name: string;
      value: string;
    }, {
      name: string;
      value: string;
    }>>>;
  }, "strict", ZodTypeAny, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    indexes: Record<string, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }>;
    foreignKeys: Record<string, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }>;
    compositePrimaryKeys: Record<string, {
      columns: string[];
      name?: string | undefined;
    }>;
    uniqueConstraints: Record<string, {
      name: string;
      columns: string[];
    }>;
    checkConstraints: Record<string, {
      name: string;
      value: string;
    }>;
  }, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    indexes: Record<string, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }>;
    foreignKeys: Record<string, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }>;
    compositePrimaryKeys: Record<string, {
      columns: string[];
      name?: string | undefined;
    }>;
    uniqueConstraints?: Record<string, {
      name: string;
      columns: string[];
    }> | undefined;
    checkConstraints?: Record<string, {
      name: string;
      value: string;
    }> | undefined;
  }>>;
  views: ZodDefault<ZodRecord<ZodString, ZodObject<{
    name: ZodString;
    columns: ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      type: ZodString;
      typeSchema: ZodOptional<ZodString>;
      primaryKey: ZodBoolean;
      notNull: ZodBoolean;
      autoincrement: ZodOptional<ZodBoolean>;
      default: ZodOptional<ZodString>;
      generated: ZodOptional<ZodObject<{
        type: ZodEnum<["stored", "virtual"]>;
        as: ZodString;
      }, "strip", ZodTypeAny, {
        type: "virtual" | "stored";
        as: string;
      }, {
        type: "virtual" | "stored";
        as: string;
      }>>;
    }, "strict", ZodTypeAny, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>>;
    definition: ZodOptional<ZodString>;
    isExisting: ZodBoolean;
  }, "strict", ZodTypeAny, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    isExisting: boolean;
    definition?: string | undefined;
  }, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    isExisting: boolean;
    definition?: string | undefined;
  }>>>;
  enums: ZodObject<{}, "strip", ZodTypeAny, {}, {}>;
  _meta: ZodObject<{
    tables: ZodRecord<ZodString, ZodString>;
    columns: ZodRecord<ZodString, ZodString>;
  }, "strip", ZodTypeAny, {
    tables: Record<string, string>;
    columns: Record<string, string>;
  }, {
    tables: Record<string, string>;
    columns: Record<string, string>;
  }>;
  internal: ZodAny;
} & {
  id: ZodString;
  prevId: ZodString;
}, "strict", ZodTypeAny, {
  version: "6";
  dialect: "sqlite";
  id: string;
  tables: Record<string, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    indexes: Record<string, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }>;
    foreignKeys: Record<string, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }>;
    compositePrimaryKeys: Record<string, {
      columns: string[];
      name?: string | undefined;
    }>;
    uniqueConstraints: Record<string, {
      name: string;
      columns: string[];
    }>;
    checkConstraints: Record<string, {
      name: string;
      value: string;
    }>;
  }>;
  views: Record<string, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    isExisting: boolean;
    definition?: string | undefined;
  }>;
  enums: {};
  _meta: {
    tables: Record<string, string>;
    columns: Record<string, string>;
  };
  prevId: string;
  internal?: any;
}, {
  version: "6";
  dialect: "sqlite";
  id: string;
  tables: Record<string, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    indexes: Record<string, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }>;
    foreignKeys: Record<string, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }>;
    compositePrimaryKeys: Record<string, {
      columns: string[];
      name?: string | undefined;
    }>;
    uniqueConstraints?: Record<string, {
      name: string;
      columns: string[];
    }> | undefined;
    checkConstraints?: Record<string, {
      name: string;
      value: string;
    }> | undefined;
  }>;
  enums: {};
  _meta: {
    tables: Record<string, string>;
    columns: Record<string, string>;
  };
  prevId: string;
  views?: Record<string, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    isExisting: boolean;
    definition?: string | undefined;
  }> | undefined;
  internal?: any;
}>;
type SQLiteSchemaV6 = TypeOf<typeof schemaV6>;
declare const snapshotValidator: {
  shape: {
    version: "7";
    dialect: "sqlite";
    id: string;
    prevIds: string[];
    ddl: ({
      name: string;
      entityType: "tables";
    } | {
      table: string;
      name: string;
      type: string;
      notNull: boolean;
      autoincrement: boolean | null;
      default: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      entityType: "columns";
    } | {
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      entityType: "pks";
    } | {
      table: string;
      name: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
      nameExplicit: boolean;
      entityType: "fks";
    } | {
      table: string;
      name: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      origin: "auto" | "manual";
      entityType: "indexes";
    } | {
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      entityType: "uniques";
    } | {
      table: string;
      name: string;
      value: string;
      entityType: "checks";
    } | {
      name: string;
      definition: string | null;
      isExisting: boolean;
      error: string | null;
      entityType: "views";
    })[];
    renames: string[];
  };
  parse: (obj: unknown) => {
    success: boolean;
    data: {
      version: "7";
      dialect: "sqlite";
      id: string;
      prevIds: string[];
      ddl: ({
        name: string;
        entityType: "tables";
      } | {
        table: string;
        name: string;
        type: string;
        notNull: boolean;
        autoincrement: boolean | null;
        default: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        entityType: "columns";
      } | {
        table: string;
        name: string;
        columns: string[];
        nameExplicit: boolean;
        entityType: "pks";
      } | {
        table: string;
        name: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: string;
        onDelete: string;
        nameExplicit: boolean;
        entityType: "fks";
      } | {
        table: string;
        name: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        origin: "auto" | "manual";
        entityType: "indexes";
      } | {
        table: string;
        name: string;
        columns: string[];
        nameExplicit: boolean;
        entityType: "uniques";
      } | {
        table: string;
        name: string;
        value: string;
        entityType: "checks";
      } | {
        name: string;
        definition: string | null;
        isExisting: boolean;
        error: string | null;
        entityType: "views";
      })[];
      renames: string[];
    } | null;
    errors?: string[] | undefined;
  };
  strict: (obj: unknown) => {
    version: "7";
    dialect: "sqlite";
    id: string;
    prevIds: string[];
    ddl: ({
      name: string;
      entityType: "tables";
    } | {
      table: string;
      name: string;
      type: string;
      notNull: boolean;
      autoincrement: boolean | null;
      default: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      entityType: "columns";
    } | {
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      entityType: "pks";
    } | {
      table: string;
      name: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
      nameExplicit: boolean;
      entityType: "fks";
    } | {
      table: string;
      name: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      origin: "auto" | "manual";
      entityType: "indexes";
    } | {
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      entityType: "uniques";
    } | {
      table: string;
      name: string;
      value: string;
      entityType: "checks";
    } | {
      name: string;
      definition: string | null;
      isExisting: boolean;
      error: string | null;
      entityType: "views";
    })[];
    renames: string[];
  };
};
type SqliteSnapshot = typeof snapshotValidator.shape;
//#endregion
//#region src/cli/commands/up-sqlite.d.ts
declare const updateToV7: (snapshot: SQLiteSchemaV6) => SqliteSnapshot;
//#endregion
//#region src/payload/sqlite.d.ts
declare const generateDrizzleJson: (imports: Record<string, unknown>, prevId?: string) => Promise<SqliteSnapshot>;
declare const generateMigration: (prev: SqliteSnapshot, cur: SqliteSnapshot, options?: {
  hints?: Hint[];
}) => Promise<string[]>;
declare const pushSchema: (imports: Record<string, unknown>, db: SQLiteClient, migrationsConfig?: {
  table?: string;
  schema?: string;
}, options?: {
  hints?: Hint[];
}) => Promise<{
  sqlStatements: string[];
  hints: {
    hint: string;
    statement?: string;
  }[];
  apply: () => Promise<void>;
}>;
declare const startStudioServer: (imports: Record<string, unknown>, credentials: SqliteCredentials | {
  driver: "d1";
  binding: D1Database;
}, options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<void>;
//#endregion
export { type Hint, type MissingHint, type MissingHintsError, generateDrizzleJson, generateMigration, pushSchema, startStudioServer, updateToV7 as up };