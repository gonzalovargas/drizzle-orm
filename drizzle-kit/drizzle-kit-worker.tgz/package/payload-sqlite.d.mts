import { a as ZodDefault, c as ZodLiteral, d as ZodOptional, f as ZodRecord, h as ZodTypeAny, i as ZodBoolean, n as ZodAny, p as ZodString, r as ZodArray, s as ZodEnum, t as TypeOf, u as ZodObject } from "./types-0NRiLQtx.mjs";
import { i as DiffStatement, n as MissingHint, r as Config, t as Hint } from "./hints-By83v2-O.mjs";
import { t as MissingHintsError } from "./errors-5EF0YvX8.mjs";
import { t as SqliteCredentials } from "./sqlite-BOa4sjzO.mjs";
import { n as SQLiteClient } from "./index-D5xy3jz2.mjs";

//#region src/dialects/sqlite/ddl.d.ts
declare const createDDL: () => {
  readonly _: {
    types: {
      tables: {
        name: string;
        entityType: "tables";
      };
      columns: {
        table: string;
        type: string;
        notNull: boolean;
        autoincrement: boolean | null;
        default: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
      indexes: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        origin: "auto" | "manual";
        name: string;
        entityType: "indexes";
      };
      fks: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: string;
        onDelete: string;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
      pks: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
      uniques: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "uniques";
      };
      checks: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      views: {
        definition: string | null;
        isExisting: boolean;
        error: string | null;
        name: string;
        entityType: "views";
      };
    };
    definition: {
      tables: {};
      columns: {
        table: "required";
        type: "string";
        notNull: "boolean";
        autoincrement: "boolean?";
        default: "string?";
        generated: {
          type: ["stored", "virtual"];
          as: "string";
        };
      };
      indexes: {
        table: "required";
        columns: [{
          value: "string";
          isExpression: "boolean";
        }];
        isUnique: "boolean";
        where: "string?";
        origin: ["manual", "auto"];
      };
      fks: {
        table: "required";
        columns: "string[]";
        tableTo: "string";
        columnsTo: "string[]";
        onUpdate: "string";
        onDelete: "string";
        nameExplicit: "boolean";
      };
      pks: {
        table: "required";
        columns: "string[]";
        nameExplicit: "boolean";
      };
      /**
       * Unique constraints and unique indexes are functionally identical in terms of behavior
       * We decided to keep both constraints and indexes because when a unique constraint is created
       * it cannot be removed, whereas an index can be dropped
       * Removing unique constraints would require recreating the table
       * Before the beta v1 all unique constraints were created and stored in snapshots as indexes
       * We do not have sufficient information for upping snapshots to beta v1
       */
      uniques: {
        table: "required";
        columns: "string[]";
        nameExplicit: "boolean";
      };
      checks: {
        table: "required";
        value: "string";
      };
      views: {
        definition: "string?";
        isExisting: "boolean";
        error: "string?";
      };
    };
    entities: {
      tables: Config;
      columns: Config;
      indexes: Config;
      fks: Config;
      pks: Config;
      uniques: Config;
      checks: Config;
      views: Config;
    };
    diffs: {
      alter: {
        tables: {
          $diffType: "alter";
          entityType: "tables";
          name: string;
          $left: {
            name: string;
            entityType: "tables";
          };
          $right: {
            name: string;
            entityType: "tables";
          };
        };
        columns: {
          $diffType: "alter";
          entityType: "columns";
          table: string;
          name: string;
          type?: {
            from: string;
            to: string;
          } | undefined;
          notNull?: {
            from: boolean;
            to: boolean;
          } | undefined;
          generated?: {
            from: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            to: {
              type: "virtual" | "stored";
              as: string;
            } | null;
          } | undefined;
          default?: {
            from: string | null;
            to: string | null;
          } | undefined;
          autoincrement?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          $left: {
            table: string;
            type: string;
            notNull: boolean;
            autoincrement: boolean | null;
            default: string | null;
            generated: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            name: string;
            entityType: "columns";
          };
          $right: {
            table: string;
            type: string;
            notNull: boolean;
            autoincrement: boolean | null;
            default: string | null;
            generated: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            name: string;
            entityType: "columns";
          };
        };
        pks: {
          $diffType: "alter";
          entityType: "pks";
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
          $right: {
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
        };
        fks: {
          $diffType: "alter";
          entityType: "fks";
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          tableTo?: {
            from: string;
            to: string;
          } | undefined;
          columnsTo?: {
            from: string[];
            to: string[];
          } | undefined;
          onUpdate?: {
            from: string;
            to: string;
          } | undefined;
          onDelete?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            table: string;
            columns: string[];
            tableTo: string;
            columnsTo: string[];
            onUpdate: string;
            onDelete: string;
            nameExplicit: boolean;
            name: string;
            entityType: "fks";
          };
          $right: {
            table: string;
            columns: string[];
            tableTo: string;
            columnsTo: string[];
            onUpdate: string;
            onDelete: string;
            nameExplicit: boolean;
            name: string;
            entityType: "fks";
          };
        };
        indexes: {
          $diffType: "alter";
          entityType: "indexes";
          table: string;
          name: string;
          columns?: {
            from: {
              value: string;
              isExpression: boolean;
            }[];
            to: {
              value: string;
              isExpression: boolean;
            }[];
          } | undefined;
          isUnique?: {
            from: boolean;
            to: boolean;
          } | undefined;
          where?: {
            from: string | null;
            to: string | null;
          } | undefined;
          origin?: {
            from: "auto" | "manual";
            to: "auto" | "manual";
          } | undefined;
          $left: {
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            where: string | null;
            origin: "auto" | "manual";
            name: string;
            entityType: "indexes";
          };
          $right: {
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            where: string | null;
            origin: "auto" | "manual";
            name: string;
            entityType: "indexes";
          };
        };
        uniques: {
          $diffType: "alter";
          entityType: "uniques";
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "uniques";
          };
          $right: {
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "uniques";
          };
        };
        checks: {
          $diffType: "alter";
          entityType: "checks";
          table: string;
          name: string;
          value?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
          $right: {
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
        };
        views: {
          $diffType: "alter";
          entityType: "views";
          name: string;
          definition?: {
            from: string | null;
            to: string | null;
          } | undefined;
          isExisting?: {
            from: boolean;
            to: boolean;
          } | undefined;
          error?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            definition: string | null;
            isExisting: boolean;
            error: string | null;
            name: string;
            entityType: "views";
          };
          $right: {
            definition: string | null;
            isExisting: boolean;
            error: string | null;
            name: string;
            entityType: "views";
          };
        };
        entities: {
          $diffType: "alter";
          entityType: "tables";
          name: string;
          $left: {
            name: string;
            entityType: "tables";
          };
          $right: {
            name: string;
            entityType: "tables";
          };
        } | {
          $diffType: "alter";
          entityType: "columns";
          table: string;
          name: string;
          type?: {
            from: string;
            to: string;
          } | undefined;
          notNull?: {
            from: boolean;
            to: boolean;
          } | undefined;
          generated?: {
            from: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            to: {
              type: "virtual" | "stored";
              as: string;
            } | null;
          } | undefined;
          default?: {
            from: string | null;
            to: string | null;
          } | undefined;
          autoincrement?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          $left: {
            table: string;
            type: string;
            notNull: boolean;
            autoincrement: boolean | null;
            default: string | null;
            generated: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            name: string;
            entityType: "columns";
          };
          $right: {
            table: string;
            type: string;
            notNull: boolean;
            autoincrement: boolean | null;
            default: string | null;
            generated: {
              type: "virtual" | "stored";
              as: string;
            } | null;
            name: string;
            entityType: "columns";
          };
        } | {
          $diffType: "alter";
          entityType: "pks";
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
          $right: {
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
        } | {
          $diffType: "alter";
          entityType: "fks";
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          tableTo?: {
            from: string;
            to: string;
          } | undefined;
          columnsTo?: {
            from: string[];
            to: string[];
          } | undefined;
          onUpdate?: {
            from: string;
            to: string;
          } | undefined;
          onDelete?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            table: string;
            columns: string[];
            tableTo: string;
            columnsTo: string[];
            onUpdate: string;
            onDelete: string;
            nameExplicit: boolean;
            name: string;
            entityType: "fks";
          };
          $right: {
            table: string;
            columns: string[];
            tableTo: string;
            columnsTo: string[];
            onUpdate: string;
            onDelete: string;
            nameExplicit: boolean;
            name: string;
            entityType: "fks";
          };
        } | {
          $diffType: "alter";
          entityType: "indexes";
          table: string;
          name: string;
          columns?: {
            from: {
              value: string;
              isExpression: boolean;
            }[];
            to: {
              value: string;
              isExpression: boolean;
            }[];
          } | undefined;
          isUnique?: {
            from: boolean;
            to: boolean;
          } | undefined;
          where?: {
            from: string | null;
            to: string | null;
          } | undefined;
          origin?: {
            from: "auto" | "manual";
            to: "auto" | "manual";
          } | undefined;
          $left: {
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            where: string | null;
            origin: "auto" | "manual";
            name: string;
            entityType: "indexes";
          };
          $right: {
            table: string;
            columns: {
              value: string;
              isExpression: boolean;
            }[];
            isUnique: boolean;
            where: string | null;
            origin: "auto" | "manual";
            name: string;
            entityType: "indexes";
          };
        } | {
          $diffType: "alter";
          entityType: "uniques";
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "uniques";
          };
          $right: {
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "uniques";
          };
        } | {
          $diffType: "alter";
          entityType: "checks";
          table: string;
          name: string;
          value?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
          $right: {
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
        } | {
          $diffType: "alter";
          entityType: "views";
          name: string;
          definition?: {
            from: string | null;
            to: string | null;
          } | undefined;
          isExisting?: {
            from: boolean;
            to: boolean;
          } | undefined;
          error?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            definition: string | null;
            isExisting: boolean;
            error: string | null;
            name: string;
            entityType: "views";
          };
          $right: {
            definition: string | null;
            isExisting: boolean;
            error: string | null;
            name: string;
            entityType: "views";
          };
        };
      };
      create: {
        tables: {
          $diffType: "create";
          entityType: "tables";
          name: string;
        };
        columns: {
          $diffType: "create";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoincrement: boolean | null;
        };
        pks: {
          $diffType: "create";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        fks: {
          $diffType: "create";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: string;
          onDelete: string;
        };
        indexes: {
          $diffType: "create";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
          origin: "auto" | "manual";
        };
        uniques: {
          $diffType: "create";
          entityType: "uniques";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        checks: {
          $diffType: "create";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        };
        views: {
          $diffType: "create";
          entityType: "views";
          name: string;
          definition: string | null;
          isExisting: boolean;
          error: string | null;
        };
        entities: {
          $diffType: "create";
          entityType: "tables";
          name: string;
        } | {
          $diffType: "create";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoincrement: boolean | null;
        } | {
          $diffType: "create";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: string;
          onDelete: string;
        } | {
          $diffType: "create";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
          origin: "auto" | "manual";
        } | {
          $diffType: "create";
          entityType: "uniques";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "create";
          entityType: "views";
          name: string;
          definition: string | null;
          isExisting: boolean;
          error: string | null;
        };
      };
      drop: {
        tables: {
          $diffType: "drop";
          entityType: "tables";
          name: string;
        };
        columns: {
          $diffType: "drop";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoincrement: boolean | null;
        };
        pks: {
          $diffType: "drop";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        fks: {
          $diffType: "drop";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: string;
          onDelete: string;
        };
        indexes: {
          $diffType: "drop";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
          origin: "auto" | "manual";
        };
        uniques: {
          $diffType: "drop";
          entityType: "uniques";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        checks: {
          $diffType: "drop";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        };
        views: {
          $diffType: "drop";
          entityType: "views";
          name: string;
          definition: string | null;
          isExisting: boolean;
          error: string | null;
        };
        entities: {
          $diffType: "drop";
          entityType: "tables";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoincrement: boolean | null;
        } | {
          $diffType: "drop";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: string;
          onDelete: string;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
          origin: "auto" | "manual";
        } | {
          $diffType: "drop";
          entityType: "uniques";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "views";
          name: string;
          definition: string | null;
          isExisting: boolean;
          error: string | null;
        };
      };
      createdrop: {
        tables: {
          $diffType: "create";
          entityType: "tables";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "tables";
          name: string;
        };
        columns: {
          $diffType: "create";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoincrement: boolean | null;
        } | {
          $diffType: "drop";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoincrement: boolean | null;
        };
        pks: {
          $diffType: "create";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        fks: {
          $diffType: "create";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: string;
          onDelete: string;
        } | {
          $diffType: "drop";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: string;
          onDelete: string;
        };
        indexes: {
          $diffType: "create";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
          origin: "auto" | "manual";
        } | {
          $diffType: "drop";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
          origin: "auto" | "manual";
        };
        uniques: {
          $diffType: "create";
          entityType: "uniques";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "uniques";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        checks: {
          $diffType: "create";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        };
        views: {
          $diffType: "create";
          entityType: "views";
          name: string;
          definition: string | null;
          isExisting: boolean;
          error: string | null;
        } | {
          $diffType: "drop";
          entityType: "views";
          name: string;
          definition: string | null;
          isExisting: boolean;
          error: string | null;
        };
        entities: ({
          $diffType: "create";
          entityType: "tables";
          name: string;
        } | {
          $diffType: "create";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoincrement: boolean | null;
        } | {
          $diffType: "create";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: string;
          onDelete: string;
        } | {
          $diffType: "create";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
          origin: "auto" | "manual";
        } | {
          $diffType: "create";
          entityType: "uniques";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "create";
          entityType: "views";
          name: string;
          definition: string | null;
          isExisting: boolean;
          error: string | null;
        }) | ({
          $diffType: "drop";
          entityType: "tables";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "columns";
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "virtual" | "stored";
            as: string;
          } | null;
          default: string | null;
          autoincrement: boolean | null;
        } | {
          $diffType: "drop";
          entityType: "pks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "fks";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          tableTo: string;
          columnsTo: string[];
          onUpdate: string;
          onDelete: string;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
          }[];
          isUnique: boolean;
          where: string | null;
          origin: "auto" | "manual";
        } | {
          $diffType: "drop";
          entityType: "uniques";
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "checks";
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "views";
          name: string;
          definition: string | null;
          isExisting: boolean;
          error: string | null;
        });
      };
      all: {
        tables: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoincrement: "boolean?";
            default: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
            origin: ["manual", "auto"];
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: "string";
            onDelete: "string";
            nameExplicit: "boolean";
          };
          pks: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          /**
           * Unique constraints and unique indexes are functionally identical in terms of behavior
           * We decided to keep both constraints and indexes because when a unique constraint is created
           * it cannot be removed, whereas an index can be dropped
           * Removing unique constraints would require recreating the table
           * Before the beta v1 all unique constraints were created and stored in snapshots as indexes
           * We do not have sufficient information for upping snapshots to beta v1
           */
          uniques: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string?";
            isExisting: "boolean";
            error: "string?";
          };
        }, "tables">;
        columns: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoincrement: "boolean?";
            default: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
            origin: ["manual", "auto"];
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: "string";
            onDelete: "string";
            nameExplicit: "boolean";
          };
          pks: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          /**
           * Unique constraints and unique indexes are functionally identical in terms of behavior
           * We decided to keep both constraints and indexes because when a unique constraint is created
           * it cannot be removed, whereas an index can be dropped
           * Removing unique constraints would require recreating the table
           * Before the beta v1 all unique constraints were created and stored in snapshots as indexes
           * We do not have sufficient information for upping snapshots to beta v1
           */
          uniques: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string?";
            isExisting: "boolean";
            error: "string?";
          };
        }, "columns">;
        pks: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoincrement: "boolean?";
            default: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
            origin: ["manual", "auto"];
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: "string";
            onDelete: "string";
            nameExplicit: "boolean";
          };
          pks: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          /**
           * Unique constraints and unique indexes are functionally identical in terms of behavior
           * We decided to keep both constraints and indexes because when a unique constraint is created
           * it cannot be removed, whereas an index can be dropped
           * Removing unique constraints would require recreating the table
           * Before the beta v1 all unique constraints were created and stored in snapshots as indexes
           * We do not have sufficient information for upping snapshots to beta v1
           */
          uniques: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string?";
            isExisting: "boolean";
            error: "string?";
          };
        }, "pks">;
        fks: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoincrement: "boolean?";
            default: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
            origin: ["manual", "auto"];
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: "string";
            onDelete: "string";
            nameExplicit: "boolean";
          };
          pks: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          /**
           * Unique constraints and unique indexes are functionally identical in terms of behavior
           * We decided to keep both constraints and indexes because when a unique constraint is created
           * it cannot be removed, whereas an index can be dropped
           * Removing unique constraints would require recreating the table
           * Before the beta v1 all unique constraints were created and stored in snapshots as indexes
           * We do not have sufficient information for upping snapshots to beta v1
           */
          uniques: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string?";
            isExisting: "boolean";
            error: "string?";
          };
        }, "fks">;
        indexes: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoincrement: "boolean?";
            default: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
            origin: ["manual", "auto"];
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: "string";
            onDelete: "string";
            nameExplicit: "boolean";
          };
          pks: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          /**
           * Unique constraints and unique indexes are functionally identical in terms of behavior
           * We decided to keep both constraints and indexes because when a unique constraint is created
           * it cannot be removed, whereas an index can be dropped
           * Removing unique constraints would require recreating the table
           * Before the beta v1 all unique constraints were created and stored in snapshots as indexes
           * We do not have sufficient information for upping snapshots to beta v1
           */
          uniques: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string?";
            isExisting: "boolean";
            error: "string?";
          };
        }, "indexes">;
        uniques: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoincrement: "boolean?";
            default: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
            origin: ["manual", "auto"];
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: "string";
            onDelete: "string";
            nameExplicit: "boolean";
          };
          pks: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          /**
           * Unique constraints and unique indexes are functionally identical in terms of behavior
           * We decided to keep both constraints and indexes because when a unique constraint is created
           * it cannot be removed, whereas an index can be dropped
           * Removing unique constraints would require recreating the table
           * Before the beta v1 all unique constraints were created and stored in snapshots as indexes
           * We do not have sufficient information for upping snapshots to beta v1
           */
          uniques: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string?";
            isExisting: "boolean";
            error: "string?";
          };
        }, "uniques">;
        checks: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoincrement: "boolean?";
            default: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
            origin: ["manual", "auto"];
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: "string";
            onDelete: "string";
            nameExplicit: "boolean";
          };
          pks: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          /**
           * Unique constraints and unique indexes are functionally identical in terms of behavior
           * We decided to keep both constraints and indexes because when a unique constraint is created
           * it cannot be removed, whereas an index can be dropped
           * Removing unique constraints would require recreating the table
           * Before the beta v1 all unique constraints were created and stored in snapshots as indexes
           * We do not have sufficient information for upping snapshots to beta v1
           */
          uniques: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string?";
            isExisting: "boolean";
            error: "string?";
          };
        }, "checks">;
        views: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoincrement: "boolean?";
            default: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
            origin: ["manual", "auto"];
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: "string";
            onDelete: "string";
            nameExplicit: "boolean";
          };
          pks: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          /**
           * Unique constraints and unique indexes are functionally identical in terms of behavior
           * We decided to keep both constraints and indexes because when a unique constraint is created
           * it cannot be removed, whereas an index can be dropped
           * Removing unique constraints would require recreating the table
           * Before the beta v1 all unique constraints were created and stored in snapshots as indexes
           * We do not have sufficient information for upping snapshots to beta v1
           */
          uniques: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string?";
            isExisting: "boolean";
            error: "string?";
          };
        }, "views">;
        entities: DiffStatement<{
          tables: {};
          columns: {
            table: "required";
            type: "string";
            notNull: "boolean";
            autoincrement: "boolean?";
            default: "string?";
            generated: {
              type: ["stored", "virtual"];
              as: "string";
            };
          };
          indexes: {
            table: "required";
            columns: [{
              value: "string";
              isExpression: "boolean";
            }];
            isUnique: "boolean";
            where: "string?";
            origin: ["manual", "auto"];
          };
          fks: {
            table: "required";
            columns: "string[]";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: "string";
            onDelete: "string";
            nameExplicit: "boolean";
          };
          pks: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          /**
           * Unique constraints and unique indexes are functionally identical in terms of behavior
           * We decided to keep both constraints and indexes because when a unique constraint is created
           * it cannot be removed, whereas an index can be dropped
           * Removing unique constraints would require recreating the table
           * Before the beta v1 all unique constraints were created and stored in snapshots as indexes
           * We do not have sufficient information for upping snapshots to beta v1
           */
          uniques: {
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          checks: {
            table: "required";
            value: "string";
          };
          views: {
            definition: "string?";
            isExisting: "boolean";
            error: "string?";
          };
        }, "entities">;
      };
    };
    store: {
      collection: Record<string, any>[];
    };
  };
  entities: {
    push: (input: {
      name: string;
      entityType: "tables";
    } | {
      autoincrement: boolean | null | undefined;
      default: string | null | undefined;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      table: string;
      type: string;
      notNull: boolean;
      name: string;
      entityType: "columns";
    } | {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | {
      where: string | null | undefined;
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      origin: "auto" | "manual";
      name: string;
      entityType: "indexes";
    } | {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "uniques";
    } | {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      definition: string | null | undefined;
      error: string | null | undefined;
      isExisting: boolean;
      name: string;
      entityType: "views";
    }, uniques?: "name"[] | ("table" | "name" | "columns" | "nameExplicit" | "tableTo" | "columnsTo" | "onUpdate" | "onDelete")[] | ("table" | "name" | "value")[] | ("table" | "name" | "type" | "notNull" | "generated" | "default" | "autoincrement")[] | ("table" | "name" | "columns" | "nameExplicit")[] | ("table" | "name" | "columns" | "isUnique" | "where" | "origin")[] | ("name" | "definition" | "isExisting" | "error")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "tables";
      } | {
        table: string;
        type: string;
        notNull: boolean;
        autoincrement: boolean | null;
        default: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      } | {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      } | {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: string;
        onDelete: string;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      } | {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        origin: "auto" | "manual";
        name: string;
        entityType: "indexes";
      } | {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "uniques";
      } | {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      } | {
        definition: string | null;
        isExisting: boolean;
        error: string | null;
        name: string;
        entityType: "views";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: ({
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoincrement?: boolean | null | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      origin?: "auto" | "manual" | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      definition?: string | null | undefined;
      isExisting?: boolean | undefined;
      error?: string | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    }) | undefined) => ({
      name: string;
      entityType: "tables";
    } | {
      table: string;
      type: string;
      notNull: boolean;
      autoincrement: boolean | null;
      default: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      origin: "auto" | "manual";
      name: string;
      entityType: "indexes";
    } | {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "uniques";
    } | {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      definition: string | null;
      isExisting: boolean;
      error: string | null;
      name: string;
      entityType: "views";
    })[];
    one: (where?: ({
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoincrement?: boolean | null | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      origin?: "auto" | "manual" | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      definition?: string | null | undefined;
      isExisting?: boolean | undefined;
      error?: string | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    }) | undefined) => {
      name: string;
      entityType: "tables";
    } | {
      table: string;
      type: string;
      notNull: boolean;
      autoincrement: boolean | null;
      default: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      origin: "auto" | "manual";
      name: string;
      entityType: "indexes";
    } | {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "uniques";
    } | {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      definition: string | null;
      isExisting: boolean;
      error: string | null;
      name: string;
      entityType: "views";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        name?: string | undefined;
        entityType?: "tables" | undefined;
      } | undefined;
    } | {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: string | ((item: string) => string) | undefined;
        notNull?: boolean | ((item: boolean) => boolean) | undefined;
        generated?: {
          type: "virtual" | "stored";
          as: string;
        } | ((item: {
          type: "virtual" | "stored";
          as: string;
        } | null) => {
          type: "virtual" | "stored";
          as: string;
        } | null) | null | undefined;
        default?: string | ((item: string | null) => string | null) | null | undefined;
        autoincrement?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
      };
      where?: {
        table?: string | undefined;
        type?: string | undefined;
        notNull?: boolean | undefined;
        autoincrement?: boolean | null | undefined;
        default?: string | null | undefined;
        generated?: {
          type: "virtual" | "stored";
          as: string;
        } | null | undefined;
        name?: string | undefined;
        entityType?: "columns" | undefined;
      } | undefined;
    } | {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "pks" | undefined;
      } | undefined;
    } | {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        tableTo?: string | ((item: string) => string) | undefined;
        columnsTo?: string[] | ((item: string) => string) | undefined;
        onUpdate?: string | ((item: string) => string) | undefined;
        onDelete?: string | ((item: string) => string) | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        tableTo?: string | undefined;
        columnsTo?: string[] | {
          CONTAINS: string;
        } | undefined;
        onUpdate?: string | undefined;
        onDelete?: string | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "fks" | undefined;
      } | undefined;
    } | {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | ((item: {
          value: string;
          isExpression: boolean;
        }) => {
          value: string;
          isExpression: boolean;
        }) | undefined;
        isUnique?: boolean | ((item: boolean) => boolean) | undefined;
        where?: string | ((item: string | null) => string | null) | null | undefined;
        origin?: "auto" | "manual" | ((item: "auto" | "manual") => "auto" | "manual") | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | {
          CONTAINS: {
            value: string;
            isExpression: boolean;
          };
        } | undefined;
        isUnique?: boolean | undefined;
        where?: string | null | undefined;
        origin?: "auto" | "manual" | undefined;
        name?: string | undefined;
        entityType?: "indexes" | undefined;
      } | undefined;
    } | {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "uniques" | undefined;
      } | undefined;
    } | {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        value?: string | ((item: string) => string) | undefined;
      };
      where?: {
        table?: string | undefined;
        value?: string | undefined;
        name?: string | undefined;
        entityType?: "checks" | undefined;
      } | undefined;
    } | {
      set: {
        name?: string | ((item: string) => string) | undefined;
        definition?: string | ((item: string | null) => string | null) | null | undefined;
        isExisting?: boolean | ((item: boolean) => boolean) | undefined;
        error?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        definition?: string | null | undefined;
        isExisting?: boolean | undefined;
        error?: string | null | undefined;
        name?: string | undefined;
        entityType?: "views" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: ({
        name: string;
        entityType: "tables";
      } | {
        table: string;
        type: string;
        notNull: boolean;
        autoincrement: boolean | null;
        default: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      } | {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      } | {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: string;
        onDelete: string;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      } | {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        origin: "auto" | "manual";
        name: string;
        entityType: "indexes";
      } | {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "uniques";
      } | {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      } | {
        definition: string | null;
        isExisting: boolean;
        error: string | null;
        name: string;
        entityType: "views";
      })[];
    };
    delete: (where?: {
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoincrement?: boolean | null | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      origin?: "auto" | "manual" | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      definition?: string | null | undefined;
      isExisting?: boolean | undefined;
      error?: string | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => ({
      name: string;
      entityType: "tables";
    } | {
      table: string;
      type: string;
      notNull: boolean;
      autoincrement: boolean | null;
      default: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      origin: "auto" | "manual";
      name: string;
      entityType: "indexes";
    } | {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "uniques";
    } | {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      definition: string | null;
      isExisting: boolean;
      error: string | null;
      name: string;
      entityType: "views";
    })[];
    validate: (data: unknown) => data is {
      name: string;
      entityType: "tables";
    } | {
      table: string;
      type: string;
      notNull: boolean;
      autoincrement: boolean | null;
      default: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      origin: "auto" | "manual";
      name: string;
      entityType: "indexes";
    } | {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "uniques";
    } | {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      definition: string | null;
      isExisting: boolean;
      error: string | null;
      name: string;
      entityType: "views";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "tables";
      name: string;
      $left: {
        name: string;
        entityType: "tables";
      };
      $right: {
        name: string;
        entityType: "tables";
      };
    } | {
      $diffType: "alter";
      entityType: "columns";
      table: string;
      name: string;
      type?: {
        from: string;
        to: string;
      } | undefined;
      notNull?: {
        from: boolean;
        to: boolean;
      } | undefined;
      generated?: {
        from: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        to: {
          type: "virtual" | "stored";
          as: string;
        } | null;
      } | undefined;
      default?: {
        from: string | null;
        to: string | null;
      } | undefined;
      autoincrement?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      $left: {
        table: string;
        type: string;
        notNull: boolean;
        autoincrement: boolean | null;
        default: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
      $right: {
        table: string;
        type: string;
        notNull: boolean;
        autoincrement: boolean | null;
        default: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
    } | {
      $diffType: "alter";
      entityType: "pks";
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
      $right: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
    } | {
      $diffType: "alter";
      entityType: "fks";
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      tableTo?: {
        from: string;
        to: string;
      } | undefined;
      columnsTo?: {
        from: string[];
        to: string[];
      } | undefined;
      onUpdate?: {
        from: string;
        to: string;
      } | undefined;
      onDelete?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: string;
        onDelete: string;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
      $right: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: string;
        onDelete: string;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
    } | {
      $diffType: "alter";
      entityType: "indexes";
      table: string;
      name: string;
      columns?: {
        from: {
          value: string;
          isExpression: boolean;
        }[];
        to: {
          value: string;
          isExpression: boolean;
        }[];
      } | undefined;
      isUnique?: {
        from: boolean;
        to: boolean;
      } | undefined;
      where?: {
        from: string | null;
        to: string | null;
      } | undefined;
      origin?: {
        from: "auto" | "manual";
        to: "auto" | "manual";
      } | undefined;
      $left: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        origin: "auto" | "manual";
        name: string;
        entityType: "indexes";
      };
      $right: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        origin: "auto" | "manual";
        name: string;
        entityType: "indexes";
      };
    } | {
      $diffType: "alter";
      entityType: "uniques";
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "uniques";
      };
      $right: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "uniques";
      };
    } | {
      $diffType: "alter";
      entityType: "checks";
      table: string;
      name: string;
      value?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      $right: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    } | {
      $diffType: "alter";
      entityType: "views";
      name: string;
      definition?: {
        from: string | null;
        to: string | null;
      } | undefined;
      isExisting?: {
        from: boolean;
        to: boolean;
      } | undefined;
      error?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        definition: string | null;
        isExisting: boolean;
        error: string | null;
        name: string;
        entityType: "views";
      };
      $right: {
        definition: string | null;
        isExisting: boolean;
        error: string | null;
        name: string;
        entityType: "views";
      };
    }) => boolean;
  };
  tables: {
    push: (input: {
      name: string;
    }, uniques?: "name"[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "tables";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      name: string;
      entityType: "tables";
    }[];
    one: (where?: {
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      name: string;
      entityType: "tables";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        name?: string | undefined;
        entityType?: "tables" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "tables";
      }[];
    };
    delete: (where?: {
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      name: string;
      entityType: "tables";
    }[];
    validate: (data: unknown) => data is {
      name: string;
      entityType: "tables";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "tables";
      name: string;
      $left: {
        name: string;
        entityType: "tables";
      };
      $right: {
        name: string;
        entityType: "tables";
      };
    }) => boolean;
  };
  columns: {
    push: (input: {
      table: string;
      name: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      default: string | null | undefined;
      autoincrement: boolean | null | undefined;
    }, uniques?: ("table" | "name" | "type" | "notNull" | "generated" | "default" | "autoincrement")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        type: string;
        notNull: boolean;
        autoincrement: boolean | null;
        default: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoincrement?: boolean | null | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      table: string;
      type: string;
      notNull: boolean;
      autoincrement: boolean | null;
      default: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    }[];
    one: (where?: {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoincrement?: boolean | null | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      table: string;
      type: string;
      notNull: boolean;
      autoincrement: boolean | null;
      default: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    } | null;
    update: (config: {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: string | ((item: string) => string) | undefined;
        notNull?: boolean | ((item: boolean) => boolean) | undefined;
        generated?: {
          type: "virtual" | "stored";
          as: string;
        } | ((item: {
          type: "virtual" | "stored";
          as: string;
        } | null) => {
          type: "virtual" | "stored";
          as: string;
        } | null) | null | undefined;
        default?: string | ((item: string | null) => string | null) | null | undefined;
        autoincrement?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
      };
      where?: {
        table?: string | undefined;
        type?: string | undefined;
        notNull?: boolean | undefined;
        autoincrement?: boolean | null | undefined;
        default?: string | null | undefined;
        generated?: {
          type: "virtual" | "stored";
          as: string;
        } | null | undefined;
        name?: string | undefined;
        entityType?: "columns" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        type: string;
        notNull: boolean;
        autoincrement: boolean | null;
        default: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      }[];
    };
    delete: (where?: {
      table?: string | undefined;
      type?: string | undefined;
      notNull?: boolean | undefined;
      autoincrement?: boolean | null | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      table: string;
      type: string;
      notNull: boolean;
      autoincrement: boolean | null;
      default: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    }[];
    validate: (data: unknown) => data is {
      table: string;
      type: string;
      notNull: boolean;
      autoincrement: boolean | null;
      default: string | null;
      generated: {
        type: "virtual" | "stored";
        as: string;
      } | null;
      name: string;
      entityType: "columns";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "columns";
      table: string;
      name: string;
      type?: {
        from: string;
        to: string;
      } | undefined;
      notNull?: {
        from: boolean;
        to: boolean;
      } | undefined;
      generated?: {
        from: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        to: {
          type: "virtual" | "stored";
          as: string;
        } | null;
      } | undefined;
      default?: {
        from: string | null;
        to: string | null;
      } | undefined;
      autoincrement?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      $left: {
        table: string;
        type: string;
        notNull: boolean;
        autoincrement: boolean | null;
        default: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
      $right: {
        table: string;
        type: string;
        notNull: boolean;
        autoincrement: boolean | null;
        default: string | null;
        generated: {
          type: "virtual" | "stored";
          as: string;
        } | null;
        name: string;
        entityType: "columns";
      };
    }) => boolean;
  };
  indexes: {
    push: (input: {
      table: string;
      name: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null | undefined;
      origin: "auto" | "manual";
    }, uniques?: ("table" | "name" | "columns" | "isUnique" | "where" | "origin")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        origin: "auto" | "manual";
        name: string;
        entityType: "indexes";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      origin?: "auto" | "manual" | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      origin: "auto" | "manual";
      name: string;
      entityType: "indexes";
    }[];
    one: (where?: {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      origin?: "auto" | "manual" | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      origin: "auto" | "manual";
      name: string;
      entityType: "indexes";
    } | null;
    update: (config: {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | ((item: {
          value: string;
          isExpression: boolean;
        }) => {
          value: string;
          isExpression: boolean;
        }) | undefined;
        isUnique?: boolean | ((item: boolean) => boolean) | undefined;
        where?: string | ((item: string | null) => string | null) | null | undefined;
        origin?: "auto" | "manual" | ((item: "auto" | "manual") => "auto" | "manual") | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
        }[] | {
          CONTAINS: {
            value: string;
            isExpression: boolean;
          };
        } | undefined;
        isUnique?: boolean | undefined;
        where?: string | null | undefined;
        origin?: "auto" | "manual" | undefined;
        name?: string | undefined;
        entityType?: "indexes" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        origin: "auto" | "manual";
        name: string;
        entityType: "indexes";
      }[];
    };
    delete: (where?: {
      table?: string | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      origin?: "auto" | "manual" | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      origin: "auto" | "manual";
      name: string;
      entityType: "indexes";
    }[];
    validate: (data: unknown) => data is {
      table: string;
      columns: {
        value: string;
        isExpression: boolean;
      }[];
      isUnique: boolean;
      where: string | null;
      origin: "auto" | "manual";
      name: string;
      entityType: "indexes";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "indexes";
      table: string;
      name: string;
      columns?: {
        from: {
          value: string;
          isExpression: boolean;
        }[];
        to: {
          value: string;
          isExpression: boolean;
        }[];
      } | undefined;
      isUnique?: {
        from: boolean;
        to: boolean;
      } | undefined;
      where?: {
        from: string | null;
        to: string | null;
      } | undefined;
      origin?: {
        from: "auto" | "manual";
        to: "auto" | "manual";
      } | undefined;
      $left: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        origin: "auto" | "manual";
        name: string;
        entityType: "indexes";
      };
      $right: {
        table: string;
        columns: {
          value: string;
          isExpression: boolean;
        }[];
        isUnique: boolean;
        where: string | null;
        origin: "auto" | "manual";
        name: string;
        entityType: "indexes";
      };
    }) => boolean;
  };
  fks: {
    push: (input: {
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
    }, uniques?: ("table" | "name" | "columns" | "nameExplicit" | "tableTo" | "columnsTo" | "onUpdate" | "onDelete")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: string;
        onDelete: string;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    }[];
    one: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    } | null;
    update: (config: {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        tableTo?: string | ((item: string) => string) | undefined;
        columnsTo?: string[] | ((item: string) => string) | undefined;
        onUpdate?: string | ((item: string) => string) | undefined;
        onDelete?: string | ((item: string) => string) | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        tableTo?: string | undefined;
        columnsTo?: string[] | {
          CONTAINS: string;
        } | undefined;
        onUpdate?: string | undefined;
        onDelete?: string | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "fks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: string;
        onDelete: string;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      }[];
    };
    delete: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    }[];
    validate: (data: unknown) => data is {
      table: string;
      columns: string[];
      tableTo: string;
      columnsTo: string[];
      onUpdate: string;
      onDelete: string;
      nameExplicit: boolean;
      name: string;
      entityType: "fks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "fks";
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      tableTo?: {
        from: string;
        to: string;
      } | undefined;
      columnsTo?: {
        from: string[];
        to: string[];
      } | undefined;
      onUpdate?: {
        from: string;
        to: string;
      } | undefined;
      onDelete?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: string;
        onDelete: string;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
      $right: {
        table: string;
        columns: string[];
        tableTo: string;
        columnsTo: string[];
        onUpdate: string;
        onDelete: string;
        nameExplicit: boolean;
        name: string;
        entityType: "fks";
      };
    }) => boolean;
  };
  pks: {
    push: (input: {
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
    }, uniques?: ("table" | "name" | "columns" | "nameExplicit")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    }[];
    one: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | null;
    update: (config: {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "pks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      }[];
    };
    delete: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    }[];
    validate: (data: unknown) => data is {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "pks";
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
      $right: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
    }) => boolean;
  };
  uniques: {
    push: (input: {
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
    }, uniques?: ("table" | "name" | "columns" | "nameExplicit")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "uniques";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "uniques";
    }[];
    one: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "uniques";
    } | null;
    update: (config: {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "uniques" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "uniques";
      }[];
    };
    delete: (where?: {
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "uniques";
    }[];
    validate: (data: unknown) => data is {
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "uniques";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "uniques";
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "uniques";
      };
      $right: {
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "uniques";
      };
    }) => boolean;
  };
  checks: {
    push: (input: {
      table: string;
      name: string;
      value: string;
    }, uniques?: ("table" | "name" | "value")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    }[];
    one: (where?: {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | null;
    update: (config: {
      set: {
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        value?: string | ((item: string) => string) | undefined;
      };
      where?: {
        table?: string | undefined;
        value?: string | undefined;
        name?: string | undefined;
        entityType?: "checks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      }[];
    };
    delete: (where?: {
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    }[];
    validate: (data: unknown) => data is {
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "checks";
      table: string;
      name: string;
      value?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      $right: {
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    }) => boolean;
  };
  views: {
    push: (input: {
      name: string;
      definition: string | null | undefined;
      isExisting: boolean;
      error: string | null | undefined;
    }, uniques?: ("name" | "definition" | "isExisting" | "error")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        definition: string | null;
        isExisting: boolean;
        error: string | null;
        name: string;
        entityType: "views";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      definition?: string | null | undefined;
      isExisting?: boolean | undefined;
      error?: string | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      definition: string | null;
      isExisting: boolean;
      error: string | null;
      name: string;
      entityType: "views";
    }[];
    one: (where?: {
      definition?: string | null | undefined;
      isExisting?: boolean | undefined;
      error?: string | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      definition: string | null;
      isExisting: boolean;
      error: string | null;
      name: string;
      entityType: "views";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
        definition?: string | ((item: string | null) => string | null) | null | undefined;
        isExisting?: boolean | ((item: boolean) => boolean) | undefined;
        error?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        definition?: string | null | undefined;
        isExisting?: boolean | undefined;
        error?: string | null | undefined;
        name?: string | undefined;
        entityType?: "views" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        definition: string | null;
        isExisting: boolean;
        error: string | null;
        name: string;
        entityType: "views";
      }[];
    };
    delete: (where?: {
      definition?: string | null | undefined;
      isExisting?: boolean | undefined;
      error?: string | null | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      definition: string | null;
      isExisting: boolean;
      error: string | null;
      name: string;
      entityType: "views";
    }[];
    validate: (data: unknown) => data is {
      definition: string | null;
      isExisting: boolean;
      error: string | null;
      name: string;
      entityType: "views";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "views";
      name: string;
      definition?: {
        from: string | null;
        to: string | null;
      } | undefined;
      isExisting?: {
        from: boolean;
        to: boolean;
      } | undefined;
      error?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        definition: string | null;
        isExisting: boolean;
        error: string | null;
        name: string;
        entityType: "views";
      };
      $right: {
        definition: string | null;
        isExisting: boolean;
        error: string | null;
        name: string;
        entityType: "views";
      };
    }) => boolean;
  };
};
type SQLiteDDL = ReturnType<typeof createDDL>;
type SqliteEntities = SQLiteDDL['_']['types'];
type SqliteEntity = SqliteEntities[keyof SqliteEntities];
//#endregion
//#region src/dialects/sqlite/snapshot.d.ts
declare const schemaV6: ZodObject<{
  version: ZodLiteral<"6">;
  dialect: ZodEnum<["sqlite"]>;
  tables: ZodRecord<ZodString, ZodObject<{
    name: ZodString;
    columns: ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      type: ZodString;
      typeSchema: ZodOptional<ZodString>;
      primaryKey: ZodBoolean;
      notNull: ZodBoolean;
      autoincrement: ZodOptional<ZodBoolean>;
      default: ZodOptional<ZodString>;
      generated: ZodOptional<ZodObject<{
        type: ZodEnum<["stored", "virtual"]>;
        as: ZodString;
      }, "strip", ZodTypeAny, {
        type: "virtual" | "stored";
        as: string;
      }, {
        type: "virtual" | "stored";
        as: string;
      }>>;
    }, "strict", ZodTypeAny, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>>;
    indexes: ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      columns: ZodArray<ZodString, "many">;
      where: ZodOptional<ZodString>;
      isUnique: ZodBoolean;
    }, "strict", ZodTypeAny, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }>>;
    foreignKeys: ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      tableFrom: ZodString;
      columnsFrom: ZodArray<ZodString, "many">;
      tableTo: ZodString;
      columnsTo: ZodArray<ZodString, "many">;
      onUpdate: ZodOptional<ZodString>;
      onDelete: ZodOptional<ZodString>;
    }, "strict", ZodTypeAny, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }>>;
    compositePrimaryKeys: ZodRecord<ZodString, ZodObject<{
      columns: ZodArray<ZodString, "many">;
      name: ZodOptional<ZodString>;
    }, "strict", ZodTypeAny, {
      columns: string[];
      name?: string | undefined;
    }, {
      columns: string[];
      name?: string | undefined;
    }>>;
    uniqueConstraints: ZodDefault<ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      columns: ZodArray<ZodString, "many">;
    }, "strict", ZodTypeAny, {
      name: string;
      columns: string[];
    }, {
      name: string;
      columns: string[];
    }>>>;
    checkConstraints: ZodDefault<ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      value: ZodString;
    }, "strict", ZodTypeAny, {
      name: string;
      value: string;
    }, {
      name: string;
      value: string;
    }>>>;
  }, "strict", ZodTypeAny, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    indexes: Record<string, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }>;
    foreignKeys: Record<string, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }>;
    compositePrimaryKeys: Record<string, {
      columns: string[];
      name?: string | undefined;
    }>;
    uniqueConstraints: Record<string, {
      name: string;
      columns: string[];
    }>;
    checkConstraints: Record<string, {
      name: string;
      value: string;
    }>;
  }, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    indexes: Record<string, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }>;
    foreignKeys: Record<string, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }>;
    compositePrimaryKeys: Record<string, {
      columns: string[];
      name?: string | undefined;
    }>;
    uniqueConstraints?: Record<string, {
      name: string;
      columns: string[];
    }> | undefined;
    checkConstraints?: Record<string, {
      name: string;
      value: string;
    }> | undefined;
  }>>;
  views: ZodDefault<ZodRecord<ZodString, ZodObject<{
    name: ZodString;
    columns: ZodRecord<ZodString, ZodObject<{
      name: ZodString;
      type: ZodString;
      typeSchema: ZodOptional<ZodString>;
      primaryKey: ZodBoolean;
      notNull: ZodBoolean;
      autoincrement: ZodOptional<ZodBoolean>;
      default: ZodOptional<ZodString>;
      generated: ZodOptional<ZodObject<{
        type: ZodEnum<["stored", "virtual"]>;
        as: ZodString;
      }, "strip", ZodTypeAny, {
        type: "virtual" | "stored";
        as: string;
      }, {
        type: "virtual" | "stored";
        as: string;
      }>>;
    }, "strict", ZodTypeAny, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>>;
    definition: ZodOptional<ZodString>;
    isExisting: ZodBoolean;
  }, "strict", ZodTypeAny, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    isExisting: boolean;
    definition?: string | undefined;
  }, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    isExisting: boolean;
    definition?: string | undefined;
  }>>>;
  enums: ZodObject<{}, "strip", ZodTypeAny, {}, {}>;
  _meta: ZodObject<{
    tables: ZodRecord<ZodString, ZodString>;
    columns: ZodRecord<ZodString, ZodString>;
  }, "strip", ZodTypeAny, {
    tables: Record<string, string>;
    columns: Record<string, string>;
  }, {
    tables: Record<string, string>;
    columns: Record<string, string>;
  }>;
  internal: ZodAny;
} & {
  id: ZodString;
  prevId: ZodString;
}, "strict", ZodTypeAny, {
  version: "6";
  dialect: "sqlite";
  id: string;
  tables: Record<string, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    indexes: Record<string, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }>;
    foreignKeys: Record<string, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }>;
    compositePrimaryKeys: Record<string, {
      columns: string[];
      name?: string | undefined;
    }>;
    uniqueConstraints: Record<string, {
      name: string;
      columns: string[];
    }>;
    checkConstraints: Record<string, {
      name: string;
      value: string;
    }>;
  }>;
  views: Record<string, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    isExisting: boolean;
    definition?: string | undefined;
  }>;
  enums: {};
  _meta: {
    tables: Record<string, string>;
    columns: Record<string, string>;
  };
  prevId: string;
  internal?: any;
}, {
  version: "6";
  dialect: "sqlite";
  id: string;
  tables: Record<string, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    indexes: Record<string, {
      name: string;
      columns: string[];
      isUnique: boolean;
      where?: string | undefined;
    }>;
    foreignKeys: Record<string, {
      name: string;
      tableTo: string;
      columnsTo: string[];
      tableFrom: string;
      columnsFrom: string[];
      onUpdate?: string | undefined;
      onDelete?: string | undefined;
    }>;
    compositePrimaryKeys: Record<string, {
      columns: string[];
      name?: string | undefined;
    }>;
    uniqueConstraints?: Record<string, {
      name: string;
      columns: string[];
    }> | undefined;
    checkConstraints?: Record<string, {
      name: string;
      value: string;
    }> | undefined;
  }>;
  enums: {};
  _meta: {
    tables: Record<string, string>;
    columns: Record<string, string>;
  };
  prevId: string;
  views?: Record<string, {
    name: string;
    columns: Record<string, {
      name: string;
      type: string;
      notNull: boolean;
      primaryKey: boolean;
      generated?: {
        type: "virtual" | "stored";
        as: string;
      } | undefined;
      default?: string | undefined;
      typeSchema?: string | undefined;
      autoincrement?: boolean | undefined;
    }>;
    isExisting: boolean;
    definition?: string | undefined;
  }> | undefined;
  internal?: any;
}>;
type SQLiteSchemaV6 = TypeOf<typeof schemaV6>;
declare const snapshotValidator: {
  shape: {
    version: "7";
    dialect: "sqlite";
    id: string;
    prevIds: string[];
    ddl: SqliteEntity[];
    renames: string[];
  };
  parse: (obj: unknown) => {
    success: boolean;
    data: {
      version: "7";
      dialect: "sqlite";
      id: string;
      prevIds: string[];
      ddl: SqliteEntity[];
      renames: string[];
    } | null;
    errors?: string[] | undefined;
  };
  strict: (obj: unknown) => {
    version: "7";
    dialect: "sqlite";
    id: string;
    prevIds: string[];
    ddl: SqliteEntity[];
    renames: string[];
  };
};
type SqliteSnapshot = typeof snapshotValidator.shape;
//#endregion
//#region src/cli/commands/up-sqlite.d.ts
declare const updateToV7: (snapshot: SQLiteSchemaV6) => SqliteSnapshot;
//#endregion
//#region src/payload/sqlite.d.ts
declare const generateDrizzleJson: (imports: Record<string, unknown>, prevId?: string) => Promise<SqliteSnapshot>;
declare const generateMigration: (prev: SqliteSnapshot, cur: SqliteSnapshot, options?: {
  hints?: Hint[];
}) => Promise<string[]>;
declare const pushSchema: (imports: Record<string, unknown>, db: SQLiteClient, migrationsConfig?: {
  table?: string;
  schema?: string;
}) => Promise<{
  sqlStatements: string[];
  hints: {
    hint: string;
    statement?: string;
  }[];
  apply: () => Promise<void>;
}>;
declare const startStudioServer: (imports: Record<string, unknown>, credentials: SqliteCredentials | {
  driver: "d1";
  binding: D1Database;
}, options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<void>;
//#endregion
export { type Hint, type MissingHint, type MissingHintsError, generateDrizzleJson, generateMigration, pushSchema, startStudioServer, updateToV7 as up };