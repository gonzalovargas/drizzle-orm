import { _ as ZodTypeAny, b as ZodUnion, c as ZodIntersection, d as ZodObject, f as ZodOptional, g as ZodType, i as ZodBoolean, l as ZodLiteral, m as ZodString, o as ZodEffects, t as TypeOf, u as ZodNumber, v as ZodTypeDef, y as ZodUndefined } from "./types-OgqGmnkF.mjs";
import { PGlite } from "@electric-sql/pglite";
import { ConnectionOptions } from "tls";
//#region src/cli/validations/postgres.d.ts
declare const postgresCredentials: ZodUnion<[ZodEffects<ZodIntersection<ZodObject<{
  driver: ZodUndefined;
}, "strip", ZodTypeAny, {
  driver?: undefined;
}, {
  driver?: undefined;
}>, ZodUnion<[ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>, ZodObject<{
  host: ZodString;
  port: ZodOptional<ZodNumber>;
  user: ZodOptional<ZodString>;
  password: ZodOptional<ZodString>;
  database: ZodString;
  ssl: ZodOptional<ZodUnion<[ZodLiteral<"require">, ZodLiteral<"allow">, ZodLiteral<"prefer">, ZodLiteral<"verify-full">, ZodBoolean, ZodType<ConnectionOptions, ZodTypeDef, ConnectionOptions>]>>;
}, "strip", ZodTypeAny, {
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | ConnectionOptions | undefined;
}, {
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | ConnectionOptions | undefined;
}>]>>, ({
  driver?: undefined;
} & {
  url: string;
}) | ({
  driver?: undefined;
} & {
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | ConnectionOptions | undefined;
}), {
  driver?: undefined;
} & ({
  url: string;
} | {
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  password?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | ConnectionOptions | undefined;
})>, ZodIntersection<ZodObject<{
  driver: ZodLiteral<"aws-data-api">;
}, "strip", ZodTypeAny, {
  driver: "aws-data-api";
}, {
  driver: "aws-data-api";
}>, ZodObject<{
  database: ZodString;
  secretArn: ZodString;
  resourceArn: ZodString;
}, "strip", ZodTypeAny, {
  database: string;
  secretArn: string;
  resourceArn: string;
}, {
  database: string;
  secretArn: string;
  resourceArn: string;
}>>, ZodIntersection<ZodObject<{
  driver: ZodLiteral<"pglite">;
}, "strip", ZodTypeAny, {
  driver: "pglite";
}, {
  driver: "pglite";
}>, ZodUnion<[ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>, ZodObject<{
  client: ZodType<PGlite, ZodTypeDef, PGlite>;
}, "strip", ZodTypeAny, {
  client: PGlite;
}, {
  client: PGlite;
}>]>>, ZodIntersection<ZodObject<{
  driver: ZodLiteral<"dsql">;
}, "strip", ZodTypeAny, {
  driver: "dsql";
}, {
  driver: "dsql";
}>, ZodIntersection<ZodUnion<[ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>, ZodObject<{
  host: ZodString;
  port: ZodOptional<ZodNumber>;
  user: ZodOptional<ZodString>;
  database: ZodString;
  ssl: ZodOptional<ZodUnion<[ZodLiteral<"require">, ZodLiteral<"allow">, ZodLiteral<"prefer">, ZodLiteral<"verify-full">, ZodBoolean, ZodType<ConnectionOptions, ZodTypeDef, ConnectionOptions>]>>;
}, "strip", ZodTypeAny, {
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | ConnectionOptions | undefined;
}, {
  database: string;
  host: string;
  port?: number | undefined;
  user?: string | undefined;
  ssl?: boolean | "require" | "allow" | "prefer" | "verify-full" | ConnectionOptions | undefined;
}>]>, ZodObject<{
  profile: ZodOptional<ZodString>;
  region: ZodOptional<ZodString>;
  customCredentialsProvider: ZodOptional<ZodObject<{
    accessKeyId: ZodString;
    secretAccessKey: ZodString;
    sessionToken: ZodOptional<ZodString>;
    credentialScope: ZodOptional<ZodString>;
    accountId: ZodOptional<ZodString>;
  }, "strip", ZodTypeAny, {
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken?: string | undefined;
    credentialScope?: string | undefined;
    accountId?: string | undefined;
  }, {
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken?: string | undefined;
    credentialScope?: string | undefined;
    accountId?: string | undefined;
  }>>;
}, "strip", ZodTypeAny, {
  profile?: string | undefined;
  region?: string | undefined;
  customCredentialsProvider?: {
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken?: string | undefined;
    credentialScope?: string | undefined;
    accountId?: string | undefined;
  } | undefined;
}, {
  profile?: string | undefined;
  region?: string | undefined;
  customCredentialsProvider?: {
    accessKeyId: string;
    secretAccessKey: string;
    sessionToken?: string | undefined;
    credentialScope?: string | undefined;
    accountId?: string | undefined;
  } | undefined;
}>>>]>;
type PostgresCredentials = TypeOf<typeof postgresCredentials>;
//#endregion
export { PostgresCredentials as t };