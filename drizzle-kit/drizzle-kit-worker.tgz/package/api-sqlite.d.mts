import { t as SqliteCredentials } from "./sqlite-ssnQ5YFh.mjs";
//#region src/ext/api-sqlite.d.ts
declare const startStudioServer: (imports: Record<string, unknown>, credentials: SqliteCredentials | {
  driver: "d1";
  binding: D1Database;
}, options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<void>;
//#endregion
export { startStudioServer };