import { n as MissingHint } from "./hints-DJq8W2Cc.mjs";
//#region src/cli/errors.d.ts
type JsonPrimitive = string | number | boolean | null;
type JsonValue = JsonPrimitive | JsonValue[] | {
  [key: string]: JsonValue;
};
type DrizzleCliErrorMeta = Record<string, JsonValue>;
declare class DrizzleCliError extends Error {
  readonly code: string;
  readonly meta?: DrizzleCliErrorMeta;
  readonly humanMessage: string;
  constructor(code: string, humanMessage: string, meta?: DrizzleCliErrorMeta, options?: ErrorOptions);
}
declare class MissingHintsError extends DrizzleCliError {
  readonly code: 'missing_hints';
  readonly missingHints: readonly MissingHint[];
  constructor(missingHints: readonly MissingHint[]);
}
//#endregion
export { MissingHintsError as t };