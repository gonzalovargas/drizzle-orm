import { _ as ZodTypeAny, a as ZodDefault, b as ZodUnion, d as ZodObject, f as ZodOptional, i as ZodBoolean, l as ZodLiteral, m as ZodString, r as ZodArray, t as TypeOf } from "./types-OgqGmnkF.mjs";
//#region src/cli/validations/common.d.ts
declare const entitiesParams: {
  tablesFilter: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
  schemaFilter: ZodOptional<ZodUnion<[ZodString, ZodArray<ZodString, "many">]>>;
  extensionsFilters: ZodOptional<ZodArray<ZodLiteral<"postgis">, "many">>;
  entities: ZodOptional<ZodObject<{
    roles: ZodDefault<ZodOptional<ZodUnion<[ZodBoolean, ZodObject<{
      provider: ZodOptional<ZodString>;
      include: ZodOptional<ZodArray<ZodString, "many">>;
      exclude: ZodOptional<ZodArray<ZodString, "many">>;
    }, "strip", ZodTypeAny, {
      provider?: string | undefined;
      include?: string[] | undefined;
      exclude?: string[] | undefined;
    }, {
      provider?: string | undefined;
      include?: string[] | undefined;
      exclude?: string[] | undefined;
    }>]>>>;
  }, "strip", ZodTypeAny, {
    roles: boolean | {
      provider?: string | undefined;
      include?: string[] | undefined;
      exclude?: string[] | undefined;
    };
  }, {
    roles?: boolean | {
      provider?: string | undefined;
      include?: string[] | undefined;
      exclude?: string[] | undefined;
    } | undefined;
  }>>;
};
type EntitiesFilter = TypeOf<typeof entitiesParams['entities']>;
type TablesFilter = TypeOf<typeof entitiesParams['tablesFilter']>;
type SchemasFilter = TypeOf<typeof entitiesParams['schemaFilter']>;
type ExtensionsFilter = TypeOf<typeof entitiesParams['extensionsFilters']>;
type EntitiesFilterConfig = {
  schemas: SchemasFilter;
  tables: TablesFilter;
  entities: EntitiesFilter;
  extensions: ExtensionsFilter;
};
//#endregion
export { EntitiesFilterConfig as t };