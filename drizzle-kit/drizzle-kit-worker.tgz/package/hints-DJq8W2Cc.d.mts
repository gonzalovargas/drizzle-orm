import { h as ZodTuple, m as ZodString, t as TypeOf } from "./types-OgqGmnkF.mjs";
//#region src/cli/hints.d.ts
declare const renameCreateEntitySchemas: readonly [{
  readonly kind: "table";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "column";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "default";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "schema";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "enum";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "sequence";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "view";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "policy";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "role";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "check";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "index";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "unique";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "primary_key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "foreign key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}];
type RenameCreateHintKind = typeof renameCreateEntitySchemas[number]['kind'];
declare const confirmEntitySchemas: readonly [{
  readonly kind: "table";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "column";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "schema";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "view";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "primary_key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "add_not_null";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "add_unique";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}];
type ConfirmEntityKind = typeof confirmEntitySchemas[number]['kind'];
type RenameCreateSchemaFor<K extends RenameCreateHintKind> = Extract<typeof renameCreateEntitySchemas[number], {
  kind: K;
}>['schema'];
type ConfirmSchemaFor<K extends ConfirmEntityKind> = Extract<typeof confirmEntitySchemas[number], {
  kind: K;
}>['schema'];
type IdFor<K extends RenameCreateHintKind> = Readonly<TypeOf<RenameCreateSchemaFor<K>>>;
type ConfirmIdFor<K extends ConfirmEntityKind> = Readonly<TypeOf<ConfirmSchemaFor<K>>>;
type RenameHint = { [K in RenameCreateHintKind]: {
  type: 'rename';
  kind: K;
  from: IdFor<K>;
  to: IdFor<K>;
}; }[RenameCreateHintKind];
type CreateHint = { [K in RenameCreateHintKind]: {
  type: 'create';
  kind: K;
  entity: IdFor<K>;
}; }[RenameCreateHintKind];
type ConfirmDataLossHint = { [K in ConfirmEntityKind]: {
  type: 'confirm_data_loss';
  kind: K;
  entity: ConfirmIdFor<K>;
}; }[ConfirmEntityKind];
type Hint = RenameHint | CreateHint | ConfirmDataLossHint;
type RenameCreateMissingHint<K extends RenameCreateHintKind> = {
  type: 'rename_or_create';
  kind: K;
  entity: IdFor<K>;
};
type ConfirmDataLossReasonDetails = {
  reason: 'non_empty';
} | {
  reason: 'table_recreate';
} | {
  reason: 'type_change';
  reason_details: {
    from: string;
    to: string;
  };
};
type ConfirmDataLossMissingHint<K extends ConfirmEntityKind> = {
  type: 'confirm_data_loss';
  kind: K;
  entity: ConfirmIdFor<K>;
} & ConfirmDataLossReasonDetails;
type MissingHint = { [K in RenameCreateHintKind]: RenameCreateMissingHint<K>; }[RenameCreateHintKind] | { [K in ConfirmEntityKind]: ConfirmDataLossMissingHint<K>; }[ConfirmEntityKind];
//#endregion
export { MissingHint as n, Hint as t };