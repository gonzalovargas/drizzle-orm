import "./postgres-DGJS29rG.mjs";
import "drizzle-orm/mssql-core";
import "drizzle-orm";
import "drizzle-orm/_relations";
import "drizzle-orm/mysql-core";
import "drizzle-orm/pg-core";
import "drizzle-orm/singlestore-core";
import "drizzle-orm/sqlite-core";
//#region src/utils/index.d.ts
type DB = {
  query: <T extends any = any>(sql: string, params?: any[]) => Promise<T[]>;
};
interface SQLiteClient {
  query: <T extends any = any>(sql: string, params?: any[]) => Promise<T[]>;
  run(query: string): Promise<void>;
  batch(statements: string[]): Promise<void>;
}
//#endregion
export { SQLiteClient as n, DB as t };