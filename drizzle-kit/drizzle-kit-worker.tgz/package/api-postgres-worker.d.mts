import { n as MissingHint, t as Hint } from "./hints-By83v2-O.mjs";
import { t as PostgresSnapshot } from "./snapshot-vvjBNqUU.mjs";

//#region src/ext/worker-hints.d.ts
declare class InvalidWorkerHintsError extends Error {
  readonly code: "invalid_hints";
  constructor(message: string);
}
declare class MissingHintsError extends Error {
  readonly code: "missing_hints";
  readonly missingHints: readonly MissingHint[];
  constructor(missingHints: readonly MissingHint[]);
}
//#endregion
//#region src/ext/api-postgres-worker.d.ts
declare const generateDrizzleJson: (imports: Record<string, unknown>, prevId?: string, schemaFilters?: string[]) => Promise<PostgresSnapshot>;
declare const generateMigration: (prev: PostgresSnapshot, cur: PostgresSnapshot, options?: {
  hints?: Hint[];
}) => Promise<string[]>;
//#endregion
export { type Hint, InvalidWorkerHintsError, type MissingHint, MissingHintsError, generateDrizzleJson, generateMigration };