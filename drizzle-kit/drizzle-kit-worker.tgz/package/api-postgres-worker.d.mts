import { n as PostgresSnapshotV8, t as PostgresSchemaState } from "./snapshot-5g9UVAog.mjs";
import { n as MissingHint, t as Hint } from "./hints-DJq8W2Cc.mjs";
//#region src/ext/worker-hints.d.ts
declare class InvalidWorkerHintsError extends Error {
  readonly code: "invalid_hints";
  constructor(message: string);
}
declare class MissingHintsError extends Error {
  readonly code: "missing_hints";
  readonly missingHints: readonly MissingHint[];
  constructor(missingHints: readonly MissingHint[]);
}
//#endregion
//#region src/ext/api-postgres-worker.d.ts
declare const generateDrizzleJson: (imports: Record<string, unknown>, prevId?: string, schemaFilters?: string[]) => Promise<PostgresSchemaState>;
type FullPostgresSnapshot = PostgresSchemaState | PostgresSnapshotV8;
declare const generateMigration: (prev: FullPostgresSnapshot, cur: FullPostgresSnapshot, options?: {
  hints?: Hint[];
}) => Promise<string[]>;
//#endregion
export { type Hint, InvalidWorkerHintsError, type MissingHint, MissingHintsError, generateDrizzleJson, generateMigration };