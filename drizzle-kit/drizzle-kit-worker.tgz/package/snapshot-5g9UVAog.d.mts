//#region src/dialects/dialect.d.ts
type Row = Record<string, any>;
type Delta = {
  op: 'create';
  row: Row;
} | {
  op: 'drop';
  key: string;
} | {
  op: 'alter';
  key: string;
  set: Row;
} | {
  op: 'rename';
  key: string;
  set: Row;
};
type EnumField = readonly (string | null)[];
type ObjectField = {
  [field: string]: Field;
};
type ObjectArrayField = readonly [ObjectField];
type Field = 'string' | 'number' | 'boolean' | 'string[]' | 'string?' | 'number?' | 'boolean?' | EnumField | ObjectField | ObjectArrayField;
type Def = Record<string, Field>;
type Simplify<T> = { [K in keyof T]: T[K]; } & {};
type FieldType<F> = F extends 'string' ? string : F extends 'number' ? number : F extends 'boolean' ? boolean : F extends 'string[]' ? string[] : F extends 'string?' ? string | null : F extends 'number?' ? number | null : F extends 'boolean?' ? boolean | null : F extends readonly [infer E] ? (E extends Record<string, Field> ? InferRow<E>[] : F[number]) : F extends readonly (string | null)[] ? F[number] : F extends Record<string, Field> ? InferRow<F> | null : never;
type InferRow<D> = Simplify<{ -readonly [K in keyof D]: FieldType<D[K]>; }>;
type InferEntities<D> = { [K in keyof D]: Simplify<InferRow<D[K]> & {
  entityType: K;
}>; };
type IdFn = (row: Row) => string;
type Edge = {
  to: string;
  cascade: boolean;
  resolve: (r: Row) => string[];
  relocate: (r: Row, from: Row, to: Row) => Row | null;
};
type EntityType = string;
type Identity = string;
type Store = Map<EntityType, Map<Identity, Row>>;
type Internals = {
  store: Store;
  defs: Record<string, Def>;
  identity: Record<string, IdFn>;
  edges: Record<string, Edge[]>;
  nulls: Record<string, Row>;
};
type Where<T> = { [K in keyof T]?: T[K] | {
  CONTAINS: any;
}; } & Record<string, any>;
type SetOps<T> = { [K in keyof T]?: T[K] | ((item: any) => any); } & Record<string, any>;
type Processors<T extends Row = Row> = {
  push: (input: Partial<T> & Record<string, any>, uniques?: (keyof T & string)[]) => {
    status: 'OK' | 'CONFLICT';
    data: T;
  };
  pushAll: (items: Iterable<Row>) => {
    status: 'OK';
    count: number;
  } | {
    status: 'CONFLICT';
    key: string;
  };
  list: (where?: Where<T>) => T[];
  one: (where?: Where<T>) => T | null;
  update: (cfg: {
    set: SetOps<T>;
    where?: Where<T> | string;
  }) => {
    status: 'OK' | 'CONFLICT';
    data: T[];
  };
  delete: (where?: Where<T> | string) => T[];
  drop: (where?: Where<T>) => T[];
  validate: (row: unknown) => row is T;
  hasDiff: (alter: Row) => boolean;
};
type DDL<TMap extends Record<string, Row> = Record<string, Row>> = { [K in keyof TMap]: Processors<TMap[K]>; } & {
  entities: Processors<TMap[keyof TMap]>;
  key: (type: string, row: Row) => string;
  rename: (from: Row, set: Row) => Delta | null;
  clone: () => DDL<TMap>;
  _: Internals;
  $entities?: TMap;
};
//#endregion
//#region src/dialects/postgres/ddl.d.ts
declare const createDDL: () => DDL<InferEntities<{
  readonly schemas: {
    readonly name: "string";
  };
  readonly tables: {
    readonly schema: "string";
    readonly name: "string";
    readonly isRlsEnabled: "boolean";
  };
  readonly enums: {
    readonly schema: "string";
    readonly name: "string";
    readonly values: "string[]";
  };
  readonly columns: {
    readonly schema: "string";
    readonly table: "string";
    readonly name: "string";
    readonly type: "string";
    readonly typeSchema: "string?";
    readonly notNull: "boolean";
    readonly dimensions: "number";
    readonly default: "string?";
    readonly generated: {
      readonly type: readonly ["stored"];
      readonly as: "string";
    };
    readonly identity: {
      readonly name: "string";
      readonly type: readonly ["always", "byDefault"];
      readonly increment: "string?";
      readonly minValue: "string?";
      readonly maxValue: "string?";
      readonly startWith: "string?";
      readonly cache: "number?";
      readonly cycle: "boolean?";
    };
  };
  readonly indexes: {
    readonly schema: "string";
    readonly table: "string";
    readonly name: "string";
    readonly nameExplicit: "boolean";
    readonly columns: readonly [{
      readonly value: "string";
      readonly isExpression: "boolean";
      readonly asc: "boolean";
      readonly nullsFirst: "boolean";
      readonly opclass: {
        readonly name: "string";
        readonly default: "boolean";
      };
    }];
    readonly isUnique: "boolean";
    readonly where: "string?";
    readonly with: "string";
    readonly method: "string";
    readonly concurrently: "boolean";
  };
  readonly fks: {
    readonly schema: "string";
    readonly table: "string";
    readonly name: "string";
    readonly nameExplicit: "boolean";
    readonly columns: "string[]";
    readonly schemaTo: "string";
    readonly tableTo: "string";
    readonly columnsTo: "string[]";
    readonly onUpdate: readonly ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
    readonly onDelete: readonly ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
  };
  readonly pks: {
    readonly schema: "string";
    readonly table: "string";
    readonly name: "string";
    readonly columns: "string[]";
    readonly nameExplicit: "boolean";
  };
  readonly uniques: {
    readonly schema: "string";
    readonly table: "string";
    readonly name: "string";
    readonly nameExplicit: "boolean";
    readonly columns: "string[]";
    readonly nullsNotDistinct: "boolean";
  };
  readonly checks: {
    readonly schema: "string";
    readonly table: "string";
    readonly name: "string";
    readonly value: "string";
  };
  readonly sequences: {
    readonly schema: "string";
    readonly name: "string";
    readonly incrementBy: "string?";
    readonly minValue: "string?";
    readonly maxValue: "string?";
    readonly startWith: "string?";
    readonly cacheSize: "number?";
    readonly cycle: "boolean?";
  };
  readonly roles: {
    readonly name: "string";
    readonly superuser: "boolean?";
    readonly createDb: "boolean?";
    readonly createRole: "boolean?";
    readonly inherit: "boolean?";
    readonly canLogin: "boolean?";
    readonly replication: "boolean?";
    readonly bypassRls: "boolean?";
    readonly connLimit: "number?";
    readonly password: "string?";
    readonly validUntil: "string?";
  };
  readonly privileges: {
    readonly grantor: "string";
    readonly grantee: "string";
    readonly schema: "string";
    readonly table: "string";
    readonly type: readonly ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
    readonly isGrantable: "boolean";
  };
  readonly policies: {
    readonly schema: "string";
    readonly table: "string";
    readonly name: "string";
    readonly as: readonly ["PERMISSIVE", "RESTRICTIVE"];
    readonly for: readonly ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
    readonly roles: "string[]";
    readonly using: "string?";
    readonly withCheck: "string?";
  };
  readonly views: {
    readonly schema: "string";
    readonly name: "string";
    readonly definition: "string?";
    readonly with: {
      readonly checkOption: readonly ["local", "cascaded", null];
      readonly securityBarrier: "boolean?";
      readonly securityInvoker: "boolean?";
      readonly fillfactor: "number?";
      readonly toastTupleTarget: "number?";
      readonly parallelWorkers: "number?";
      readonly autovacuumEnabled: "boolean?";
      readonly vacuumIndexCleanup: readonly ["auto", "off", "on", null];
      readonly vacuumTruncate: "boolean?";
      readonly autovacuumVacuumThreshold: "number?";
      readonly autovacuumVacuumScaleFactor: "number?";
      readonly autovacuumVacuumCostDelay: "number?";
      readonly autovacuumVacuumCostLimit: "number?";
      readonly autovacuumFreezeMinAge: "number?";
      readonly autovacuumFreezeMaxAge: "number?";
      readonly autovacuumFreezeTableAge: "number?";
      readonly autovacuumMultixactFreezeMinAge: "number?";
      readonly autovacuumMultixactFreezeMaxAge: "number?";
      readonly autovacuumMultixactFreezeTableAge: "number?";
      readonly logAutovacuumMinDuration: "number?";
      readonly userCatalogTable: "boolean?";
    };
    readonly withNoData: "boolean?";
    readonly using: "string?";
    readonly tablespace: "string?";
    readonly materialized: "boolean";
  };
}>>;
type PostgresDDL = ReturnType<typeof createDDL>;
type PostgresEntities = NonNullable<PostgresDDL['$entities']>;
type PostgresEntity = PostgresEntities[keyof PostgresEntities];
//#endregion
//#region src/dialects/postgres/snapshot.d.ts
type PostgresSnapshotV8 = {
  version: '8';
  dialect: 'postgres';
  id: string;
  prevIds: string[];
  ddl: PostgresEntity[];
  renames: string[];
};
type PostgresSchemaState = {
  version: '9';
  dialect: 'postgres';
  id: string;
  prevIds: string[];
  ddl: PostgresEntity[];
};
//#endregion
export { PostgresSnapshotV8 as n, PostgresSchemaState as t };