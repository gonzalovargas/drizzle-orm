import { g as ZodTuple, h as ZodString, o as Dialect, s as TypeOf } from "./postgres-PsuB9IHg.mjs";
import "drizzle-orm/_relations";
import "drizzle-orm/pg-core";
import "drizzle-orm";
import "drizzle-orm/mssql-core";
import "drizzle-orm/mysql-core";
import "drizzle-orm/singlestore-core";
import "drizzle-orm/sqlite-core";
//#region src/cli/hints.d.ts
declare const renameCreateEntitySchemas: readonly [{
  readonly kind: "table";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "column";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "default";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "schema";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "enum";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "sequence";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "view";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "policy";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "role";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "check";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "index";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "unique";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "primary_key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "foreign key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}];
type RenameCreateHintKind = typeof renameCreateEntitySchemas[number]['kind'];
declare const confirmEntitySchemas: readonly [{
  readonly kind: "table";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "column";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "schema";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "view";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "primary_key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "add_not_null";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "add_unique";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}];
type ConfirmEntityKind = typeof confirmEntitySchemas[number]['kind'];
type RenameCreateSchemaFor<K extends RenameCreateHintKind> = Extract<typeof renameCreateEntitySchemas[number], {
  kind: K;
}>['schema'];
type ConfirmSchemaFor<K extends ConfirmEntityKind> = Extract<typeof confirmEntitySchemas[number], {
  kind: K;
}>['schema'];
type IdFor<K extends RenameCreateHintKind> = Readonly<TypeOf<RenameCreateSchemaFor<K>>>;
type ConfirmIdFor<K extends ConfirmEntityKind> = Readonly<TypeOf<ConfirmSchemaFor<K>>>;
type RenameHint = { [K in RenameCreateHintKind]: {
  type: 'rename';
  kind: K;
  from: IdFor<K>;
  to: IdFor<K>;
}; }[RenameCreateHintKind];
type CreateHint = { [K in RenameCreateHintKind]: {
  type: 'create';
  kind: K;
  entity: IdFor<K>;
}; }[RenameCreateHintKind];
type ConfirmDataLossHint = { [K in ConfirmEntityKind]: {
  type: 'confirm_data_loss';
  kind: K;
  entity: ConfirmIdFor<K>;
}; }[ConfirmEntityKind];
type Hint = RenameHint | CreateHint | ConfirmDataLossHint;
type RenameCreateMissingHint<K extends RenameCreateHintKind> = {
  type: 'rename_or_create';
  kind: K;
  entity: IdFor<K>;
};
type ConfirmDataLossReasonDetails = {
  reason: 'non_empty';
} | {
  reason: 'table_recreate';
} | {
  reason: 'type_change';
  reason_details: {
    from: string;
    to: string;
  };
};
type ConfirmDataLossMissingHint<K extends ConfirmEntityKind> = {
  type: 'confirm_data_loss';
  kind: K;
  entity: ConfirmIdFor<K>;
} & ConfirmDataLossReasonDetails;
type MissingHint = { [K in RenameCreateHintKind]: RenameCreateMissingHint<K>; }[RenameCreateHintKind] | { [K in ConfirmEntityKind]: ConfirmDataLossMissingHint<K>; }[ConfirmEntityKind];
type MissingHintsResponse = {
  status: 'missing_hints';
  unresolved: readonly MissingHint[];
};
//#endregion
//#region src/cli/commands/check-postgres.d.ts
type CheckWarning = {
  kind: 'schema_changed' | 'merge_needed' | 'not_compared';
  message: string;
};
//#endregion
//#region ../node_modules/.pnpm/@drizzle-team+brocli@0.12.1/node_modules/@drizzle-team/brocli/index.d.ts
type OptionType = 'string' | 'boolean' | 'number' | 'positional';
type OutputType = string | boolean | number | undefined;
type BuilderConfig<TType extends OptionType = OptionType> = {
  name?: string | undefined;
  aliases: string[];
  type: TType;
  description?: string;
  default?: OutputType;
  isHidden?: boolean;
  isRequired?: boolean;
  isInt?: boolean;
  minVal?: number;
  maxVal?: number;
  enumVals?: [string, ...string[]];
};
declare class OptionBuilderBase<TBuilderConfig extends BuilderConfig = BuilderConfig, TOutput extends OutputType = string, TOmit extends string = '', TEnums extends string | undefined = undefined> {
  _: {
    config: TBuilderConfig;
    /**
     * Type-level only field
     *
     * Do not attempt to access at a runtime
     */
    $output: TOutput;
  };
  private config;
  constructor(config?: TBuilderConfig);
  string<TName extends string>(name: TName): Omit<OptionBuilderBase<BuilderConfig<'string'>, string | undefined, TOmit | OptionType | 'min' | 'max' | 'int'>, TOmit | OptionType | 'min' | 'max' | 'int'>;
  string(): Omit<OptionBuilderBase<BuilderConfig<'string'>, string | undefined, TOmit | OptionType | 'min' | 'max' | 'int'>, TOmit | OptionType | 'min' | 'max' | 'int'>;
  number<TName extends string>(name: TName): Omit<OptionBuilderBase<BuilderConfig<'number'>, number | undefined, TOmit | OptionType | 'enum'>, TOmit | OptionType | 'enum'>;
  number(): Omit<OptionBuilderBase<BuilderConfig<'number'>, string | undefined, TOmit | OptionType | 'enum'>, TOmit | OptionType | 'enum'>;
  boolean<TName extends string>(name: TName): Omit<OptionBuilderBase<BuilderConfig<'boolean'>, boolean | undefined, TOmit | OptionType | 'min' | 'max' | 'enum' | 'int'>, TOmit | OptionType | 'min' | 'max' | 'enum' | 'int'>;
  boolean(): Omit<OptionBuilderBase<BuilderConfig<'boolean'>, boolean | undefined, TOmit | OptionType | 'min' | 'max' | 'enum' | 'int'>, TOmit | OptionType | 'min' | 'max' | 'enum' | 'int'>;
  positional<TName extends string>(displayName: TName): Omit<OptionBuilderBase<BuilderConfig<'positional'>, string | undefined, TOmit | OptionType | 'min' | 'max' | 'int' | 'alias'>, TOmit | OptionType | 'min' | 'max' | 'int' | 'alias'>;
  positional(): Omit<OptionBuilderBase<BuilderConfig<'positional'>, string | undefined, TOmit | OptionType | 'min' | 'max' | 'int' | 'alias'>, TOmit | OptionType | 'min' | 'max' | 'int' | 'alias'>;
  alias(...aliases: string[]): Omit<OptionBuilderBase<TBuilderConfig, TOutput, TOmit | 'alias'>, TOmit | 'alias'>;
  desc<TDescription extends string>(description: TDescription): Omit<OptionBuilderBase<TBuilderConfig, TOutput, TOmit | 'desc'>, TOmit | 'desc'>;
  hidden(): Omit<OptionBuilderBase<TBuilderConfig, TOutput, TOmit | 'hidden'>, TOmit | 'hidden'>;
  required(): Omit<OptionBuilderBase<TBuilderConfig, Exclude<TOutput, undefined>, TOmit | 'required' | 'default'>, TOmit | 'required' | 'default'>;
  default<TDefVal extends TEnums extends undefined ? Exclude<TOutput, undefined> : TEnums>(value: TDefVal): Omit<OptionBuilderBase<TBuilderConfig, Exclude<TOutput, undefined>, TOmit | 'enum' | 'required' | 'default', TEnums>, TOmit | 'enum' | 'required' | 'default'>;
  enum<TValues extends [string, ...string[]], TUnion extends TValues[number] = TValues[number]>(...values: TValues): Omit<OptionBuilderBase<TBuilderConfig, TUnion | (TOutput extends undefined ? undefined : never), TOmit | 'enum', TUnion>, TOmit | 'enum'>;
  min(value: number): Omit<OptionBuilderBase<TBuilderConfig, TOutput, TOmit | 'min'>, TOmit | 'min'>;
  max(value: number): Omit<OptionBuilderBase<TBuilderConfig, TOutput, TOmit | 'max'>, TOmit | 'max'>;
  int(): Omit<OptionBuilderBase<TBuilderConfig, TOutput, TOmit | 'int'>, TOmit | 'int'>;
}
type GenericBuilderInternalsFields = {
  /**
   * Type-level only field
   *
   * Do not attempt to access at a runtime
   */
  $output: OutputType;
  config: BuilderConfig;
};
type GenericBuilderInternals = {
  _: GenericBuilderInternalsFields;
};
type Simplify<T> = { [K in keyof T]: T[K]; } & {};
//#endregion
//#region src/@types/utils.d.ts
declare global {
  interface String {
    trimChar(char: string): string;
    squashSpaces(): string;
    capitalise(): string;
    camelCase(): string;
    snake_case(): string;
    concatIf(it: string, condition: boolean): string;
  }
  interface Array<T> {
    random(): T;
  }
}
//#endregion
//#region src/cli/schema.d.ts
declare const generateOptions: {
  readonly config: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<OptionBuilderBase<BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly driver: Omit<OptionBuilderBase<BuilderConfig<"string">, "d1-http" | "expo" | "durable-sqlite" | "sqlite-cloud" | "aws-data-api" | "pglite" | "dsql" | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly schema: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly out: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly name: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly breakpoints: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly custom: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
  readonly ignoreConflicts: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly fixConflicts: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly explain: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
  readonly output: Omit<OptionBuilderBase<BuilderConfig<"string">, "text" | "json", "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
  readonly hints: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly hintsFile: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
};
declare const pushOptions: {
  readonly verbose: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
  readonly strict: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly force: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
  readonly output: Omit<OptionBuilderBase<BuilderConfig<"string">, "text" | "json", "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
  readonly explain: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
  readonly hints: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly hintsFile: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly url: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly host: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly port: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly user: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly password: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly database: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly ssl: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly authToken: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly tlsSecurity: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly driver: Omit<OptionBuilderBase<BuilderConfig<"string">, "d1-http" | "expo" | "durable-sqlite" | "sqlite-cloud" | "aws-data-api" | "pglite" | "dsql" | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly tablesFilter: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly schemaFilter: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly extensionsFilters: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly config: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<OptionBuilderBase<BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly schema: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
};
declare const checkOptions: {
  readonly config: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<OptionBuilderBase<BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly out: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly schema: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly ignoreConflicts: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly output: Omit<OptionBuilderBase<BuilderConfig<"string">, "text" | "json", "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
};
declare const upOptions: {
  readonly config: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<OptionBuilderBase<BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly out: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly output: Omit<OptionBuilderBase<BuilderConfig<"string">, "text" | "json", "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
};
declare const pullOptions: {
  readonly output: Omit<OptionBuilderBase<BuilderConfig<"string">, "text" | "json", "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
  readonly url: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly host: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly port: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly user: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly password: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly database: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly ssl: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly authToken: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly tlsSecurity: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly driver: Omit<OptionBuilderBase<BuilderConfig<"string">, "d1-http" | "expo" | "durable-sqlite" | "sqlite-cloud" | "aws-data-api" | "pglite" | "dsql" | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly tablesFilter: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly schemaFilter: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly extensionsFilters: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly config: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<OptionBuilderBase<BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly out: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly breakpoints: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly casing: Omit<OptionBuilderBase<BuilderConfig<"string">, "camel" | "preserve" | undefined, OptionType | "min" | "max" | "int" | "enum", "camel" | "preserve">, OptionType | "min" | "max" | "int" | "enum">;
  readonly init: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
};
declare const exportOptions: {
  readonly sql: Omit<OptionBuilderBase<BuilderConfig<"boolean">, boolean, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
  readonly config: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<OptionBuilderBase<BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, OptionType | "min" | "max" | "int" | "desc" | "enum", undefined>, OptionType | "min" | "max" | "int" | "desc" | "enum">;
  readonly schema: Omit<OptionBuilderBase<BuilderConfig<"string">, string | undefined, OptionType | "min" | "max" | "int" | "desc", undefined>, OptionType | "min" | "max" | "int" | "desc">;
  readonly output: Omit<OptionBuilderBase<BuilderConfig<"string">, "text" | "json", "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum", undefined>, "default" | OptionType | "min" | "max" | "int" | "desc" | "required" | "enum">;
};
//#endregion
//#region src/cli/contract.d.ts
type BrocliInputOf<TOptions extends Record<string, GenericBuilderInternals>> = Simplify<{ [K in keyof TOptions]?: TOptions[K]['_']['$output'] | undefined; }>;
type GenerateOptionsInput = BrocliInputOf<typeof generateOptions> & {
  dialect?: Dialect;
};
type PushOptionsInput = BrocliInputOf<typeof pushOptions> & {
  dialect?: Dialect;
};
/**
 * Public SDK option type; the `output` flag is omitted because the SDK always
 * runs in JSON mode internally and never accepts a caller-supplied output mode.
 * `hints` is a raw `Hint[]`, whereas the CLI `--hints` flag takes a JSON string.
 */
type GenerateOptions = Omit<GenerateOptionsInput, 'output' | 'hints'> & {
  hints?: Hint[];
};
/**
 * Public SDK option type; the `output` flag is omitted because the SDK always
 * runs in JSON mode internally and never accepts a caller-supplied output mode.
 * `hints` is a raw `Hint[]`, whereas the CLI `--hints` flag takes a JSON string.
 */
type PushOptions = Omit<PushOptionsInput, 'output' | 'hints'> & {
  hints?: Hint[];
};
type CheckOptionsInput = BrocliInputOf<typeof checkOptions> & {
  dialect?: Dialect;
};
type CheckOptions = Omit<CheckOptionsInput, 'output'>;
type ExportOptionsInput = BrocliInputOf<typeof exportOptions> & {
  dialect?: Dialect;
};
type ExportOptions = Omit<ExportOptionsInput, 'output'>;
type UpOptionsInput = BrocliInputOf<typeof upOptions> & {
  dialect?: Dialect;
};
type UpOptions = Omit<UpOptionsInput, 'output'>;
type PullOptionsInput = BrocliInputOf<typeof pullOptions> & {
  dialect?: Dialect;
};
type PullOptions = Omit<PullOptionsInput, 'output'>;
//#endregion
//#region src/cli-sdk/check.d.ts
declare const check: (opts: CheckOptions) => Promise<{
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
} | {
  warnings?: CheckWarning[] | undefined;
  status: "ok";
  dialect: "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb";
}>;
//#endregion
//#region src/cli-sdk/export.d.ts
declare const exportSql: (opts: ExportOptions) => Promise<{
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
} | {
  status: "ok";
  dialect: "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach";
  statements: string[];
  warnings: string[];
}>;
//#endregion
//#region src/cli-sdk/generate.d.ts
declare const generate: (opts: GenerateOptions) => Promise<{
  status: "no_changes";
  dialect: string | undefined;
} | {
  status: "ok";
  dialect: string | undefined;
  migration_path: string;
} | MissingHintsResponse | {
  status: "ok";
  dialect: string;
} | {
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
}>;
//#endregion
//#region src/cli-sdk/pull.d.ts
declare const pull: (opts: PullOptions) => Promise<{
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
} | {
  schemaPath: string;
  relationsPath?: string;
  snapshotPath: string;
  migrationPath?: string;
  status: "ok";
  dialect: "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach";
}>;
//#endregion
//#region src/cli-sdk/push.d.ts
declare const push: (opts: PushOptions) => Promise<MissingHintsResponse | {
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
} | {
  status: "no_changes";
  dialect: string;
} | {
  status: "ok";
  dialect: string;
}>;
//#endregion
//#region src/cli-sdk/up.d.ts
declare const up: (opts: UpOptions) => Promise<{
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
} | {
  status: "ok";
  dialect: "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach";
  upgraded: string[];
}>;
//#endregion
export { type CheckOptions, type ExportOptions, type GenerateOptions, type Hint, type MissingHint, type PullOptions, type PushOptions, type UpOptions, check, exportSql, generate, pull, push, up };