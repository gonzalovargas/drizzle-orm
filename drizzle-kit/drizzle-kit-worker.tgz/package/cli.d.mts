import { n as Dialect } from "./common-BM4sgbVL.mjs";
import * as _drizzle_team_brocli0 from "@drizzle-team/brocli";
import { GenericBuilderInternals, Simplify } from "@drizzle-team/brocli";

//#region ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/typeAliases.d.cts
type Primitive = string | number | symbol | bigint | boolean | null | undefined;
//#endregion
//#region ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/util.d.cts
declare namespace util {
  type AssertEqual<T, U> = (<V>() => V extends T ? 1 : 2) extends (<V>() => V extends U ? 1 : 2) ? true : false;
  export type isAny<T> = 0 extends 1 & T ? true : false;
  export const assertEqual: <A, B>(_: AssertEqual<A, B>) => void;
  export function assertIs<T>(_arg: T): void;
  export function assertNever(_x: never): never;
  export type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>;
  export type OmitKeys<T, K extends string> = Pick<T, Exclude<keyof T, K>>;
  export type MakePartial<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
  export type Exactly<T, X> = T & Record<Exclude<keyof X, keyof T>, never>;
  export type InexactPartial<T> = { [k in keyof T]?: T[k] | undefined };
  export const arrayToEnum: <T extends string, U extends [T, ...T[]]>(items: U) => { [k in U[number]]: k };
  export const getValidEnumValues: (obj: any) => any[];
  export const objectValues: (obj: any) => any[];
  export const objectKeys: ObjectConstructor["keys"];
  export const find: <T>(arr: T[], checker: (arg: T) => any) => T | undefined;
  export type identity<T> = objectUtil.identity<T>;
  export type flatten<T> = objectUtil.flatten<T>;
  export type noUndefined<T> = T extends undefined ? never : T;
  export const isInteger: NumberConstructor["isInteger"];
  export function joinValues<T extends any[]>(array: T, separator?: string): string;
  export const jsonStringifyReplacer: (_: string, value: any) => any;
  export {};
}
declare namespace objectUtil {
  export type MergeShapes<U, V> = keyof U & keyof V extends never ? U & V : { [k in Exclude<keyof U, keyof V>]: U[k] } & V;
  type optionalKeys<T extends object> = { [k in keyof T]: undefined extends T[k] ? k : never }[keyof T];
  type requiredKeys<T extends object> = { [k in keyof T]: undefined extends T[k] ? never : k }[keyof T];
  export type addQuestionMarks<T extends object, _O = any> = { [K in requiredKeys<T>]: T[K] } & { [K in optionalKeys<T>]?: T[K] } & { [k in keyof T]?: unknown };
  export type identity<T> = T;
  export type flatten<T> = identity<{ [k in keyof T]: T[k] }>;
  export type noNeverKeys<T> = { [k in keyof T]: [T[k]] extends [never] ? never : k }[keyof T];
  export type noNever<T> = identity<{ [k in noNeverKeys<T>]: k extends keyof T ? T[k] : never }>;
  export const mergeShapes: <U, T>(first: U, second: T) => T & U;
  export type extendShape<A extends object, B extends object> = keyof A & keyof B extends never ? A & B : { [K in keyof A as K extends keyof B ? never : K]: A[K] } & { [K in keyof B]: B[K] };
  export {};
}
declare const ZodParsedType: {
  string: "string";
  nan: "nan";
  number: "number";
  integer: "integer";
  float: "float";
  boolean: "boolean";
  date: "date";
  bigint: "bigint";
  symbol: "symbol";
  function: "function";
  undefined: "undefined";
  null: "null";
  array: "array";
  object: "object";
  unknown: "unknown";
  promise: "promise";
  void: "void";
  never: "never";
  map: "map";
  set: "set";
};
type ZodParsedType = keyof typeof ZodParsedType;
//#endregion
//#region ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/ZodError.d.cts
type allKeys<T> = T extends any ? keyof T : never;
type typeToFlattenedError<T, U = string> = {
  formErrors: U[];
  fieldErrors: { [P in allKeys<T>]?: U[] };
};
declare const ZodIssueCode: {
  invalid_type: "invalid_type";
  invalid_literal: "invalid_literal";
  custom: "custom";
  invalid_union: "invalid_union";
  invalid_union_discriminator: "invalid_union_discriminator";
  invalid_enum_value: "invalid_enum_value";
  unrecognized_keys: "unrecognized_keys";
  invalid_arguments: "invalid_arguments";
  invalid_return_type: "invalid_return_type";
  invalid_date: "invalid_date";
  invalid_string: "invalid_string";
  too_small: "too_small";
  too_big: "too_big";
  invalid_intersection_types: "invalid_intersection_types";
  not_multiple_of: "not_multiple_of";
  not_finite: "not_finite";
};
type ZodIssueCode = keyof typeof ZodIssueCode;
type ZodIssueBase = {
  path: (string | number)[];
  message?: string | undefined;
};
interface ZodInvalidTypeIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.invalid_type;
  expected: ZodParsedType;
  received: ZodParsedType;
}
interface ZodInvalidLiteralIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.invalid_literal;
  expected: unknown;
  received: unknown;
}
interface ZodUnrecognizedKeysIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.unrecognized_keys;
  keys: string[];
}
interface ZodInvalidUnionIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.invalid_union;
  unionErrors: ZodError[];
}
interface ZodInvalidUnionDiscriminatorIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.invalid_union_discriminator;
  options: Primitive[];
}
interface ZodInvalidEnumValueIssue extends ZodIssueBase {
  received: string | number;
  code: typeof ZodIssueCode.invalid_enum_value;
  options: (string | number)[];
}
interface ZodInvalidArgumentsIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.invalid_arguments;
  argumentsError: ZodError;
}
interface ZodInvalidReturnTypeIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.invalid_return_type;
  returnTypeError: ZodError;
}
interface ZodInvalidDateIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.invalid_date;
}
type StringValidation = "email" | "url" | "emoji" | "uuid" | "nanoid" | "regex" | "cuid" | "cuid2" | "ulid" | "datetime" | "date" | "time" | "duration" | "ip" | "cidr" | "base64" | "jwt" | "base64url" | {
  includes: string;
  position?: number | undefined;
} | {
  startsWith: string;
} | {
  endsWith: string;
};
interface ZodInvalidStringIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.invalid_string;
  validation: StringValidation;
}
interface ZodTooSmallIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.too_small;
  minimum: number | bigint;
  inclusive: boolean;
  exact?: boolean;
  type: "array" | "string" | "number" | "set" | "date" | "bigint";
}
interface ZodTooBigIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.too_big;
  maximum: number | bigint;
  inclusive: boolean;
  exact?: boolean;
  type: "array" | "string" | "number" | "set" | "date" | "bigint";
}
interface ZodInvalidIntersectionTypesIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.invalid_intersection_types;
}
interface ZodNotMultipleOfIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.not_multiple_of;
  multipleOf: number | bigint;
}
interface ZodNotFiniteIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.not_finite;
}
interface ZodCustomIssue extends ZodIssueBase {
  code: typeof ZodIssueCode.custom;
  params?: {
    [k: string]: any;
  };
}
type ZodIssueOptionalMessage = ZodInvalidTypeIssue | ZodInvalidLiteralIssue | ZodUnrecognizedKeysIssue | ZodInvalidUnionIssue | ZodInvalidUnionDiscriminatorIssue | ZodInvalidEnumValueIssue | ZodInvalidArgumentsIssue | ZodInvalidReturnTypeIssue | ZodInvalidDateIssue | ZodInvalidStringIssue | ZodTooSmallIssue | ZodTooBigIssue | ZodInvalidIntersectionTypesIssue | ZodNotMultipleOfIssue | ZodNotFiniteIssue | ZodCustomIssue;
type ZodIssue = ZodIssueOptionalMessage & {
  fatal?: boolean | undefined;
  message: string;
};
type recursiveZodFormattedError<T> = T extends [any, ...any[]] ? { [K in keyof T]?: ZodFormattedError<T[K]> } : T extends any[] ? {
  [k: number]: ZodFormattedError<T[number]>;
} : T extends object ? { [K in keyof T]?: ZodFormattedError<T[K]> } : unknown;
type ZodFormattedError<T, U = string> = {
  _errors: U[];
} & recursiveZodFormattedError<NonNullable<T>>;
declare class ZodError<T = any> extends Error {
  issues: ZodIssue[];
  get errors(): ZodIssue[];
  constructor(issues: ZodIssue[]);
  format(): ZodFormattedError<T>;
  format<U>(mapper: (issue: ZodIssue) => U): ZodFormattedError<T, U>;
  static create: (issues: ZodIssue[]) => ZodError<any>;
  static assert(value: unknown): asserts value is ZodError;
  toString(): string;
  get message(): string;
  get isEmpty(): boolean;
  addIssue: (sub: ZodIssue) => void;
  addIssues: (subs?: ZodIssue[]) => void;
  flatten(): typeToFlattenedError<T>;
  flatten<U>(mapper?: (issue: ZodIssue) => U): typeToFlattenedError<T, U>;
  get formErrors(): typeToFlattenedError<T, string>;
}
type stripPath<T extends object> = T extends any ? util.OmitKeys<T, "path"> : never;
type IssueData = stripPath<ZodIssueOptionalMessage> & {
  path?: (string | number)[];
  fatal?: boolean | undefined;
};
type ErrorMapCtx = {
  defaultError: string;
  data: any;
};
type ZodErrorMap = (issue: ZodIssueOptionalMessage, _ctx: ErrorMapCtx) => {
  message: string;
};
//#endregion
//#region ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/parseUtil.d.cts
type ParseParams = {
  path: (string | number)[];
  errorMap: ZodErrorMap;
  async: boolean;
};
type ParsePathComponent = string | number;
type ParsePath = ParsePathComponent[];
interface ParseContext {
  readonly common: {
    readonly issues: ZodIssue[];
    readonly contextualErrorMap?: ZodErrorMap | undefined;
    readonly async: boolean;
  };
  readonly path: ParsePath;
  readonly schemaErrorMap?: ZodErrorMap | undefined;
  readonly parent: ParseContext | null;
  readonly data: any;
  readonly parsedType: ZodParsedType;
}
type ParseInput = {
  data: any;
  path: (string | number)[];
  parent: ParseContext;
};
declare class ParseStatus {
  value: "aborted" | "dirty" | "valid";
  dirty(): void;
  abort(): void;
  static mergeArray(status: ParseStatus, results: SyncParseReturnType<any>[]): SyncParseReturnType;
  static mergeObjectAsync(status: ParseStatus, pairs: {
    key: ParseReturnType<any>;
    value: ParseReturnType<any>;
  }[]): Promise<SyncParseReturnType<any>>;
  static mergeObjectSync(status: ParseStatus, pairs: {
    key: SyncParseReturnType<any>;
    value: SyncParseReturnType<any>;
    alwaysSet?: boolean;
  }[]): SyncParseReturnType;
}
type INVALID = {
  status: "aborted";
};
declare const INVALID: INVALID;
type DIRTY<T> = {
  status: "dirty";
  value: T;
};
declare const DIRTY: <T>(value: T) => DIRTY<T>;
type OK<T> = {
  status: "valid";
  value: T;
};
declare const OK: <T>(value: T) => OK<T>;
type SyncParseReturnType<T = any> = OK<T> | DIRTY<T> | INVALID;
type AsyncParseReturnType<T> = Promise<SyncParseReturnType<T>>;
type ParseReturnType<T> = SyncParseReturnType<T> | AsyncParseReturnType<T>;
//#endregion
//#region ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/helpers/errorUtil.d.cts
declare namespace errorUtil {
  type ErrMessage = string | {
    message?: string | undefined;
  };
  const errToObj: (message?: ErrMessage) => {
    message?: string | undefined;
  };
  const toString: (message?: ErrMessage) => string | undefined;
}
//#endregion
//#region ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/standard-schema.d.cts
/**
 * The Standard Schema interface.
 */
type StandardSchemaV1<Input = unknown, Output = Input> = {
  /**
   * The Standard Schema properties.
   */
  readonly "~standard": StandardSchemaV1.Props<Input, Output>;
};
declare namespace StandardSchemaV1 {
  /**
   * The Standard Schema properties interface.
   */
  export interface Props<Input = unknown, Output = Input> {
    /**
     * The version number of the standard.
     */
    readonly version: 1;
    /**
     * The vendor name of the schema library.
     */
    readonly vendor: string;
    /**
     * Validates unknown input values.
     */
    readonly validate: (value: unknown) => Result<Output> | Promise<Result<Output>>;
    /**
     * Inferred types associated with the schema.
     */
    readonly types?: Types<Input, Output> | undefined;
  }
  /**
   * The result interface of the validate function.
   */
  export type Result<Output> = SuccessResult<Output> | FailureResult;
  /**
   * The result interface if validation succeeds.
   */
  export interface SuccessResult<Output> {
    /**
     * The typed output value.
     */
    readonly value: Output;
    /**
     * The non-existent issues.
     */
    readonly issues?: undefined;
  }
  /**
   * The result interface if validation fails.
   */
  export interface FailureResult {
    /**
     * The issues of failed validation.
     */
    readonly issues: ReadonlyArray<Issue>;
  }
  /**
   * The issue interface of the failure output.
   */
  export interface Issue {
    /**
     * The error message of the issue.
     */
    readonly message: string;
    /**
     * The path of the issue, if any.
     */
    readonly path?: ReadonlyArray<PropertyKey | PathSegment> | undefined;
  }
  /**
   * The path segment interface of the issue.
   */
  export interface PathSegment {
    /**
     * The key representing a path segment.
     */
    readonly key: PropertyKey;
  }
  /**
   * The Standard Schema types interface.
   */
  export interface Types<Input = unknown, Output = Input> {
    /**
     * The input type of the schema.
     */
    readonly input: Input;
    /**
     * The output type of the schema.
     */
    readonly output: Output;
  }
  /**
   * Infers the input type of a Standard Schema.
   */
  export type InferInput<Schema extends StandardSchemaV1> = NonNullable<Schema["~standard"]["types"]>["input"];
  /**
   * Infers the output type of a Standard Schema.
   */
  export type InferOutput<Schema extends StandardSchemaV1> = NonNullable<Schema["~standard"]["types"]>["output"];
  export {};
}
//#endregion
//#region ../node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/types.d.cts
interface RefinementCtx {
  addIssue: (arg: IssueData) => void;
  path: (string | number)[];
}
type ZodTypeAny = ZodType<any, any, any>;
type TypeOf<T extends ZodType<any, any, any>> = T["_output"];
type input<T extends ZodType<any, any, any>> = T["_input"];
type output<T extends ZodType<any, any, any>> = T["_output"];
type CustomErrorParams = Partial<util.Omit<ZodCustomIssue, "code">>;
interface ZodTypeDef {
  errorMap?: ZodErrorMap | undefined;
  description?: string | undefined;
}
type RawCreateParams = {
  errorMap?: ZodErrorMap | undefined;
  invalid_type_error?: string | undefined;
  required_error?: string | undefined;
  message?: string | undefined;
  description?: string | undefined;
} | undefined;
type SafeParseSuccess<Output> = {
  success: true;
  data: Output;
  error?: never;
};
type SafeParseError<Input> = {
  success: false;
  error: ZodError<Input>;
  data?: never;
};
type SafeParseReturnType<Input, Output> = SafeParseSuccess<Output> | SafeParseError<Input>;
declare abstract class ZodType<Output = any, Def extends ZodTypeDef = ZodTypeDef, Input = Output> {
  readonly _type: Output;
  readonly _output: Output;
  readonly _input: Input;
  readonly _def: Def;
  get description(): string | undefined;
  "~standard": StandardSchemaV1.Props<Input, Output>;
  abstract _parse(input: ParseInput): ParseReturnType<Output>;
  _getType(input: ParseInput): string;
  _getOrReturnCtx(input: ParseInput, ctx?: ParseContext | undefined): ParseContext;
  _processInputParams(input: ParseInput): {
    status: ParseStatus;
    ctx: ParseContext;
  };
  _parseSync(input: ParseInput): SyncParseReturnType<Output>;
  _parseAsync(input: ParseInput): AsyncParseReturnType<Output>;
  parse(data: unknown, params?: util.InexactPartial<ParseParams>): Output;
  safeParse(data: unknown, params?: util.InexactPartial<ParseParams>): SafeParseReturnType<Input, Output>;
  "~validate"(data: unknown): StandardSchemaV1.Result<Output> | Promise<StandardSchemaV1.Result<Output>>;
  parseAsync(data: unknown, params?: util.InexactPartial<ParseParams>): Promise<Output>;
  safeParseAsync(data: unknown, params?: util.InexactPartial<ParseParams>): Promise<SafeParseReturnType<Input, Output>>;
  /** Alias of safeParseAsync */
  spa: (data: unknown, params?: util.InexactPartial<ParseParams>) => Promise<SafeParseReturnType<Input, Output>>;
  refine<RefinedOutput extends Output>(check: (arg: Output) => arg is RefinedOutput, message?: string | CustomErrorParams | ((arg: Output) => CustomErrorParams)): ZodEffects<this, RefinedOutput, Input>;
  refine(check: (arg: Output) => unknown | Promise<unknown>, message?: string | CustomErrorParams | ((arg: Output) => CustomErrorParams)): ZodEffects<this, Output, Input>;
  refinement<RefinedOutput extends Output>(check: (arg: Output) => arg is RefinedOutput, refinementData: IssueData | ((arg: Output, ctx: RefinementCtx) => IssueData)): ZodEffects<this, RefinedOutput, Input>;
  refinement(check: (arg: Output) => boolean, refinementData: IssueData | ((arg: Output, ctx: RefinementCtx) => IssueData)): ZodEffects<this, Output, Input>;
  _refinement(refinement: RefinementEffect<Output>["refinement"]): ZodEffects<this, Output, Input>;
  superRefine<RefinedOutput extends Output>(refinement: (arg: Output, ctx: RefinementCtx) => arg is RefinedOutput): ZodEffects<this, RefinedOutput, Input>;
  superRefine(refinement: (arg: Output, ctx: RefinementCtx) => void): ZodEffects<this, Output, Input>;
  superRefine(refinement: (arg: Output, ctx: RefinementCtx) => Promise<void>): ZodEffects<this, Output, Input>;
  constructor(def: Def);
  optional(): ZodOptional<this>;
  nullable(): ZodNullable<this>;
  nullish(): ZodOptional<ZodNullable<this>>;
  array(): ZodArray<this>;
  promise(): ZodPromise<this>;
  or<T extends ZodTypeAny>(option: T): ZodUnion<[this, T]>;
  and<T extends ZodTypeAny>(incoming: T): ZodIntersection<this, T>;
  transform<NewOut>(transform: (arg: Output, ctx: RefinementCtx) => NewOut | Promise<NewOut>): ZodEffects<this, NewOut>;
  default(def: util.noUndefined<Input>): ZodDefault<this>;
  default(def: () => util.noUndefined<Input>): ZodDefault<this>;
  brand<B extends string | number | symbol>(brand?: B): ZodBranded<this, B>;
  catch(def: Output): ZodCatch<this>;
  catch(def: (ctx: {
    error: ZodError;
    input: Input;
  }) => Output): ZodCatch<this>;
  describe(description: string): this;
  pipe<T extends ZodTypeAny>(target: T): ZodPipeline<this, T>;
  readonly(): ZodReadonly<this>;
  isOptional(): boolean;
  isNullable(): boolean;
}
type IpVersion = "v4" | "v6";
type ZodStringCheck = {
  kind: "min";
  value: number;
  message?: string | undefined;
} | {
  kind: "max";
  value: number;
  message?: string | undefined;
} | {
  kind: "length";
  value: number;
  message?: string | undefined;
} | {
  kind: "email";
  message?: string | undefined;
} | {
  kind: "url";
  message?: string | undefined;
} | {
  kind: "emoji";
  message?: string | undefined;
} | {
  kind: "uuid";
  message?: string | undefined;
} | {
  kind: "nanoid";
  message?: string | undefined;
} | {
  kind: "cuid";
  message?: string | undefined;
} | {
  kind: "includes";
  value: string;
  position?: number | undefined;
  message?: string | undefined;
} | {
  kind: "cuid2";
  message?: string | undefined;
} | {
  kind: "ulid";
  message?: string | undefined;
} | {
  kind: "startsWith";
  value: string;
  message?: string | undefined;
} | {
  kind: "endsWith";
  value: string;
  message?: string | undefined;
} | {
  kind: "regex";
  regex: RegExp;
  message?: string | undefined;
} | {
  kind: "trim";
  message?: string | undefined;
} | {
  kind: "toLowerCase";
  message?: string | undefined;
} | {
  kind: "toUpperCase";
  message?: string | undefined;
} | {
  kind: "jwt";
  alg?: string;
  message?: string | undefined;
} | {
  kind: "datetime";
  offset: boolean;
  local: boolean;
  precision: number | null;
  message?: string | undefined;
} | {
  kind: "date";
  message?: string | undefined;
} | {
  kind: "time";
  precision: number | null;
  message?: string | undefined;
} | {
  kind: "duration";
  message?: string | undefined;
} | {
  kind: "ip";
  version?: IpVersion | undefined;
  message?: string | undefined;
} | {
  kind: "cidr";
  version?: IpVersion | undefined;
  message?: string | undefined;
} | {
  kind: "base64";
  message?: string | undefined;
} | {
  kind: "base64url";
  message?: string | undefined;
};
interface ZodStringDef extends ZodTypeDef {
  checks: ZodStringCheck[];
  typeName: ZodFirstPartyTypeKind.ZodString;
  coerce: boolean;
}
declare class ZodString extends ZodType<string, ZodStringDef, string> {
  _parse(input: ParseInput): ParseReturnType<string>;
  protected _regex(regex: RegExp, validation: StringValidation, message?: errorUtil.ErrMessage): ZodEffects<this, string, string>;
  _addCheck(check: ZodStringCheck): ZodString;
  email(message?: errorUtil.ErrMessage): ZodString;
  url(message?: errorUtil.ErrMessage): ZodString;
  emoji(message?: errorUtil.ErrMessage): ZodString;
  uuid(message?: errorUtil.ErrMessage): ZodString;
  nanoid(message?: errorUtil.ErrMessage): ZodString;
  cuid(message?: errorUtil.ErrMessage): ZodString;
  cuid2(message?: errorUtil.ErrMessage): ZodString;
  ulid(message?: errorUtil.ErrMessage): ZodString;
  base64(message?: errorUtil.ErrMessage): ZodString;
  base64url(message?: errorUtil.ErrMessage): ZodString;
  jwt(options?: {
    alg?: string;
    message?: string | undefined;
  }): ZodString;
  ip(options?: string | {
    version?: IpVersion;
    message?: string | undefined;
  }): ZodString;
  cidr(options?: string | {
    version?: IpVersion;
    message?: string | undefined;
  }): ZodString;
  datetime(options?: string | {
    message?: string | undefined;
    precision?: number | null;
    offset?: boolean;
    local?: boolean;
  }): ZodString;
  date(message?: string): ZodString;
  time(options?: string | {
    message?: string | undefined;
    precision?: number | null;
  }): ZodString;
  duration(message?: errorUtil.ErrMessage): ZodString;
  regex(regex: RegExp, message?: errorUtil.ErrMessage): ZodString;
  includes(value: string, options?: {
    message?: string;
    position?: number;
  }): ZodString;
  startsWith(value: string, message?: errorUtil.ErrMessage): ZodString;
  endsWith(value: string, message?: errorUtil.ErrMessage): ZodString;
  min(minLength: number, message?: errorUtil.ErrMessage): ZodString;
  max(maxLength: number, message?: errorUtil.ErrMessage): ZodString;
  length(len: number, message?: errorUtil.ErrMessage): ZodString;
  /**
   * Equivalent to `.min(1)`
   */
  nonempty(message?: errorUtil.ErrMessage): ZodString;
  trim(): ZodString;
  toLowerCase(): ZodString;
  toUpperCase(): ZodString;
  get isDatetime(): boolean;
  get isDate(): boolean;
  get isTime(): boolean;
  get isDuration(): boolean;
  get isEmail(): boolean;
  get isURL(): boolean;
  get isEmoji(): boolean;
  get isUUID(): boolean;
  get isNANOID(): boolean;
  get isCUID(): boolean;
  get isCUID2(): boolean;
  get isULID(): boolean;
  get isIP(): boolean;
  get isCIDR(): boolean;
  get isBase64(): boolean;
  get isBase64url(): boolean;
  get minLength(): number | null;
  get maxLength(): number | null;
  static create: (params?: RawCreateParams & {
    coerce?: true;
  }) => ZodString;
}
interface ZodArrayDef<T extends ZodTypeAny = ZodTypeAny> extends ZodTypeDef {
  type: T;
  typeName: ZodFirstPartyTypeKind.ZodArray;
  exactLength: {
    value: number;
    message?: string | undefined;
  } | null;
  minLength: {
    value: number;
    message?: string | undefined;
  } | null;
  maxLength: {
    value: number;
    message?: string | undefined;
  } | null;
}
type ArrayCardinality = "many" | "atleastone";
type arrayOutputType<T extends ZodTypeAny, Cardinality extends ArrayCardinality = "many"> = Cardinality extends "atleastone" ? [T["_output"], ...T["_output"][]] : T["_output"][];
declare class ZodArray<T extends ZodTypeAny, Cardinality extends ArrayCardinality = "many"> extends ZodType<arrayOutputType<T, Cardinality>, ZodArrayDef<T>, Cardinality extends "atleastone" ? [T["_input"], ...T["_input"][]] : T["_input"][]> {
  _parse(input: ParseInput): ParseReturnType<this["_output"]>;
  get element(): T;
  min(minLength: number, message?: errorUtil.ErrMessage): this;
  max(maxLength: number, message?: errorUtil.ErrMessage): this;
  length(len: number, message?: errorUtil.ErrMessage): this;
  nonempty(message?: errorUtil.ErrMessage): ZodArray<T, "atleastone">;
  static create: <El extends ZodTypeAny>(schema: El, params?: RawCreateParams) => ZodArray<El>;
}
type ZodUnionOptions = Readonly<[ZodTypeAny, ...ZodTypeAny[]]>;
interface ZodUnionDef<T extends ZodUnionOptions = Readonly<[ZodTypeAny, ZodTypeAny, ...ZodTypeAny[]]>> extends ZodTypeDef {
  options: T;
  typeName: ZodFirstPartyTypeKind.ZodUnion;
}
declare class ZodUnion<T extends ZodUnionOptions> extends ZodType<T[number]["_output"], ZodUnionDef<T>, T[number]["_input"]> {
  _parse(input: ParseInput): ParseReturnType<this["_output"]>;
  get options(): T;
  static create: <Options extends Readonly<[ZodTypeAny, ZodTypeAny, ...ZodTypeAny[]]>>(types: Options, params?: RawCreateParams) => ZodUnion<Options>;
}
interface ZodIntersectionDef<T extends ZodTypeAny = ZodTypeAny, U extends ZodTypeAny = ZodTypeAny> extends ZodTypeDef {
  left: T;
  right: U;
  typeName: ZodFirstPartyTypeKind.ZodIntersection;
}
declare class ZodIntersection<T extends ZodTypeAny, U extends ZodTypeAny> extends ZodType<T["_output"] & U["_output"], ZodIntersectionDef<T, U>, T["_input"] & U["_input"]> {
  _parse(input: ParseInput): ParseReturnType<this["_output"]>;
  static create: <TSchema extends ZodTypeAny, USchema extends ZodTypeAny>(left: TSchema, right: USchema, params?: RawCreateParams) => ZodIntersection<TSchema, USchema>;
}
type ZodTupleItems = [ZodTypeAny, ...ZodTypeAny[]];
type AssertArray<T> = T extends any[] ? T : never;
type OutputTypeOfTuple<T extends ZodTupleItems | []> = AssertArray<{ [k in keyof T]: T[k] extends ZodType<any, any, any> ? T[k]["_output"] : never }>;
type OutputTypeOfTupleWithRest<T extends ZodTupleItems | [], Rest extends ZodTypeAny | null = null> = Rest extends ZodTypeAny ? [...OutputTypeOfTuple<T>, ...Rest["_output"][]] : OutputTypeOfTuple<T>;
type InputTypeOfTuple<T extends ZodTupleItems | []> = AssertArray<{ [k in keyof T]: T[k] extends ZodType<any, any, any> ? T[k]["_input"] : never }>;
type InputTypeOfTupleWithRest<T extends ZodTupleItems | [], Rest extends ZodTypeAny | null = null> = Rest extends ZodTypeAny ? [...InputTypeOfTuple<T>, ...Rest["_input"][]] : InputTypeOfTuple<T>;
interface ZodTupleDef<T extends ZodTupleItems | [] = ZodTupleItems, Rest extends ZodTypeAny | null = null> extends ZodTypeDef {
  items: T;
  rest: Rest;
  typeName: ZodFirstPartyTypeKind.ZodTuple;
}
declare class ZodTuple<T extends ZodTupleItems | [] = ZodTupleItems, Rest extends ZodTypeAny | null = null> extends ZodType<OutputTypeOfTupleWithRest<T, Rest>, ZodTupleDef<T, Rest>, InputTypeOfTupleWithRest<T, Rest>> {
  _parse(input: ParseInput): ParseReturnType<this["_output"]>;
  get items(): T;
  rest<RestSchema extends ZodTypeAny>(rest: RestSchema): ZodTuple<T, RestSchema>;
  static create: <Items extends [ZodTypeAny, ...ZodTypeAny[]] | []>(schemas: Items, params?: RawCreateParams) => ZodTuple<Items, null>;
}
interface ZodPromiseDef<T extends ZodTypeAny = ZodTypeAny> extends ZodTypeDef {
  type: T;
  typeName: ZodFirstPartyTypeKind.ZodPromise;
}
declare class ZodPromise<T extends ZodTypeAny> extends ZodType<Promise<T["_output"]>, ZodPromiseDef<T>, Promise<T["_input"]>> {
  unwrap(): T;
  _parse(input: ParseInput): ParseReturnType<this["_output"]>;
  static create: <Inner extends ZodTypeAny>(schema: Inner, params?: RawCreateParams) => ZodPromise<Inner>;
}
type RefinementEffect<T> = {
  type: "refinement";
  refinement: (arg: T, ctx: RefinementCtx) => any;
};
type TransformEffect<T> = {
  type: "transform";
  transform: (arg: T, ctx: RefinementCtx) => any;
};
type PreprocessEffect<T> = {
  type: "preprocess";
  transform: (arg: T, ctx: RefinementCtx) => any;
};
type Effect<T> = RefinementEffect<T> | TransformEffect<T> | PreprocessEffect<T>;
interface ZodEffectsDef<T extends ZodTypeAny = ZodTypeAny> extends ZodTypeDef {
  schema: T;
  typeName: ZodFirstPartyTypeKind.ZodEffects;
  effect: Effect<any>;
}
declare class ZodEffects<T extends ZodTypeAny, Output = output<T>, Input = input<T>> extends ZodType<Output, ZodEffectsDef<T>, Input> {
  innerType(): T;
  sourceType(): T;
  _parse(input: ParseInput): ParseReturnType<this["_output"]>;
  static create: <I extends ZodTypeAny>(schema: I, effect: Effect<I["_output"]>, params?: RawCreateParams) => ZodEffects<I, I["_output"]>;
  static createWithPreprocess: <I extends ZodTypeAny>(preprocess: (arg: unknown, ctx: RefinementCtx) => unknown, schema: I, params?: RawCreateParams) => ZodEffects<I, I["_output"], unknown>;
}
interface ZodOptionalDef<T extends ZodTypeAny = ZodTypeAny> extends ZodTypeDef {
  innerType: T;
  typeName: ZodFirstPartyTypeKind.ZodOptional;
}
declare class ZodOptional<T extends ZodTypeAny> extends ZodType<T["_output"] | undefined, ZodOptionalDef<T>, T["_input"] | undefined> {
  _parse(input: ParseInput): ParseReturnType<this["_output"]>;
  unwrap(): T;
  static create: <Inner extends ZodTypeAny>(type: Inner, params?: RawCreateParams) => ZodOptional<Inner>;
}
interface ZodNullableDef<T extends ZodTypeAny = ZodTypeAny> extends ZodTypeDef {
  innerType: T;
  typeName: ZodFirstPartyTypeKind.ZodNullable;
}
declare class ZodNullable<T extends ZodTypeAny> extends ZodType<T["_output"] | null, ZodNullableDef<T>, T["_input"] | null> {
  _parse(input: ParseInput): ParseReturnType<this["_output"]>;
  unwrap(): T;
  static create: <Inner extends ZodTypeAny>(type: Inner, params?: RawCreateParams) => ZodNullable<Inner>;
}
interface ZodDefaultDef<T extends ZodTypeAny = ZodTypeAny> extends ZodTypeDef {
  innerType: T;
  defaultValue: () => util.noUndefined<T["_input"]>;
  typeName: ZodFirstPartyTypeKind.ZodDefault;
}
declare class ZodDefault<T extends ZodTypeAny> extends ZodType<util.noUndefined<T["_output"]>, ZodDefaultDef<T>, T["_input"] | undefined> {
  _parse(input: ParseInput): ParseReturnType<this["_output"]>;
  removeDefault(): T;
  static create: <Inner extends ZodTypeAny>(type: Inner, params: RawCreateParams & {
    default: Inner["_input"] | (() => util.noUndefined<Inner["_input"]>);
  }) => ZodDefault<Inner>;
}
interface ZodCatchDef<T extends ZodTypeAny = ZodTypeAny> extends ZodTypeDef {
  innerType: T;
  catchValue: (ctx: {
    error: ZodError;
    input: unknown;
  }) => T["_input"];
  typeName: ZodFirstPartyTypeKind.ZodCatch;
}
declare class ZodCatch<T extends ZodTypeAny> extends ZodType<T["_output"], ZodCatchDef<T>, unknown> {
  _parse(input: ParseInput): ParseReturnType<this["_output"]>;
  removeCatch(): T;
  static create: <Inner extends ZodTypeAny>(type: Inner, params: RawCreateParams & {
    catch: Inner["_output"] | (() => Inner["_output"]);
  }) => ZodCatch<Inner>;
}
interface ZodBrandedDef<T extends ZodTypeAny> extends ZodTypeDef {
  type: T;
  typeName: ZodFirstPartyTypeKind.ZodBranded;
}
declare const BRAND: unique symbol;
type BRAND<T extends string | number | symbol> = {
  [BRAND]: { [k in T]: true };
};
declare class ZodBranded<T extends ZodTypeAny, B extends string | number | symbol> extends ZodType<T["_output"] & BRAND<B>, ZodBrandedDef<T>, T["_input"]> {
  _parse(input: ParseInput): ParseReturnType<any>;
  unwrap(): T;
}
interface ZodPipelineDef<A extends ZodTypeAny, B extends ZodTypeAny> extends ZodTypeDef {
  in: A;
  out: B;
  typeName: ZodFirstPartyTypeKind.ZodPipeline;
}
declare class ZodPipeline<A extends ZodTypeAny, B extends ZodTypeAny> extends ZodType<B["_output"], ZodPipelineDef<A, B>, A["_input"]> {
  _parse(input: ParseInput): ParseReturnType<any>;
  static create<ASchema extends ZodTypeAny, BSchema extends ZodTypeAny>(a: ASchema, b: BSchema): ZodPipeline<ASchema, BSchema>;
}
type BuiltIn = (((...args: any[]) => any) | (new (...args: any[]) => any)) | {
  readonly [Symbol.toStringTag]: string;
} | Date | Error | Generator | Promise<unknown> | RegExp;
type MakeReadonly<T> = T extends Map<infer K, infer V> ? ReadonlyMap<K, V> : T extends Set<infer V> ? ReadonlySet<V> : T extends [infer Head, ...infer Tail] ? readonly [Head, ...Tail] : T extends Array<infer V> ? ReadonlyArray<V> : T extends BuiltIn ? T : Readonly<T>;
interface ZodReadonlyDef<T extends ZodTypeAny = ZodTypeAny> extends ZodTypeDef {
  innerType: T;
  typeName: ZodFirstPartyTypeKind.ZodReadonly;
}
declare class ZodReadonly<T extends ZodTypeAny> extends ZodType<MakeReadonly<T["_output"]>, ZodReadonlyDef<T>, MakeReadonly<T["_input"]>> {
  _parse(input: ParseInput): ParseReturnType<this["_output"]>;
  static create: <Inner extends ZodTypeAny>(type: Inner, params?: RawCreateParams) => ZodReadonly<Inner>;
  unwrap(): T;
}
declare enum ZodFirstPartyTypeKind {
  ZodString = "ZodString",
  ZodNumber = "ZodNumber",
  ZodNaN = "ZodNaN",
  ZodBigInt = "ZodBigInt",
  ZodBoolean = "ZodBoolean",
  ZodDate = "ZodDate",
  ZodSymbol = "ZodSymbol",
  ZodUndefined = "ZodUndefined",
  ZodNull = "ZodNull",
  ZodAny = "ZodAny",
  ZodUnknown = "ZodUnknown",
  ZodNever = "ZodNever",
  ZodVoid = "ZodVoid",
  ZodArray = "ZodArray",
  ZodObject = "ZodObject",
  ZodUnion = "ZodUnion",
  ZodDiscriminatedUnion = "ZodDiscriminatedUnion",
  ZodIntersection = "ZodIntersection",
  ZodTuple = "ZodTuple",
  ZodRecord = "ZodRecord",
  ZodMap = "ZodMap",
  ZodSet = "ZodSet",
  ZodFunction = "ZodFunction",
  ZodLazy = "ZodLazy",
  ZodLiteral = "ZodLiteral",
  ZodEnum = "ZodEnum",
  ZodEffects = "ZodEffects",
  ZodNativeEnum = "ZodNativeEnum",
  ZodOptional = "ZodOptional",
  ZodNullable = "ZodNullable",
  ZodDefault = "ZodDefault",
  ZodCatch = "ZodCatch",
  ZodPromise = "ZodPromise",
  ZodBranded = "ZodBranded",
  ZodPipeline = "ZodPipeline",
  ZodReadonly = "ZodReadonly"
}
//#endregion
//#region src/cli/hints.d.ts
declare const renameCreateEntitySchemas: readonly [{
  readonly kind: "table";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "column";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "default";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "schema";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "enum";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "sequence";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "view";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "policy";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "role";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "privilege";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "check";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "index";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "unique";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "primary_key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "foreign key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}];
type RenameCreateHintKind = typeof renameCreateEntitySchemas[number]['kind'];
declare const confirmEntitySchemas: readonly [{
  readonly kind: "table";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "column";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "schema";
  readonly schema: ZodTuple<[ZodString], null>;
}, {
  readonly kind: "view";
  readonly schema: ZodTuple<[ZodString, ZodString], null>;
}, {
  readonly kind: "primary_key";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "add_not_null";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}, {
  readonly kind: "add_unique";
  readonly schema: ZodTuple<[ZodString, ZodString, ZodString], null>;
}];
type ConfirmEntityKind = typeof confirmEntitySchemas[number]['kind'];
type RenameCreateSchemaFor<K extends RenameCreateHintKind> = Extract<typeof renameCreateEntitySchemas[number], {
  kind: K;
}>['schema'];
type ConfirmSchemaFor<K extends ConfirmEntityKind> = Extract<typeof confirmEntitySchemas[number], {
  kind: K;
}>['schema'];
type IdFor<K extends RenameCreateHintKind> = Readonly<TypeOf<RenameCreateSchemaFor<K>>>;
type ConfirmIdFor<K extends ConfirmEntityKind> = Readonly<TypeOf<ConfirmSchemaFor<K>>>;
type RenameHint = { [K in RenameCreateHintKind]: {
  type: 'rename';
  kind: K;
  from: IdFor<K>;
  to: IdFor<K>;
} }[RenameCreateHintKind];
type CreateHint = { [K in RenameCreateHintKind]: {
  type: 'create';
  kind: K;
  entity: IdFor<K>;
} }[RenameCreateHintKind];
type ConfirmDataLossHint = { [K in ConfirmEntityKind]: {
  type: 'confirm_data_loss';
  kind: K;
  entity: ConfirmIdFor<K>;
} }[ConfirmEntityKind];
type Hint = RenameHint | CreateHint | ConfirmDataLossHint;
type RenameCreateMissingHint<K extends RenameCreateHintKind> = {
  type: 'rename_or_create';
  kind: K;
  entity: IdFor<K>;
};
type ConfirmDataLossReasonDetails = {
  reason: 'non_empty';
} | {
  reason: 'table_recreate';
} | {
  reason: 'type_change';
  reason_details: {
    from: string;
    to: string;
  };
};
type ConfirmDataLossMissingHint<K extends ConfirmEntityKind> = {
  type: 'confirm_data_loss';
  kind: K;
  entity: ConfirmIdFor<K>;
} & ConfirmDataLossReasonDetails;
type MissingHint = { [K in RenameCreateHintKind]: RenameCreateMissingHint<K> }[RenameCreateHintKind] | { [K in ConfirmEntityKind]: ConfirmDataLossMissingHint<K> }[ConfirmEntityKind];
type MissingHintsResponse = {
  status: 'missing_hints';
  unresolved: readonly MissingHint[];
};
//#endregion
//#region src/@types/utils.d.ts
declare global {
  interface String {
    trimChar(char: string): string;
    squashSpaces(): string;
    capitalise(): string;
    camelCase(): string;
    snake_case(): string;
    concatIf(it: string, condition: boolean): string;
  }
  interface Array<T> {
    random(): T;
  }
}
//#endregion
//#region src/cli/schema.d.ts
declare const generateOptions: {
  readonly config: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly driver: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "d1-http" | "expo" | "aws-data-api" | "pglite" | "durable-sqlite" | "sqlite-cloud" | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly schema: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly out: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly name: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly breakpoints: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly custom: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
  readonly ignoreConflicts: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly explain: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
  readonly output: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "text" | "json", "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
  readonly hints: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly hintsFile: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
};
declare const pushOptions: {
  readonly verbose: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
  readonly strict: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly force: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
  readonly output: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "text" | "json", "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
  readonly explain: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
  readonly hints: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly hintsFile: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly url: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly host: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly port: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly user: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly password: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly database: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly ssl: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly authToken: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly tlsSecurity: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly driver: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "d1-http" | "expo" | "aws-data-api" | "pglite" | "durable-sqlite" | "sqlite-cloud" | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly tablesFilter: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly schemaFilters: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly extensionsFilters: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly config: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly schema: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
};
declare const checkOptions: {
  readonly config: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly out: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly ignoreConflicts: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly output: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "text" | "json", "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
};
declare const upOptions: {
  readonly config: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly out: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly output: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "text" | "json", "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
};
declare const pullOptions: {
  readonly output: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "text" | "json", "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
  readonly url: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly host: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly port: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly user: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly password: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly database: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly ssl: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly authToken: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly tlsSecurity: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly driver: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "d1-http" | "expo" | "aws-data-api" | "pglite" | "durable-sqlite" | "sqlite-cloud" | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly tablesFilter: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly schemaFilters: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly extensionsFilters: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly config: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly out: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly breakpoints: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly casing: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "camel" | "preserve" | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int", "camel" | "preserve">, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int">;
  readonly init: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
};
declare const exportOptions: {
  readonly sql: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"boolean">, boolean, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
  readonly config: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly dialect: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb" | undefined, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly schema: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, string | undefined, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc", undefined>, _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc">;
  readonly output: Omit<_drizzle_team_brocli0.OptionBuilderBase<_drizzle_team_brocli0.BuilderConfig<"string">, "text" | "json", "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required", undefined>, "default" | "enum" | _drizzle_team_brocli0.OptionType | "min" | "max" | "int" | "desc" | "required">;
};
//#endregion
//#region src/cli/contract.d.ts
type BrocliInputOf<TOptions extends Record<string, GenericBuilderInternals>> = Simplify<{ [K in keyof TOptions]?: TOptions[K]['_']['$output'] | undefined }>;
type GenerateOptionsInput = BrocliInputOf<typeof generateOptions> & {
  dialect?: Dialect;
};
type PushOptionsInput = BrocliInputOf<typeof pushOptions> & {
  dialect?: Dialect;
};
/**
 * Public SDK option type; the `output` flag is omitted because the SDK always
 * runs in JSON mode internally and never accepts a caller-supplied output mode.
 * `hints` is a raw `Hint[]`, whereas the CLI `--hints` flag takes a JSON string.
 */
type GenerateOptions = Omit<GenerateOptionsInput, 'output' | 'hints'> & {
  hints?: Hint[];
};
/**
 * Public SDK option type; the `output` flag is omitted because the SDK always
 * runs in JSON mode internally and never accepts a caller-supplied output mode.
 * `hints` is a raw `Hint[]`, whereas the CLI `--hints` flag takes a JSON string.
 */
type PushOptions = Omit<PushOptionsInput, 'output' | 'hints'> & {
  hints?: Hint[];
};
type CheckOptionsInput = BrocliInputOf<typeof checkOptions> & {
  dialect?: Dialect;
};
type CheckOptions = Omit<CheckOptionsInput, 'output'>;
type ExportOptionsInput = BrocliInputOf<typeof exportOptions> & {
  dialect?: Dialect;
};
type ExportOptions = Omit<ExportOptionsInput, 'output'>;
type UpOptionsInput = BrocliInputOf<typeof upOptions> & {
  dialect?: Dialect;
};
type UpOptions = Omit<UpOptionsInput, 'output'>;
type PullOptionsInput = BrocliInputOf<typeof pullOptions> & {
  dialect?: Dialect;
};
type PullOptions = Omit<PullOptionsInput, 'output'>;
//#endregion
//#region src/cli-sdk/check.d.ts
declare const check: (opts: CheckOptions) => Promise<{
  status: "ok";
  dialect: "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach" | "duckdb";
} | {
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
}>;
//#endregion
//#region src/cli-sdk/export.d.ts
declare const exportSql: (opts: ExportOptions) => Promise<{
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
} | {
  status: "ok";
  dialect: "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach";
  statements: string[];
  warnings: string[];
}>;
//#endregion
//#region src/cli-sdk/generate.d.ts
declare const generate: (opts: GenerateOptions) => Promise<{
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
} | MissingHintsResponse | {
  status: "no_changes";
  dialect: string | undefined;
} | {
  status: "ok";
  dialect: string | undefined;
  migration_path: string;
} | {
  status: "ok";
  dialect: string;
}>;
//#endregion
//#region src/cli-sdk/pull.d.ts
declare const pull: (opts: PullOptions) => Promise<{
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
} | {
  schemaPath: string;
  relationsPath?: string;
  snapshotPath: string;
  migrationPath?: string;
  status: "ok";
  dialect: "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach";
}>;
//#endregion
//#region src/cli-sdk/push.d.ts
declare const push: (opts: PushOptions) => Promise<{
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
} | MissingHintsResponse | {
  status: "no_changes";
  dialect: string;
} | {
  status: "ok";
  dialect: string;
}>;
//#endregion
//#region src/cli-sdk/up.d.ts
declare const up: (opts: UpOptions) => Promise<{
  status: "error";
  error: {
    code: string;
    sql?: undefined;
    params?: undefined;
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    sql: string;
    params: any[];
    message?: undefined;
  };
} | {
  status: "error";
  error: {
    code: string;
    message: string;
    sql?: undefined;
    params?: undefined;
  };
} | {
  status: "ok";
  dialect: "postgresql" | "mysql" | "sqlite" | "turso" | "singlestore" | "mssql" | "cockroach";
  upgraded: string[];
}>;
//#endregion
export { type CheckOptions, type ExportOptions, type GenerateOptions, type Hint, type MissingHint, type PullOptions, type PushOptions, type UpOptions, check, exportSql, generate, pull, push, up };