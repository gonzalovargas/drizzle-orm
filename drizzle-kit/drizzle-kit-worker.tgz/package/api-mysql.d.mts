import { t as MysqlCredentials } from "./mysql-BMCPSAUS.mjs";

//#region src/ext/api-mysql.d.ts
declare const startStudioServer: (imports: Record<string, unknown>, credentials: MysqlCredentials, options?: {
  host?: string;
  port?: number;
  key?: string;
  cert?: string;
}) => Promise<void>;
//#endregion
export { startStudioServer };