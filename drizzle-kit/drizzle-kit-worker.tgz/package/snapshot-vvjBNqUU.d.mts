import { i as DiffStatement, r as Config } from "./hints-By83v2-O.mjs";

//#region src/dialects/postgres/ddl.d.ts
declare const createDDL: () => {
  readonly _: {
    types: {
      schemas: {
        name: string;
        entityType: "schemas";
      };
      tables: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
      enums: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
      columns: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
      indexes: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
      fks: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        name: string;
        entityType: "fks";
      };
      pks: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
      uniques: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
      checks: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      sequences: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
      roles: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
      privileges: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
      policies: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
      views: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
    };
    definition: {
      schemas: {};
      tables: {
        schema: "required";
        isRlsEnabled: "boolean";
      };
      enums: {
        schema: "required";
        values: "string[]";
      };
      columns: {
        schema: "required";
        table: "required";
        type: "string";
        typeSchema: "string?";
        notNull: "boolean";
        dimensions: "number";
        default: "string?";
        generated: {
          type: ["stored"];
          as: "string";
        };
        identity: {
          name: "string";
          type: ["always", "byDefault"];
          increment: "string?";
          minValue: "string?";
          maxValue: "string?";
          startWith: "string?";
          cache: "number?";
          cycle: "boolean?";
        };
      };
      indexes: {
        schema: "required";
        table: "required";
        nameExplicit: "boolean";
        columns: [{
          value: "string";
          isExpression: "boolean";
          asc: "boolean";
          nullsFirst: "boolean";
          opclass: {
            name: "string";
            default: "boolean";
          };
        }];
        isUnique: "boolean";
        where: "string?";
        with: "string";
        method: "string";
        concurrently: "boolean";
      };
      fks: {
        schema: "required";
        table: "required";
        nameExplicit: "boolean";
        columns: "string[]";
        schemaTo: "string";
        tableTo: "string";
        columnsTo: "string[]";
        onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
        onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
      };
      pks: {
        schema: "required";
        table: "required";
        columns: "string[]";
        nameExplicit: "boolean";
      };
      uniques: {
        schema: "required";
        table: "required";
        nameExplicit: "boolean";
        columns: "string[]";
        nullsNotDistinct: "boolean";
      };
      checks: {
        schema: "required";
        table: "required";
        value: "string";
      };
      sequences: {
        schema: "required";
        incrementBy: "string?";
        minValue: "string?";
        maxValue: "string?";
        startWith: "string?";
        cacheSize: "number?";
        cycle: "boolean?";
      };
      roles: {
        superuser: "boolean?";
        createDb: "boolean?";
        createRole: "boolean?";
        inherit: "boolean?";
        canLogin: "boolean?";
        replication: "boolean?";
        bypassRls: "boolean?";
        connLimit: "number?";
        password: "string?";
        validUntil: "string?";
      };
      privileges: {
        grantor: "string";
        grantee: "string";
        schema: "required";
        table: "required";
        type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
        isGrantable: "boolean";
      };
      policies: {
        schema: "required";
        table: "required";
        as: ["PERMISSIVE", "RESTRICTIVE"];
        for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
        roles: "string[]";
        using: "string?";
        withCheck: "string?";
      };
      views: {
        schema: "required";
        definition: "string?";
        with: {
          checkOption: ["local", "cascaded", null];
          securityBarrier: "boolean?";
          securityInvoker: "boolean?";
          fillfactor: "number?";
          toastTupleTarget: "number?";
          parallelWorkers: "number?";
          autovacuumEnabled: "boolean?";
          vacuumIndexCleanup: ["auto", "off", "on", null];
          vacuumTruncate: "boolean?";
          autovacuumVacuumThreshold: "number?";
          autovacuumVacuumScaleFactor: "number?";
          autovacuumVacuumCostDelay: "number?";
          autovacuumVacuumCostLimit: "number?";
          autovacuumFreezeMinAge: "number?";
          autovacuumFreezeMaxAge: "number?";
          autovacuumFreezeTableAge: "number?";
          autovacuumMultixactFreezeMinAge: "number?";
          autovacuumMultixactFreezeMaxAge: "number?";
          autovacuumMultixactFreezeTableAge: "number?";
          logAutovacuumMinDuration: "number?";
          userCatalogTable: "boolean?";
        };
        withNoData: "boolean?";
        using: "string?";
        tablespace: "string?";
        materialized: "boolean";
      };
    };
    entities: {
      schemas: Config;
      tables: Config;
      enums: Config;
      columns: Config;
      indexes: Config;
      fks: Config;
      pks: Config;
      uniques: Config;
      checks: Config;
      sequences: Config;
      roles: Config;
      privileges: Config;
      policies: Config;
      views: Config;
    };
    diffs: {
      alter: {
        schemas: {
          $diffType: "alter";
          entityType: "schemas";
          name: string;
          $left: {
            name: string;
            entityType: "schemas";
          };
          $right: {
            name: string;
            entityType: "schemas";
          };
        };
        tables: {
          $diffType: "alter";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            isRlsEnabled: boolean;
            name: string;
            entityType: "tables";
          };
          $right: {
            schema: string;
            isRlsEnabled: boolean;
            name: string;
            entityType: "tables";
          };
        };
        columns: {
          $diffType: "alter";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type?: {
            from: string;
            to: string;
          } | undefined;
          notNull?: {
            from: boolean;
            to: boolean;
          } | undefined;
          generated?: {
            from: {
              type: "stored";
              as: string;
            } | null;
            to: {
              type: "stored";
              as: string;
            } | null;
          } | undefined;
          identity?: {
            from: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            to: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
          } | undefined;
          default?: {
            from: string | null;
            to: string | null;
          } | undefined;
          typeSchema?: {
            from: string | null;
            to: string | null;
          } | undefined;
          dimensions?: {
            from: number;
            to: number;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            type: string;
            typeSchema: string | null;
            notNull: boolean;
            dimensions: number;
            default: string | null;
            generated: {
              type: "stored";
              as: string;
            } | null;
            identity: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            name: string;
            entityType: "columns";
          };
          $right: {
            schema: string;
            table: string;
            type: string;
            typeSchema: string | null;
            notNull: boolean;
            dimensions: number;
            default: string | null;
            generated: {
              type: "stored";
              as: string;
            } | null;
            identity: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            name: string;
            entityType: "columns";
          };
        };
        pks: {
          $diffType: "alter";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
          $right: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
        };
        fks: {
          $diffType: "alter";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          schemaTo?: {
            from: string;
            to: string;
          } | undefined;
          tableTo?: {
            from: string;
            to: string;
          } | undefined;
          columnsTo?: {
            from: string[];
            to: string[];
          } | undefined;
          onUpdate?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          } | undefined;
          onDelete?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            name: string;
            entityType: "fks";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            name: string;
            entityType: "fks";
          };
        };
        indexes: {
          $diffType: "alter";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            to: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
          } | undefined;
          with?: {
            from: string;
            to: string;
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          isUnique?: {
            from: boolean;
            to: boolean;
          } | undefined;
          where?: {
            from: string | null;
            to: string | null;
          } | undefined;
          method?: {
            from: string;
            to: string;
          } | undefined;
          concurrently?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            isUnique: boolean;
            where: string | null;
            with: string;
            method: string;
            concurrently: boolean;
            name: string;
            entityType: "indexes";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            isUnique: boolean;
            where: string | null;
            with: string;
            method: string;
            concurrently: boolean;
            name: string;
            entityType: "indexes";
          };
        };
        uniques: {
          $diffType: "alter";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          nullsNotDistinct?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            nullsNotDistinct: boolean;
            name: string;
            entityType: "uniques";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            nullsNotDistinct: boolean;
            name: string;
            entityType: "uniques";
          };
        };
        checks: {
          $diffType: "alter";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
          $right: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
        };
        views: {
          $diffType: "alter";
          entityType: "views";
          schema: string;
          name: string;
          with?: {
            from: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            to: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
          } | undefined;
          definition?: {
            from: string | null;
            to: string | null;
          } | undefined;
          using?: {
            from: string | null;
            to: string | null;
          } | undefined;
          withNoData?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          tablespace?: {
            from: string | null;
            to: string | null;
          } | undefined;
          materialized?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            definition: string | null;
            with: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            withNoData: boolean | null;
            using: string | null;
            tablespace: string | null;
            materialized: boolean;
            name: string;
            entityType: "views";
          };
          $right: {
            schema: string;
            definition: string | null;
            with: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            withNoData: boolean | null;
            using: string | null;
            tablespace: string | null;
            materialized: boolean;
            name: string;
            entityType: "views";
          };
        };
        entities: {
          $diffType: "alter";
          entityType: "schemas";
          name: string;
          $left: {
            name: string;
            entityType: "schemas";
          };
          $right: {
            name: string;
            entityType: "schemas";
          };
        } | {
          $diffType: "alter";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            isRlsEnabled: boolean;
            name: string;
            entityType: "tables";
          };
          $right: {
            schema: string;
            isRlsEnabled: boolean;
            name: string;
            entityType: "tables";
          };
        } | {
          $diffType: "alter";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type?: {
            from: string;
            to: string;
          } | undefined;
          notNull?: {
            from: boolean;
            to: boolean;
          } | undefined;
          generated?: {
            from: {
              type: "stored";
              as: string;
            } | null;
            to: {
              type: "stored";
              as: string;
            } | null;
          } | undefined;
          identity?: {
            from: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            to: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
          } | undefined;
          default?: {
            from: string | null;
            to: string | null;
          } | undefined;
          typeSchema?: {
            from: string | null;
            to: string | null;
          } | undefined;
          dimensions?: {
            from: number;
            to: number;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            type: string;
            typeSchema: string | null;
            notNull: boolean;
            dimensions: number;
            default: string | null;
            generated: {
              type: "stored";
              as: string;
            } | null;
            identity: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            name: string;
            entityType: "columns";
          };
          $right: {
            schema: string;
            table: string;
            type: string;
            typeSchema: string | null;
            notNull: boolean;
            dimensions: number;
            default: string | null;
            generated: {
              type: "stored";
              as: string;
            } | null;
            identity: {
              name: string;
              type: "always" | "byDefault";
              increment: string | null;
              minValue: string | null;
              maxValue: string | null;
              startWith: string | null;
              cache: number | null;
              cycle: boolean | null;
            } | null;
            name: string;
            entityType: "columns";
          };
        } | {
          $diffType: "alter";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
          $right: {
            schema: string;
            table: string;
            columns: string[];
            nameExplicit: boolean;
            name: string;
            entityType: "pks";
          };
        } | {
          $diffType: "alter";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          schemaTo?: {
            from: string;
            to: string;
          } | undefined;
          tableTo?: {
            from: string;
            to: string;
          } | undefined;
          columnsTo?: {
            from: string[];
            to: string[];
          } | undefined;
          onUpdate?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          } | undefined;
          onDelete?: {
            from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            name: string;
            entityType: "fks";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            schemaTo: string;
            tableTo: string;
            columnsTo: string[];
            onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
            name: string;
            entityType: "fks";
          };
        } | {
          $diffType: "alter";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            to: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
          } | undefined;
          with?: {
            from: string;
            to: string;
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          isUnique?: {
            from: boolean;
            to: boolean;
          } | undefined;
          where?: {
            from: string | null;
            to: string | null;
          } | undefined;
          method?: {
            from: string;
            to: string;
          } | undefined;
          concurrently?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            isUnique: boolean;
            where: string | null;
            with: string;
            method: string;
            concurrently: boolean;
            name: string;
            entityType: "indexes";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: {
              value: string;
              isExpression: boolean;
              asc: boolean;
              nullsFirst: boolean;
              opclass: {
                name: string;
                default: boolean;
              } | null;
            }[];
            isUnique: boolean;
            where: string | null;
            with: string;
            method: string;
            concurrently: boolean;
            name: string;
            entityType: "indexes";
          };
        } | {
          $diffType: "alter";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns?: {
            from: string[];
            to: string[];
          } | undefined;
          nameExplicit?: {
            from: boolean;
            to: boolean;
          } | undefined;
          nullsNotDistinct?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            nullsNotDistinct: boolean;
            name: string;
            entityType: "uniques";
          };
          $right: {
            schema: string;
            table: string;
            nameExplicit: boolean;
            columns: string[];
            nullsNotDistinct: boolean;
            name: string;
            entityType: "uniques";
          };
        } | {
          $diffType: "alter";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value?: {
            from: string;
            to: string;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
          $right: {
            schema: string;
            table: string;
            value: string;
            name: string;
            entityType: "checks";
          };
        } | {
          $diffType: "alter";
          entityType: "views";
          schema: string;
          name: string;
          with?: {
            from: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            to: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
          } | undefined;
          definition?: {
            from: string | null;
            to: string | null;
          } | undefined;
          using?: {
            from: string | null;
            to: string | null;
          } | undefined;
          withNoData?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          tablespace?: {
            from: string | null;
            to: string | null;
          } | undefined;
          materialized?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            schema: string;
            definition: string | null;
            with: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            withNoData: boolean | null;
            using: string | null;
            tablespace: string | null;
            materialized: boolean;
            name: string;
            entityType: "views";
          };
          $right: {
            schema: string;
            definition: string | null;
            with: {
              checkOption: "local" | "cascaded" | null;
              securityBarrier: boolean | null;
              securityInvoker: boolean | null;
              fillfactor: number | null;
              toastTupleTarget: number | null;
              parallelWorkers: number | null;
              autovacuumEnabled: boolean | null;
              vacuumIndexCleanup: "auto" | "off" | "on" | null;
              vacuumTruncate: boolean | null;
              autovacuumVacuumThreshold: number | null;
              autovacuumVacuumScaleFactor: number | null;
              autovacuumVacuumCostDelay: number | null;
              autovacuumVacuumCostLimit: number | null;
              autovacuumFreezeMinAge: number | null;
              autovacuumFreezeMaxAge: number | null;
              autovacuumFreezeTableAge: number | null;
              autovacuumMultixactFreezeMinAge: number | null;
              autovacuumMultixactFreezeMaxAge: number | null;
              autovacuumMultixactFreezeTableAge: number | null;
              logAutovacuumMinDuration: number | null;
              userCatalogTable: boolean | null;
            } | null;
            withNoData: boolean | null;
            using: string | null;
            tablespace: string | null;
            materialized: boolean;
            name: string;
            entityType: "views";
          };
        } | {
          $diffType: "alter";
          entityType: "enums";
          schema: string;
          name: string;
          values?: {
            from: string[];
            to: string[];
          } | undefined;
          $left: {
            schema: string;
            values: string[];
            name: string;
            entityType: "enums";
          };
          $right: {
            schema: string;
            values: string[];
            name: string;
            entityType: "enums";
          };
        } | {
          $diffType: "alter";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue?: {
            from: string | null;
            to: string | null;
          } | undefined;
          maxValue?: {
            from: string | null;
            to: string | null;
          } | undefined;
          startWith?: {
            from: string | null;
            to: string | null;
          } | undefined;
          cycle?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          incrementBy?: {
            from: string | null;
            to: string | null;
          } | undefined;
          cacheSize?: {
            from: number | null;
            to: number | null;
          } | undefined;
          $left: {
            schema: string;
            incrementBy: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cacheSize: number | null;
            cycle: boolean | null;
            name: string;
            entityType: "sequences";
          };
          $right: {
            schema: string;
            incrementBy: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cacheSize: number | null;
            cycle: boolean | null;
            name: string;
            entityType: "sequences";
          };
        } | {
          $diffType: "alter";
          entityType: "roles";
          name: string;
          password?: {
            from: string | null;
            to: string | null;
          } | undefined;
          superuser?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          createDb?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          createRole?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          inherit?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          canLogin?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          replication?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          bypassRls?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          connLimit?: {
            from: number | null;
            to: number | null;
          } | undefined;
          validUntil?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            superuser: boolean | null;
            createDb: boolean | null;
            createRole: boolean | null;
            inherit: boolean | null;
            canLogin: boolean | null;
            replication: boolean | null;
            bypassRls: boolean | null;
            connLimit: number | null;
            password: string | null;
            validUntil: string | null;
            name: string;
            entityType: "roles";
          };
          $right: {
            superuser: boolean | null;
            createDb: boolean | null;
            createRole: boolean | null;
            inherit: boolean | null;
            canLogin: boolean | null;
            replication: boolean | null;
            bypassRls: boolean | null;
            connLimit: number | null;
            password: string | null;
            validUntil: string | null;
            name: string;
            entityType: "roles";
          };
        } | {
          $diffType: "alter";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type?: {
            from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          } | undefined;
          grantor?: {
            from: string;
            to: string;
          } | undefined;
          grantee?: {
            from: string;
            to: string;
          } | undefined;
          isGrantable?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            grantor: string;
            grantee: string;
            schema: string;
            table: string;
            type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            isGrantable: boolean;
            name: string;
            entityType: "privileges";
          };
          $right: {
            grantor: string;
            grantee: string;
            schema: string;
            table: string;
            type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            isGrantable: boolean;
            name: string;
            entityType: "privileges";
          };
        } | {
          $diffType: "alter";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as?: {
            from: "PERMISSIVE" | "RESTRICTIVE";
            to: "PERMISSIVE" | "RESTRICTIVE";
          } | undefined;
          roles?: {
            from: string[];
            to: string[];
          } | undefined;
          for?: {
            from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          } | undefined;
          using?: {
            from: string | null;
            to: string | null;
          } | undefined;
          withCheck?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            as: "PERMISSIVE" | "RESTRICTIVE";
            for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            roles: string[];
            using: string | null;
            withCheck: string | null;
            name: string;
            entityType: "policies";
          };
          $right: {
            schema: string;
            table: string;
            as: "PERMISSIVE" | "RESTRICTIVE";
            for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            roles: string[];
            using: string | null;
            withCheck: string | null;
            name: string;
            entityType: "policies";
          };
        };
        enums: {
          $diffType: "alter";
          entityType: "enums";
          schema: string;
          name: string;
          values?: {
            from: string[];
            to: string[];
          } | undefined;
          $left: {
            schema: string;
            values: string[];
            name: string;
            entityType: "enums";
          };
          $right: {
            schema: string;
            values: string[];
            name: string;
            entityType: "enums";
          };
        };
        sequences: {
          $diffType: "alter";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue?: {
            from: string | null;
            to: string | null;
          } | undefined;
          maxValue?: {
            from: string | null;
            to: string | null;
          } | undefined;
          startWith?: {
            from: string | null;
            to: string | null;
          } | undefined;
          cycle?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          incrementBy?: {
            from: string | null;
            to: string | null;
          } | undefined;
          cacheSize?: {
            from: number | null;
            to: number | null;
          } | undefined;
          $left: {
            schema: string;
            incrementBy: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cacheSize: number | null;
            cycle: boolean | null;
            name: string;
            entityType: "sequences";
          };
          $right: {
            schema: string;
            incrementBy: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cacheSize: number | null;
            cycle: boolean | null;
            name: string;
            entityType: "sequences";
          };
        };
        roles: {
          $diffType: "alter";
          entityType: "roles";
          name: string;
          password?: {
            from: string | null;
            to: string | null;
          } | undefined;
          superuser?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          createDb?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          createRole?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          inherit?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          canLogin?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          replication?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          bypassRls?: {
            from: boolean | null;
            to: boolean | null;
          } | undefined;
          connLimit?: {
            from: number | null;
            to: number | null;
          } | undefined;
          validUntil?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            superuser: boolean | null;
            createDb: boolean | null;
            createRole: boolean | null;
            inherit: boolean | null;
            canLogin: boolean | null;
            replication: boolean | null;
            bypassRls: boolean | null;
            connLimit: number | null;
            password: string | null;
            validUntil: string | null;
            name: string;
            entityType: "roles";
          };
          $right: {
            superuser: boolean | null;
            createDb: boolean | null;
            createRole: boolean | null;
            inherit: boolean | null;
            canLogin: boolean | null;
            replication: boolean | null;
            bypassRls: boolean | null;
            connLimit: number | null;
            password: string | null;
            validUntil: string | null;
            name: string;
            entityType: "roles";
          };
        };
        privileges: {
          $diffType: "alter";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type?: {
            from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          } | undefined;
          grantor?: {
            from: string;
            to: string;
          } | undefined;
          grantee?: {
            from: string;
            to: string;
          } | undefined;
          isGrantable?: {
            from: boolean;
            to: boolean;
          } | undefined;
          $left: {
            grantor: string;
            grantee: string;
            schema: string;
            table: string;
            type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            isGrantable: boolean;
            name: string;
            entityType: "privileges";
          };
          $right: {
            grantor: string;
            grantee: string;
            schema: string;
            table: string;
            type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
            isGrantable: boolean;
            name: string;
            entityType: "privileges";
          };
        };
        policies: {
          $diffType: "alter";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as?: {
            from: "PERMISSIVE" | "RESTRICTIVE";
            to: "PERMISSIVE" | "RESTRICTIVE";
          } | undefined;
          roles?: {
            from: string[];
            to: string[];
          } | undefined;
          for?: {
            from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          } | undefined;
          using?: {
            from: string | null;
            to: string | null;
          } | undefined;
          withCheck?: {
            from: string | null;
            to: string | null;
          } | undefined;
          $left: {
            schema: string;
            table: string;
            as: "PERMISSIVE" | "RESTRICTIVE";
            for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            roles: string[];
            using: string | null;
            withCheck: string | null;
            name: string;
            entityType: "policies";
          };
          $right: {
            schema: string;
            table: string;
            as: "PERMISSIVE" | "RESTRICTIVE";
            for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
            roles: string[];
            using: string | null;
            withCheck: string | null;
            name: string;
            entityType: "policies";
          };
        };
      };
      create: {
        schemas: {
          $diffType: "create";
          entityType: "schemas";
          name: string;
        };
        tables: {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        };
        columns: {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
          default: string | null;
          typeSchema: string | null;
          dimensions: number;
        };
        pks: {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        fks: {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        };
        indexes: {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        };
        uniques: {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        };
        checks: {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        };
        views: {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          definition: string | null;
          using: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        };
        entities: {
          $diffType: "create";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        } | {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
          default: string | null;
          typeSchema: string | null;
          dimensions: number;
        } | {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        } | {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        } | {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        } | {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          definition: string | null;
          using: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        } | {
          $diffType: "create";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        } | {
          $diffType: "create";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        } | {
          $diffType: "create";
          entityType: "roles";
          name: string;
          password: string | null;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          validUntil: string | null;
        } | {
          $diffType: "create";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        } | {
          $diffType: "create";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        };
        enums: {
          $diffType: "create";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        };
        sequences: {
          $diffType: "create";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        };
        roles: {
          $diffType: "create";
          entityType: "roles";
          name: string;
          password: string | null;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          validUntil: string | null;
        };
        privileges: {
          $diffType: "create";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        };
        policies: {
          $diffType: "create";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        };
      };
      drop: {
        schemas: {
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        };
        tables: {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        };
        columns: {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
          default: string | null;
          typeSchema: string | null;
          dimensions: number;
        };
        pks: {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        fks: {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        };
        indexes: {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        };
        uniques: {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        };
        checks: {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        };
        views: {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          definition: string | null;
          using: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        };
        entities: {
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        } | {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
          default: string | null;
          typeSchema: string | null;
          dimensions: number;
        } | {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        } | {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        } | {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          definition: string | null;
          using: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        } | {
          $diffType: "drop";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        } | {
          $diffType: "drop";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        } | {
          $diffType: "drop";
          entityType: "roles";
          name: string;
          password: string | null;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          validUntil: string | null;
        } | {
          $diffType: "drop";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        } | {
          $diffType: "drop";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        };
        enums: {
          $diffType: "drop";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        };
        sequences: {
          $diffType: "drop";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        };
        roles: {
          $diffType: "drop";
          entityType: "roles";
          name: string;
          password: string | null;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          validUntil: string | null;
        };
        privileges: {
          $diffType: "drop";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        };
        policies: {
          $diffType: "drop";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        };
      };
      createdrop: {
        schemas: {
          $diffType: "create";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        };
        tables: {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        } | {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        };
        columns: {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
          default: string | null;
          typeSchema: string | null;
          dimensions: number;
        } | {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
          default: string | null;
          typeSchema: string | null;
          dimensions: number;
        };
        pks: {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        };
        fks: {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        } | {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        };
        indexes: {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        };
        uniques: {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        } | {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        };
        checks: {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        };
        views: {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          definition: string | null;
          using: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        } | {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          definition: string | null;
          using: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        };
        entities: ({
          $diffType: "create";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "create";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        } | {
          $diffType: "create";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
          default: string | null;
          typeSchema: string | null;
          dimensions: number;
        } | {
          $diffType: "create";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "create";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        } | {
          $diffType: "create";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        } | {
          $diffType: "create";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        } | {
          $diffType: "create";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "create";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          definition: string | null;
          using: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        } | {
          $diffType: "create";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        } | {
          $diffType: "create";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        } | {
          $diffType: "create";
          entityType: "roles";
          name: string;
          password: string | null;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          validUntil: string | null;
        } | {
          $diffType: "create";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        } | {
          $diffType: "create";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        }) | ({
          $diffType: "drop";
          entityType: "schemas";
          name: string;
        } | {
          $diffType: "drop";
          entityType: "tables";
          schema: string;
          name: string;
          isRlsEnabled: boolean;
        } | {
          $diffType: "drop";
          entityType: "columns";
          schema: string;
          table: string;
          name: string;
          type: string;
          notNull: boolean;
          generated: {
            type: "stored";
            as: string;
          } | null;
          identity: {
            name: string;
            type: "always" | "byDefault";
            increment: string | null;
            minValue: string | null;
            maxValue: string | null;
            startWith: string | null;
            cache: number | null;
            cycle: boolean | null;
          } | null;
          default: string | null;
          typeSchema: string | null;
          dimensions: number;
        } | {
          $diffType: "drop";
          entityType: "pks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
        } | {
          $diffType: "drop";
          entityType: "fks";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          schemaTo: string;
          tableTo: string;
          columnsTo: string[];
          onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
          onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        } | {
          $diffType: "drop";
          entityType: "indexes";
          schema: string;
          table: string;
          name: string;
          columns: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          }[];
          with: string;
          nameExplicit: boolean;
          isUnique: boolean;
          where: string | null;
          method: string;
          concurrently: boolean;
        } | {
          $diffType: "drop";
          entityType: "uniques";
          schema: string;
          table: string;
          name: string;
          columns: string[];
          nameExplicit: boolean;
          nullsNotDistinct: boolean;
        } | {
          $diffType: "drop";
          entityType: "checks";
          schema: string;
          table: string;
          name: string;
          value: string;
        } | {
          $diffType: "drop";
          entityType: "views";
          schema: string;
          name: string;
          with: {
            checkOption: "local" | "cascaded" | null;
            securityBarrier: boolean | null;
            securityInvoker: boolean | null;
            fillfactor: number | null;
            toastTupleTarget: number | null;
            parallelWorkers: number | null;
            autovacuumEnabled: boolean | null;
            vacuumIndexCleanup: "auto" | "off" | "on" | null;
            vacuumTruncate: boolean | null;
            autovacuumVacuumThreshold: number | null;
            autovacuumVacuumScaleFactor: number | null;
            autovacuumVacuumCostDelay: number | null;
            autovacuumVacuumCostLimit: number | null;
            autovacuumFreezeMinAge: number | null;
            autovacuumFreezeMaxAge: number | null;
            autovacuumFreezeTableAge: number | null;
            autovacuumMultixactFreezeMinAge: number | null;
            autovacuumMultixactFreezeMaxAge: number | null;
            autovacuumMultixactFreezeTableAge: number | null;
            logAutovacuumMinDuration: number | null;
            userCatalogTable: boolean | null;
          } | null;
          definition: string | null;
          using: string | null;
          withNoData: boolean | null;
          tablespace: string | null;
          materialized: boolean;
        } | {
          $diffType: "drop";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        } | {
          $diffType: "drop";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        } | {
          $diffType: "drop";
          entityType: "roles";
          name: string;
          password: string | null;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          validUntil: string | null;
        } | {
          $diffType: "drop";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        } | {
          $diffType: "drop";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        });
        enums: {
          $diffType: "create";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        } | {
          $diffType: "drop";
          entityType: "enums";
          schema: string;
          name: string;
          values: string[];
        };
        sequences: {
          $diffType: "create";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        } | {
          $diffType: "drop";
          entityType: "sequences";
          schema: string;
          name: string;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cycle: boolean | null;
          incrementBy: string | null;
          cacheSize: number | null;
        };
        roles: {
          $diffType: "create";
          entityType: "roles";
          name: string;
          password: string | null;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          validUntil: string | null;
        } | {
          $diffType: "drop";
          entityType: "roles";
          name: string;
          password: string | null;
          superuser: boolean | null;
          createDb: boolean | null;
          createRole: boolean | null;
          inherit: boolean | null;
          canLogin: boolean | null;
          replication: boolean | null;
          bypassRls: boolean | null;
          connLimit: number | null;
          validUntil: string | null;
        };
        privileges: {
          $diffType: "create";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        } | {
          $diffType: "drop";
          entityType: "privileges";
          schema: string;
          table: string;
          name: string;
          type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
          grantor: string;
          grantee: string;
          isGrantable: boolean;
        };
        policies: {
          $diffType: "create";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        } | {
          $diffType: "drop";
          entityType: "policies";
          schema: string;
          table: string;
          name: string;
          as: "PERMISSIVE" | "RESTRICTIVE";
          roles: string[];
          for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
          using: string | null;
          withCheck: string | null;
        };
      };
      all: {
        schemas: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "schemas">;
        tables: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "tables">;
        columns: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "columns">;
        pks: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "pks">;
        fks: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "fks">;
        indexes: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "indexes">;
        uniques: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "uniques">;
        checks: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "checks">;
        views: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "views">;
        entities: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "entities">;
        enums: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "enums">;
        sequences: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "sequences">;
        roles: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "roles">;
        privileges: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "privileges">;
        policies: DiffStatement<{
          schemas: {};
          tables: {
            schema: "required";
            isRlsEnabled: "boolean";
          };
          enums: {
            schema: "required";
            values: "string[]";
          };
          columns: {
            schema: "required";
            table: "required";
            type: "string";
            typeSchema: "string?";
            notNull: "boolean";
            dimensions: "number";
            default: "string?";
            generated: {
              type: ["stored"];
              as: "string";
            };
            identity: {
              name: "string";
              type: ["always", "byDefault"];
              increment: "string?";
              minValue: "string?";
              maxValue: "string?";
              startWith: "string?";
              cache: "number?";
              cycle: "boolean?";
            };
          };
          indexes: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: [{
              value: "string";
              isExpression: "boolean";
              asc: "boolean";
              nullsFirst: "boolean";
              opclass: {
                name: "string";
                default: "boolean";
              };
            }];
            isUnique: "boolean";
            where: "string?";
            with: "string";
            method: "string";
            concurrently: "boolean";
          };
          fks: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            schemaTo: "string";
            tableTo: "string";
            columnsTo: "string[]";
            onUpdate: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
            onDelete: ["NO ACTION", "RESTRICT", "SET NULL", "CASCADE", "SET DEFAULT", null];
          };
          pks: {
            schema: "required";
            table: "required";
            columns: "string[]";
            nameExplicit: "boolean";
          };
          uniques: {
            schema: "required";
            table: "required";
            nameExplicit: "boolean";
            columns: "string[]";
            nullsNotDistinct: "boolean";
          };
          checks: {
            schema: "required";
            table: "required";
            value: "string";
          };
          sequences: {
            schema: "required";
            incrementBy: "string?";
            minValue: "string?";
            maxValue: "string?";
            startWith: "string?";
            cacheSize: "number?";
            cycle: "boolean?";
          };
          roles: {
            superuser: "boolean?";
            createDb: "boolean?";
            createRole: "boolean?";
            inherit: "boolean?";
            canLogin: "boolean?";
            replication: "boolean?";
            bypassRls: "boolean?";
            connLimit: "number?";
            password: "string?";
            validUntil: "string?";
          };
          privileges: {
            grantor: "string";
            grantee: "string";
            schema: "required";
            table: "required";
            type: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE", "REFERENCES", "TRIGGER"];
            isGrantable: "boolean";
          };
          policies: {
            schema: "required";
            table: "required";
            as: ["PERMISSIVE", "RESTRICTIVE"];
            for: ["ALL", "SELECT", "INSERT", "UPDATE", "DELETE"];
            roles: "string[]";
            using: "string?";
            withCheck: "string?";
          };
          views: {
            schema: "required";
            definition: "string?";
            with: {
              checkOption: ["local", "cascaded", null];
              securityBarrier: "boolean?";
              securityInvoker: "boolean?";
              fillfactor: "number?";
              toastTupleTarget: "number?";
              parallelWorkers: "number?";
              autovacuumEnabled: "boolean?";
              vacuumIndexCleanup: ["auto", "off", "on", null];
              vacuumTruncate: "boolean?";
              autovacuumVacuumThreshold: "number?";
              autovacuumVacuumScaleFactor: "number?";
              autovacuumVacuumCostDelay: "number?";
              autovacuumVacuumCostLimit: "number?";
              autovacuumFreezeMinAge: "number?";
              autovacuumFreezeMaxAge: "number?";
              autovacuumFreezeTableAge: "number?";
              autovacuumMultixactFreezeMinAge: "number?";
              autovacuumMultixactFreezeMaxAge: "number?";
              autovacuumMultixactFreezeTableAge: "number?";
              logAutovacuumMinDuration: "number?";
              userCatalogTable: "boolean?";
            };
            withNoData: "boolean?";
            using: "string?";
            tablespace: "string?";
            materialized: "boolean";
          };
        }, "policies">;
      };
    };
    store: {
      collection: Record<string, any>[];
    };
  };
  entities: {
    push: (input: {
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | {
      typeSchema: string | null | undefined;
      default: string | null | undefined;
      generated: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      schema: string;
      table: string;
      type: string;
      notNull: boolean;
      dimensions: number;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      name: string;
      entityType: "fks";
    } | {
      where: string | null | undefined;
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      definition: string | null | undefined;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData: boolean | null | undefined;
      using: string | null | undefined;
      tablespace: string | null | undefined;
      schema: string;
      materialized: boolean;
      name: string;
      entityType: "views";
    } | {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | {
      incrementBy: string | null | undefined;
      minValue: string | null | undefined;
      maxValue: string | null | undefined;
      startWith: string | null | undefined;
      cacheSize: number | null | undefined;
      cycle: boolean | null | undefined;
      schema: string;
      name: string;
      entityType: "sequences";
    } | {
      superuser: boolean | null | undefined;
      createDb: boolean | null | undefined;
      createRole: boolean | null | undefined;
      inherit: boolean | null | undefined;
      canLogin: boolean | null | undefined;
      replication: boolean | null | undefined;
      bypassRls: boolean | null | undefined;
      connLimit: number | null | undefined;
      password: string | null | undefined;
      validUntil: string | null | undefined;
      name: string;
      entityType: "roles";
    } | {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | {
      using: string | null | undefined;
      withCheck: string | null | undefined;
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      name: string;
      entityType: "policies";
    }, uniques?: "name"[] | ("schema" | "name" | "isRlsEnabled")[] | ("schema" | "table" | "name" | "type" | "notNull" | "generated" | "identity" | "default" | "typeSchema" | "dimensions")[] | ("schema" | "table" | "name" | "columns" | "nameExplicit")[] | ("schema" | "table" | "name" | "columns" | "nameExplicit" | "schemaTo" | "tableTo" | "columnsTo" | "onUpdate" | "onDelete")[] | ("schema" | "table" | "name" | "columns" | "with" | "nameExplicit" | "isUnique" | "where" | "method" | "concurrently")[] | ("schema" | "table" | "name" | "columns" | "nameExplicit" | "nullsNotDistinct")[] | ("schema" | "table" | "name" | "value")[] | ("schema" | "name" | "with" | "definition" | "using" | "withNoData" | "tablespace" | "materialized")[] | ("schema" | "name" | "values")[] | ("schema" | "name" | "minValue" | "maxValue" | "startWith" | "cycle" | "incrementBy" | "cacheSize")[] | ("name" | "password" | "superuser" | "createDb" | "createRole" | "inherit" | "canLogin" | "replication" | "bypassRls" | "connLimit" | "validUntil")[] | ("schema" | "table" | "name" | "type" | "grantor" | "grantee" | "isGrantable")[] | ("schema" | "table" | "name" | "as" | "roles" | "for" | "using" | "withCheck")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "schemas";
      } | {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      } | {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      } | {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        name: string;
        entityType: "fks";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      } | {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      } | {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      } | {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      } | {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      } | {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      } | {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      } | {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: ({
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    }) | undefined) => ({
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    } | {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    } | {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    } | {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    })[];
    one: (where?: ({
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    }) | undefined) => {
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    } | {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    } | {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    } | {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        name?: string | undefined;
        entityType?: "schemas" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        isRlsEnabled?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        isRlsEnabled?: boolean | undefined;
        name?: string | undefined;
        entityType?: "tables" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: string | ((item: string) => string) | undefined;
        notNull?: boolean | ((item: boolean) => boolean) | undefined;
        generated?: {
          type: "stored";
          as: string;
        } | ((item: {
          type: "stored";
          as: string;
        } | null) => {
          type: "stored";
          as: string;
        } | null) | null | undefined;
        identity?: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | ((item: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null) => {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null) | null | undefined;
        default?: string | ((item: string | null) => string | null) | null | undefined;
        typeSchema?: string | ((item: string | null) => string | null) | null | undefined;
        dimensions?: number | ((item: number) => number) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        type?: string | undefined;
        typeSchema?: string | null | undefined;
        notNull?: boolean | undefined;
        dimensions?: number | undefined;
        default?: string | null | undefined;
        generated?: {
          type: "stored";
          as: string;
        } | null | undefined;
        identity?: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null | undefined;
        name?: string | undefined;
        entityType?: "columns" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "pks" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        schemaTo?: string | ((item: string) => string) | undefined;
        tableTo?: string | ((item: string) => string) | undefined;
        columnsTo?: string[] | ((item: string) => string) | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) | null | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        schemaTo?: string | undefined;
        tableTo?: string | undefined;
        columnsTo?: string[] | {
          CONTAINS: string;
        } | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
        name?: string | undefined;
        entityType?: "fks" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[] | ((item: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }) => {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }) | undefined;
        with?: string | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        isUnique?: boolean | ((item: boolean) => boolean) | undefined;
        where?: string | ((item: string | null) => string | null) | null | undefined;
        method?: string | ((item: string) => string) | undefined;
        concurrently?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[] | {
          CONTAINS: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          };
        } | undefined;
        isUnique?: boolean | undefined;
        where?: string | null | undefined;
        with?: string | undefined;
        method?: string | undefined;
        concurrently?: boolean | undefined;
        name?: string | undefined;
        entityType?: "indexes" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        nullsNotDistinct?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nullsNotDistinct?: boolean | undefined;
        name?: string | undefined;
        entityType?: "uniques" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        value?: string | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        value?: string | undefined;
        name?: string | undefined;
        entityType?: "checks" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        with?: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | ((item: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null) => {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null) | null | undefined;
        definition?: string | ((item: string | null) => string | null) | null | undefined;
        using?: string | ((item: string | null) => string | null) | null | undefined;
        withNoData?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        tablespace?: string | ((item: string | null) => string | null) | null | undefined;
        materialized?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        definition?: string | null | undefined;
        with?: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null | undefined;
        withNoData?: boolean | null | undefined;
        using?: string | null | undefined;
        tablespace?: string | null | undefined;
        materialized?: boolean | undefined;
        name?: string | undefined;
        entityType?: "views" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        values?: string[] | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        values?: string[] | {
          CONTAINS: string;
        } | undefined;
        name?: string | undefined;
        entityType?: "enums" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        minValue?: string | ((item: string | null) => string | null) | null | undefined;
        maxValue?: string | ((item: string | null) => string | null) | null | undefined;
        startWith?: string | ((item: string | null) => string | null) | null | undefined;
        cycle?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        incrementBy?: string | ((item: string | null) => string | null) | null | undefined;
        cacheSize?: number | ((item: number | null) => number | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        incrementBy?: string | null | undefined;
        minValue?: string | null | undefined;
        maxValue?: string | null | undefined;
        startWith?: string | null | undefined;
        cacheSize?: number | null | undefined;
        cycle?: boolean | null | undefined;
        name?: string | undefined;
        entityType?: "sequences" | undefined;
      } | undefined;
    } | {
      set: {
        name?: string | ((item: string) => string) | undefined;
        password?: string | ((item: string | null) => string | null) | null | undefined;
        superuser?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        createDb?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        createRole?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        inherit?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        canLogin?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        replication?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        bypassRls?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        connLimit?: number | ((item: number | null) => number | null) | null | undefined;
        validUntil?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        superuser?: boolean | null | undefined;
        createDb?: boolean | null | undefined;
        createRole?: boolean | null | undefined;
        inherit?: boolean | null | undefined;
        canLogin?: boolean | null | undefined;
        replication?: boolean | null | undefined;
        bypassRls?: boolean | null | undefined;
        connLimit?: number | null | undefined;
        password?: string | null | undefined;
        validUntil?: string | null | undefined;
        name?: string | undefined;
        entityType?: "roles" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | ((item: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER") => "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER") | undefined;
        grantor?: string | ((item: string) => string) | undefined;
        grantee?: string | ((item: string) => string) | undefined;
        isGrantable?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        grantor?: string | undefined;
        grantee?: string | undefined;
        schema?: string | undefined;
        table?: string | undefined;
        type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
        isGrantable?: boolean | undefined;
        name?: string | undefined;
        entityType?: "privileges" | undefined;
      } | undefined;
    } | {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        as?: "PERMISSIVE" | "RESTRICTIVE" | ((item: "PERMISSIVE" | "RESTRICTIVE") => "PERMISSIVE" | "RESTRICTIVE") | undefined;
        roles?: string[] | ((item: string) => string) | undefined;
        for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | ((item: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE") => "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE") | undefined;
        using?: string | ((item: string | null) => string | null) | null | undefined;
        withCheck?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
        for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
        roles?: string[] | {
          CONTAINS: string;
        } | undefined;
        using?: string | null | undefined;
        withCheck?: string | null | undefined;
        name?: string | undefined;
        entityType?: "policies" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: ({
        name: string;
        entityType: "schemas";
      } | {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      } | {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      } | {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        name: string;
        entityType: "fks";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      } | {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      } | {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      } | {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      } | {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      } | {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      } | {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      } | {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      } | {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      })[];
    };
    delete: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    } | undefined) => ({
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    } | {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    } | {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    } | {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    })[];
    validate: (data: unknown) => data is {
      name: string;
      entityType: "schemas";
    } | {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    } | {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      name: string;
      entityType: "fks";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    } | {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    } | {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    } | {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "schemas";
      name: string;
      $left: {
        name: string;
        entityType: "schemas";
      };
      $right: {
        name: string;
        entityType: "schemas";
      };
    } | {
      $diffType: "alter";
      entityType: "tables";
      schema: string;
      name: string;
      isRlsEnabled?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
      $right: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
    } | {
      $diffType: "alter";
      entityType: "columns";
      schema: string;
      table: string;
      name: string;
      type?: {
        from: string;
        to: string;
      } | undefined;
      notNull?: {
        from: boolean;
        to: boolean;
      } | undefined;
      generated?: {
        from: {
          type: "stored";
          as: string;
        } | null;
        to: {
          type: "stored";
          as: string;
        } | null;
      } | undefined;
      identity?: {
        from: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        to: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
      } | undefined;
      default?: {
        from: string | null;
        to: string | null;
      } | undefined;
      typeSchema?: {
        from: string | null;
        to: string | null;
      } | undefined;
      dimensions?: {
        from: number;
        to: number;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
      $right: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
    } | {
      $diffType: "alter";
      entityType: "pks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
      $right: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
    } | {
      $diffType: "alter";
      entityType: "fks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      schemaTo?: {
        from: string;
        to: string;
      } | undefined;
      tableTo?: {
        from: string;
        to: string;
      } | undefined;
      columnsTo?: {
        from: string[];
        to: string[];
      } | undefined;
      onUpdate?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      } | undefined;
      onDelete?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        name: string;
        entityType: "fks";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        name: string;
        entityType: "fks";
      };
    } | {
      $diffType: "alter";
      entityType: "indexes";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        to: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
      } | undefined;
      with?: {
        from: string;
        to: string;
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      isUnique?: {
        from: boolean;
        to: boolean;
      } | undefined;
      where?: {
        from: string | null;
        to: string | null;
      } | undefined;
      method?: {
        from: string;
        to: string;
      } | undefined;
      concurrently?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
    } | {
      $diffType: "alter";
      entityType: "uniques";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      nullsNotDistinct?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
    } | {
      $diffType: "alter";
      entityType: "checks";
      schema: string;
      table: string;
      name: string;
      value?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      $right: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    } | {
      $diffType: "alter";
      entityType: "views";
      schema: string;
      name: string;
      with?: {
        from: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        to: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
      } | undefined;
      definition?: {
        from: string | null;
        to: string | null;
      } | undefined;
      using?: {
        from: string | null;
        to: string | null;
      } | undefined;
      withNoData?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      tablespace?: {
        from: string | null;
        to: string | null;
      } | undefined;
      materialized?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
      $right: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
    } | {
      $diffType: "alter";
      entityType: "enums";
      schema: string;
      name: string;
      values?: {
        from: string[];
        to: string[];
      } | undefined;
      $left: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
      $right: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
    } | {
      $diffType: "alter";
      entityType: "sequences";
      schema: string;
      name: string;
      minValue?: {
        from: string | null;
        to: string | null;
      } | undefined;
      maxValue?: {
        from: string | null;
        to: string | null;
      } | undefined;
      startWith?: {
        from: string | null;
        to: string | null;
      } | undefined;
      cycle?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      incrementBy?: {
        from: string | null;
        to: string | null;
      } | undefined;
      cacheSize?: {
        from: number | null;
        to: number | null;
      } | undefined;
      $left: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
      $right: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
    } | {
      $diffType: "alter";
      entityType: "roles";
      name: string;
      password?: {
        from: string | null;
        to: string | null;
      } | undefined;
      superuser?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      createDb?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      createRole?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      inherit?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      canLogin?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      replication?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      bypassRls?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      connLimit?: {
        from: number | null;
        to: number | null;
      } | undefined;
      validUntil?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
      $right: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
    } | {
      $diffType: "alter";
      entityType: "privileges";
      schema: string;
      table: string;
      name: string;
      type?: {
        from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      } | undefined;
      grantor?: {
        from: string;
        to: string;
      } | undefined;
      grantee?: {
        from: string;
        to: string;
      } | undefined;
      isGrantable?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
      $right: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
    } | {
      $diffType: "alter";
      entityType: "policies";
      schema: string;
      table: string;
      name: string;
      as?: {
        from: "PERMISSIVE" | "RESTRICTIVE";
        to: "PERMISSIVE" | "RESTRICTIVE";
      } | undefined;
      roles?: {
        from: string[];
        to: string[];
      } | undefined;
      for?: {
        from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      } | undefined;
      using?: {
        from: string | null;
        to: string | null;
      } | undefined;
      withCheck?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
      $right: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
    }) => boolean;
  };
  schemas: {
    push: (input: {
      name: string;
    }, uniques?: "name"[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "schemas";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | undefined) => {
      name: string;
      entityType: "schemas";
    }[];
    one: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | undefined) => {
      name: string;
      entityType: "schemas";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
      };
      where?: {
        name?: string | undefined;
        entityType?: "schemas" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        name: string;
        entityType: "schemas";
      }[];
    };
    delete: (where?: {
      name?: string | undefined;
      entityType?: "schemas" | undefined;
    } | undefined) => {
      name: string;
      entityType: "schemas";
    }[];
    validate: (data: unknown) => data is {
      name: string;
      entityType: "schemas";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "schemas";
      name: string;
      $left: {
        name: string;
        entityType: "schemas";
      };
      $right: {
        name: string;
        entityType: "schemas";
      };
    }) => boolean;
  };
  tables: {
    push: (input: {
      schema: string;
      name: string;
      isRlsEnabled: boolean;
    }, uniques?: ("schema" | "name" | "isRlsEnabled")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    }[];
    one: (where?: {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        isRlsEnabled?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        isRlsEnabled?: boolean | undefined;
        name?: string | undefined;
        entityType?: "tables" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      isRlsEnabled?: boolean | undefined;
      name?: string | undefined;
      entityType?: "tables" | undefined;
    } | undefined) => {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      isRlsEnabled: boolean;
      name: string;
      entityType: "tables";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "tables";
      schema: string;
      name: string;
      isRlsEnabled?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
      $right: {
        schema: string;
        isRlsEnabled: boolean;
        name: string;
        entityType: "tables";
      };
    }) => boolean;
  };
  enums: {
    push: (input: {
      schema: string;
      name: string;
      values: string[];
    }, uniques?: ("schema" | "name" | "values")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | undefined) => {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    }[];
    one: (where?: {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | undefined) => {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        values?: string[] | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        values?: string[] | {
          CONTAINS: string;
        } | undefined;
        name?: string | undefined;
        entityType?: "enums" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      values?: string[] | {
        CONTAINS: string;
      } | undefined;
      name?: string | undefined;
      entityType?: "enums" | undefined;
    } | undefined) => {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      values: string[];
      name: string;
      entityType: "enums";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "enums";
      schema: string;
      name: string;
      values?: {
        from: string[];
        to: string[];
      } | undefined;
      $left: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
      $right: {
        schema: string;
        values: string[];
        name: string;
        entityType: "enums";
      };
    }) => boolean;
  };
  columns: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      type: string;
      notNull: boolean;
      generated: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      default: string | null | undefined;
      typeSchema: string | null | undefined;
      dimensions: number;
    }, uniques?: ("schema" | "table" | "name" | "type" | "notNull" | "generated" | "identity" | "default" | "typeSchema" | "dimensions")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: string | ((item: string) => string) | undefined;
        notNull?: boolean | ((item: boolean) => boolean) | undefined;
        generated?: {
          type: "stored";
          as: string;
        } | ((item: {
          type: "stored";
          as: string;
        } | null) => {
          type: "stored";
          as: string;
        } | null) | null | undefined;
        identity?: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | ((item: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null) => {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null) | null | undefined;
        default?: string | ((item: string | null) => string | null) | null | undefined;
        typeSchema?: string | ((item: string | null) => string | null) | null | undefined;
        dimensions?: number | ((item: number) => number) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        type?: string | undefined;
        typeSchema?: string | null | undefined;
        notNull?: boolean | undefined;
        dimensions?: number | undefined;
        default?: string | null | undefined;
        generated?: {
          type: "stored";
          as: string;
        } | null | undefined;
        identity?: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null | undefined;
        name?: string | undefined;
        entityType?: "columns" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      type?: string | undefined;
      typeSchema?: string | null | undefined;
      notNull?: boolean | undefined;
      dimensions?: number | undefined;
      default?: string | null | undefined;
      generated?: {
        type: "stored";
        as: string;
      } | null | undefined;
      identity?: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null | undefined;
      name?: string | undefined;
      entityType?: "columns" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      type: string;
      typeSchema: string | null;
      notNull: boolean;
      dimensions: number;
      default: string | null;
      generated: {
        type: "stored";
        as: string;
      } | null;
      identity: {
        name: string;
        type: "always" | "byDefault";
        increment: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cache: number | null;
        cycle: boolean | null;
      } | null;
      name: string;
      entityType: "columns";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "columns";
      schema: string;
      table: string;
      name: string;
      type?: {
        from: string;
        to: string;
      } | undefined;
      notNull?: {
        from: boolean;
        to: boolean;
      } | undefined;
      generated?: {
        from: {
          type: "stored";
          as: string;
        } | null;
        to: {
          type: "stored";
          as: string;
        } | null;
      } | undefined;
      identity?: {
        from: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        to: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
      } | undefined;
      default?: {
        from: string | null;
        to: string | null;
      } | undefined;
      typeSchema?: {
        from: string | null;
        to: string | null;
      } | undefined;
      dimensions?: {
        from: number;
        to: number;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
      $right: {
        schema: string;
        table: string;
        type: string;
        typeSchema: string | null;
        notNull: boolean;
        dimensions: number;
        default: string | null;
        generated: {
          type: "stored";
          as: string;
        } | null;
        identity: {
          name: string;
          type: "always" | "byDefault";
          increment: string | null;
          minValue: string | null;
          maxValue: string | null;
          startWith: string | null;
          cache: number | null;
          cycle: boolean | null;
        } | null;
        name: string;
        entityType: "columns";
      };
    }) => boolean;
  };
  indexes: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      with: string;
      nameExplicit: boolean;
      isUnique: boolean;
      where: string | null | undefined;
      method: string;
      concurrently: boolean;
    }, uniques?: ("schema" | "table" | "name" | "columns" | "with" | "nameExplicit" | "isUnique" | "where" | "method" | "concurrently")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[] | ((item: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }) => {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }) | undefined;
        with?: string | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        isUnique?: boolean | ((item: boolean) => boolean) | undefined;
        where?: string | ((item: string | null) => string | null) | null | undefined;
        method?: string | ((item: string) => string) | undefined;
        concurrently?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[] | {
          CONTAINS: {
            value: string;
            isExpression: boolean;
            asc: boolean;
            nullsFirst: boolean;
            opclass: {
              name: string;
              default: boolean;
            } | null;
          };
        } | undefined;
        isUnique?: boolean | undefined;
        where?: string | null | undefined;
        with?: string | undefined;
        method?: string | undefined;
        concurrently?: boolean | undefined;
        name?: string | undefined;
        entityType?: "indexes" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[] | {
        CONTAINS: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        };
      } | undefined;
      isUnique?: boolean | undefined;
      where?: string | null | undefined;
      with?: string | undefined;
      method?: string | undefined;
      concurrently?: boolean | undefined;
      name?: string | undefined;
      entityType?: "indexes" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: {
        value: string;
        isExpression: boolean;
        asc: boolean;
        nullsFirst: boolean;
        opclass: {
          name: string;
          default: boolean;
        } | null;
      }[];
      isUnique: boolean;
      where: string | null;
      with: string;
      method: string;
      concurrently: boolean;
      name: string;
      entityType: "indexes";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "indexes";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        to: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
      } | undefined;
      with?: {
        from: string;
        to: string;
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      isUnique?: {
        from: boolean;
        to: boolean;
      } | undefined;
      where?: {
        from: string | null;
        to: string | null;
      } | undefined;
      method?: {
        from: string;
        to: string;
      } | undefined;
      concurrently?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: {
          value: string;
          isExpression: boolean;
          asc: boolean;
          nullsFirst: boolean;
          opclass: {
            name: string;
            default: boolean;
          } | null;
        }[];
        isUnique: boolean;
        where: string | null;
        with: string;
        method: string;
        concurrently: boolean;
        name: string;
        entityType: "indexes";
      };
    }) => boolean;
  };
  fks: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
    }, uniques?: ("schema" | "table" | "name" | "columns" | "nameExplicit" | "schemaTo" | "tableTo" | "columnsTo" | "onUpdate" | "onDelete")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        name: string;
        entityType: "fks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      name: string;
      entityType: "fks";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      name: string;
      entityType: "fks";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        schemaTo?: string | ((item: string) => string) | undefined;
        tableTo?: string | ((item: string) => string) | undefined;
        columnsTo?: string[] | ((item: string) => string) | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) | null | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | ((item: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) => "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        schemaTo?: string | undefined;
        tableTo?: string | undefined;
        columnsTo?: string[] | {
          CONTAINS: string;
        } | undefined;
        onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
        onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
        name?: string | undefined;
        entityType?: "fks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        name: string;
        entityType: "fks";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      schemaTo?: string | undefined;
      tableTo?: string | undefined;
      columnsTo?: string[] | {
        CONTAINS: string;
      } | undefined;
      onUpdate?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      onDelete?: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null | undefined;
      name?: string | undefined;
      entityType?: "fks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      name: string;
      entityType: "fks";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      schemaTo: string;
      tableTo: string;
      columnsTo: string[];
      onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      name: string;
      entityType: "fks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "fks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      schemaTo?: {
        from: string;
        to: string;
      } | undefined;
      tableTo?: {
        from: string;
        to: string;
      } | undefined;
      columnsTo?: {
        from: string[];
        to: string[];
      } | undefined;
      onUpdate?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      } | undefined;
      onDelete?: {
        from: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        to: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        name: string;
        entityType: "fks";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        schemaTo: string;
        tableTo: string;
        columnsTo: string[];
        onUpdate: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        onDelete: "NO ACTION" | "CASCADE" | "SET NULL" | "SET DEFAULT" | "RESTRICT" | null;
        name: string;
        entityType: "fks";
      };
    }) => boolean;
  };
  pks: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
    }, uniques?: ("schema" | "table" | "name" | "columns" | "nameExplicit")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nameExplicit?: boolean | undefined;
        name?: string | undefined;
        entityType?: "pks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nameExplicit?: boolean | undefined;
      name?: string | undefined;
      entityType?: "pks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      columns: string[];
      nameExplicit: boolean;
      name: string;
      entityType: "pks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "pks";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
      $right: {
        schema: string;
        table: string;
        columns: string[];
        nameExplicit: boolean;
        name: string;
        entityType: "pks";
      };
    }) => boolean;
  };
  uniques: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      columns: string[];
      nameExplicit: boolean;
      nullsNotDistinct: boolean;
    }, uniques?: ("schema" | "table" | "name" | "columns" | "nameExplicit" | "nullsNotDistinct")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        columns?: string[] | ((item: string) => string) | undefined;
        nameExplicit?: boolean | ((item: boolean) => boolean) | undefined;
        nullsNotDistinct?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        nameExplicit?: boolean | undefined;
        columns?: string[] | {
          CONTAINS: string;
        } | undefined;
        nullsNotDistinct?: boolean | undefined;
        name?: string | undefined;
        entityType?: "uniques" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      nameExplicit?: boolean | undefined;
      columns?: string[] | {
        CONTAINS: string;
      } | undefined;
      nullsNotDistinct?: boolean | undefined;
      name?: string | undefined;
      entityType?: "uniques" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      nameExplicit: boolean;
      columns: string[];
      nullsNotDistinct: boolean;
      name: string;
      entityType: "uniques";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "uniques";
      schema: string;
      table: string;
      name: string;
      columns?: {
        from: string[];
        to: string[];
      } | undefined;
      nameExplicit?: {
        from: boolean;
        to: boolean;
      } | undefined;
      nullsNotDistinct?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
      $right: {
        schema: string;
        table: string;
        nameExplicit: boolean;
        columns: string[];
        nullsNotDistinct: boolean;
        name: string;
        entityType: "uniques";
      };
    }) => boolean;
  };
  checks: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      value: string;
    }, uniques?: ("schema" | "table" | "name" | "value")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        value?: string | ((item: string) => string) | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        value?: string | undefined;
        name?: string | undefined;
        entityType?: "checks" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      value?: string | undefined;
      name?: string | undefined;
      entityType?: "checks" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      value: string;
      name: string;
      entityType: "checks";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "checks";
      schema: string;
      table: string;
      name: string;
      value?: {
        from: string;
        to: string;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
      $right: {
        schema: string;
        table: string;
        value: string;
        name: string;
        entityType: "checks";
      };
    }) => boolean;
  };
  sequences: {
    push: (input: {
      schema: string;
      name: string;
      minValue: string | null | undefined;
      maxValue: string | null | undefined;
      startWith: string | null | undefined;
      cycle: boolean | null | undefined;
      incrementBy: string | null | undefined;
      cacheSize: number | null | undefined;
    }, uniques?: ("schema" | "name" | "minValue" | "maxValue" | "startWith" | "cycle" | "incrementBy" | "cacheSize")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | undefined) => {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    }[];
    one: (where?: {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | undefined) => {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        minValue?: string | ((item: string | null) => string | null) | null | undefined;
        maxValue?: string | ((item: string | null) => string | null) | null | undefined;
        startWith?: string | ((item: string | null) => string | null) | null | undefined;
        cycle?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        incrementBy?: string | ((item: string | null) => string | null) | null | undefined;
        cacheSize?: number | ((item: number | null) => number | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        incrementBy?: string | null | undefined;
        minValue?: string | null | undefined;
        maxValue?: string | null | undefined;
        startWith?: string | null | undefined;
        cacheSize?: number | null | undefined;
        cycle?: boolean | null | undefined;
        name?: string | undefined;
        entityType?: "sequences" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      incrementBy?: string | null | undefined;
      minValue?: string | null | undefined;
      maxValue?: string | null | undefined;
      startWith?: string | null | undefined;
      cacheSize?: number | null | undefined;
      cycle?: boolean | null | undefined;
      name?: string | undefined;
      entityType?: "sequences" | undefined;
    } | undefined) => {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      incrementBy: string | null;
      minValue: string | null;
      maxValue: string | null;
      startWith: string | null;
      cacheSize: number | null;
      cycle: boolean | null;
      name: string;
      entityType: "sequences";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "sequences";
      schema: string;
      name: string;
      minValue?: {
        from: string | null;
        to: string | null;
      } | undefined;
      maxValue?: {
        from: string | null;
        to: string | null;
      } | undefined;
      startWith?: {
        from: string | null;
        to: string | null;
      } | undefined;
      cycle?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      incrementBy?: {
        from: string | null;
        to: string | null;
      } | undefined;
      cacheSize?: {
        from: number | null;
        to: number | null;
      } | undefined;
      $left: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
      $right: {
        schema: string;
        incrementBy: string | null;
        minValue: string | null;
        maxValue: string | null;
        startWith: string | null;
        cacheSize: number | null;
        cycle: boolean | null;
        name: string;
        entityType: "sequences";
      };
    }) => boolean;
  };
  roles: {
    push: (input: {
      name: string;
      password: string | null | undefined;
      superuser: boolean | null | undefined;
      createDb: boolean | null | undefined;
      createRole: boolean | null | undefined;
      inherit: boolean | null | undefined;
      canLogin: boolean | null | undefined;
      replication: boolean | null | undefined;
      bypassRls: boolean | null | undefined;
      connLimit: number | null | undefined;
      validUntil: string | null | undefined;
    }, uniques?: ("name" | "password" | "superuser" | "createDb" | "createRole" | "inherit" | "canLogin" | "replication" | "bypassRls" | "connLimit" | "validUntil")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | undefined) => {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    }[];
    one: (where?: {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | undefined) => {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    } | null;
    update: (config: {
      set: {
        name?: string | ((item: string) => string) | undefined;
        password?: string | ((item: string | null) => string | null) | null | undefined;
        superuser?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        createDb?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        createRole?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        inherit?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        canLogin?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        replication?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        bypassRls?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        connLimit?: number | ((item: number | null) => number | null) | null | undefined;
        validUntil?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        superuser?: boolean | null | undefined;
        createDb?: boolean | null | undefined;
        createRole?: boolean | null | undefined;
        inherit?: boolean | null | undefined;
        canLogin?: boolean | null | undefined;
        replication?: boolean | null | undefined;
        bypassRls?: boolean | null | undefined;
        connLimit?: number | null | undefined;
        password?: string | null | undefined;
        validUntil?: string | null | undefined;
        name?: string | undefined;
        entityType?: "roles" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      }[];
    };
    delete: (where?: {
      superuser?: boolean | null | undefined;
      createDb?: boolean | null | undefined;
      createRole?: boolean | null | undefined;
      inherit?: boolean | null | undefined;
      canLogin?: boolean | null | undefined;
      replication?: boolean | null | undefined;
      bypassRls?: boolean | null | undefined;
      connLimit?: number | null | undefined;
      password?: string | null | undefined;
      validUntil?: string | null | undefined;
      name?: string | undefined;
      entityType?: "roles" | undefined;
    } | undefined) => {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    }[];
    validate: (data: unknown) => data is {
      superuser: boolean | null;
      createDb: boolean | null;
      createRole: boolean | null;
      inherit: boolean | null;
      canLogin: boolean | null;
      replication: boolean | null;
      bypassRls: boolean | null;
      connLimit: number | null;
      password: string | null;
      validUntil: string | null;
      name: string;
      entityType: "roles";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "roles";
      name: string;
      password?: {
        from: string | null;
        to: string | null;
      } | undefined;
      superuser?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      createDb?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      createRole?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      inherit?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      canLogin?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      replication?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      bypassRls?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      connLimit?: {
        from: number | null;
        to: number | null;
      } | undefined;
      validUntil?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
      $right: {
        superuser: boolean | null;
        createDb: boolean | null;
        createRole: boolean | null;
        inherit: boolean | null;
        canLogin: boolean | null;
        replication: boolean | null;
        bypassRls: boolean | null;
        connLimit: number | null;
        password: string | null;
        validUntil: string | null;
        name: string;
        entityType: "roles";
      };
    }) => boolean;
  };
  privileges: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      grantor: string;
      grantee: string;
      isGrantable: boolean;
    }, uniques?: ("schema" | "table" | "name" | "type" | "grantor" | "grantee" | "isGrantable")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | undefined) => {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    }[];
    one: (where?: {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | undefined) => {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | ((item: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER") => "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER") | undefined;
        grantor?: string | ((item: string) => string) | undefined;
        grantee?: string | ((item: string) => string) | undefined;
        isGrantable?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        grantor?: string | undefined;
        grantee?: string | undefined;
        schema?: string | undefined;
        table?: string | undefined;
        type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
        isGrantable?: boolean | undefined;
        name?: string | undefined;
        entityType?: "privileges" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      }[];
    };
    delete: (where?: {
      grantor?: string | undefined;
      grantee?: string | undefined;
      schema?: string | undefined;
      table?: string | undefined;
      type?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER" | undefined;
      isGrantable?: boolean | undefined;
      name?: string | undefined;
      entityType?: "privileges" | undefined;
    } | undefined) => {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    }[];
    validate: (data: unknown) => data is {
      grantor: string;
      grantee: string;
      schema: string;
      table: string;
      type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      isGrantable: boolean;
      name: string;
      entityType: "privileges";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "privileges";
      schema: string;
      table: string;
      name: string;
      type?: {
        from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
      } | undefined;
      grantor?: {
        from: string;
        to: string;
      } | undefined;
      grantee?: {
        from: string;
        to: string;
      } | undefined;
      isGrantable?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
      $right: {
        grantor: string;
        grantee: string;
        schema: string;
        table: string;
        type: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | "TRUNCATE" | "REFERENCES" | "TRIGGER";
        isGrantable: boolean;
        name: string;
        entityType: "privileges";
      };
    }) => boolean;
  };
  policies: {
    push: (input: {
      schema: string;
      table: string;
      name: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      roles: string[];
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      using: string | null | undefined;
      withCheck: string | null | undefined;
    }, uniques?: ("schema" | "table" | "name" | "as" | "roles" | "for" | "using" | "withCheck")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    }[];
    one: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        table?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        as?: "PERMISSIVE" | "RESTRICTIVE" | ((item: "PERMISSIVE" | "RESTRICTIVE") => "PERMISSIVE" | "RESTRICTIVE") | undefined;
        roles?: string[] | ((item: string) => string) | undefined;
        for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | ((item: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE") => "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE") | undefined;
        using?: string | ((item: string | null) => string | null) | null | undefined;
        withCheck?: string | ((item: string | null) => string | null) | null | undefined;
      };
      where?: {
        schema?: string | undefined;
        table?: string | undefined;
        as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
        for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
        roles?: string[] | {
          CONTAINS: string;
        } | undefined;
        using?: string | null | undefined;
        withCheck?: string | null | undefined;
        name?: string | undefined;
        entityType?: "policies" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      table?: string | undefined;
      as?: "PERMISSIVE" | "RESTRICTIVE" | undefined;
      for?: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE" | undefined;
      roles?: string[] | {
        CONTAINS: string;
      } | undefined;
      using?: string | null | undefined;
      withCheck?: string | null | undefined;
      name?: string | undefined;
      entityType?: "policies" | undefined;
    } | undefined) => {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      table: string;
      as: "PERMISSIVE" | "RESTRICTIVE";
      for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      roles: string[];
      using: string | null;
      withCheck: string | null;
      name: string;
      entityType: "policies";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "policies";
      schema: string;
      table: string;
      name: string;
      as?: {
        from: "PERMISSIVE" | "RESTRICTIVE";
        to: "PERMISSIVE" | "RESTRICTIVE";
      } | undefined;
      roles?: {
        from: string[];
        to: string[];
      } | undefined;
      for?: {
        from: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        to: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
      } | undefined;
      using?: {
        from: string | null;
        to: string | null;
      } | undefined;
      withCheck?: {
        from: string | null;
        to: string | null;
      } | undefined;
      $left: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
      $right: {
        schema: string;
        table: string;
        as: "PERMISSIVE" | "RESTRICTIVE";
        for: "ALL" | "SELECT" | "INSERT" | "UPDATE" | "DELETE";
        roles: string[];
        using: string | null;
        withCheck: string | null;
        name: string;
        entityType: "policies";
      };
    }) => boolean;
  };
  views: {
    push: (input: {
      schema: string;
      name: string;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      definition: string | null | undefined;
      using: string | null | undefined;
      withNoData: boolean | null | undefined;
      tablespace: string | null | undefined;
      materialized: boolean;
    }, uniques?: ("schema" | "name" | "with" | "definition" | "using" | "withNoData" | "tablespace" | "materialized")[] | undefined) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
    };
    pushAll: (items: Iterable<Record<string, any>>) => {
      status: "OK";
      count: number;
    } | {
      status: "CONFLICT";
      key: string;
    };
    list: (where?: {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    }[];
    one: (where?: {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    } | null;
    update: (config: {
      set: {
        schema?: string | ((item: string) => string) | undefined;
        name?: string | ((item: string) => string) | undefined;
        with?: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | ((item: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null) => {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null) | null | undefined;
        definition?: string | ((item: string | null) => string | null) | null | undefined;
        using?: string | ((item: string | null) => string | null) | null | undefined;
        withNoData?: boolean | ((item: boolean | null) => boolean | null) | null | undefined;
        tablespace?: string | ((item: string | null) => string | null) | null | undefined;
        materialized?: boolean | ((item: boolean) => boolean) | undefined;
      };
      where?: {
        schema?: string | undefined;
        definition?: string | null | undefined;
        with?: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null | undefined;
        withNoData?: boolean | null | undefined;
        using?: string | null | undefined;
        tablespace?: string | null | undefined;
        materialized?: boolean | undefined;
        name?: string | undefined;
        entityType?: "views" | undefined;
      } | undefined;
    }) => {
      status: "OK" | "CONFLICT";
      data: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      }[];
    };
    delete: (where?: {
      schema?: string | undefined;
      definition?: string | null | undefined;
      with?: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null | undefined;
      withNoData?: boolean | null | undefined;
      using?: string | null | undefined;
      tablespace?: string | null | undefined;
      materialized?: boolean | undefined;
      name?: string | undefined;
      entityType?: "views" | undefined;
    } | undefined) => {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    }[];
    validate: (data: unknown) => data is {
      schema: string;
      definition: string | null;
      with: {
        checkOption: "local" | "cascaded" | null;
        securityBarrier: boolean | null;
        securityInvoker: boolean | null;
        fillfactor: number | null;
        toastTupleTarget: number | null;
        parallelWorkers: number | null;
        autovacuumEnabled: boolean | null;
        vacuumIndexCleanup: "auto" | "off" | "on" | null;
        vacuumTruncate: boolean | null;
        autovacuumVacuumThreshold: number | null;
        autovacuumVacuumScaleFactor: number | null;
        autovacuumVacuumCostDelay: number | null;
        autovacuumVacuumCostLimit: number | null;
        autovacuumFreezeMinAge: number | null;
        autovacuumFreezeMaxAge: number | null;
        autovacuumFreezeTableAge: number | null;
        autovacuumMultixactFreezeMinAge: number | null;
        autovacuumMultixactFreezeMaxAge: number | null;
        autovacuumMultixactFreezeTableAge: number | null;
        logAutovacuumMinDuration: number | null;
        userCatalogTable: boolean | null;
      } | null;
      withNoData: boolean | null;
      using: string | null;
      tablespace: string | null;
      materialized: boolean;
      name: string;
      entityType: "views";
    };
    hasDiff: (input: {
      $diffType: "alter";
      entityType: "views";
      schema: string;
      name: string;
      with?: {
        from: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        to: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
      } | undefined;
      definition?: {
        from: string | null;
        to: string | null;
      } | undefined;
      using?: {
        from: string | null;
        to: string | null;
      } | undefined;
      withNoData?: {
        from: boolean | null;
        to: boolean | null;
      } | undefined;
      tablespace?: {
        from: string | null;
        to: string | null;
      } | undefined;
      materialized?: {
        from: boolean;
        to: boolean;
      } | undefined;
      $left: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
      $right: {
        schema: string;
        definition: string | null;
        with: {
          checkOption: "local" | "cascaded" | null;
          securityBarrier: boolean | null;
          securityInvoker: boolean | null;
          fillfactor: number | null;
          toastTupleTarget: number | null;
          parallelWorkers: number | null;
          autovacuumEnabled: boolean | null;
          vacuumIndexCleanup: "auto" | "off" | "on" | null;
          vacuumTruncate: boolean | null;
          autovacuumVacuumThreshold: number | null;
          autovacuumVacuumScaleFactor: number | null;
          autovacuumVacuumCostDelay: number | null;
          autovacuumVacuumCostLimit: number | null;
          autovacuumFreezeMinAge: number | null;
          autovacuumFreezeMaxAge: number | null;
          autovacuumFreezeTableAge: number | null;
          autovacuumMultixactFreezeMinAge: number | null;
          autovacuumMultixactFreezeMaxAge: number | null;
          autovacuumMultixactFreezeTableAge: number | null;
          logAutovacuumMinDuration: number | null;
          userCatalogTable: boolean | null;
        } | null;
        withNoData: boolean | null;
        using: string | null;
        tablespace: string | null;
        materialized: boolean;
        name: string;
        entityType: "views";
      };
    }) => boolean;
  };
};
type PostgresDDL = ReturnType<typeof createDDL>;
type PostgresEntities = PostgresDDL['_']['types'];
type PostgresEntity = PostgresEntities[keyof PostgresEntities];
//#endregion
//#region src/dialects/postgres/snapshot.d.ts
declare const snapshotValidator: {
  shape: {
    version: "8";
    dialect: "postgres";
    id: string;
    prevIds: string[];
    ddl: PostgresEntity[];
    renames: string[];
  };
  parse: (obj: unknown) => {
    success: boolean;
    data: {
      version: "8";
      dialect: "postgres";
      id: string;
      prevIds: string[];
      ddl: PostgresEntity[];
      renames: string[];
    } | null;
    errors?: string[] | undefined;
  };
  strict: (obj: unknown) => {
    version: "8";
    dialect: "postgres";
    id: string;
    prevIds: string[];
    ddl: PostgresEntity[];
    renames: string[];
  };
};
type PostgresSnapshot = typeof snapshotValidator.shape;
//#endregion
export { PostgresSnapshot as t };