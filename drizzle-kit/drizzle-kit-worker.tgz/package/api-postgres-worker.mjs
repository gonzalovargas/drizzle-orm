import { IndexedColumn, PgDialect, PgEnumColumn, PgEnumObjectColumn, PgGeometry, PgGeometryObject, PgLineABC, PgLineTuple, PgPointObject, PgPointTuple, PgPolicy, PgRole, PgSchema, PgTable, PgView, getMaterializedViewConfig, getTableConfig, getViewConfig, isPgEnum, isPgMaterializedView, isPgSequence, isPgView, uniqueKeyName } from "drizzle-orm/pg-core";
import { SQL, getTableName, is } from "drizzle-orm";
import { Relations } from "drizzle-orm/_relations";
//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJSMin = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
//#region src/dialects/dialect.ts
const commonConfig = {
	schema: "string?",
	table: "string?",
	name: "string"
};
function matchesFilters(item, filter) {
	for (const [k, v] of Object.entries(filter)) {
		if (v === void 0) continue;
		const target = item[k];
		if (v && typeof v === "object" && v.CONTAINS !== void 0) {
			if (!Array.isArray(target)) return false;
			if (!target.find((e) => isEqual(e, v.CONTAINS))) return false;
		} else if (!isEqual(target, v)) return false;
	}
	return true;
}
function filterCollection(collection, filter) {
	return collection.filter((e) => matchesFilters(e, filter));
}
function getCompositeKey(row) {
	return `${row.schema ?? ""}:${row.table ?? ""}:${row.name}:${row.entityType}`;
}
function findCompositeKey(dataSource, target) {
	const targetKey = getCompositeKey(target);
	return dataSource.find((e) => getCompositeKey(e) === targetKey);
}
function findCompositeKeys(dataSource, target) {
	const targetKey = getCompositeKey(target);
	return dataSource.filter((e) => getCompositeKey(e) === targetKey);
}
const generatePushAll = (configs, store, type) => {
	const nullsByType = /* @__PURE__ */ new Map();
	const getNulls = (entityType) => {
		let cached = nullsByType.get(entityType);
		if (cached) return cached;
		cached = Object.fromEntries(Object.keys(configs[entityType]).map((e) => [e, null]));
		nullsByType.set(entityType, cached);
		return cached;
	};
	return (items) => {
		const seen = /* @__PURE__ */ new Set();
		for (const existing of store.collection) seen.add(getCompositeKey(existing));
		const prepared = [];
		for (const input of items) {
			const filtered = {};
			for (const k in input) if (input[k] !== void 0) filtered[k] = input[k];
			const entityType = type ?? filtered.entityType;
			const mapped = {
				...getNulls(entityType),
				...filtered,
				entityType
			};
			const key = getCompositeKey(mapped);
			if (seen.has(key)) return {
				status: "CONFLICT",
				key
			};
			seen.add(key);
			prepared.push(mapped);
		}
		for (const row of prepared) store.collection.push(row);
		return {
			status: "OK",
			count: prepared.length
		};
	};
};
const generateInsert = (configs, store, type) => {
	let nulls = type ? Object.fromEntries(Object.keys(configs[type]).filter((e) => !commonConfig[e] || !commonConfig[e].endsWith("?")).map((e) => [e, null])) : void 0;
	return (input, uniques) => {
		const filteredElement = Object.fromEntries(Object.entries(input).filter(([_, value]) => value !== void 0));
		const localType = type ?? filteredElement.entityType;
		const mapped = {
			...nulls ?? Object.fromEntries(Object.keys(configs[localType]).map((e) => [e, null])),
			...filteredElement,
			entityType: localType
		};
		const conflict = uniques ? store.collection.find((e) => {
			if (e.entityType !== mapped.entityType) return false;
			for (const k of uniques) if (k in mapped && !isEqual(mapped[k], e[k])) return false;
			return true;
		}) : findCompositeKey(store.collection, mapped);
		if (conflict) return {
			status: "CONFLICT",
			data: conflict
		};
		store.collection.push(mapped);
		return {
			status: "OK",
			data: mapped
		};
	};
};
const generateList = (store, type) => {
	return (where) => {
		const from = type ? filterCollection(store.collection, { entityType: type }) : store.collection;
		if (!where) return from;
		return filterCollection(from, where);
	};
};
const generateOne = (store, type) => {
	return (where) => {
		const from = type ? filterCollection(store.collection, { entityType: type }) : store.collection;
		if (!where) return from[0] ?? null;
		return filterCollection(from, where)[0] ?? null;
	};
};
const generateUpdate = (store, type) => {
	return ({ set, where }) => {
		const filter = type ? {
			...where,
			entityType: type
		} : where;
		const targets = filter ? filterCollection(store.collection, filter) : store.collection;
		const entries = Object.entries(set);
		const newItems = [];
		let i = 0;
		const dupes = [];
		for (const item of targets) {
			const newItem = { ...item };
			for (const [k, v] of entries) {
				if (!(k in item)) continue;
				const target = item[k];
				newItem[k] = typeof v === "function" ? Array.isArray(target) ? target.map(v) : v(target) : v;
			}
			const dupe = findCompositeKeys(store.collection, newItem).filter((e) => e !== item);
			dupes.push(...dupe.filter((e) => !dupes.find((d) => d === e)));
			if (!dupe.length) newItems.push({
				item: newItem,
				index: i++
			});
		}
		if (dupes.length) return {
			status: "CONFLICT",
			data: dupes
		};
		for (const { index, item } of newItems) Object.assign(targets[index], item);
		return {
			status: "OK",
			data: targets
		};
	};
};
const generateDelete = (store, type) => {
	return (where) => {
		const updatedCollection = [];
		const deleted = [];
		const filter = type ? {
			...where,
			entityType: type
		} : where;
		if (!filter) {
			store.collection = updatedCollection;
			return deleted;
		}
		store.collection.forEach((e) => {
			if (matchesFilters(e, filter)) deleted.push(e);
			else updatedCollection.push(e);
		});
		store.collection = updatedCollection;
		return deleted;
	};
};
const generateHasDiff = (lengths) => {
	return (input) => {
		const length = lengths[input.entityType];
		return Object.keys(input).length > length;
	};
};
function validate(data, schema, deep = false) {
	if (typeof data !== "object" || data === null) return false;
	for (const k of Array.from(new Set([...Object.keys(data), ...Object.keys(schema)]))) {
		if (!deep && k === "entityType") continue;
		if (!schema[k]) return false;
		if (schema[k] === "string[]") {
			if (!Array.isArray(data[k])) return false;
			if (!data[k].every((e) => typeof e === "string")) return false;
		} else if (typeof schema[k] === "string") {
			const isNullable = schema[k].endsWith("?");
			if (data[k] === null && !isNullable) return false;
			if (data[k] !== null && typeof data[k] !== removeQuestionMark(schema[k])) return false;
		} else if (Array.isArray(schema[k])) if (typeof schema[k][0] === "string") {
			if (!schema[k].some((e) => e === data[k])) return false;
		} else {
			if (!Array.isArray(data[k])) return false;
			if (!data[k].every((e) => validate(e, schema[k][0]), true)) return false;
		}
		else if (data[k] !== null && !validate(data[k], schema[k], true)) return false;
	}
	return true;
}
const generateValidate = (configs, type) => {
	return ((data) => {
		if (typeof data !== "object" || data === null) return false;
		const localType = type ?? data.entityType;
		if (typeof localType !== "string" || data.entityType !== localType) return false;
		const config = configs[localType];
		if (!config) return false;
		return validate(data, config);
	});
};
function initSchemaProcessors({ entities }, store, common, extraConfigs) {
	const entries = Object.entries(entities);
	const extraKeys = 4;
	const lengths = Object.fromEntries(Object.entries(common ? extraConfigs : entities).map(([k, v]) => {
		return [k, Object.keys(v).filter((e) => e in commonConfig).length + extraKeys];
	}));
	return Object.fromEntries(entries.map(([k, _v]) => {
		return [k, {
			push: generateInsert(common ? extraConfigs : entities, store, common ? void 0 : k),
			pushAll: generatePushAll(common ? extraConfigs : entities, store, common ? void 0 : k),
			list: generateList(store, common ? void 0 : k),
			one: generateOne(store, common ? void 0 : k),
			update: generateUpdate(store, common ? void 0 : k),
			delete: generateDelete(store, common ? void 0 : k),
			validate: generateValidate(common ? extraConfigs : entities, common ? void 0 : k),
			hasDiff: generateHasDiff(lengths)
		}];
	}));
}
const ignoreChanges = {
	entityType: true,
	name: true,
	schema: true,
	table: true
};
function isEqual(a, b) {
	if (typeof a !== typeof b) return false;
	if (Array.isArray(a) && Array.isArray(b)) {
		if (a.length !== b.length) return false;
		return a.every((v, i) => isEqual(v, b[i]));
	}
	if (typeof a === "object") {
		if (a === b) return true;
		if ((a === null || b === null) && a !== b) return false;
		return Array.from(new Set([...Object.keys(a), ...Object.keys(b)])).every((k) => isEqual(a[k], b[k]));
	}
	return a === b;
}
function sanitizeRow(row) {
	return Object.fromEntries(Object.entries(row).filter(([k, _v]) => !ignoreChanges[k]));
}
function getRowCommons(row) {
	const res = {};
	for (const k of Object.keys(commonConfig)) {
		if (row[k] === void 0 || row[k] === null) continue;
		res[k] = row[k];
	}
	return res;
}
function _diff(dbOld, dbNew, collection, mode) {
	collection = collection ?? "entities";
	mode = mode ?? "all";
	const leftEntities = dbOld.entities.list(collection === "entities" ? void 0 : { entityType: collection });
	const rightEntities = dbNew.entities.list(collection === "entities" ? void 0 : { entityType: collection });
	const left = {};
	const right = {};
	for (const row of leftEntities) left[getCompositeKey(row)] = row;
	for (const row of rightEntities) right[getCompositeKey(row)] = row;
	const created = [];
	const dropped = [];
	const altered = [];
	for (const [key, oldRow] of Object.entries(left)) {
		const newRow = right[key];
		if (!newRow) {
			if (mode === "all" || mode === "drop" || mode === "createdrop") dropped.push({
				$diffType: "drop",
				entityType: oldRow.entityType,
				...getRowCommons(oldRow),
				...sanitizeRow(oldRow)
			});
		} else if (mode === "all" || mode === "alter") {
			const changes = {};
			let isChanged = false;
			for (const [k, _v] of Object.entries(oldRow)) {
				if (ignoreChanges[k]) continue;
				if (!isEqual(oldRow[k], newRow[k])) {
					isChanged = true;
					changes[k] = {
						from: oldRow[k],
						to: newRow[k]
					};
				}
			}
			if (isChanged) altered.push({
				$diffType: "alter",
				entityType: newRow.entityType,
				...getRowCommons(newRow),
				...changes,
				$left: oldRow,
				$right: newRow
			});
		}
		delete right[key];
	}
	if (mode === "all" || mode === "create" || mode === "createdrop") for (const newRow of Object.values(right)) created.push({
		$diffType: "create",
		entityType: newRow.entityType,
		...getRowCommons(newRow),
		...sanitizeRow(newRow)
	});
	return [
		...created,
		...dropped,
		...altered
	];
}
function diff(dbOld, dbNew, collection) {
	return _diff(dbOld, dbNew, collection, "createdrop");
}
(function(_diff2) {
	function all(dbOld, dbNew, collection) {
		return _diff(dbOld, dbNew, collection, "all");
	}
	_diff2.all = all;
	function creates(dbOld, dbNew, collection) {
		return _diff(dbOld, dbNew, collection, "create");
	}
	_diff2.creates = creates;
	function drops(dbOld, dbNew, collection) {
		return _diff(dbOld, dbNew, collection, "drop");
	}
	_diff2.drops = drops;
	function alters(dbOld, dbNew, collection) {
		return _diff(dbOld, dbNew, collection, "alter");
	}
	_diff2.alters = alters;
})(diff || (diff = {}));
function removeQuestionMark(str) {
	if (!str.endsWith("?")) return str;
	return str.slice(0, str.length - 1);
}
var SimpleDb = class {
	_ = {
		diffs: {},
		store: { collection: [] }
	};
	entities;
	constructor(definition) {
		const entries = Object.entries(definition);
		const configs = Object.fromEntries(entries.map(([type, def]) => {
			if (type === "entities" || type === "_") throw new Error(`Illegal entity type name: "${type}"`);
			const cloneDef = {};
			Object.entries(def).forEach(([fieldName, fieldValue]) => {
				cloneDef[fieldName] = fieldValue;
				if (fieldValue === "required") {
					if (!(fieldName in commonConfig)) throw new Error(`Type value "required" is only applicable to common keys [ ${Object.keys(commonConfig).map((e) => `"${e}"`).join(", ")} ], used on: "${fieldName}"`);
					cloneDef[fieldName] = removeQuestionMark(commonConfig[fieldName]);
				} else if (fieldName in commonConfig) throw new Error(`Used forbidden key "${fieldName}" in entity "${type}"`);
			});
			for (const k in commonConfig) {
				if (commonConfig[k].endsWith("?")) continue;
				cloneDef[k] = commonConfig[k];
			}
			return [type, cloneDef];
		}));
		this._.entities = configs;
		this.entities = initSchemaProcessors({
			...this._,
			entities: { entities: commonConfig }
		}, this._.store, true, this._.entities).entities;
	}
};
function create(definition) {
	const db = new SimpleDb(definition);
	const processors = initSchemaProcessors(db._, db._.store, false);
	for (const [k, v] of Object.entries(processors)) db[k] = v;
	return db;
}
//#endregion
//#region ../node_modules/.pnpm/@js-temporal+polyfill@0.5.1/node_modules/@js-temporal/polyfill/dist/index.esm.js
var import_jsbi_umd = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(e, t) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = e || self, e.JSBI = t());
	})(exports, function() {
		"use strict";
		var e = Math.imul, t = Math.clz32;
		function i(t, i) {
			(null == i || i > t.length) && (i = t.length);
			for (var _ = 0, o = Array(i); _ < i; _++) o[_] = t[_];
			return o;
		}
		function _(e) {
			if (Array.isArray(e)) return e;
		}
		function n(t) {
			if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
			return t;
		}
		function o(i, t, _) {
			return t = r(t), v(i, b() ? Reflect.construct(t, _ || [], r(i).constructor) : t.apply(i, _));
		}
		function l(e, t) {
			if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
		}
		function g(i, t, e) {
			if (b()) return Reflect.construct.apply(null, arguments);
			var _ = [null];
			_.push.apply(_, t);
			var n = new (i.bind.apply(i, _))();
			return e && y(n, e.prototype), n;
		}
		function a(i, e) {
			for (var _, n = 0; n < e.length; n++) _ = e[n], _.enumerable = _.enumerable || !1, _.configurable = !0, "value" in _ && (_.writable = !0), Object.defineProperty(i, D(_.key), _);
		}
		function s(i, e, _) {
			return e && a(i.prototype, e), _ && a(i, _), Object.defineProperty(i, "prototype", { writable: !1 }), i;
		}
		function u(i, _) {
			var e = "undefined" != typeof Symbol && i[Symbol.iterator] || i["@@iterator"];
			if (!e) {
				if (Array.isArray(i) || (e = B(i)) || _ && i && "number" == typeof i.length) {
					e && (i = e);
					var l = 0, g = function() {};
					return {
						s: g,
						n: function() {
							return l >= i.length ? { done: !0 } : {
								done: !1,
								value: i[l++]
							};
						},
						e: function(e) {
							throw e;
						},
						f: g
					};
				}
				throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
			}
			var s, d = !0, h = !1;
			return {
				s: function() {
					e = e.call(i);
				},
				n: function() {
					var t = e.next();
					return d = t.done, t;
				},
				e: function(e) {
					h = !0, s = e;
				},
				f: function() {
					try {
						d || null == e.return || e.return();
					} finally {
						if (h) throw s;
					}
				}
			};
		}
		function r(e) {
			return r = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
				return e.__proto__ || Object.getPrototypeOf(e);
			}, r(e);
		}
		function d(i, t) {
			if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
			i.prototype = Object.create(t && t.prototype, { constructor: {
				value: i,
				writable: !0,
				configurable: !0
			} }), Object.defineProperty(i, "prototype", { writable: !1 }), t && y(i, t);
		}
		function h(e) {
			try {
				return -1 !== Function.toString.call(e).indexOf("[native code]");
			} catch (t) {
				return "function" == typeof e;
			}
		}
		function b() {
			try {
				var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}));
			} catch (e) {}
			return (b = function() {
				return !!e;
			})();
		}
		function m(_, g) {
			var l = null == _ ? null : "undefined" != typeof Symbol && _[Symbol.iterator] || _["@@iterator"];
			if (null != l) {
				var s, d, r, h, b = [], a = !0, m = !1;
				try {
					if (r = (l = l.call(_)).next, 0 === g) {
						if (Object(l) !== l) return;
						a = !1;
					} else for (; !(a = (s = r.call(l)).done) && (b.push(s.value), b.length !== g); a = !0);
				} catch (e) {
					m = !0, d = e;
				} finally {
					try {
						if (!a && null != l.return && (h = l.return(), Object(h) !== h)) return;
					} finally {
						if (m) throw d;
					}
				}
				return b;
			}
		}
		function c() {
			throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
		}
		function v(i, t) {
			if (t && ("object" == typeof t || "function" == typeof t)) return t;
			if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
			return n(i);
		}
		function y(i, t) {
			return y = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(i, t) {
				return i.__proto__ = t, i;
			}, y(i, t);
		}
		function f(t, i) {
			return _(t) || m(t, i) || B(t, i) || c();
		}
		function k(_, t) {
			if ("object" != typeof _ || !_) return _;
			var n = _[Symbol.toPrimitive];
			if (void 0 !== n) {
				var e = n.call(_, t || "default");
				if ("object" != typeof e) return e;
				throw new TypeError("@@toPrimitive must return a primitive value.");
			}
			return ("string" === t ? String : Number)(_);
		}
		function D(e) {
			var t = k(e, "string");
			return "symbol" == typeof t ? t : t + "";
		}
		function p(e) {
			"@babel/helpers - typeof";
			return p = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
				return typeof e;
			} : function(e) {
				return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
			}, p(e);
		}
		function B(e, _) {
			if (e) {
				if ("string" == typeof e) return i(e, _);
				var n = {}.toString.call(e).slice(8, -1);
				return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? i(e, _) : void 0;
			}
		}
		function S(e) {
			var i = "function" == typeof Map ? /* @__PURE__ */ new Map() : void 0;
			return S = function(e) {
				function t() {
					return g(e, arguments, r(this).constructor);
				}
				if (null === e || !h(e)) return e;
				if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
				if (void 0 !== i) {
					if (i.has(e)) return i.get(e);
					i.set(e, t);
				}
				return t.prototype = Object.create(e.prototype, { constructor: {
					value: t,
					enumerable: !1,
					writable: !0,
					configurable: !0
				} }), y(t, e);
			}, S(e);
		}
		var C = function(e) {
			var t = Math.abs, i = Math.max, _ = Math.floor;
			function g(e, t) {
				var i;
				if (l(this, g), i = o(this, g, [e]), i.sign = t, Object.setPrototypeOf(i, g.prototype), e > g.__kMaxLength) throw new RangeError("Maximum BigInt size exceeded");
				return i;
			}
			return d(g, e), s(g, [
				{
					key: "toDebugString",
					value: function e() {
						var t, i = ["BigInt["], _ = u(this);
						try {
							for (_.s(); !(t = _.n()).done;) {
								var n = t.value;
								i.push((n ? (n >>> 0).toString(16) : n) + ", ");
							}
						} catch (e) {
							_.e(e);
						} finally {
							_.f();
						}
						return i.push("]"), i.join("");
					}
				},
				{
					key: "toString",
					value: function e() {
						var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 10;
						if (2 > t || 36 < t) throw new RangeError("toString() radix argument must be between 2 and 36");
						return 0 === this.length ? "0" : 0 == (t & t - 1) ? g.__toStringBasePowerOfTwo(this, t) : g.__toStringGeneric(this, t, !1);
					}
				},
				{
					key: "valueOf",
					value: function e() {
						throw new Error("Convert JSBI instances to native numbers using `toNumber`.");
					}
				},
				{
					key: "__copy",
					value: function e() {
						for (var t = new g(this.length, this.sign), _ = 0; _ < this.length; _++) t[_] = this[_];
						return t;
					}
				},
				{
					key: "__trim",
					value: function e() {
						for (var t = this.length, i = this[t - 1]; 0 === i;) t--, i = this[t - 1], this.pop();
						return 0 === t && (this.sign = !1), this;
					}
				},
				{
					key: "__initializeDigits",
					value: function e() {
						for (var t = 0; t < this.length; t++) this[t] = 0;
					}
				},
				{
					key: "__clzmsd",
					value: function e() {
						return g.__clz30(this.__digit(this.length - 1));
					}
				},
				{
					key: "__inplaceMultiplyAdd",
					value: function n(e, t, _) {
						_ > this.length && (_ = this.length);
						for (var o = 32767 & e, l = e >>> 15, a = 0, s = t, u = 0; u < _; u++) {
							var r = this.__digit(u), h = 32767 & r, b = r >>> 15, m = g.__imul(h, o), c = g.__imul(h, l), v = g.__imul(b, o), y = g.__imul(b, l), f = s + m + a;
							a = f >>> 30, f &= 1073741823, f += ((32767 & c) << 15) + ((32767 & v) << 15), a += f >>> 30, s = y + (c >>> 15) + (v >>> 15), this.__setDigit(u, 1073741823 & f);
						}
						if (0 !== a || 0 !== s) throw new Error("implementation bug");
					}
				},
				{
					key: "__inplaceAdd",
					value: function n(e, t, _) {
						for (var o, l = 0, g = 0; g < _; g++) o = this.__halfDigit(t + g) + e.__halfDigit(g) + l, l = o >>> 15, this.__setHalfDigit(t + g, 32767 & o);
						return l;
					}
				},
				{
					key: "__inplaceSub",
					value: function n(e, t, _) {
						var o = _ - 1 >>> 1, l = 0;
						if (1 & t) {
							t >>= 1;
							for (var g = this.__digit(t), a = 32767 & g, s = 0; s < o; s++) {
								var u = e.__digit(s), r = (g >>> 15) - (32767 & u) - l;
								l = 1 & r >>> 15, this.__setDigit(t + s, (32767 & r) << 15 | 32767 & a), g = this.__digit(t + s + 1), a = (32767 & g) - (u >>> 15) - l, l = 1 & a >>> 15;
							}
							var d = e.__digit(s), h = (g >>> 15) - (32767 & d) - l;
							l = 1 & h >>> 15, this.__setDigit(t + s, (32767 & h) << 15 | 32767 & a);
							var b = d >>> 15;
							if (t + s + 1 >= this.length) throw new RangeError("out of bounds");
							0 == (1 & _) && (g = this.__digit(t + s + 1), a = (32767 & g) - b - l, l = 1 & a >>> 15, this.__setDigit(t + e.length, 1073709056 & g | 32767 & a));
						} else {
							t >>= 1;
							for (var m = 0; m < e.length - 1; m++) {
								var c = this.__digit(t + m), v = e.__digit(m), y = (32767 & c) - (32767 & v) - l;
								l = 1 & y >>> 15;
								var f = (c >>> 15) - (v >>> 15) - l;
								l = 1 & f >>> 15, this.__setDigit(t + m, (32767 & f) << 15 | 32767 & y);
							}
							var k = this.__digit(t + m), D = e.__digit(m), p = (32767 & k) - (32767 & D) - l;
							l = 1 & p >>> 15;
							var B = 0;
							0 == (1 & _) && (B = (k >>> 15) - (D >>> 15) - l, l = 1 & B >>> 15), this.__setDigit(t + m, (32767 & B) << 15 | 32767 & p);
						}
						return l;
					}
				},
				{
					key: "__inplaceRightShift",
					value: function t(e) {
						if (0 !== e) {
							for (var _, n = this.__digit(0) >>> e, o = this.length - 1, l = 0; l < o; l++) _ = this.__digit(l + 1), this.__setDigit(l, 1073741823 & _ << 30 - e | n), n = _ >>> e;
							this.__setDigit(o, n);
						}
					}
				},
				{
					key: "__digit",
					value: function t(e) {
						return this[e];
					}
				},
				{
					key: "__unsignedDigit",
					value: function t(e) {
						return this[e] >>> 0;
					}
				},
				{
					key: "__setDigit",
					value: function i(e, t) {
						this[e] = 0 | t;
					}
				},
				{
					key: "__setDigitGrow",
					value: function i(e, t) {
						this[e] = 0 | t;
					}
				},
				{
					key: "__halfDigitLength",
					value: function e() {
						var t = this.length;
						return 32767 >= this.__unsignedDigit(t - 1) ? 2 * t - 1 : 2 * t;
					}
				},
				{
					key: "__halfDigit",
					value: function t(e) {
						return 32767 & this[e >>> 1] >>> 15 * (1 & e);
					}
				},
				{
					key: "__setHalfDigit",
					value: function i(e, t) {
						var _ = e >>> 1, n = this.__digit(_), o = 1 & e ? 32767 & n | t << 15 : 1073709056 & n | 32767 & t;
						this.__setDigit(_, o);
					}
				}
			], [
				{
					key: "BigInt",
					value: function t(e) {
						var i = Number.isFinite;
						if ("number" == typeof e) {
							if (0 === e) return g.__zero();
							if (g.__isOneDigitInt(e)) return 0 > e ? g.__oneDigit(-e, !0) : g.__oneDigit(e, !1);
							if (!i(e) || _(e) !== e) throw new RangeError("The number " + e + " cannot be converted to BigInt because it is not an integer");
							return g.__fromDouble(e);
						}
						if ("string" == typeof e) {
							var n = g.__fromString(e);
							if (null === n) throw new SyntaxError("Cannot convert " + e + " to a BigInt");
							return n;
						}
						if ("boolean" == typeof e) return !0 === e ? g.__oneDigit(1, !1) : g.__zero();
						if ("object" === p(e)) {
							if (e.constructor === g) return e;
							var o = g.__toPrimitive(e);
							return g.BigInt(o);
						}
						throw new TypeError("Cannot convert " + e + " to a BigInt");
					}
				},
				{
					key: "toNumber",
					value: function t(e) {
						var i = e.length;
						if (0 === i) return 0;
						if (1 === i) {
							var _ = e.__unsignedDigit(0);
							return e.sign ? -_ : _;
						}
						var n = e.__digit(i - 1), o = g.__clz30(n), l = 30 * i - o;
						if (1024 < l) return e.sign ? -Infinity : Infinity;
						var a = l - 1, s = n, u = i - 1, r = o + 3, d = 32 === r ? 0 : s << r;
						d >>>= 12;
						var h = r - 12, b = 12 <= r ? 0 : s << 20 + r, m = 20 + r;
						for (0 < h && 0 < u && (u--, s = e.__digit(u), d |= s >>> 30 - h, b = s << h + 2, m = h + 2); 0 < m && 0 < u;) u--, s = e.__digit(u), b |= 30 <= m ? s << m - 30 : s >>> 30 - m, m -= 30;
						var c = g.__decideRounding(e, m, u, s);
						if ((1 === c || 0 === c && 1 == (1 & b)) && (b = b + 1 >>> 0, 0 === b && (d++, 0 != d >>> 20 && (d = 0, a++, 1023 < a)))) return e.sign ? -Infinity : Infinity;
						var v = e.sign ? -2147483648 : 0;
						return a = a + 1023 << 20, g.__kBitConversionInts[g.__kBitConversionIntHigh] = v | a | d, g.__kBitConversionInts[g.__kBitConversionIntLow] = b, g.__kBitConversionDouble[0];
					}
				},
				{
					key: "unaryMinus",
					value: function t(e) {
						if (0 === e.length) return e;
						var i = e.__copy();
						return i.sign = !e.sign, i;
					}
				},
				{
					key: "bitwiseNot",
					value: function t(e) {
						return e.sign ? g.__absoluteSubOne(e).__trim() : g.__absoluteAddOne(e, !0);
					}
				},
				{
					key: "exponentiate",
					value: function i(e, t) {
						if (t.sign) throw new RangeError("Exponent must be positive");
						if (0 === t.length) return g.__oneDigit(1, !1);
						if (0 === e.length) return e;
						if (1 === e.length && 1 === e.__digit(0)) return e.sign && 0 == (1 & t.__digit(0)) ? g.unaryMinus(e) : e;
						if (1 < t.length) throw new RangeError("BigInt too big");
						var _ = t.__unsignedDigit(0);
						if (1 === _) return e;
						if (_ >= g.__kMaxLengthBits) throw new RangeError("BigInt too big");
						if (1 === e.length && 2 === e.__digit(0)) {
							var n = 1 + (0 | _ / 30), l = new g(n, e.sign && 0 != (1 & _));
							l.__initializeDigits();
							var a = 1 << _ % 30;
							return l.__setDigit(n - 1, a), l;
						}
						var s = null, u = e;
						for (0 != (1 & _) && (s = e), _ >>= 1; 0 !== _; _ >>= 1) u = g.multiply(u, u), 0 != (1 & _) && (null === s ? s = u : s = g.multiply(s, u));
						return s;
					}
				},
				{
					key: "multiply",
					value: function _(e, t) {
						if (0 === e.length) return e;
						if (0 === t.length) return t;
						var n = e.length + t.length;
						30 <= e.__clzmsd() + t.__clzmsd() && n--;
						var o = new g(n, e.sign !== t.sign);
						o.__initializeDigits();
						for (var l = 0; l < e.length; l++) g.__multiplyAccumulate(t, e.__digit(l), o, l);
						return o.__trim();
					}
				},
				{
					key: "divide",
					value: function i(e, t) {
						if (0 === t.length) throw new RangeError("Division by zero");
						if (0 > g.__absoluteCompare(e, t)) return g.__zero();
						var _, n = e.sign !== t.sign, o = t.__unsignedDigit(0);
						if (1 === t.length && 32767 >= o) {
							if (1 === o) return n === e.sign ? e : g.unaryMinus(e);
							_ = g.__absoluteDivSmall(e, o, null);
						} else _ = g.__absoluteDivLarge(e, t, !0, !1);
						return _.sign = n, _.__trim();
					}
				},
				{
					key: "remainder",
					value: function i(e, t) {
						if (0 === t.length) throw new RangeError("Division by zero");
						if (0 > g.__absoluteCompare(e, t)) return e;
						var _ = t.__unsignedDigit(0);
						if (1 === t.length && 32767 >= _) {
							if (1 === _) return g.__zero();
							var n = g.__absoluteModSmall(e, _);
							return 0 === n ? g.__zero() : g.__oneDigit(n, e.sign);
						}
						var i = g.__absoluteDivLarge(e, t, !1, !0);
						return i.sign = e.sign, i.__trim();
					}
				},
				{
					key: "add",
					value: function i(e, t) {
						var _ = e.sign;
						return _ === t.sign ? g.__absoluteAdd(e, t, _) : 0 <= g.__absoluteCompare(e, t) ? g.__absoluteSub(e, t, _) : g.__absoluteSub(t, e, !_);
					}
				},
				{
					key: "subtract",
					value: function i(e, t) {
						var _ = e.sign;
						return _ === t.sign ? 0 <= g.__absoluteCompare(e, t) ? g.__absoluteSub(e, t, _) : g.__absoluteSub(t, e, !_) : g.__absoluteAdd(e, t, _);
					}
				},
				{
					key: "leftShift",
					value: function i(e, t) {
						return 0 === t.length || 0 === e.length ? e : t.sign ? g.__rightShiftByAbsolute(e, t) : g.__leftShiftByAbsolute(e, t);
					}
				},
				{
					key: "signedRightShift",
					value: function i(e, t) {
						return 0 === t.length || 0 === e.length ? e : t.sign ? g.__leftShiftByAbsolute(e, t) : g.__rightShiftByAbsolute(e, t);
					}
				},
				{
					key: "unsignedRightShift",
					value: function e() {
						throw new TypeError("BigInts have no unsigned right shift; use >> instead");
					}
				},
				{
					key: "lessThan",
					value: function i(e, t) {
						return 0 > g.__compareToBigInt(e, t);
					}
				},
				{
					key: "lessThanOrEqual",
					value: function i(e, t) {
						return 0 >= g.__compareToBigInt(e, t);
					}
				},
				{
					key: "greaterThan",
					value: function i(e, t) {
						return 0 < g.__compareToBigInt(e, t);
					}
				},
				{
					key: "greaterThanOrEqual",
					value: function i(e, t) {
						return 0 <= g.__compareToBigInt(e, t);
					}
				},
				{
					key: "equal",
					value: function _(e, t) {
						if (e.sign !== t.sign) return !1;
						if (e.length !== t.length) return !1;
						for (var n = 0; n < e.length; n++) if (e.__digit(n) !== t.__digit(n)) return !1;
						return !0;
					}
				},
				{
					key: "notEqual",
					value: function i(e, t) {
						return !g.equal(e, t);
					}
				},
				{
					key: "bitwiseAnd",
					value: function _(e, t) {
						if (!e.sign && !t.sign) return g.__absoluteAnd(e, t).__trim();
						if (e.sign && t.sign) {
							var n = i(e.length, t.length) + 1, o = g.__absoluteSubOne(e, n), l = g.__absoluteSubOne(t);
							return o = g.__absoluteOr(o, l, o), g.__absoluteAddOne(o, !0, o).__trim();
						}
						if (e.sign) {
							var a = [t, e];
							e = a[0], t = a[1];
						}
						return g.__absoluteAndNot(e, g.__absoluteSubOne(t)).__trim();
					}
				},
				{
					key: "bitwiseXor",
					value: function _(e, t) {
						if (!e.sign && !t.sign) return g.__absoluteXor(e, t).__trim();
						if (e.sign && t.sign) {
							var n = i(e.length, t.length), o = g.__absoluteSubOne(e, n), l = g.__absoluteSubOne(t);
							return g.__absoluteXor(o, l, o).__trim();
						}
						var a = i(e.length, t.length) + 1;
						if (e.sign) {
							var s = [t, e];
							e = s[0], t = s[1];
						}
						var u = g.__absoluteSubOne(t, a);
						return u = g.__absoluteXor(u, e, u), g.__absoluteAddOne(u, !0, u).__trim();
					}
				},
				{
					key: "bitwiseOr",
					value: function _(e, t) {
						var n = i(e.length, t.length);
						if (!e.sign && !t.sign) return g.__absoluteOr(e, t).__trim();
						if (e.sign && t.sign) {
							var o = g.__absoluteSubOne(e, n), l = g.__absoluteSubOne(t);
							return o = g.__absoluteAnd(o, l, o), g.__absoluteAddOne(o, !0, o).__trim();
						}
						if (e.sign) {
							var a = [t, e];
							e = a[0], t = a[1];
						}
						var s = g.__absoluteSubOne(t, n);
						return s = g.__absoluteAndNot(s, e, s), g.__absoluteAddOne(s, !0, s).__trim();
					}
				},
				{
					key: "asIntN",
					value: function o(e, t) {
						if (0 === t.length) return t;
						if (e = _(e), 0 > e) throw new RangeError("Invalid value: not (convertible to) a safe integer");
						if (0 === e) return g.__zero();
						if (e >= g.__kMaxLengthBits) return t;
						var l = 0 | (e + 29) / 30;
						if (t.length < l) return t;
						var a = t.__unsignedDigit(l - 1), s = 1 << (e - 1) % 30;
						if (t.length === l && a < s) return t;
						if (!((a & s) === s)) return g.__truncateToNBits(e, t);
						if (!t.sign) return g.__truncateAndSubFromPowerOfTwo(e, t, !0);
						if (0 == (a & s - 1)) {
							for (var r = l - 2; 0 <= r; r--) if (0 !== t.__digit(r)) return g.__truncateAndSubFromPowerOfTwo(e, t, !1);
							return t.length === l && a === s ? t : g.__truncateToNBits(e, t);
						}
						return g.__truncateAndSubFromPowerOfTwo(e, t, !1);
					}
				},
				{
					key: "asUintN",
					value: function i(e, t) {
						if (0 === t.length) return t;
						if (e = _(e), 0 > e) throw new RangeError("Invalid value: not (convertible to) a safe integer");
						if (0 === e) return g.__zero();
						if (t.sign) {
							if (e > g.__kMaxLengthBits) throw new RangeError("BigInt too big");
							return g.__truncateAndSubFromPowerOfTwo(e, t, !1);
						}
						if (e >= g.__kMaxLengthBits) return t;
						var o = 0 | (e + 29) / 30;
						if (t.length < o) return t;
						var l = e % 30;
						if (t.length == o) {
							if (0 === l) return t;
							if (0 == t.__digit(o - 1) >>> l) return t;
						}
						return g.__truncateToNBits(e, t);
					}
				},
				{
					key: "ADD",
					value: function i(e, t) {
						if (e = g.__toPrimitive(e), t = g.__toPrimitive(t), "string" == typeof e) return "string" != typeof t && (t = t.toString()), e + t;
						if ("string" == typeof t) return e.toString() + t;
						if (e = g.__toNumeric(e), t = g.__toNumeric(t), g.__isBigInt(e) && g.__isBigInt(t)) return g.add(e, t);
						if ("number" == typeof e && "number" == typeof t) return e + t;
						throw new TypeError("Cannot mix BigInt and other types, use explicit conversions");
					}
				},
				{
					key: "LT",
					value: function i(e, t) {
						return g.__compare(e, t, 0);
					}
				},
				{
					key: "LE",
					value: function i(e, t) {
						return g.__compare(e, t, 1);
					}
				},
				{
					key: "GT",
					value: function i(e, t) {
						return g.__compare(e, t, 2);
					}
				},
				{
					key: "GE",
					value: function i(e, t) {
						return g.__compare(e, t, 3);
					}
				},
				{
					key: "EQ",
					value: function i(e, t) {
						for (;;) {
							if (g.__isBigInt(e)) return g.__isBigInt(t) ? g.equal(e, t) : g.EQ(t, e);
							if ("number" == typeof e) {
								if (g.__isBigInt(t)) return g.__equalToNumber(t, e);
								if ("object" !== p(t)) return e == t;
								t = g.__toPrimitive(t);
							} else if ("string" == typeof e) {
								if (g.__isBigInt(t)) return e = g.__fromString(e), null !== e && g.equal(e, t);
								if ("object" !== p(t)) return e == t;
								t = g.__toPrimitive(t);
							} else if ("boolean" == typeof e) {
								if (g.__isBigInt(t)) return g.__equalToNumber(t, +e);
								if ("object" !== p(t)) return e == t;
								t = g.__toPrimitive(t);
							} else if ("symbol" === p(e)) {
								if (g.__isBigInt(t)) return !1;
								if ("object" !== p(t)) return e == t;
								t = g.__toPrimitive(t);
							} else if ("object" === p(e)) {
								if ("object" === p(t) && t.constructor !== g) return e == t;
								e = g.__toPrimitive(e);
							} else return e == t;
						}
					}
				},
				{
					key: "NE",
					value: function i(e, t) {
						return !g.EQ(e, t);
					}
				},
				{
					key: "DataViewGetBigInt64",
					value: function i(e, t) {
						var _ = !!(2 < arguments.length && void 0 !== arguments[2]) && arguments[2];
						return g.asIntN(64, g.DataViewGetBigUint64(e, t, _));
					}
				},
				{
					key: "DataViewGetBigUint64",
					value: function i(e, t) {
						var _ = !!(2 < arguments.length && void 0 !== arguments[2]) && arguments[2], o = f(_ ? [4, 0] : [0, 4], 2), a = o[0], s = o[1], l = e.getUint32(t + a, _), u = e.getUint32(t + s, _), r = new g(3, !1);
						return r.__setDigit(0, 1073741823 & u), r.__setDigit(1, (268435455 & l) << 2 | u >>> 30), r.__setDigit(2, l >>> 28), r.__trim();
					}
				},
				{
					key: "DataViewSetBigInt64",
					value: function _(e, t, i) {
						var n = !!(3 < arguments.length && void 0 !== arguments[3]) && arguments[3];
						g.DataViewSetBigUint64(e, t, i, n);
					}
				},
				{
					key: "DataViewSetBigUint64",
					value: function _(e, t, i) {
						var n = !!(3 < arguments.length && void 0 !== arguments[3]) && arguments[3];
						i = g.asUintN(64, i);
						var o = 0, a = 0;
						if (0 < i.length && (a = i.__digit(0), 1 < i.length)) {
							var s = i.__digit(1);
							a |= s << 30, o = s >>> 2, 2 < i.length && (o |= i.__digit(2) << 28);
						}
						var r = f(n ? [4, 0] : [0, 4], 2), d = r[0], h = r[1];
						e.setUint32(t + d, o, n), e.setUint32(t + h, a, n);
					}
				},
				{
					key: "__zero",
					value: function e() {
						return new g(0, !1);
					}
				},
				{
					key: "__oneDigit",
					value: function i(e, t) {
						var _ = new g(1, t);
						return _.__setDigit(0, e), _;
					}
				},
				{
					key: "__decideRounding",
					value: function n(e, t, i, _) {
						if (0 < t) return -1;
						var o;
						if (0 > t) o = -t - 1;
						else {
							if (0 === i) return -1;
							i--, _ = e.__digit(i), o = 29;
						}
						var l = 1 << o;
						if (0 == (_ & l)) return -1;
						if (l -= 1, 0 != (_ & l)) return 1;
						for (; 0 < i;) if (i--, 0 !== e.__digit(i)) return 1;
						return 0;
					}
				},
				{
					key: "__fromDouble",
					value: function t(e) {
						var i = 0 > e;
						g.__kBitConversionDouble[0] = e;
						var _, o = (2047 & g.__kBitConversionInts[g.__kBitConversionIntHigh] >>> 20) - 1023, l = (0 | o / 30) + 1, a = new g(l, i), u = 1048575 & g.__kBitConversionInts[g.__kBitConversionIntHigh] | 1048576, r = g.__kBitConversionInts[g.__kBitConversionIntLow], d = 20, h = o % 30, b = 0;
						if (h < d) {
							var m = d - h;
							b = m + 32, _ = u >>> m, u = u << 32 - m | r >>> m, r <<= 32 - m;
						} else if (h === d) b = 32, _ = u, u = r, r = 0;
						else {
							var c = h - d;
							b = 32 - c, _ = u << c | r >>> 32 - c, u = r << c, r = 0;
						}
						a.__setDigit(l - 1, _);
						for (var v = l - 2; 0 <= v; v--) 0 < b ? (b -= 30, _ = u >>> 2, u = u << 30 | r >>> 2, r <<= 30) : _ = 0, a.__setDigit(v, _);
						return a.__trim();
					}
				},
				{
					key: "__isWhitespace",
					value: function t(e) {
						return !!(13 >= e && 9 <= e) || (159 >= e ? 32 == e : 131071 >= e ? 160 == e || 5760 == e : 196607 >= e ? (e &= 131071, 10 >= e || 40 == e || 41 == e || 47 == e || 95 == e || 4096 == e) : 65279 == e);
					}
				},
				{
					key: "__fromString",
					value: function t(e) {
						var i = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 0, _ = 0, n = e.length, o = 0;
						if (o === n) return g.__zero();
						for (var l = e.charCodeAt(o); g.__isWhitespace(l);) {
							if (++o === n) return g.__zero();
							l = e.charCodeAt(o);
						}
						if (43 === l) {
							if (++o === n) return null;
							l = e.charCodeAt(o), _ = 1;
						} else if (45 === l) {
							if (++o === n) return null;
							l = e.charCodeAt(o), _ = -1;
						}
						if (0 === i) {
							if (i = 10, 48 === l) {
								if (++o === n) return g.__zero();
								if (l = e.charCodeAt(o), 88 === l || 120 === l) {
									if (i = 16, ++o === n) return null;
									l = e.charCodeAt(o);
								} else if (79 === l || 111 === l) {
									if (i = 8, ++o === n) return null;
									l = e.charCodeAt(o);
								} else if (66 === l || 98 === l) {
									if (i = 2, ++o === n) return null;
									l = e.charCodeAt(o);
								}
							}
						} else if (16 === i && 48 === l) {
							if (++o === n) return g.__zero();
							if (l = e.charCodeAt(o), 88 === l || 120 === l) {
								if (++o === n) return null;
								l = e.charCodeAt(o);
							}
						}
						if (0 !== _ && 10 !== i) return null;
						for (; 48 === l;) {
							if (++o === n) return g.__zero();
							l = e.charCodeAt(o);
						}
						var a = n - o, s = g.__kMaxBitsPerChar[i], u = g.__kBitsPerCharTableMultiplier - 1;
						if (a > 1073741824 / s) return null;
						var b = new g(0 | ((s * a + u >>> g.__kBitsPerCharTableShift) + 29) / 30, !1), c = 10 > i ? i : 10, v = 10 < i ? i - 10 : 0;
						if (0 == (i & i - 1)) {
							s >>= g.__kBitsPerCharTableShift;
							var y = [], f = [], k = !1;
							do {
								for (var D, p = 0, B = 0;;) {
									if (D = void 0, l - 48 >>> 0 < c) D = l - 48;
									else if ((32 | l) - 97 >>> 0 < v) D = (32 | l) - 87;
									else {
										k = !0;
										break;
									}
									if (B += s, p = p << s | D, ++o === n) {
										k = !0;
										break;
									}
									if (l = e.charCodeAt(o), 30 < B + s) break;
								}
								y.push(p), f.push(B);
							} while (!k);
							g.__fillFromParts(b, y, f);
						} else {
							b.__initializeDigits();
							var S = !1, C = 0;
							do {
								for (var I, A = 0, T = 1;;) {
									if (I = void 0, l - 48 >>> 0 < c) I = l - 48;
									else if ((32 | l) - 97 >>> 0 < v) I = (32 | l) - 87;
									else {
										S = !0;
										break;
									}
									var P = T * i;
									if (1073741823 < P) break;
									if (T = P, A = A * i + I, C++, ++o === n) {
										S = !0;
										break;
									}
									l = e.charCodeAt(o);
								}
								u = 30 * g.__kBitsPerCharTableMultiplier - 1;
								var O = 0 | (s * C + u >>> g.__kBitsPerCharTableShift) / 30;
								b.__inplaceMultiplyAdd(T, A, O);
							} while (!S);
						}
						if (o !== n) {
							if (!g.__isWhitespace(l)) return null;
							for (o++; o < n; o++) if (l = e.charCodeAt(o), !g.__isWhitespace(l)) return null;
						}
						return b.sign = -1 === _, b.__trim();
					}
				},
				{
					key: "__fillFromParts",
					value: function n(e, t, _) {
						for (var o = 0, l = 0, g = 0, a = t.length - 1; 0 <= a; a--) {
							var s = t[a], u = _[a];
							l |= s << g, g += u, 30 === g ? (e.__setDigit(o++, l), g = 0, l = 0) : 30 < g && (e.__setDigit(o++, 1073741823 & l), g -= 30, l = s >>> u - g);
						}
						if (0 !== l) {
							if (o >= e.length) throw new Error("implementation bug");
							e.__setDigit(o++, l);
						}
						for (; o < e.length; o++) e.__setDigit(o, 0);
					}
				},
				{
					key: "__toStringBasePowerOfTwo",
					value: function _(e, t) {
						var n = e.length, o = t - 1;
						o = (85 & o >>> 1) + (85 & o), o = (51 & o >>> 2) + (51 & o), o = (15 & o >>> 4) + (15 & o);
						var l = o, a = t - 1, s = e.__digit(n - 1), u = g.__clz30(s), d = 0 | (30 * n - u + l - 1) / l;
						if (e.sign && d++, 268435456 < d) throw new Error("string too long");
						for (var h = Array(d), b = d - 1, m = 0, c = 0, v = 0; v < n - 1; v++) {
							var y = e.__digit(v), f = (m | y << c) & a;
							h[b--] = g.__kConversionChars[f];
							var k = l - c;
							for (m = y >>> k, c = 30 - k; c >= l;) h[b--] = g.__kConversionChars[m & a], m >>>= l, c -= l;
						}
						var D = (m | s << c) & a;
						for (h[b--] = g.__kConversionChars[D], m = s >>> l - c; 0 !== m;) h[b--] = g.__kConversionChars[m & a], m >>>= l;
						if (e.sign && (h[b--] = "-"), -1 !== b) throw new Error("implementation bug");
						return h.join("");
					}
				},
				{
					key: "__toStringGeneric",
					value: function n(e, t, _) {
						var o = e.length;
						if (0 === o) return "";
						if (1 === o) {
							var l = e.__unsignedDigit(0).toString(t);
							return !1 === _ && e.sign && (l = "-" + l), l;
						}
						var a = 30 * o - g.__clz30(e.__digit(o - 1)), u = g.__kMaxBitsPerChar[t] - 1, r = a * g.__kBitsPerCharTableMultiplier;
						r += u - 1, r = 0 | r / u;
						var d, h, b = r + 1 >> 1, m = g.exponentiate(g.__oneDigit(t, !1), g.__oneDigit(b, !1)), c = m.__unsignedDigit(0);
						if (1 === m.length && 32767 >= c) {
							d = new g(e.length, !1), d.__initializeDigits();
							for (var v, y = 0, f = 2 * e.length - 1; 0 <= f; f--) v = y << 15 | e.__halfDigit(f), d.__setHalfDigit(f, 0 | v / c), y = 0 | v % c;
							h = y.toString(t);
						} else {
							var k = g.__absoluteDivLarge(e, m, !0, !0);
							d = k.quotient;
							var D = k.remainder.__trim();
							h = g.__toStringGeneric(D, t, !0);
						}
						d.__trim();
						for (var p = g.__toStringGeneric(d, t, !0); h.length < b;) h = "0" + h;
						return !1 === _ && e.sign && (p = "-" + p), p + h;
					}
				},
				{
					key: "__unequalSign",
					value: function t(e) {
						return e ? -1 : 1;
					}
				},
				{
					key: "__absoluteGreater",
					value: function t(e) {
						return e ? -1 : 1;
					}
				},
				{
					key: "__absoluteLess",
					value: function t(e) {
						return e ? 1 : -1;
					}
				},
				{
					key: "__compareToBigInt",
					value: function i(e, t) {
						var _ = e.sign;
						if (_ !== t.sign) return g.__unequalSign(_);
						var n = g.__absoluteCompare(e, t);
						return 0 < n ? g.__absoluteGreater(_) : 0 > n ? g.__absoluteLess(_) : 0;
					}
				},
				{
					key: "__compareToNumber",
					value: function _(e, i) {
						if (g.__isOneDigitInt(i)) {
							var n = e.sign, o = 0 > i;
							if (n !== o) return g.__unequalSign(n);
							if (0 === e.length) {
								if (o) throw new Error("implementation bug");
								return 0 === i ? 0 : -1;
							}
							if (1 < e.length) return g.__absoluteGreater(n);
							var l = t(i), a = e.__unsignedDigit(0);
							return a > l ? g.__absoluteGreater(n) : a < l ? g.__absoluteLess(n) : 0;
						}
						return g.__compareToDouble(e, i);
					}
				},
				{
					key: "__compareToDouble",
					value: function i(e, t) {
						if (t !== t) return t;
						if (t === Infinity) return -1;
						if (t === -Infinity) return 1;
						var _ = e.sign;
						if (_ !== 0 > t) return g.__unequalSign(_);
						if (0 === t) throw new Error("implementation bug: should be handled elsewhere");
						if (0 === e.length) return -1;
						g.__kBitConversionDouble[0] = t;
						var o = 2047 & g.__kBitConversionInts[g.__kBitConversionIntHigh] >>> 20;
						if (2047 == o) throw new Error("implementation bug: handled elsewhere");
						var l = o - 1023;
						if (0 > l) return g.__absoluteGreater(_);
						var a = e.length, s = e.__digit(a - 1), u = g.__clz30(s), r = 30 * a - u, d = l + 1;
						if (r < d) return g.__absoluteLess(_);
						if (r > d) return g.__absoluteGreater(_);
						var b = 1048576 | 1048575 & g.__kBitConversionInts[g.__kBitConversionIntHigh], m = g.__kBitConversionInts[g.__kBitConversionIntLow], c = 20, v = 29 - u;
						if (v !== (0 | (r - 1) % 30)) throw new Error("implementation bug");
						var y, f = 0;
						if (v < c) {
							var k = c - v;
							f = k + 32, y = b >>> k, b = b << 32 - k | m >>> k, m <<= 32 - k;
						} else if (v === c) f = 32, y = b, b = m, m = 0;
						else {
							var D = v - c;
							f = 32 - D, y = b << D | m >>> 32 - D, b = m << D, m = 0;
						}
						if (s >>>= 0, y >>>= 0, s > y) return g.__absoluteGreater(_);
						if (s < y) return g.__absoluteLess(_);
						for (var p = a - 2; 0 <= p; p--) {
							0 < f ? (f -= 30, y = b >>> 2, b = b << 30 | m >>> 2, m <<= 30) : y = 0;
							var B = e.__unsignedDigit(p);
							if (B > y) return g.__absoluteGreater(_);
							if (B < y) return g.__absoluteLess(_);
						}
						if (0 !== b || 0 !== m) {
							if (0 === f) throw new Error("implementation bug");
							return g.__absoluteLess(_);
						}
						return 0;
					}
				},
				{
					key: "__equalToNumber",
					value: function _(e, i) {
						return g.__isOneDigitInt(i) ? 0 === i ? 0 === e.length : 1 === e.length && e.sign === 0 > i && e.__unsignedDigit(0) === t(i) : 0 === g.__compareToDouble(e, i);
					}
				},
				{
					key: "__comparisonResultToBool",
					value: function i(e, t) {
						return 0 === t ? 0 > e : 1 === t ? 0 >= e : 2 === t ? 0 < e : 3 === t ? 0 <= e : void 0;
					}
				},
				{
					key: "__compare",
					value: function _(e, t, i) {
						if (e = g.__toPrimitive(e), t = g.__toPrimitive(t), "string" == typeof e && "string" == typeof t) switch (i) {
							case 0: return e < t;
							case 1: return e <= t;
							case 2: return e > t;
							case 3: return e >= t;
						}
						if (g.__isBigInt(e) && "string" == typeof t) return t = g.__fromString(t), null !== t && g.__comparisonResultToBool(g.__compareToBigInt(e, t), i);
						if ("string" == typeof e && g.__isBigInt(t)) return e = g.__fromString(e), null !== e && g.__comparisonResultToBool(g.__compareToBigInt(e, t), i);
						if (e = g.__toNumeric(e), t = g.__toNumeric(t), g.__isBigInt(e)) {
							if (g.__isBigInt(t)) return g.__comparisonResultToBool(g.__compareToBigInt(e, t), i);
							if ("number" != typeof t) throw new Error("implementation bug");
							return g.__comparisonResultToBool(g.__compareToNumber(e, t), i);
						}
						if ("number" != typeof e) throw new Error("implementation bug");
						if (g.__isBigInt(t)) return g.__comparisonResultToBool(g.__compareToNumber(t, e), 2 ^ i);
						if ("number" != typeof t) throw new Error("implementation bug");
						return 0 === i ? e < t : 1 === i ? e <= t : 2 === i ? e > t : 3 === i ? e >= t : void 0;
					}
				},
				{
					key: "__absoluteAdd",
					value: function n(e, t, _) {
						if (e.length < t.length) return g.__absoluteAdd(t, e, _);
						if (0 === e.length) return e;
						if (0 === t.length) return e.sign === _ ? e : g.unaryMinus(e);
						var o = e.length;
						(0 === e.__clzmsd() || t.length === e.length && 0 === t.__clzmsd()) && o++;
						for (var l, a = new g(o, _), s = 0, u = 0; u < t.length; u++) l = e.__digit(u) + t.__digit(u) + s, s = l >>> 30, a.__setDigit(u, 1073741823 & l);
						for (; u < e.length; u++) {
							var d = e.__digit(u) + s;
							s = d >>> 30, a.__setDigit(u, 1073741823 & d);
						}
						return u < a.length && a.__setDigit(u, s), a.__trim();
					}
				},
				{
					key: "__absoluteSub",
					value: function n(e, t, _) {
						if (0 === e.length) return e;
						if (0 === t.length) return e.sign === _ ? e : g.unaryMinus(e);
						for (var o, l = new g(e.length, _), a = 0, s = 0; s < t.length; s++) o = e.__digit(s) - t.__digit(s) - a, a = 1 & o >>> 30, l.__setDigit(s, 1073741823 & o);
						for (; s < e.length; s++) {
							var u = e.__digit(s) - a;
							a = 1 & u >>> 30, l.__setDigit(s, 1073741823 & u);
						}
						return l.__trim();
					}
				},
				{
					key: "__absoluteAddOne",
					value: function _(e, t) {
						var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, o = e.length;
						null === n ? n = new g(o, t) : n.sign = t;
						for (var l, a = 1, s = 0; s < o; s++) l = e.__digit(s) + a, a = l >>> 30, n.__setDigit(s, 1073741823 & l);
						return 0 !== a && n.__setDigitGrow(o, 1), n;
					}
				},
				{
					key: "__absoluteSubOne",
					value: function _(e, t) {
						var n = e.length;
						t = t || n;
						for (var o, l = new g(t, !1), a = 1, s = 0; s < n; s++) o = e.__digit(s) - a, a = 1 & o >>> 30, l.__setDigit(s, 1073741823 & o);
						if (0 !== a) throw new Error("implementation bug");
						for (var u = n; u < t; u++) l.__setDigit(u, 0);
						return l;
					}
				},
				{
					key: "__absoluteAnd",
					value: function _(e, t) {
						var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, o = e.length, l = t.length, a = l;
						if (o < l) {
							a = o;
							var s = e, u = o;
							e = t, o = l, t = s, l = u;
						}
						var r = a;
						null === n ? n = new g(r, !1) : r = n.length;
						for (var d = 0; d < a; d++) n.__setDigit(d, e.__digit(d) & t.__digit(d));
						for (; d < r; d++) n.__setDigit(d, 0);
						return n;
					}
				},
				{
					key: "__absoluteAndNot",
					value: function _(e, t) {
						var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, o = e.length, l = t.length, a = l;
						o < l && (a = o);
						var s = o;
						null === n ? n = new g(s, !1) : s = n.length;
						for (var u = 0; u < a; u++) n.__setDigit(u, e.__digit(u) & ~t.__digit(u));
						for (; u < o; u++) n.__setDigit(u, e.__digit(u));
						for (; u < s; u++) n.__setDigit(u, 0);
						return n;
					}
				},
				{
					key: "__absoluteOr",
					value: function _(e, t) {
						var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, o = e.length, l = t.length, a = l;
						if (o < l) {
							a = o;
							var s = e, u = o;
							e = t, o = l, t = s, l = u;
						}
						var r = o;
						null === n ? n = new g(r, !1) : r = n.length;
						for (var d = 0; d < a; d++) n.__setDigit(d, e.__digit(d) | t.__digit(d));
						for (; d < o; d++) n.__setDigit(d, e.__digit(d));
						for (; d < r; d++) n.__setDigit(d, 0);
						return n;
					}
				},
				{
					key: "__absoluteXor",
					value: function _(e, t) {
						var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null, o = e.length, l = t.length, a = l;
						if (o < l) {
							a = o;
							var s = e, u = o;
							e = t, o = l, t = s, l = u;
						}
						var r = o;
						null === n ? n = new g(r, !1) : r = n.length;
						for (var d = 0; d < a; d++) n.__setDigit(d, e.__digit(d) ^ t.__digit(d));
						for (; d < o; d++) n.__setDigit(d, e.__digit(d));
						for (; d < r; d++) n.__setDigit(d, 0);
						return n;
					}
				},
				{
					key: "__absoluteCompare",
					value: function _(e, t) {
						var n = e.length - t.length;
						if (0 != n) return n;
						for (var o = e.length - 1; 0 <= o && e.__digit(o) === t.__digit(o);) o--;
						return 0 > o ? 0 : e.__unsignedDigit(o) > t.__unsignedDigit(o) ? 1 : -1;
					}
				},
				{
					key: "__multiplyAccumulate",
					value: function o(e, t, _, n) {
						if (0 !== t) {
							for (var l = 32767 & t, a = t >>> 15, s = 0, u = 0, r = 0; r < e.length; r++, n++) {
								var d = _.__digit(n), h = e.__digit(r), b = 32767 & h, m = h >>> 15, c = g.__imul(b, l), v = g.__imul(b, a), y = g.__imul(m, l), f = g.__imul(m, a);
								d += u + c + s, s = d >>> 30, d &= 1073741823, d += ((32767 & v) << 15) + ((32767 & y) << 15), s += d >>> 30, u = f + (v >>> 15) + (y >>> 15), _.__setDigit(n, 1073741823 & d);
							}
							for (; 0 !== s || 0 !== u; n++) {
								var k = _.__digit(n);
								k += s + u, u = 0, s = k >>> 30, _.__setDigit(n, 1073741823 & k);
							}
						}
					}
				},
				{
					key: "__internalMultiplyAdd",
					value: function a(e, t, _, o, l) {
						for (var s = _, u = 0, d = 0; d < o; d++) {
							var h = e.__digit(d), b = g.__imul(32767 & h, t), m = g.__imul(h >>> 15, t), c = b + ((32767 & m) << 15) + u + s;
							s = c >>> 30, u = m >>> 15, l.__setDigit(d, 1073741823 & c);
						}
						if (l.length > o) for (l.__setDigit(o++, s + u); o < l.length;) l.__setDigit(o++, 0);
						else if (0 !== s + u) throw new Error("implementation bug");
					}
				},
				{
					key: "__absoluteDivSmall",
					value: function _(e, t) {
						var n = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
						null === n && (n = new g(e.length, !1));
						for (var o = 0, l = 2 * e.length - 1; 0 <= l; l -= 2) {
							var a = (o << 15 | e.__halfDigit(l)) >>> 0, s = 0 | a / t;
							o = 0 | a % t, a = (o << 15 | e.__halfDigit(l - 1)) >>> 0;
							var u = 0 | a / t;
							o = 0 | a % t, n.__setDigit(l >>> 1, s << 15 | u);
						}
						return n;
					}
				},
				{
					key: "__absoluteModSmall",
					value: function _(e, t) {
						for (var n, o = 0, l = 2 * e.length - 1; 0 <= l; l--) n = (o << 15 | e.__halfDigit(l)) >>> 0, o = 0 | n % t;
						return o;
					}
				},
				{
					key: "__absoluteDivLarge",
					value: function o(e, t, i, _) {
						var l = t.__halfDigitLength(), n = t.length, a = e.__halfDigitLength() - l, s = null;
						i && (s = new g(a + 2 >>> 1, !1), s.__initializeDigits());
						var r = new g(l + 2 >>> 1, !1);
						r.__initializeDigits();
						var d = g.__clz15(t.__halfDigit(l - 1));
						0 < d && (t = g.__specialLeftShift(t, d, 0));
						for (var h = g.__specialLeftShift(e, d, 1), u = t.__halfDigit(l - 1), b = 0, m = a; 0 <= m; m--) {
							var v = 32767, y = h.__halfDigit(m + l);
							if (y !== u) {
								var f = (y << 15 | h.__halfDigit(m + l - 1)) >>> 0;
								v = 0 | f / u;
								for (var k = 0 | f % u, D = t.__halfDigit(l - 2), p = h.__halfDigit(m + l - 2); g.__imul(v, D) >>> 0 > (k << 16 | p) >>> 0 && (v--, k += u, !(32767 < k)););
							}
							g.__internalMultiplyAdd(t, v, 0, n, r);
							var B = h.__inplaceSub(r, m, l + 1);
							0 !== B && (B = h.__inplaceAdd(t, m, l), h.__setHalfDigit(m + l, 32767 & h.__halfDigit(m + l) + B), v--), i && (1 & m ? b = v << 15 : s.__setDigit(m >>> 1, b | v));
						}
						if (_) return h.__inplaceRightShift(d), i ? {
							quotient: s,
							remainder: h
						} : h;
						if (i) return s;
						throw new Error("unreachable");
					}
				},
				{
					key: "__clz15",
					value: function t(e) {
						return g.__clz30(e) - 15;
					}
				},
				{
					key: "__specialLeftShift",
					value: function o(e, t, _) {
						var l = e.length, a = new g(l + _, !1);
						if (0 === t) {
							for (var s = 0; s < l; s++) a.__setDigit(s, e.__digit(s));
							return 0 < _ && a.__setDigit(l, 0), a;
						}
						for (var u, r = 0, h = 0; h < l; h++) u = e.__digit(h), a.__setDigit(h, 1073741823 & u << t | r), r = u >>> 30 - t;
						return 0 < _ && a.__setDigit(l, r), a;
					}
				},
				{
					key: "__leftShiftByAbsolute",
					value: function _(e, t) {
						var n = g.__toShiftAmount(t);
						if (0 > n) throw new RangeError("BigInt too big");
						var o = 0 | n / 30, l = n % 30, a = e.length, s = 0 !== l && 0 != e.__digit(a - 1) >>> 30 - l, u = a + o + (s ? 1 : 0), r = new g(u, e.sign);
						if (0 === l) {
							for (var h = 0; h < o; h++) r.__setDigit(h, 0);
							for (; h < u; h++) r.__setDigit(h, e.__digit(h - o));
						} else {
							for (var b = 0, m = 0; m < o; m++) r.__setDigit(m, 0);
							for (var c, v = 0; v < a; v++) c = e.__digit(v), r.__setDigit(v + o, 1073741823 & c << l | b), b = c >>> 30 - l;
							if (s) r.__setDigit(a + o, b);
							else if (0 !== b) throw new Error("implementation bug");
						}
						return r.__trim();
					}
				},
				{
					key: "__rightShiftByAbsolute",
					value: function _(e, t) {
						var n = e.length, o = e.sign, l = g.__toShiftAmount(t);
						if (0 > l) return g.__rightShiftByMaximum(o);
						var a = 0 | l / 30, s = l % 30, u = n - a;
						if (0 >= u) return g.__rightShiftByMaximum(o);
						var r = !1;
						if (o) {
							var h = (1 << s) - 1;
							if (0 != (e.__digit(a) & h)) r = !0;
							else for (var b = 0; b < a; b++) if (0 !== e.__digit(b)) {
								r = !0;
								break;
							}
						}
						if (r && 0 === s) 0 == ~e.__digit(n - 1) && u++;
						var v = new g(u, o);
						if (0 === s) {
							v.__setDigit(u - 1, 0);
							for (var y = a; y < n; y++) v.__setDigit(y - a, e.__digit(y));
						} else {
							for (var f, k = e.__digit(a) >>> s, D = n - a - 1, p = 0; p < D; p++) f = e.__digit(p + a + 1), v.__setDigit(p, 1073741823 & f << 30 - s | k), k = f >>> s;
							v.__setDigit(D, k);
						}
						return r && (v = g.__absoluteAddOne(v, !0, v)), v.__trim();
					}
				},
				{
					key: "__rightShiftByMaximum",
					value: function t(e) {
						return e ? g.__oneDigit(1, !0) : g.__zero();
					}
				},
				{
					key: "__toShiftAmount",
					value: function t(e) {
						if (1 < e.length) return -1;
						var i = e.__unsignedDigit(0);
						return i > g.__kMaxLengthBits ? -1 : i;
					}
				},
				{
					key: "__toPrimitive",
					value: function t(e) {
						var i = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "default";
						if ("object" !== p(e)) return e;
						if (e.constructor === g) return e;
						if ("undefined" != typeof Symbol && "symbol" === p(Symbol.toPrimitive) && e[Symbol.toPrimitive]) {
							var _ = e[Symbol.toPrimitive](i);
							if ("object" !== p(_)) return _;
							throw new TypeError("Cannot convert object to primitive value");
						}
						var n = e.valueOf;
						if (n) {
							var o = n.call(e);
							if ("object" !== p(o)) return o;
						}
						var l = e.toString;
						if (l) {
							var a = l.call(e);
							if ("object" !== p(a)) return a;
						}
						throw new TypeError("Cannot convert object to primitive value");
					}
				},
				{
					key: "__toNumeric",
					value: function t(e) {
						return g.__isBigInt(e) ? e : +e;
					}
				},
				{
					key: "__isBigInt",
					value: function t(e) {
						return "object" === p(e) && null !== e && e.constructor === g;
					}
				},
				{
					key: "__truncateToNBits",
					value: function _(e, t) {
						for (var n = 0 | (e + 29) / 30, o = new g(n, t.sign), l = n - 1, a = 0; a < l; a++) o.__setDigit(a, t.__digit(a));
						var s = t.__digit(l);
						if (0 != e % 30) {
							var u = 32 - e % 30;
							s = s << u >>> u;
						}
						return o.__setDigit(l, s), o.__trim();
					}
				},
				{
					key: "__truncateAndSubFromPowerOfTwo",
					value: function n(e, t, _) {
						for (var o = Math.min, l, a = 0 | (e + 29) / 30, s = new g(a, _), u = 0, d = a - 1, h = 0, b = o(d, t.length); u < b; u++) l = 0 - t.__digit(u) - h, h = 1 & l >>> 30, s.__setDigit(u, 1073741823 & l);
						for (; u < d; u++) s.__setDigit(u, 0 | 1073741823 & -h);
						var m, c = d < t.length ? t.__digit(d) : 0, v = e % 30;
						if (0 === v) m = 0 - c - h, m &= 1073741823;
						else {
							var y = 32 - v;
							c = c << y >>> y;
							var f = 1 << 32 - y;
							m = f - c - h, m &= f - 1;
						}
						return s.__setDigit(d, m), s.__trim();
					}
				},
				{
					key: "__digitPow",
					value: function i(e, t) {
						for (var _ = 1; 0 < t;) 1 & t && (_ *= e), t >>>= 1, e *= e;
						return _;
					}
				},
				{
					key: "__detectBigEndian",
					value: function e() {
						return g.__kBitConversionDouble[0] = -0, 0 !== g.__kBitConversionInts[0];
					}
				},
				{
					key: "__isOneDigitInt",
					value: function t(e) {
						return (1073741823 & e) === e;
					}
				}
			]);
		}(S(Array));
		return C.__kMaxLength = 33554432, C.__kMaxLengthBits = C.__kMaxLength << 5, C.__kMaxBitsPerChar = [
			0,
			0,
			32,
			51,
			64,
			75,
			83,
			90,
			96,
			102,
			107,
			111,
			115,
			119,
			122,
			126,
			128,
			131,
			134,
			136,
			139,
			141,
			143,
			145,
			147,
			149,
			151,
			153,
			154,
			156,
			158,
			159,
			160,
			162,
			163,
			165,
			166
		], C.__kBitsPerCharTableShift = 5, C.__kBitsPerCharTableMultiplier = 1 << C.__kBitsPerCharTableShift, C.__kConversionChars = [
			"0",
			"1",
			"2",
			"3",
			"4",
			"5",
			"6",
			"7",
			"8",
			"9",
			"a",
			"b",
			"c",
			"d",
			"e",
			"f",
			"g",
			"h",
			"i",
			"j",
			"k",
			"l",
			"m",
			"n",
			"o",
			"p",
			"q",
			"r",
			"s",
			"t",
			"u",
			"v",
			"w",
			"x",
			"y",
			"z"
		], C.__kBitConversionBuffer = /* @__PURE__ */ new ArrayBuffer(8), C.__kBitConversionDouble = new Float64Array(C.__kBitConversionBuffer), C.__kBitConversionInts = new Int32Array(C.__kBitConversionBuffer), C.__kBitConversionIntHigh = C.__detectBigEndian() ? 0 : 1, C.__kBitConversionIntLow = C.__detectBigEndian() ? 1 : 0, C.__clz30 = t ? function(e) {
			return t(e) - 2;
		} : function(e) {
			var t = Math.LN2, i = Math.log;
			return 0 === e ? 30 : 0 | 29 - (0 | i(e >>> 0) / t);
		}, C.__imul = e || function(e, t) {
			return 0 | e * t;
		}, C;
	});
})))(), 1);
const t = import_jsbi_umd.default.BigInt(0), n = import_jsbi_umd.default.BigInt(1), r = import_jsbi_umd.default.BigInt(2), o = import_jsbi_umd.default.BigInt(10), i = import_jsbi_umd.default.BigInt(24), a = import_jsbi_umd.default.BigInt(60), s = import_jsbi_umd.default.BigInt(1e3), c = import_jsbi_umd.default.BigInt(1e6), d = import_jsbi_umd.default.BigInt(1e9), h = import_jsbi_umd.default.multiply(import_jsbi_umd.default.BigInt(3600), d), u = import_jsbi_umd.default.multiply(a, d), l = import_jsbi_umd.default.multiply(h, i);
function m(t) {
	return "bigint" == typeof t ? import_jsbi_umd.default.BigInt(t.toString(10)) : t;
}
function f(n) {
	return import_jsbi_umd.default.equal(import_jsbi_umd.default.remainder(n, r), t);
}
function y(n) {
	return import_jsbi_umd.default.lessThan(n, t) ? import_jsbi_umd.default.unaryMinus(n) : n;
}
function p(t, n) {
	return import_jsbi_umd.default.lessThan(t, n) ? -1 : import_jsbi_umd.default.greaterThan(t, n) ? 1 : 0;
}
function g(t, n) {
	return {
		quotient: import_jsbi_umd.default.divide(t, n),
		remainder: import_jsbi_umd.default.remainder(t, n)
	};
}
var w, v;
const b = "slot-epochNanoSeconds", D = "slot-iso-date", T = "slot-iso-date-time", M = "slot-time", E = "slot-calendar", I = "slot-date-brand", C = "slot-year-month-brand", O = "slot-month-day-brand", $ = "slot-time-zone", Y = "slot-years", R = "slot-months", S = "slot-weeks", j = "slot-days", k = "slot-hours", N = "slot-minutes", x = "slot-seconds", L = "slot-milliseconds", P = "slot-microseconds", U = "slot-nanoseconds", B = "date", Z = "ym", F = "md", H = "time", z = "datetime", A = "instant", q = "original", W = "timezone-canonical", _ = "timezone-original", J = "calendar-id", G = "locale", K = "options", V = /* @__PURE__ */ new WeakMap(), X = Symbol.for("@@Temporal__GetSlots");
(w = globalThis)[X] || (w[X] = function(e) {
	return V.get(e);
});
const Q = globalThis[X], ee = Symbol.for("@@Temporal__CreateSlots");
(v = globalThis)[ee] || (v[ee] = function(e) {
	V.set(e, Object.create(null));
});
const te = globalThis[ee];
function ne(e, ...t) {
	if (!e || "object" != typeof e) return !1;
	const n = Q(e);
	return !!n && t.every(((e) => e in n));
}
function re(e, t) {
	const n = Q(e)?.[t];
	if (void 0 === n) throw new TypeError(`Missing internal slot ${t}`);
	return n;
}
function oe(e, t, n) {
	const r = Q(e);
	if (void 0 === r) throw new TypeError("Missing slots for the given container");
	if (r[t]) throw new TypeError(`${t} already has set`);
	r[t] = n;
}
const ie = {};
function ae(e, t) {
	Object.defineProperty(e.prototype, Symbol.toStringTag, {
		value: t,
		writable: !1,
		enumerable: !1,
		configurable: !0
	});
	const n = Object.getOwnPropertyNames(e);
	for (let t = 0; t < n.length; t++) {
		const r = n[t], o = Object.getOwnPropertyDescriptor(e, r);
		o.configurable && o.enumerable && (o.enumerable = !1, Object.defineProperty(e, r, o));
	}
	const r = Object.getOwnPropertyNames(e.prototype);
	for (let t = 0; t < r.length; t++) {
		const n = r[t], o = Object.getOwnPropertyDescriptor(e.prototype, n);
		o.configurable && o.enumerable && (o.enumerable = !1, Object.defineProperty(e.prototype, n, o));
	}
	se(t, e), se(`${t}.prototype`, e.prototype);
}
function se(e, t) {
	const n = `%${e}%`;
	if (void 0 !== ie[n]) throw new Error(`intrinsic ${e} already exists`);
	ie[n] = t;
}
function ce(e) {
	return ie[e];
}
function de(e, t) {
	let n = e;
	if (0 === n) return {
		div: n,
		mod: n
	};
	const r = Math.sign(n);
	n = Math.abs(n);
	const o = Math.trunc(1 + Math.log10(n));
	if (t >= o) return {
		div: 0 * r,
		mod: r * n
	};
	if (0 === t) return {
		div: r * n,
		mod: 0 * r
	};
	const i = n.toPrecision(o);
	return {
		div: r * Number.parseInt(i.slice(0, o - t), 10),
		mod: r * Number.parseInt(i.slice(o - t), 10)
	};
}
function he(e, t, n) {
	let r = e, o = n;
	if (0 === r) return o;
	const i = Math.sign(r) || Math.sign(o);
	r = Math.abs(r), o = Math.abs(o);
	const a = r.toPrecision(Math.trunc(1 + Math.log10(r)));
	if (0 === o) return i * Number.parseInt(a + "0".repeat(t), 10);
	const s = a + o.toPrecision(Math.trunc(1 + Math.log10(o))).padStart(t, "0");
	return i * Number.parseInt(s, 10);
}
function ue(e, t) {
	const n = "negative" === t;
	switch (e) {
		case "ceil": return n ? "zero" : "infinity";
		case "floor": return n ? "infinity" : "zero";
		case "expand": return "infinity";
		case "trunc": return "zero";
		case "halfCeil": return n ? "half-zero" : "half-infinity";
		case "halfFloor": return n ? "half-infinity" : "half-zero";
		case "halfExpand": return "half-infinity";
		case "halfTrunc": return "half-zero";
		case "halfEven": return "half-even";
	}
}
function le(e, t, n, r, o) {
	return "zero" === o ? e : "infinity" === o ? t : n < 0 ? e : n > 0 ? t : "half-zero" === o ? e : "half-infinity" === o ? t : r ? e : t;
}
var TimeDuration = class TimeDuration {
	constructor(t) {
		this.totalNs = m(t), this.sec = import_jsbi_umd.default.toNumber(import_jsbi_umd.default.divide(this.totalNs, d)), this.subsec = import_jsbi_umd.default.toNumber(import_jsbi_umd.default.remainder(this.totalNs, d));
	}
	static validateNew(t, n) {
		if (import_jsbi_umd.default.greaterThan(y(t), TimeDuration.MAX)) throw new RangeError(`${n} of duration time units cannot exceed ${TimeDuration.MAX} s`);
		return new TimeDuration(t);
	}
	static fromEpochNsDiff(t, n) {
		return new TimeDuration(import_jsbi_umd.default.subtract(m(t), m(n)));
	}
	static fromComponents(t, n, r, o, i, a) {
		const l = import_jsbi_umd.default.add(import_jsbi_umd.default.add(import_jsbi_umd.default.add(import_jsbi_umd.default.add(import_jsbi_umd.default.add(import_jsbi_umd.default.BigInt(a), import_jsbi_umd.default.multiply(import_jsbi_umd.default.BigInt(i), s)), import_jsbi_umd.default.multiply(import_jsbi_umd.default.BigInt(o), c)), import_jsbi_umd.default.multiply(import_jsbi_umd.default.BigInt(r), d)), import_jsbi_umd.default.multiply(import_jsbi_umd.default.BigInt(n), u)), import_jsbi_umd.default.multiply(import_jsbi_umd.default.BigInt(t), h));
		return TimeDuration.validateNew(l, "total");
	}
	abs() {
		return new TimeDuration(y(this.totalNs));
	}
	add(t) {
		return TimeDuration.validateNew(import_jsbi_umd.default.add(this.totalNs, t.totalNs), "sum");
	}
	add24HourDays(t) {
		return TimeDuration.validateNew(import_jsbi_umd.default.add(this.totalNs, import_jsbi_umd.default.multiply(import_jsbi_umd.default.BigInt(t), l)), "sum");
	}
	addToEpochNs(t) {
		return import_jsbi_umd.default.add(m(t), this.totalNs);
	}
	cmp(e) {
		return p(this.totalNs, e.totalNs);
	}
	divmod(t) {
		const { quotient: n, remainder: r } = g(this.totalNs, import_jsbi_umd.default.BigInt(t));
		return {
			quotient: import_jsbi_umd.default.toNumber(n),
			remainder: new TimeDuration(r)
		};
	}
	fdiv(n) {
		const r = m(n), i = import_jsbi_umd.default.BigInt(r);
		let { quotient: a, remainder: s } = g(this.totalNs, i);
		const c = [];
		let d;
		const h = (import_jsbi_umd.default.lessThan(this.totalNs, t) ? -1 : 1) * Math.sign(import_jsbi_umd.default.toNumber(r));
		for (; !import_jsbi_umd.default.equal(s, t) && c.length < 50;) s = import_jsbi_umd.default.multiply(s, o), {quotient: d, remainder: s} = g(s, i), c.push(Math.abs(import_jsbi_umd.default.toNumber(d)));
		return h * Number(y(a).toString() + "." + c.join(""));
	}
	isZero() {
		return import_jsbi_umd.default.equal(this.totalNs, t);
	}
	round(o, i) {
		const a = m(o);
		if (import_jsbi_umd.default.equal(a, n)) return this;
		const { quotient: s, remainder: c } = g(this.totalNs, a), d = import_jsbi_umd.default.lessThan(this.totalNs, t) ? "negative" : "positive", h = import_jsbi_umd.default.multiply(y(s), a), u = import_jsbi_umd.default.add(h, a), l = p(y(import_jsbi_umd.default.multiply(c, r)), a), w = ue(i, d), v = import_jsbi_umd.default.equal(y(this.totalNs), h) ? h : le(h, u, l, f(s), w), b = "positive" === d ? v : import_jsbi_umd.default.unaryMinus(v);
		return TimeDuration.validateNew(b, "rounding");
	}
	sign() {
		return this.cmp(new TimeDuration(t));
	}
	subtract(t) {
		return TimeDuration.validateNew(import_jsbi_umd.default.subtract(this.totalNs, t.totalNs), "difference");
	}
};
TimeDuration.MAX = import_jsbi_umd.default.BigInt("9007199254740991999999999"), TimeDuration.ZERO = new TimeDuration(t);
const me = /[A-Za-z._][A-Za-z._0-9+-]*/, fe = new RegExp(`(?:${/(?:[+-](?:[01][0-9]|2[0-3])(?::?[0-5][0-9])?)/.source}|(?:${me.source})(?:\\/(?:${me.source}))*)`), ye = /(?:[+-]\d{6}|\d{4})/, pe = /(?:0[1-9]|1[0-2])/, ge = /(?:0[1-9]|[12]\d|3[01])/, we = new RegExp(`(${ye.source})(?:-(${pe.source})-(${ge.source})|(${pe.source})(${ge.source}))`), ve = /(\d{2})(?::(\d{2})(?::(\d{2})(?:[.,](\d{1,9}))?)?|(\d{2})(?:(\d{2})(?:[.,](\d{1,9}))?)?)?/, be = /((?:[+-])(?:[01][0-9]|2[0-3])(?::?(?:[0-5][0-9])(?::?(?:[0-5][0-9])(?:[.,](?:\d{1,9}))?)?)?)/, De = new RegExp(`([zZ])|${be.source}?`), Te = /\[(!)?([a-z_][a-z0-9_-]*)=([A-Za-z0-9]+(?:-[A-Za-z0-9]+)*)\]/g, Me = new RegExp([
	`^${we.source}`,
	`(?:(?:[tT]|\\s+)${ve.source}(?:${De.source})?)?`,
	`(?:\\[!?(${fe.source})\\])?`,
	`((?:${Te.source})*)$`
].join("")), Ee = new RegExp([
	`^[tT]?${ve.source}`,
	`(?:${De.source})?`,
	`(?:\\[!?${fe.source}\\])?`,
	`((?:${Te.source})*)$`
].join("")), Ie = new RegExp(`^(${ye.source})-?(${pe.source})(?:\\[!?${fe.source}\\])?((?:${Te.source})*)$`), Ce = new RegExp(`^(?:--)?(${pe.source})-?(${ge.source})(?:\\[!?${fe.source}\\])?((?:${Te.source})*)$`), Oe = /(\d+)(?:[.,](\d{1,9}))?/, $e = new RegExp(`(?:${Oe.source}H)?(?:${Oe.source}M)?(?:${Oe.source}S)?`), Ye = new RegExp(`^([+-])?P${/(?:(\d+)Y)?(?:(\d+)M)?(?:(\d+)W)?(?:(\d+)D)?/.source}(?:T(?!$)${$e.source})?$`, "i"), Re = 864e5, Se = 1e6 * Re, je = 6e10, ke = 1e8 * Re, Ne = xo(ke), xe = import_jsbi_umd.default.unaryMinus(Ne), Le = import_jsbi_umd.default.add(import_jsbi_umd.default.subtract(xe, l), n), Pe = import_jsbi_umd.default.subtract(import_jsbi_umd.default.add(Ne, l), n), Ue = 146097 * Re, Be = -271821, Ze = 275760, Fe = Date.UTC(1847, 0, 1), He = [
	"iso8601",
	"hebrew",
	"islamic",
	"islamic-umalqura",
	"islamic-tbla",
	"islamic-civil",
	"islamic-rgsa",
	"islamicc",
	"persian",
	"ethiopic",
	"ethioaa",
	"ethiopic-amete-alem",
	"coptic",
	"chinese",
	"dangi",
	"roc",
	"indian",
	"buddhist",
	"japanese",
	"gregory"
], ze = new Set([
	"ACT",
	"AET",
	"AGT",
	"ART",
	"AST",
	"BET",
	"BST",
	"CAT",
	"CNT",
	"CST",
	"CTT",
	"EAT",
	"ECT",
	"IET",
	"IST",
	"JST",
	"MIT",
	"NET",
	"NST",
	"PLT",
	"PNT",
	"PRT",
	"PST",
	"SST",
	"VST"
]);
function Ae(e) {
	return "object" == typeof e && null !== e || "function" == typeof e;
}
function qe(e) {
	if ("bigint" == typeof e) throw new TypeError("Cannot convert BigInt to number");
	return Number(e);
}
function We(e) {
	if ("symbol" == typeof e) throw new TypeError("Cannot convert a Symbol value to a String");
	return String(e);
}
function _e(e) {
	const t = qe(e);
	if (0 === t) return 0;
	if (Number.isNaN(t) || t === Infinity || t === -Infinity) throw new RangeError("invalid number value");
	const n = Math.trunc(t);
	return 0 === n ? 0 : n;
}
function Je(e, t) {
	const n = _e(e);
	if (n <= 0) {
		if (void 0 !== t) throw new RangeError(`property '${t}' cannot be a a number less than one`);
		throw new RangeError("Cannot convert a number less than one to a positive integer");
	}
	return n;
}
function Ge(e) {
	const t = qe(e);
	if (Number.isNaN(t)) throw new RangeError("not a number");
	if (t === Infinity || t === -Infinity) throw new RangeError("infinity is out of range");
	if (!function(e) {
		if ("number" != typeof e || Number.isNaN(e) || e === Infinity || e === -Infinity) return !1;
		const t = Math.abs(e);
		return Math.floor(t) === t;
	}(t)) throw new RangeError(`unsupported fractional value ${e}`);
	return 0 === t ? 0 : t;
}
function Ke(e, t) {
	return String(e).padStart(t, "0");
}
function Ve(e) {
	if ("string" != typeof e) throw new TypeError(`expected a string, not ${String(e)}`);
	return e;
}
function Xe(e, t) {
	if (Ae(e)) {
		const t = e?.toString();
		if ("string" == typeof t || "number" == typeof t) return t;
		throw new TypeError("Cannot convert object to primitive value");
	}
	return e;
}
const Qe = [
	"era",
	"eraYear",
	"year",
	"month",
	"monthCode",
	"day",
	"hour",
	"minute",
	"second",
	"millisecond",
	"microsecond",
	"nanosecond",
	"offset",
	"timeZone"
], et = {
	era: We,
	eraYear: _e,
	year: _e,
	month: Je,
	monthCode: function(e) {
		const t = Ve(Xe(e));
		if (t.length < 3 || t.length > 4 || "M" !== t[0] || -1 === "0123456789".indexOf(t[1]) || -1 === "0123456789".indexOf(t[2]) || t[1] + t[2] === "00" && "L" !== t[3] || "L" !== t[3] && void 0 !== t[3]) throw new RangeError(`bad month code ${t}; must match M01-M99 or M00L-M99L`);
		return t;
	},
	day: Je,
	hour: _e,
	minute: _e,
	second: _e,
	millisecond: _e,
	microsecond: _e,
	nanosecond: _e,
	offset: function(e) {
		const t = Ve(Xe(e));
		return sr(t), t;
	},
	timeZone: Bn
}, tt = {
	hour: 0,
	minute: 0,
	second: 0,
	millisecond: 0,
	microsecond: 0,
	nanosecond: 0
}, nt = [
	[
		"years",
		"year",
		"date"
	],
	[
		"months",
		"month",
		"date"
	],
	[
		"weeks",
		"week",
		"date"
	],
	[
		"days",
		"day",
		"date"
	],
	[
		"hours",
		"hour",
		"time"
	],
	[
		"minutes",
		"minute",
		"time"
	],
	[
		"seconds",
		"second",
		"time"
	],
	[
		"milliseconds",
		"millisecond",
		"time"
	],
	[
		"microseconds",
		"microsecond",
		"time"
	],
	[
		"nanoseconds",
		"nanosecond",
		"time"
	]
], rt = Object.fromEntries(nt.map(((e) => [e[0], e[1]]))), ot = Object.fromEntries(nt.map((([e, t]) => [t, e]))), it = nt.map((([, e]) => e)), at = {
	day: Se,
	hour: 36e11,
	minute: 6e10,
	second: 1e9,
	millisecond: 1e6,
	microsecond: 1e3,
	nanosecond: 1
}, st = [
	"days",
	"hours",
	"microseconds",
	"milliseconds",
	"minutes",
	"months",
	"nanoseconds",
	"seconds",
	"weeks",
	"years"
], ct = Intl.DateTimeFormat, dt = /* @__PURE__ */ new Map();
function ht(e) {
	const t = Ao(e);
	let n = dt.get(t);
	return void 0 === n && (n = new ct("en-us", {
		timeZone: t,
		hour12: !1,
		era: "short",
		year: "numeric",
		month: "numeric",
		day: "numeric",
		hour: "numeric",
		minute: "numeric",
		second: "numeric"
	}), dt.set(t, n)), n;
}
function ut(e) {
	return ne(e, b) && !ne(e, $, E);
}
function lt(e) {
	return ne(e, Y, R, j, k, N, x, L, P, U);
}
function mt(e) {
	return ne(e, I);
}
function ft(e) {
	return ne(e, M);
}
function yt(e) {
	return ne(e, T);
}
function pt(e) {
	return ne(e, C);
}
function gt(e) {
	return ne(e, O);
}
function wt(e) {
	return ne(e, b, $, E);
}
function vt(e, t) {
	if (!t(e)) throw new TypeError("invalid receiver: method called with the wrong type of this-object");
}
function bt(e) {
	if (ne(e, E) || ne(e, $)) throw new TypeError("with() does not support a calendar or timeZone property");
	if (ft(e)) throw new TypeError("with() does not accept Temporal.PlainTime, use withPlainTime() instead");
	if (void 0 !== e.calendar) throw new TypeError("with() does not support a calendar property");
	if (void 0 !== e.timeZone) throw new TypeError("with() does not support a timeZone property");
}
function Dt(e, t) {
	return "never" === t || "auto" === t && "iso8601" === e ? "" : `[${"critical" === t ? "!" : ""}u-ca=${e}]`;
}
function Tt(e) {
	let t, n, r = !1;
	for (Te.lastIndex = 0; n = Te.exec(e);) {
		const { 1: o, 2: i, 3: a } = n;
		if ("u-ca" === i) {
			if (void 0 === t) t = a, r = "!" === o;
			else if ("!" === o || r) throw new RangeError(`Invalid annotations in ${e}: more than one u-ca present with critical flag`);
		} else if ("!" === o) throw new RangeError(`Unrecognized annotation: !${i}=${a}`);
	}
	return t;
}
function Mt(e) {
	const t = Me.exec(e);
	if (!t) throw new RangeError(`invalid RFC 9557 string: ${e}`);
	const n = Tt(t[16]);
	let r = t[1];
	if ("-000000" === r) throw new RangeError(`invalid RFC 9557 string: ${e}`);
	const o = +r, i = +(t[2] ?? t[4] ?? 1), a = +(t[3] ?? t[5] ?? 1), s = void 0 !== t[6], c = +(t[6] ?? 0), d = +(t[7] ?? t[10] ?? 0);
	let h = +(t[8] ?? t[11] ?? 0);
	60 === h && (h = 59);
	const u = (t[9] ?? t[12] ?? "") + "000000000", l = +u.slice(0, 3), m = +u.slice(3, 6), f = +u.slice(6, 9);
	let y, p = !1;
	t[13] ? (y = void 0, p = !0) : t[14] && (y = t[14]);
	const g = t[15];
	return Ur(o, i, a, c, d, h, l, m, f), {
		year: o,
		month: i,
		day: a,
		time: s ? {
			hour: c,
			minute: d,
			second: h,
			millisecond: l,
			microsecond: m,
			nanosecond: f
		} : "start-of-day",
		tzAnnotation: g,
		offset: y,
		z: p,
		calendar: n
	};
}
function Et(e) {
	const t = Ee.exec(e);
	let n, r, o, i, a, s, c;
	if (t) {
		c = Tt(t[10]), n = +(t[1] ?? 0), r = +(t[2] ?? t[5] ?? 0), o = +(t[3] ?? t[6] ?? 0), 60 === o && (o = 59);
		const e = (t[4] ?? t[7] ?? "") + "000000000";
		if (i = +e.slice(0, 3), a = +e.slice(3, 6), s = +e.slice(6, 9), t[8]) throw new RangeError("Z designator not supported for PlainTime");
	} else {
		let t, d;
		if ({time: t, z: d, calendar: c} = Mt(e), "start-of-day" === t) throw new RangeError(`time is missing in string: ${e}`);
		if (d) throw new RangeError("Z designator not supported for PlainTime");
		({hour: n, minute: r, second: o, millisecond: i, microsecond: a, nanosecond: s} = t);
	}
	if (Pr(n, r, o, i, a, s), /[tT ][0-9][0-9]/.test(e)) return {
		hour: n,
		minute: r,
		second: o,
		millisecond: i,
		microsecond: a,
		nanosecond: s,
		calendar: c
	};
	try {
		const { month: t, day: n } = Ct(e);
		xr(1972, t, n);
	} catch {
		try {
			const { year: t, month: n } = It(e);
			xr(t, n, 1);
		} catch {
			return {
				hour: n,
				minute: r,
				second: o,
				millisecond: i,
				microsecond: a,
				nanosecond: s,
				calendar: c
			};
		}
	}
	throw new RangeError(`invalid RFC 9557 time-only string ${e}; may need a T prefix`);
}
function It(e) {
	const t = Ie.exec(e);
	let n, r, o, i;
	if (t) {
		o = Tt(t[3]);
		let a = t[1];
		if ("-000000" === a) throw new RangeError(`invalid RFC 9557 string: ${e}`);
		if (n = +a, r = +t[2], i = 1, void 0 !== o && "iso8601" !== o) throw new RangeError("YYYY-MM format is only valid with iso8601 calendar");
	} else {
		let t;
		if ({year: n, month: r, calendar: o, day: i, z: t} = Mt(e), t) throw new RangeError("Z designator not supported for PlainYearMonth");
	}
	return {
		year: n,
		month: r,
		calendar: o,
		referenceISODay: i
	};
}
function Ct(e) {
	const t = Ce.exec(e);
	let n, r, o, i;
	if (t) {
		if (o = Tt(t[3]), n = +t[1], r = +t[2], void 0 !== o && "iso8601" !== o) throw new RangeError("MM-DD format is only valid with iso8601 calendar");
	} else {
		let t;
		if ({month: n, day: r, calendar: o, year: i, z: t} = Mt(e), t) throw new RangeError("Z designator not supported for PlainMonthDay");
	}
	return {
		month: n,
		day: r,
		calendar: o,
		referenceISOYear: i
	};
}
const Ot = new RegExp(`^${fe.source}$`, "i"), $t = new RegExp(`^${/([+-])([01][0-9]|2[0-3])(?::?([0-5][0-9])?)?/.source}$`);
function Yt(e) {
	const t = Wo.test(e) ? "Seconds not allowed in offset time zone" : "Invalid time zone";
	throw new RangeError(`${t}: ${e}`);
}
function Rt(e) {
	return Ot.test(e) || Yt(e), $t.test(e) ? { offsetMinutes: sr(e) / 6e10 } : { tzName: e };
}
function St(e, t, n, r) {
	let o = e, i = t, a = n;
	switch (r) {
		case "reject":
			xr(o, i, a);
			break;
		case "constrain": ({year: o, month: i, day: a} = kr(o, i, a));
	}
	return {
		year: o,
		month: i,
		day: a
	};
}
function jt(e, t, n, r, o, i, a) {
	let s = e, c = t, d = n, h = r, u = o, l = i;
	switch (a) {
		case "reject":
			Pr(s, c, d, h, u, l);
			break;
		case "constrain": s = jr(s, 0, 23), c = jr(c, 0, 59), d = jr(d, 0, 59), h = jr(h, 0, 999), u = jr(u, 0, 999), l = jr(l, 0, 999);
	}
	return {
		hour: s,
		minute: c,
		second: d,
		millisecond: h,
		microsecond: u,
		nanosecond: l
	};
}
function kt(e) {
	if (!Ae(e)) throw new TypeError("invalid duration-like");
	const t = {
		years: void 0,
		months: void 0,
		weeks: void 0,
		days: void 0,
		hours: void 0,
		minutes: void 0,
		seconds: void 0,
		milliseconds: void 0,
		microseconds: void 0,
		nanoseconds: void 0
	};
	let n = !1;
	for (let r = 0; r < st.length; r++) {
		const o = st[r], i = e[o];
		void 0 !== i && (n = !0, t[o] = Ge(i));
	}
	if (!n) throw new TypeError("invalid duration-like");
	return t;
}
function Nt({ years: e, months: t, weeks: n, days: r }, o, i, a) {
	return {
		years: e,
		months: a ?? t,
		weeks: i ?? n,
		days: o ?? r
	};
}
function xt(e, t) {
	return {
		isoDate: e,
		time: t
	};
}
function Lt(e) {
	return Ho(e, "overflow", ["constrain", "reject"], "constrain");
}
function Pt(e) {
	return Ho(e, "disambiguation", [
		"compatible",
		"earlier",
		"later",
		"reject"
	], "compatible");
}
function Ut(e, t) {
	return Ho(e, "roundingMode", [
		"ceil",
		"floor",
		"expand",
		"trunc",
		"halfCeil",
		"halfFloor",
		"halfExpand",
		"halfTrunc",
		"halfEven"
	], t);
}
function Bt(e, t) {
	return Ho(e, "offset", [
		"prefer",
		"use",
		"ignore",
		"reject"
	], t);
}
function Zt(e) {
	return Ho(e, "calendarName", [
		"auto",
		"always",
		"never",
		"critical"
	], "auto");
}
function Ft(e) {
	let t = e.roundingIncrement;
	if (void 0 === t) return 1;
	const n = _e(t);
	if (n < 1 || n > 1e9) throw new RangeError(`roundingIncrement must be at least 1 and at most 1e9, not ${t}`);
	return n;
}
function Ht(e, t, n) {
	const r = n ? t : t - 1;
	if (e > r) throw new RangeError(`roundingIncrement must be at least 1 and less than ${r}, not ${e}`);
	if (t % e != 0) throw new RangeError(`Rounding increment must divide evenly into ${t}`);
}
function zt(e) {
	const t = e.fractionalSecondDigits;
	if (void 0 === t) return "auto";
	if ("number" != typeof t) {
		if ("auto" !== We(t)) throw new RangeError(`fractionalSecondDigits must be 'auto' or 0 through 9, not ${t}`);
		return "auto";
	}
	const n = Math.floor(t);
	if (!Number.isFinite(n) || n < 0 || n > 9) throw new RangeError(`fractionalSecondDigits must be 'auto' or 0 through 9, not ${t}`);
	return n;
}
function At(e, t) {
	switch (e) {
		case "minute": return {
			precision: "minute",
			unit: "minute",
			increment: 1
		};
		case "second": return {
			precision: 0,
			unit: "second",
			increment: 1
		};
		case "millisecond": return {
			precision: 3,
			unit: "millisecond",
			increment: 1
		};
		case "microsecond": return {
			precision: 6,
			unit: "microsecond",
			increment: 1
		};
		case "nanosecond": return {
			precision: 9,
			unit: "nanosecond",
			increment: 1
		};
	}
	switch (t) {
		case "auto": return {
			precision: t,
			unit: "nanosecond",
			increment: 1
		};
		case 0: return {
			precision: t,
			unit: "second",
			increment: 1
		};
		case 1:
		case 2:
		case 3: return {
			precision: t,
			unit: "millisecond",
			increment: 10 ** (3 - t)
		};
		case 4:
		case 5:
		case 6: return {
			precision: t,
			unit: "microsecond",
			increment: 10 ** (6 - t)
		};
		case 7:
		case 8:
		case 9: return {
			precision: t,
			unit: "nanosecond",
			increment: 10 ** (9 - t)
		};
		default: throw new RangeError(`fractionalSecondDigits must be 'auto' or 0 through 9, not ${t}`);
	}
}
const qt = Symbol("~required~");
function Wt(e, t, n, r, o = []) {
	let i = [];
	for (let e = 0; e < nt.length; e++) {
		const t = nt[e], r = t[1], o = t[2];
		"datetime" !== n && n !== o || i.push(r);
	}
	i = i.concat(o);
	let a = r;
	a === qt ? a = void 0 : void 0 !== a && i.push(a);
	let s = [];
	s = s.concat(i);
	for (let e = 0; e < i.length; e++) {
		const n = ot[i[e]];
		void 0 !== n && s.push(n);
	}
	let c = Ho(e, t, s, a);
	if (void 0 === c && r === qt) throw new RangeError(`${t} is required`);
	return c && c in rt ? rt[c] : c;
}
function _t(e) {
	const t = e.relativeTo;
	if (void 0 === t) return {};
	let n, r, o, i, a, s = "option", c = !1;
	if (Ae(t)) {
		if (wt(t)) return { zonedRelativeTo: t };
		if (mt(t)) return { plainRelativeTo: t };
		if (yt(t)) return { plainRelativeTo: pn(re(t, T).isoDate, re(t, E)) };
		o = Nn(t);
		const e = tn(o, t, [
			"year",
			"month",
			"monthCode",
			"day"
		], [
			"hour",
			"minute",
			"second",
			"millisecond",
			"microsecond",
			"nanosecond",
			"offset",
			"timeZone"
		], []);
		({isoDate: n, time: r} = on(o, e, "constrain")), {offset: a, timeZone: i} = e, void 0 === a && (s = "wall");
	} else {
		let e, d, h, u, l;
		if ({year: h, month: u, day: l, time: r, calendar: o, tzAnnotation: e, offset: a, z: d} = Mt(Ve(t)), e) i = Bn(e), d ? s = "exact" : a || (s = "wall"), c = !0;
		else if (d) throw new RangeError("Z designator not supported for PlainDate relativeTo; either remove the Z or add a bracketed time zone");
		o || (o = "iso8601"), o = zo(o), n = {
			year: h,
			month: u,
			day: l
		};
	}
	return void 0 === i ? { plainRelativeTo: pn(n, o) } : { zonedRelativeTo: $n(mn(n, r, s, "option" === s ? sr(a) : 0, i, "compatible", "reject", c), i, o) };
}
function Jt(e) {
	return 0 !== re(e, Y) ? "year" : 0 !== re(e, R) ? "month" : 0 !== re(e, S) ? "week" : 0 !== re(e, j) ? "day" : 0 !== re(e, k) ? "hour" : 0 !== re(e, N) ? "minute" : 0 !== re(e, x) ? "second" : 0 !== re(e, L) ? "millisecond" : 0 !== re(e, P) ? "microsecond" : "nanosecond";
}
function Gt(e, t) {
	return it.indexOf(e) > it.indexOf(t) ? t : e;
}
function Kt(e) {
	return "year" === e || "month" === e || "week" === e;
}
function Vt(e) {
	return Kt(e) || "day" === e ? "date" : "time";
}
function Xt(e) {
	return ce("%calendarImpl%")(e);
}
function Qt(e) {
	return ce("%calendarImpl%")(re(e, E));
}
function en(e, t, n = "date") {
	const r = Object.create(null), o = Xt(e).isoToDate(t, {
		year: !0,
		monthCode: !0,
		day: !0
	});
	return r.monthCode = o.monthCode, "month-day" !== n && "date" !== n || (r.day = o.day), "year-month" !== n && "date" !== n || (r.year = o.year), r;
}
function tn(e, t, n, r, o) {
	const i = Xt(e).extraFields(n), a = n.concat(r, i), s = Object.create(null);
	let c = !1;
	a.sort();
	for (let e = 0; e < a.length; e++) {
		const n = a[e], r = t[n];
		if (void 0 !== r) c = !0, s[n] = (0, et[n])(r);
		else if ("partial" !== o) {
			if (o.includes(n)) throw new TypeError(`required property '${n}' missing or undefined`);
			s[n] = tt[n];
		}
	}
	if ("partial" === o && !c) throw new TypeError("no supported properties found");
	return s;
}
function nn(e, t = "complete") {
	const n = [
		"hour",
		"microsecond",
		"millisecond",
		"minute",
		"nanosecond",
		"second"
	];
	let r = !1;
	const o = Object.create(null);
	for (let i = 0; i < n.length; i++) {
		const a = n[i], s = e[a];
		void 0 !== s ? (o[a] = _e(s), r = !0) : "complete" === t && (o[a] = 0);
	}
	if (!r) throw new TypeError("invalid time-like");
	return o;
}
function rn(e, t) {
	if (Ae(e)) {
		if (mt(e)) return Lt(Zo(t)), pn(re(e, D), re(e, E));
		if (wt(e)) {
			const n = zn(re(e, $), re(e, b));
			return Lt(Zo(t)), pn(n.isoDate, re(e, E));
		}
		if (yt(e)) return Lt(Zo(t)), pn(re(e, T).isoDate, re(e, E));
		const n = Nn(e);
		return pn(Ln(n, tn(n, e, [
			"year",
			"month",
			"monthCode",
			"day"
		], [], []), Lt(Zo(t))), n);
	}
	let { year: n, month: r, day: o, calendar: i, z: a } = Mt(Ve(e));
	if (a) throw new RangeError("Z designator not supported for PlainDate");
	return i || (i = "iso8601"), i = zo(i), Lt(Zo(t)), pn({
		year: n,
		month: r,
		day: o
	}, i);
}
function on(e, t, n) {
	return xt(Ln(e, t, n), jt(t.hour, t.minute, t.second, t.millisecond, t.microsecond, t.nanosecond, n));
}
function an(e, t) {
	let n, r, o;
	if (Ae(e)) {
		if (yt(e)) return Lt(Zo(t)), wn(re(e, T), re(e, E));
		if (wt(e)) {
			const n = zn(re(e, $), re(e, b));
			return Lt(Zo(t)), wn(n, re(e, E));
		}
		if (mt(e)) return Lt(Zo(t)), wn(xt(re(e, D), {
			deltaDays: 0,
			hour: 0,
			minute: 0,
			second: 0,
			millisecond: 0,
			microsecond: 0,
			nanosecond: 0
		}), re(e, E));
		o = Nn(e);
		const i = tn(o, e, [
			"year",
			"month",
			"monthCode",
			"day"
		], [
			"hour",
			"minute",
			"second",
			"millisecond",
			"microsecond",
			"nanosecond"
		], []), a = Lt(Zo(t));
		({isoDate: n, time: r} = on(o, i, a));
	} else {
		let i, a, s, c;
		if ({year: a, month: s, day: c, time: r, calendar: o, z: i} = Mt(Ve(e)), i) throw new RangeError("Z designator not supported for PlainDateTime");
		"start-of-day" === r && (r = {
			deltaDays: 0,
			hour: 0,
			minute: 0,
			second: 0,
			millisecond: 0,
			microsecond: 0,
			nanosecond: 0
		}), Ur(a, s, c, r.hour, r.minute, r.second, r.millisecond, r.microsecond, r.nanosecond), o || (o = "iso8601"), o = zo(o), Lt(Zo(t)), n = {
			year: a,
			month: s,
			day: c
		};
	}
	return wn(xt(n, r), o);
}
function sn(e) {
	const t = ce("%Temporal.Duration%");
	if (lt(e)) return new t(re(e, Y), re(e, R), re(e, S), re(e, j), re(e, k), re(e, N), re(e, x), re(e, L), re(e, P), re(e, U));
	if (!Ae(e)) return function(e) {
		const { years: t, months: n, weeks: r, days: o, hours: i, minutes: a, seconds: s, milliseconds: c, microseconds: d, nanoseconds: h } = function(e) {
			const t = Ye.exec(e);
			if (!t) throw new RangeError(`invalid duration: ${e}`);
			if (t.every(((e, t) => t < 2 || void 0 === e))) throw new RangeError(`invalid duration: ${e}`);
			const n = "-" === t[1] ? -1 : 1, r = void 0 === t[2] ? 0 : _e(t[2]) * n, o = void 0 === t[3] ? 0 : _e(t[3]) * n, i = void 0 === t[4] ? 0 : _e(t[4]) * n, a = void 0 === t[5] ? 0 : _e(t[5]) * n, s = void 0 === t[6] ? 0 : _e(t[6]) * n, c = t[7], d = t[8], h = t[9], u = t[10], l = t[11];
			let m = 0, f = 0, y = 0;
			if (void 0 !== c) {
				if (d ?? h ?? u ?? l) throw new RangeError("only the smallest unit can be fractional");
				y = 3600 * _e((c + "000000000").slice(0, 9)) * n;
			} else if (m = void 0 === d ? 0 : _e(d) * n, void 0 !== h) {
				if (u ?? l) throw new RangeError("only the smallest unit can be fractional");
				y = 60 * _e((h + "000000000").slice(0, 9)) * n;
			} else f = void 0 === u ? 0 : _e(u) * n, void 0 !== l && (y = _e((l + "000000000").slice(0, 9)) * n);
			const p = y % 1e3, g = Math.trunc(y / 1e3) % 1e3, w = Math.trunc(y / 1e6) % 1e3;
			return f += Math.trunc(y / 1e9) % 60, m += Math.trunc(y / 6e10), zr(r, o, i, a, s, m, f, w, g, p), {
				years: r,
				months: o,
				weeks: i,
				days: a,
				hours: s,
				minutes: m,
				seconds: f,
				milliseconds: w,
				microseconds: g,
				nanoseconds: p
			};
		}(e);
		return new (ce("%Temporal.Duration%"))(t, n, r, o, i, a, s, c, d, h);
	}(Ve(e));
	const n = {
		years: 0,
		months: 0,
		weeks: 0,
		days: 0,
		hours: 0,
		minutes: 0,
		seconds: 0,
		milliseconds: 0,
		microseconds: 0,
		nanoseconds: 0
	};
	let r = kt(e);
	for (let e = 0; e < st.length; e++) {
		const t = st[e], o = r[t];
		void 0 !== o && (n[t] = o);
	}
	return new t(n.years, n.months, n.weeks, n.days, n.hours, n.minutes, n.seconds, n.milliseconds, n.microseconds, n.nanoseconds);
}
function cn(e) {
	let t;
	if (Ae(e)) {
		if (ut(e) || wt(e)) return Cn(re(e, b));
		t = Xe(e);
	} else t = e;
	const { year: n, month: r, day: o, time: i, offset: a, z: s } = function(e) {
		const t = Mt(e);
		if (!t.z && !t.offset) throw new RangeError("Temporal.Instant requires a time zone offset");
		return t;
	}(Ve(t)), { hour: c = 0, minute: d = 0, second: h = 0, millisecond: u = 0, microsecond: l = 0, nanosecond: m = 0 } = "start-of-day" === i ? {} : i, f = $r(n, r, o, c, d, h, u, l, m - (s ? 0 : sr(a)));
	return Kr(f.isoDate), Cn(pr(f));
}
function dn(e, t) {
	if (Ae(e)) {
		if (gt(e)) return Lt(Zo(t)), bn(re(e, D), re(e, E));
		let n;
		return ne(e, E) ? n = re(e, E) : (n = e.calendar, void 0 === n && (n = "iso8601"), n = kn(n)), bn(Un(n, tn(n, e, [
			"year",
			"month",
			"monthCode",
			"day"
		], [], []), Lt(Zo(t))), n);
	}
	let { month: n, day: r, referenceISOYear: o, calendar: i } = Ct(Ve(e));
	if (void 0 === i && (i = "iso8601"), i = zo(i), Lt(Zo(t)), "iso8601" === i) return bn({
		year: 1972,
		month: n,
		day: r
	}, i);
	let a = {
		year: o,
		month: n,
		day: r
	};
	return Lr(a), a = Un(i, en(i, a, "month-day"), "constrain"), bn(a, i);
}
function hn(e, t) {
	let n;
	if (Ae(e)) {
		if (ft(e)) return Lt(Zo(t)), Tn(re(e, M));
		if (yt(e)) return Lt(Zo(t)), Tn(re(e, T).time);
		if (wt(e)) {
			const n = zn(re(e, $), re(e, b));
			return Lt(Zo(t)), Tn(n.time);
		}
		const { hour: r, minute: o, second: i, millisecond: a, microsecond: s, nanosecond: c } = nn(e);
		n = jt(r, o, i, a, s, c, Lt(Zo(t)));
	} else n = Et(Ve(e)), Lt(Zo(t));
	return Tn(n);
}
function un(e) {
	return void 0 === e ? {
		deltaDays: 0,
		hour: 0,
		minute: 0,
		second: 0,
		millisecond: 0,
		microsecond: 0,
		nanosecond: 0
	} : re(hn(e), M);
}
function ln(e, t) {
	if (Ae(e)) {
		if (pt(e)) return Lt(Zo(t)), En(re(e, D), re(e, E));
		const n = Nn(e);
		return En(Pn(n, tn(n, e, [
			"year",
			"month",
			"monthCode"
		], [], []), Lt(Zo(t))), n);
	}
	let { year: n, month: r, referenceISODay: o, calendar: i } = It(Ve(e));
	void 0 === i && (i = "iso8601"), i = zo(i), Lt(Zo(t));
	let a = {
		year: n,
		month: r,
		day: o
	};
	return Hr(a), a = Pn(i, en(i, a, "year-month"), "constrain"), En(a, i);
}
function mn(t, n, r, o, i, a, s, c) {
	if ("start-of-day" === n) return _n(i, t);
	const d = xt(t, n);
	if ("wall" === r || "ignore" === s) return An(i, d, a);
	if ("exact" === r || "use" === s) {
		const e = $r(t.year, t.month, t.day, n.hour, n.minute, n.second, n.millisecond, n.microsecond, n.nanosecond - o);
		Kr(e.isoDate);
		const r = pr(e);
		return Fr(r), r;
	}
	Kr(t);
	const h = pr(d), u = Wn(i, d);
	for (let t = 0; t < u.length; t++) {
		const n = u[t], r = import_jsbi_umd.default.toNumber(import_jsbi_umd.default.subtract(h, n)), i = Eo(r, 6e10, "halfExpand");
		if (r === o || c && i === o) return n;
	}
	if ("reject" === s) {
		const e = Hn(o), t = nr(d, "iso8601", "auto");
		throw new RangeError(`Offset ${e} is invalid for ${t} in ${i}`);
	}
	return qn(u, i, d, a);
}
function fn(e, t) {
	let n, r, o, i, a, s, c, d = !1, h = "option";
	if (Ae(e)) {
		if (wt(e)) {
			const n = Zo(t);
			return Pt(n), Bt(n, "reject"), Lt(n), $n(re(e, b), re(e, $), re(e, E));
		}
		a = Nn(e);
		const d = tn(a, e, [
			"year",
			"month",
			"monthCode",
			"day"
		], [
			"hour",
			"minute",
			"second",
			"millisecond",
			"microsecond",
			"nanosecond",
			"offset",
			"timeZone"
		], ["timeZone"]);
		({offset: i, timeZone: o} = d), void 0 === i && (h = "wall");
		const u = Zo(t);
		s = Pt(u), c = Bt(u, "reject");
		const l = Lt(u);
		({isoDate: n, time: r} = on(a, d, l));
	} else {
		let u, l, m, f, y;
		({year: m, month: f, day: y, time: r, tzAnnotation: u, offset: i, z: l, calendar: a} = function(e) {
			const t = Mt(e);
			if (!t.tzAnnotation) throw new RangeError("Temporal.ZonedDateTime requires a time zone ID in brackets");
			return t;
		}(Ve(e))), o = Bn(u), l ? h = "exact" : i || (h = "wall"), a || (a = "iso8601"), a = zo(a), d = !0;
		const p = Zo(t);
		s = Pt(p), c = Bt(p, "reject"), Lt(p), n = {
			year: m,
			month: f,
			day: y
		};
	}
	let u = 0;
	return "option" === h && (u = sr(i)), $n(mn(n, r, h, u, o, s, c, d), o, a);
}
function yn(e, t, n) {
	Lr(t), te(e), oe(e, D, t), oe(e, E, n), oe(e, I, !0);
}
function pn(e, t) {
	const n = ce("%Temporal.PlainDate%"), r = Object.create(n.prototype);
	return yn(r, e, t), r;
}
function gn(e, t, n) {
	Br(t), te(e), oe(e, T, t), oe(e, E, n);
}
function wn(e, t) {
	const n = ce("%Temporal.PlainDateTime%"), r = Object.create(n.prototype);
	return gn(r, e, t), r;
}
function vn(e, t, n) {
	Lr(t), te(e), oe(e, D, t), oe(e, E, n), oe(e, O, !0);
}
function bn(e, t) {
	const n = ce("%Temporal.PlainMonthDay%"), r = Object.create(n.prototype);
	return vn(r, e, t), r;
}
function Dn(e, t) {
	te(e), oe(e, M, t);
}
function Tn(e) {
	const t = ce("%Temporal.PlainTime%"), n = Object.create(t.prototype);
	return Dn(n, e), n;
}
function Mn(e, t, n) {
	Hr(t), te(e), oe(e, D, t), oe(e, E, n), oe(e, C, !0);
}
function En(e, t) {
	const n = ce("%Temporal.PlainYearMonth%"), r = Object.create(n.prototype);
	return Mn(r, e, t), r;
}
function In(e, t) {
	Fr(t), te(e), oe(e, b, t);
}
function Cn(e) {
	const t = ce("%Temporal.Instant%"), n = Object.create(t.prototype);
	return In(n, e), n;
}
function On(e, t, n, r) {
	Fr(t), te(e), oe(e, b, t), oe(e, $, n), oe(e, E, r);
}
function $n(e, t, n = "iso8601") {
	const r = ce("%Temporal.ZonedDateTime%"), o = Object.create(r.prototype);
	return On(o, e, t, n), o;
}
function Yn(e) {
	return Qe.filter(((t) => void 0 !== e[t]));
}
function Rn(e, t, n) {
	const r = Yn(n), o = Xt(e).fieldKeysToIgnore(r), i = Object.create(null), a = Yn(t);
	for (let e = 0; e < Qe.length; e++) {
		let s;
		const c = Qe[e];
		a.includes(c) && !o.includes(c) && (s = t[c]), r.includes(c) && (s = n[c]), void 0 !== s && (i[c] = s);
	}
	return i;
}
function Sn(e, t, n, r) {
	const o = Xt(e).dateAdd(t, n, r);
	return Lr(o), o;
}
function jn(e, t, n, r) {
	return Xt(e).dateUntil(t, n, r);
}
function kn(e) {
	if (Ae(e) && ne(e, E)) return re(e, E);
	const t = Ve(e);
	try {
		return zo(t);
	} catch {}
	let n;
	try {
		({calendar: n} = Mt(t));
	} catch {
		try {
			({calendar: n} = Et(t));
		} catch {
			try {
				({calendar: n} = It(t));
			} catch {
				({calendar: n} = Ct(t));
			}
		}
	}
	return n || (n = "iso8601"), zo(n);
}
function Nn(e) {
	if (ne(e, E)) return re(e, E);
	const { calendar: t } = e;
	return void 0 === t ? "iso8601" : kn(t);
}
function xn(e, t) {
	return zo(e) === zo(t);
}
function Ln(e, t, n) {
	const r = Xt(e);
	r.resolveFields(t, "date");
	const o = r.dateToISO(t, n);
	return Lr(o), o;
}
function Pn(e, t, n) {
	const r = Xt(e);
	r.resolveFields(t, "year-month"), t.day = 1;
	const o = r.dateToISO(t, n);
	return Hr(o), o;
}
function Un(e, t, n) {
	const r = Xt(e);
	r.resolveFields(t, "month-day");
	const o = r.monthDayToISOReferenceDate(t, n);
	return Lr(o), o;
}
function Bn(e) {
	if (Ae(e) && wt(e)) return re(e, $);
	const t = Ve(e);
	if ("UTC" === t) return "UTC";
	const { tzName: n, offsetMinutes: r } = function(e) {
		const { tzAnnotation: t, offset: n, z: r } = function(e) {
			if (Ot.test(e)) return {
				tzAnnotation: e,
				offset: void 0,
				z: !1
			};
			try {
				const { tzAnnotation: t, offset: n, z: r } = Mt(e);
				if (r || t || n) return {
					tzAnnotation: t,
					offset: n,
					z: r
				};
			} catch {}
			Yt(e);
		}(e);
		return t ? Rt(t) : r ? Rt("UTC") : n ? Rt(n) : void 0;
	}(t);
	if (void 0 !== r) return mr(r);
	const o = hr(n);
	if (!o) throw new RangeError(`Unrecognized time zone ${n}`);
	return o.identifier;
}
function Zn(e, t) {
	if (e === t) return !0;
	const n = Rt(e).offsetMinutes, r = Rt(t).offsetMinutes;
	if (void 0 === n && void 0 === r) {
		const n = hr(t);
		if (!n) return !1;
		const r = hr(e);
		return !!r && r.primaryIdentifier === n.primaryIdentifier;
	}
	return n === r;
}
function Fn(e, t) {
	const n = Rt(e).offsetMinutes;
	return void 0 !== n ? 6e10 * n : lr(e, t);
}
function Hn(e) {
	const t = e < 0 ? "-" : "+", n = Math.abs(e), r = Math.floor(n / 36e11), o = Math.floor(n / 6e10) % 60, i = Math.floor(n / 1e9) % 60, a = n % 1e9;
	return `${t}${Vn(r, o, i, a, 0 === i && 0 === a ? "minute" : "auto")}`;
}
function zn(e, t) {
	const n = Fn(e, t);
	let { isoDate: { year: r, month: o, day: i }, time: { hour: a, minute: s, second: c, millisecond: d, microsecond: h, nanosecond: u } } = gr(t);
	return $r(r, o, i, a, s, c, d, h, u + n);
}
function An(e, t, n) {
	return qn(Wn(e, t), e, t, n);
}
function qn(t, n, r, o) {
	const i = t.length;
	if (1 === i) return t[0];
	if (i) switch (o) {
		case "compatible":
		case "earlier": return t[0];
		case "later": return t[i - 1];
		case "reject": throw new RangeError("multiple instants found");
	}
	if ("reject" === o) throw new RangeError("multiple instants found");
	const a = pr(r), s = import_jsbi_umd.default.subtract(a, l);
	Fr(s);
	const c = Fn(n, s), d = import_jsbi_umd.default.add(a, l);
	Fr(d);
	const h = Fn(n, d) - c;
	switch (o) {
		case "earlier": {
			const e = TimeDuration.fromComponents(0, 0, 0, 0, 0, -h), t = fo(r.time, e);
			return Wn(n, xt(Or(r.isoDate.year, r.isoDate.month, r.isoDate.day + t.deltaDays), t))[0];
		}
		case "compatible":
		case "later": {
			const e = TimeDuration.fromComponents(0, 0, 0, 0, 0, h), t = fo(r.time, e), o = Wn(n, xt(Or(r.isoDate.year, r.isoDate.month, r.isoDate.day + t.deltaDays), t));
			return o[o.length - 1];
		}
	}
}
function Wn(t, n) {
	if ("UTC" === t) return Kr(n.isoDate), [pr(n)];
	const r = Rt(t).offsetMinutes;
	if (void 0 !== r) {
		const e = $r(n.isoDate.year, n.isoDate.month, n.isoDate.day, n.time.hour, n.time.minute - r, n.time.second, n.time.millisecond, n.time.microsecond, n.time.nanosecond);
		Kr(e.isoDate);
		const t = pr(e);
		return Fr(t), [t];
	}
	return Kr(n.isoDate), function(t, n) {
		let r = pr(n), o = import_jsbi_umd.default.subtract(r, l);
		import_jsbi_umd.default.lessThan(o, xe) && (o = r);
		let i = import_jsbi_umd.default.add(r, l);
		import_jsbi_umd.default.greaterThan(i, Ne) && (i = r);
		const a = lr(t, o), s = lr(t, i);
		return (a === s ? [a] : [a, s]).map(((o) => {
			const i = import_jsbi_umd.default.subtract(r, import_jsbi_umd.default.BigInt(o));
			if (0 === jo(n, function(e, t) {
				const { epochMilliseconds: n, time: { millisecond: r, microsecond: o, nanosecond: i } } = gr(t), { year: a, month: s, day: c, hour: d, minute: h, second: u } = br(e, n);
				return $r(a, s, c, d, h, u, r, o, i);
			}(t, i))) return Fr(i), i;
		})).filter(((e) => void 0 !== e));
	}(t, n);
}
function _n(t, n) {
	const r = xt(n, {
		deltaDays: 0,
		hour: 0,
		minute: 0,
		second: 0,
		millisecond: 0,
		microsecond: 0,
		nanosecond: 0
	}), o = Wn(t, r);
	if (o.length) return o[0];
	const i = pr(r), a = import_jsbi_umd.default.subtract(i, l);
	return Fr(a), wr(t, a);
}
function Jn(e) {
	let t;
	return t = e < 0 || e > 9999 ? (e < 0 ? "-" : "+") + Ke(Math.abs(e), 6) : Ke(e, 4), t;
}
function Gn(e) {
	return Ke(e, 2);
}
function Kn(e, t) {
	let n;
	if ("auto" === t) {
		if (0 === e) return "";
		n = Ke(e, 9).replace(/0+$/, "");
	} else {
		if (0 === t) return "";
		n = Ke(e, 9).slice(0, t);
	}
	return `.${n}`;
}
function Vn(e, t, n, r, o) {
	let i = `${Gn(e)}:${Gn(t)}`;
	return "minute" === o || (i += `:${Gn(n)}`, i += Kn(r, o)), i;
}
function Xn(e, t, n) {
	let r = t;
	void 0 === r && (r = "UTC");
	const o = re(e, b), i = nr(zn(r, o), "iso8601", n, "never");
	let a = "Z";
	return void 0 !== t && (a = fr(Fn(r, o))), `${i}${a}`;
}
function Qn(e, t) {
	const n = re(e, Y), r = re(e, R), o = re(e, S), i = re(e, j), a = re(e, k), s = re(e, N), c = Mr(e);
	let d = "";
	0 !== n && (d += `${Math.abs(n)}Y`), 0 !== r && (d += `${Math.abs(r)}M`), 0 !== o && (d += `${Math.abs(o)}W`), 0 !== i && (d += `${Math.abs(i)}D`);
	let h = "";
	0 !== a && (h += `${Math.abs(a)}H`), 0 !== s && (h += `${Math.abs(s)}M`);
	const u = TimeDuration.fromComponents(0, 0, re(e, x), re(e, L), re(e, P), re(e, U));
	u.isZero() && ![
		"second",
		"millisecond",
		"microsecond",
		"nanosecond"
	].includes(Jt(e)) && "auto" === t || (h += `${Math.abs(u.sec)}${Kn(Math.abs(u.subsec), t)}S`);
	let l = `${c < 0 ? "-" : ""}P${d}`;
	return h && (l = `${l}T${h}`), l;
}
function er(e, t = "auto") {
	const { year: n, month: r, day: o } = re(e, D);
	return `${Jn(n)}-${Gn(r)}-${Gn(o)}${Dt(re(e, E), t)}`;
}
function tr({ hour: e, minute: t, second: n, millisecond: r, microsecond: o, nanosecond: i }, a) {
	return Vn(e, t, n, 1e6 * r + 1e3 * o + i, a);
}
function nr(e, t, n, r = "auto") {
	const { isoDate: { year: o, month: i, day: a }, time: { hour: s, minute: c, second: d, millisecond: h, microsecond: u, nanosecond: l } } = e;
	return `${Jn(o)}-${Gn(i)}-${Gn(a)}T${Vn(s, c, d, 1e6 * h + 1e3 * u + l, n)}${Dt(t, r)}`;
}
function rr(e, t = "auto") {
	const { year: n, month: r, day: o } = re(e, D);
	let i = `${Gn(r)}-${Gn(o)}`;
	const a = re(e, E);
	"always" !== t && "critical" !== t && "iso8601" === a || (i = `${Jn(n)}-${i}`);
	const s = Dt(a, t);
	return s && (i += s), i;
}
function or(e, t = "auto") {
	const { year: n, month: r, day: o } = re(e, D);
	let i = `${Jn(n)}-${Gn(r)}`;
	const a = re(e, E);
	"always" !== t && "critical" !== t && "iso8601" === a || (i += `-${Gn(o)}`);
	const s = Dt(a, t);
	return s && (i += s), i;
}
function ir(e, t, n = "auto", r = "auto", o = "auto", i = void 0) {
	let a = re(e, b);
	if (i) {
		const { unit: e, increment: t, roundingMode: n } = i;
		a = Io(a, t, e, n);
	}
	const s = re(e, $), c = Fn(s, a);
	let d = nr(zn(s, a), "iso8601", t, "never");
	return "never" !== o && (d += fr(c)), "never" !== r && (d += `[${"critical" === r ? "!" : ""}${s}]`), d += Dt(re(e, E), n), d;
}
function ar(e) {
	return $t.test(e);
}
function sr(e) {
	const t = _o.exec(e);
	if (!t) throw new RangeError(`invalid time zone offset: ${e}; must match ±HH:MM[:SS.SSSSSSSSS]`);
	return ("-" === t[1] ? -1 : 1) * (1e9 * (60 * (60 * +t[2] + +(t[3] || 0)) + +(t[4] || 0)) + +((t[5] || 0) + "000000000").slice(0, 9));
}
let cr;
const dr = Object.assign(Object.create(null), {
	"/": !0,
	"-": !0,
	_: !0
});
function hr(e) {
	if (void 0 === cr) {
		const e = Intl.supportedValuesOf?.("timeZone");
		if (e) {
			cr = /* @__PURE__ */ new Map();
			for (let t = 0; t < e.length; t++) {
				const n = e[t];
				cr.set(Ao(n), n);
			}
		} else cr = null;
	}
	const t = Ao(e);
	let n = cr?.get(t);
	if (n) return {
		identifier: n,
		primaryIdentifier: n
	};
	try {
		n = ht(e).resolvedOptions().timeZone;
	} catch {
		return;
	}
	if ("antarctica/south_pole" === t && (n = "Antarctica/McMurdo"), ze.has(e)) throw new RangeError(`${e} is a legacy time zone identifier from ICU. Use ${n} instead`);
	const r = [...t].map(((e, n) => 0 === n || dr[t[n - 1]] ? e.toUpperCase() : e)).join("").split("/");
	if (1 === r.length) return "gb-eire" === t ? {
		identifier: "GB-Eire",
		primaryIdentifier: n
	} : {
		identifier: t.length <= 3 || /[-0-9]/.test(t) ? t.toUpperCase() : r[0],
		primaryIdentifier: n
	};
	if ("Etc" === r[0]) return {
		identifier: `Etc/${[
			"Zulu",
			"Greenwich",
			"Universal"
		].includes(r[1]) ? r[1] : r[1].toUpperCase()}`,
		primaryIdentifier: n
	};
	if ("Us" === r[0]) return {
		identifier: `US/${r[1]}`,
		primaryIdentifier: n
	};
	const o = new Map([
		["Act", "ACT"],
		["Lhi", "LHI"],
		["Nsw", "NSW"],
		["Dar_Es_Salaam", "Dar_es_Salaam"],
		["Port_Of_Spain", "Port_of_Spain"],
		["Port-Au-Prince", "Port-au-Prince"],
		["Isle_Of_Man", "Isle_of_Man"],
		["Comodrivadavia", "ComodRivadavia"],
		["Knox_In", "Knox_IN"],
		["Dumontdurville", "DumontDUrville"],
		["Mcmurdo", "McMurdo"],
		["Denoronha", "DeNoronha"],
		["Easterisland", "EasterIsland"],
		["Bajanorte", "BajaNorte"],
		["Bajasur", "BajaSur"]
	]);
	return r[1] = o.get(r[1]) ?? r[1], r.length > 2 && (r[2] = o.get(r[2]) ?? r[2]), {
		identifier: r.join("/"),
		primaryIdentifier: n
	};
}
function ur(e, t) {
	const { year: n, month: r, day: o, hour: i, minute: a, second: s } = br(e, t);
	let c = t % 1e3;
	return c < 0 && (c += 1e3), 1e6 * (yr({
		isoDate: {
			year: n,
			month: r,
			day: o
		},
		time: {
			hour: i,
			minute: a,
			second: s,
			millisecond: c
		}
	}) - t);
}
function lr(e, t) {
	return ur(e, No(t, "floor"));
}
function mr(e) {
	const t = e < 0 ? "-" : "+", n = Math.abs(e);
	return `${t}${Vn(Math.floor(n / 60), n % 60, 0, 0, "minute")}`;
}
function fr(e) {
	return mr(Eo(e, je, "halfExpand") / 6e10);
}
function yr({ isoDate: { year: e, month: t, day: n }, time: { hour: r, minute: o, second: i, millisecond: a } }) {
	const s = e % 400, c = (e - s) / 400, d = /* @__PURE__ */ new Date();
	return d.setUTCHours(r, o, i, a), d.setUTCFullYear(s, t - 1, n), d.getTime() + Ue * c;
}
function pr(t) {
	const n = yr(t), r = 1e3 * t.time.microsecond + t.time.nanosecond;
	return import_jsbi_umd.default.add(xo(n), import_jsbi_umd.default.BigInt(r));
}
function gr(t) {
	let n = No(t, "trunc"), r = import_jsbi_umd.default.toNumber(import_jsbi_umd.default.remainder(t, c));
	r < 0 && (r += 1e6, n -= 1);
	const o = Math.floor(r / 1e3) % 1e3, i = r % 1e3, a = new Date(n);
	return {
		epochMilliseconds: n,
		isoDate: {
			year: a.getUTCFullYear(),
			month: a.getUTCMonth() + 1,
			day: a.getUTCDate()
		},
		time: {
			hour: a.getUTCHours(),
			minute: a.getUTCMinutes(),
			second: a.getUTCSeconds(),
			millisecond: a.getUTCMilliseconds(),
			microsecond: o,
			nanosecond: i
		}
	};
}
function wr(e, t) {
	if ("UTC" === e) return null;
	const n = No(t, "floor");
	if (n < Fe) return wr(e, xo(Fe));
	const r = Date.now(), o = Math.max(n, r) + 366 * Re * 3;
	let i = n, a = ur(e, i), s = i, c = a;
	for (; a === c && i < o;) {
		if (s = i + 2 * Re * 7, s > ke) return null;
		c = ur(e, s), a === c && (i = s);
	}
	return a === c ? null : xo(Jo(((t) => ur(e, t)), i, s, a, c));
}
function vr(t, n) {
	if ("UTC" === t) return null;
	const r = No(n, "ceil"), o = Date.now(), i = o + 366 * Re * 3;
	if (r > i) {
		const n = vr(t, xo(i));
		if (null === n || import_jsbi_umd.default.lessThan(n, xo(o))) return n;
	}
	if ("Africa/Casablanca" === t || "Africa/El_Aaiun" === t) {
		const e = Date.UTC(2088, 0, 1);
		if (e < r) return vr(t, xo(e));
	}
	let a = r - 1;
	if (a < Fe) return null;
	let s = ur(t, a), c = a, d = s;
	for (; s === d && a > Fe;) {
		if (c = a - 2 * Re * 7, c < Fe) return null;
		d = ur(t, c), s === d && (a = c);
	}
	return s === d ? null : xo(Jo(((e) => ur(t, e)), c, a, d, s));
}
function br(e, t) {
	return function(e) {
		const t = e.split(/[^\w]+/);
		if (7 !== t.length) throw new RangeError(`expected 7 parts in "${e}`);
		const n = +t[0], r = +t[1];
		let o = +t[2];
		const i = t[3];
		if ("b" === i[0] || "B" === i[0]) o = 1 - o;
		else if ("a" !== i[0] && "A" !== i[0]) throw new RangeError(`Unknown era ${i} in "${e}`);
		const a = "24" === t[4] ? 0 : +t[4], s = +t[5], c = +t[6];
		if (!(Number.isFinite(o) && Number.isFinite(n) && Number.isFinite(r) && Number.isFinite(a) && Number.isFinite(s) && Number.isFinite(c))) throw new RangeError(`Invalid number in "${e}`);
		return {
			year: o,
			month: n,
			day: r,
			hour: a,
			minute: s,
			second: c
		};
	}(ht(e).format(t));
}
function Dr(e) {
	return void 0 !== e && !(e % 4 != 0 || e % 100 == 0 && e % 400 != 0);
}
function Tr(e, t) {
	return {
		standard: [
			31,
			28,
			31,
			30,
			31,
			30,
			31,
			31,
			30,
			31,
			30,
			31
		],
		leapyear: [
			31,
			29,
			31,
			30,
			31,
			30,
			31,
			31,
			30,
			31,
			30,
			31
		]
	}[Dr(e) ? "leapyear" : "standard"][t - 1];
}
function Mr(e) {
	const t = [
		re(e, Y),
		re(e, R),
		re(e, S),
		re(e, j),
		re(e, k),
		re(e, N),
		re(e, x),
		re(e, L),
		re(e, P),
		re(e, U)
	];
	for (let e = 0; e < t.length; e++) {
		const n = t[e];
		if (0 !== n) return n < 0 ? -1 : 1;
	}
	return 0;
}
function Er(e) {
	const t = [
		"years",
		"months",
		"weeks",
		"days"
	];
	for (let n = 0; n < t.length; n++) {
		const r = e[t[n]];
		if (0 !== r) return r < 0 ? -1 : 1;
	}
	return 0;
}
function Ir(e) {
	const t = Er(e.date);
	return 0 !== t ? t : e.time.sign();
}
function Cr(e, t) {
	let n = e, r = t;
	if (!Number.isFinite(n) || !Number.isFinite(r)) throw new RangeError("infinity is out of range");
	return r -= 1, n += Math.floor(r / 12), r %= 12, r < 0 && (r += 12), r += 1, {
		year: n,
		month: r
	};
}
function Or(e, t, n) {
	let r = e, o = t, i = n;
	if (!Number.isFinite(i)) throw new RangeError("infinity is out of range");
	({year: r, month: o} = Cr(r, o));
	const a = 146097;
	if (Math.abs(i) > a) {
		const e = Math.trunc(i / a);
		r += 400 * e, i -= e * a;
	}
	let s = 0, c = o > 2 ? r : r - 1;
	for (; s = Dr(c) ? 366 : 365, i < -s;) r -= 1, c -= 1, i += s;
	for (c += 1; s = Dr(c) ? 366 : 365, i > s;) r += 1, c += 1, i -= s;
	for (; i < 1;) ({year: r, month: o} = Cr(r, o - 1)), i += Tr(r, o);
	for (; i > Tr(r, o);) i -= Tr(r, o), {year: r, month: o} = Cr(r, o + 1);
	return {
		year: r,
		month: o,
		day: i
	};
}
function $r(e, t, n, r, o, i, a, s, c) {
	const d = Yr(r, o, i, a, s, c);
	return xt(Or(e, t, n + d.deltaDays), d);
}
function Yr(e, t, n, r, o, i) {
	let a, s = e, c = t, d = n, h = r, u = o, l = i;
	({div: a, mod: l} = de(l, 3)), u += a, l < 0 && (u -= 1, l += 1e3), {div: a, mod: u} = de(u, 3), h += a, u < 0 && (h -= 1, u += 1e3), d += Math.trunc(h / 1e3), h %= 1e3, h < 0 && (d -= 1, h += 1e3), c += Math.trunc(d / 60), d %= 60, d < 0 && (c -= 1, d += 60), s += Math.trunc(c / 60), c %= 60, c < 0 && (s -= 1, c += 60);
	let m = Math.trunc(s / 24);
	return s %= 24, s < 0 && (m -= 1, s += 24), m += 0, s += 0, c += 0, d += 0, h += 0, u += 0, l += 0, {
		deltaDays: m,
		hour: s,
		minute: c,
		second: d,
		millisecond: h,
		microsecond: u,
		nanosecond: l
	};
}
function Rr(e, t) {
	const n = Nt(e, 0);
	if (0 === Er(n)) return e.days;
	const r = re(t, D), o = Sn(re(t, E), r, n, "constrain"), i = Gr(r.year, r.month - 1, r.day), a = Gr(o.year, o.month - 1, o.day) - i;
	return e.days + a;
}
function Sr(e) {
	return new (ce("%Temporal.Duration%"))(-re(e, Y), -re(e, R), -re(e, S), -re(e, j), -re(e, k), -re(e, N), -re(e, x), -re(e, L), -re(e, P), -re(e, U));
}
function jr(e, t, n) {
	return Math.min(n, Math.max(t, e));
}
function kr(e, t, n) {
	const r = jr(t, 1, 12);
	return {
		year: e,
		month: r,
		day: jr(n, 1, Tr(e, r))
	};
}
function Nr(e, t, n) {
	if (e < t || e > n) throw new RangeError(`value out of range: ${t} <= ${e} <= ${n}`);
}
function xr(e, t, n) {
	Nr(t, 1, 12), Nr(n, 1, Tr(e, t));
}
function Lr(e) {
	Br(xt(e, {
		deltaDays: 0,
		hour: 12,
		minute: 0,
		second: 0,
		millisecond: 0,
		microsecond: 0,
		nanosecond: 0
	}));
}
function Pr(e, t, n, r, o, i) {
	Nr(e, 0, 23), Nr(t, 0, 59), Nr(n, 0, 59), Nr(r, 0, 999), Nr(o, 0, 999), Nr(i, 0, 999);
}
function Ur(e, t, n, r, o, i, a, s, c) {
	xr(e, t, n), Pr(r, o, i, a, s, c);
}
function Br(t) {
	const n = pr(t);
	(import_jsbi_umd.default.lessThan(n, Le) || import_jsbi_umd.default.greaterThan(n, Pe)) && Fr(n);
}
function Zr(e) {
	pr(e);
}
function Fr(t) {
	if (import_jsbi_umd.default.lessThan(t, xe) || import_jsbi_umd.default.greaterThan(t, Ne)) throw new RangeError("date/time value is outside of supported range");
}
function Hr({ year: e, month: t }) {
	Nr(e, Be, Ze), e === Be ? Nr(t, 4, 12) : e === Ze && Nr(t, 1, 9);
}
function zr(e, t, n, r, o, i, a, s, c, d) {
	let h = 0;
	const u = [
		e,
		t,
		n,
		r,
		o,
		i,
		a,
		s,
		c,
		d
	];
	for (let e = 0; e < u.length; e++) {
		const t = u[e];
		if (t === Infinity || t === -Infinity) throw new RangeError("infinite values not allowed as duration fields");
		if (0 !== t) {
			const e = t < 0 ? -1 : 1;
			if (0 !== h && e !== h) throw new RangeError("mixed-sign values not allowed as duration fields");
			h = e;
		}
	}
	if (Math.abs(e) >= 2 ** 32 || Math.abs(t) >= 2 ** 32 || Math.abs(n) >= 2 ** 32) throw new RangeError("years, months, and weeks must be < 2³²");
	const l = de(s, 3), m = de(c, 6), f = de(d, 9), y = de(1e6 * l.mod + 1e3 * m.mod + f.mod, 9).div, p = 86400 * r + 3600 * o + 60 * i + a + l.div + m.div + f.div + y;
	if (!Number.isSafeInteger(p)) throw new RangeError("total of duration time units cannot exceed 9007199254740991.999999999 s");
}
function Ar(e) {
	return {
		date: {
			years: re(e, Y),
			months: re(e, R),
			weeks: re(e, S),
			days: re(e, j)
		},
		time: TimeDuration.fromComponents(re(e, k), re(e, N), re(e, x), re(e, L), re(e, P), re(e, U))
	};
}
function qr(e) {
	const t = TimeDuration.fromComponents(re(e, k), re(e, N), re(e, x), re(e, L), re(e, P), re(e, U)).add24HourDays(re(e, j));
	return {
		date: {
			years: re(e, Y),
			months: re(e, R),
			weeks: re(e, S),
			days: 0
		},
		time: t
	};
}
function Wr(e) {
	const t = qr(e), n = Math.trunc(t.time.sec / 86400);
	return zr(t.date.years, t.date.months, t.date.weeks, n, 0, 0, 0, 0, 0, 0), {
		...t.date,
		days: n
	};
}
function _r(e, t) {
	const n = e.time.sign();
	let r = e.time.abs().subsec, o = 0, i = 0, a = e.time.abs().sec, s = 0, c = 0, d = 0;
	switch (t) {
		case "year":
		case "month":
		case "week":
		case "day":
			o = Math.trunc(r / 1e3), r %= 1e3, i = Math.trunc(o / 1e3), o %= 1e3, a += Math.trunc(i / 1e3), i %= 1e3, s = Math.trunc(a / 60), a %= 60, c = Math.trunc(s / 60), s %= 60, d = Math.trunc(c / 24), c %= 24;
			break;
		case "hour":
			o = Math.trunc(r / 1e3), r %= 1e3, i = Math.trunc(o / 1e3), o %= 1e3, a += Math.trunc(i / 1e3), i %= 1e3, s = Math.trunc(a / 60), a %= 60, c = Math.trunc(s / 60), s %= 60;
			break;
		case "minute":
			o = Math.trunc(r / 1e3), r %= 1e3, i = Math.trunc(o / 1e3), o %= 1e3, a += Math.trunc(i / 1e3), i %= 1e3, s = Math.trunc(a / 60), a %= 60;
			break;
		case "second":
			o = Math.trunc(r / 1e3), r %= 1e3, i = Math.trunc(o / 1e3), o %= 1e3, a += Math.trunc(i / 1e3), i %= 1e3;
			break;
		case "millisecond":
			o = Math.trunc(r / 1e3), r %= 1e3, i = he(a, 3, Math.trunc(o / 1e3)), o %= 1e3, a = 0;
			break;
		case "microsecond":
			o = he(a, 6, Math.trunc(r / 1e3)), r %= 1e3, a = 0;
			break;
		case "nanosecond": r = he(a, 9, r), a = 0;
	}
	return new (ce("%Temporal.Duration%"))(e.date.years, e.date.months, e.date.weeks, e.date.days + n * d, n * c, n * s, n * a, n * i, n * o, n * r);
}
function Jr(e, t) {
	return Er(e), t.sign(), {
		date: e,
		time: t
	};
}
function Gr(e, t, n) {
	return yr({
		isoDate: {
			year: e,
			month: t + 1,
			day: n
		},
		time: {
			hour: 0,
			minute: 0,
			second: 0,
			millisecond: 0
		}
	}) / Re;
}
function Kr({ year: e, month: t, day: n }) {
	if (Math.abs(Gr(e, t - 1, n)) > 1e8) throw new RangeError("date/time value is outside the supported range");
}
function Vr(e, t) {
	const n = t.hour - e.hour, r = t.minute - e.minute, o = t.second - e.second, i = t.millisecond - e.millisecond, a = t.microsecond - e.microsecond, s = t.nanosecond - e.nanosecond;
	return TimeDuration.fromComponents(n, r, o, i, a, s);
}
function Xr(e, t, n, r, o) {
	let i = TimeDuration.fromEpochNsDiff(t, e);
	return i = $o(i, n, r, o), Jr({
		years: 0,
		months: 0,
		weeks: 0,
		days: 0
	}, i);
}
function Qr(e, t, n, r) {
	Zr(e), Zr(t);
	let o = Vr(e.time, t.time);
	const i = o.sign(), a = Ro(e.isoDate, t.isoDate);
	let s = t.isoDate;
	a === i && (s = Or(s.year, s.month, s.day + i), o = o.add24HourDays(-i));
	const c = Gt("day", r), d = jn(n, e.isoDate, s, c);
	return r !== c && (o = o.add24HourDays(d.days), d.days = 0), Jr(d, o);
}
function eo(n, r, o, i, a) {
	const s = import_jsbi_umd.default.subtract(r, n);
	if (import_jsbi_umd.default.equal(s, t)) return {
		date: {
			years: 0,
			months: 0,
			weeks: 0,
			days: 0
		},
		time: TimeDuration.ZERO
	};
	const c = import_jsbi_umd.default.lessThan(s, t) ? -1 : 1, d = zn(o, n), h = zn(o, r);
	let u, l = 0, m = 1 === c ? 2 : 1, f = Vr(d.time, h.time);
	for (f.sign() === -c && l++; l <= m; l++) {
		u = xt(Or(h.isoDate.year, h.isoDate.month, h.isoDate.day - l * c), d.time);
		const e = An(o, u, "compatible");
		if (f = TimeDuration.fromEpochNsDiff(r, e), f.sign() !== -c) break;
	}
	const y = Gt("day", a);
	return Jr(jn(i, d.isoDate, u.isoDate, y), f);
}
function to(t, n, r, o, i, a, s, c, d) {
	let h, u, l, m, f = n;
	switch (c) {
		case "year": {
			const e = Eo(f.date.years, s, "trunc");
			h = e, u = e + s * t, l = {
				years: h,
				months: 0,
				weeks: 0,
				days: 0
			}, m = {
				...l,
				years: u
			};
			break;
		}
		case "month": {
			const e = Eo(f.date.months, s, "trunc");
			h = e, u = e + s * t, l = Nt(f.date, 0, 0, h), m = Nt(f.date, 0, 0, u);
			break;
		}
		case "week": {
			const e = Nt(f.date, 0, 0), n = Sn(a, o.isoDate, e, "constrain"), r = jn(a, n, Or(n.year, n.month, n.day + f.date.days), "week"), i = Eo(f.date.weeks + r.weeks, s, "trunc");
			h = i, u = i + s * t, l = Nt(f.date, 0, h), m = Nt(f.date, 0, u);
			break;
		}
		case "day": {
			const e = Eo(f.date.days, s, "trunc");
			h = e, u = e + s * t, l = Nt(f.date, h), m = Nt(f.date, u);
			break;
		}
	}
	const y = Sn(a, o.isoDate, l, "constrain"), p = Sn(a, o.isoDate, m, "constrain");
	let g, w;
	const v = xt(y, o.time), b = xt(p, o.time);
	i ? (g = An(i, v, "compatible"), w = An(i, b, "compatible")) : (g = pr(v), w = pr(b));
	const D = TimeDuration.fromEpochNsDiff(r, g), T = TimeDuration.fromEpochNsDiff(w, g), M = ue(d, t < 0 ? "negative" : "positive"), E = D.add(D).abs().subtract(T.abs()).sign(), I = Math.abs(h) / s % 2 == 0, C = D.isZero() ? Math.abs(h) : D.cmp(T) ? le(Math.abs(h), Math.abs(u), E, I, M) : Math.abs(u), O = new TimeDuration(import_jsbi_umd.default.add(import_jsbi_umd.default.multiply(T.totalNs, import_jsbi_umd.default.BigInt(h)), import_jsbi_umd.default.multiply(D.totalNs, import_jsbi_umd.default.BigInt(s * t)))).fdiv(T.totalNs), $ = C === Math.abs(u);
	return f = {
		date: $ ? m : l,
		time: TimeDuration.ZERO
	}, {
		nudgeResult: {
			duration: f,
			nudgedEpochNs: $ ? w : g,
			didExpandCalendarUnit: $
		},
		total: O
	};
}
function no(t, n, r, o, i, a, s, c, d) {
	let h = t;
	const u = Kt(c) || o && "day" === c, l = Ir(h) < 0 ? -1 : 1;
	let m;
	return u ? {nudgeResult: m} = to(l, h, n, r, o, i, s, c, d) : m = o ? function(t, n, r, o, i, a, s, c) {
		let d = n;
		const h = Sn(i, r.isoDate, d.date, "constrain"), u = xt(h, r.time), l = xt(Or(h.year, h.month, h.day + t), r.time), m = An(o, u, "compatible"), f = An(o, l, "compatible"), y = TimeDuration.fromEpochNsDiff(f, m);
		if (y.sign() !== t) throw new RangeError("time zone returned inconsistent Instants");
		const p = import_jsbi_umd.default.BigInt(at[s] * a);
		let g = d.time.round(p, c);
		const w = g.subtract(y), v = w.sign() !== -t;
		let b, D;
		return v ? (b = t, g = w.round(p, c), D = g.addToEpochNs(f)) : (b = 0, D = g.addToEpochNs(m)), {
			duration: Jr(Nt(d.date, d.date.days + b), g),
			nudgedEpochNs: D,
			didExpandCalendarUnit: v
		};
	}(l, h, r, o, i, s, c, d) : function(t, n, r, o, i, a) {
		let s = t;
		const c = s.time.add24HourDays(s.date.days), d = c.round(import_jsbi_umd.default.BigInt(o * at[i]), a), h = d.subtract(c), { quotient: u } = c.divmod(Se), { quotient: l } = d.divmod(Se), m = Math.sign(l - u) === c.sign(), f = h.addToEpochNs(n);
		let y = 0, p = d;
		return "date" === Vt(r) && (y = l, p = d.add(TimeDuration.fromComponents(24 * -l, 0, 0, 0, 0, 0))), {
			duration: {
				date: Nt(s.date, y),
				time: p
			},
			nudgedEpochNs: f,
			didExpandCalendarUnit: m
		};
	}(h, n, a, s, c, d), h = m.duration, m.didExpandCalendarUnit && "week" !== c && (h = function(e, t, n, r, o, i, a, s) {
		let c = t;
		if (s === a) return c;
		const d = it.indexOf(a);
		for (let t = it.indexOf(s) - 1; t >= d; t--) {
			const s = it[t];
			if ("week" === s && "week" !== a) continue;
			let d;
			switch (s) {
				case "year":
					d = {
						years: c.date.years + e,
						months: 0,
						weeks: 0,
						days: 0
					};
					break;
				case "month": {
					const t = c.date.months + e;
					d = Nt(c.date, 0, 0, t);
					break;
				}
				case "week": {
					const t = c.date.weeks + e;
					d = Nt(c.date, 0, t);
					break;
				}
			}
			const h = xt(Sn(i, r.isoDate, d, "constrain"), r.time);
			let u;
			if (u = o ? An(o, h, "compatible") : pr(h), p(n, u) === -e) break;
			c = {
				date: d,
				time: TimeDuration.ZERO
			};
		}
		return c;
	}(l, h, m.nudgedEpochNs, r, o, i, a, Gt(c, "day"))), h;
}
function ro(e, t, n, r, o, i) {
	return Kt(i) || r && "day" === i ? to(Ir(e) < 0 ? -1 : 1, e, t, n, r, o, 1, i, "trunc").total : Yo(e.time.add24HourDays(e.date.days), i);
}
function oo(e, t, n, r, o, i, a) {
	if (0 == jo(e, t)) return {
		date: {
			years: 0,
			months: 0,
			weeks: 0,
			days: 0
		},
		time: TimeDuration.ZERO
	};
	Br(e), Br(t);
	const s = Qr(e, t, n, r);
	return "nanosecond" === i && 1 === o ? s : no(s, pr(t), e, null, n, r, o, i, a);
}
function io(e, t, n, r, o, i, a, s) {
	if ("time" === Vt(o)) return Xr(e, t, i, a, s);
	const c = eo(e, t, n, r, o);
	return "nanosecond" === a && 1 === i ? c : no(c, t, zn(n, e), n, r, o, i, a, s);
}
function ao(e, t, n, r, o, i) {
	const a = nt.reduce(((e, t) => {
		const o = t[0], i = t[1], a = t[2];
		return "datetime" !== n && a !== n || r.includes(i) || e.push(i, o), e;
	}), []);
	let s = Wt(t, "largestUnit", n, "auto");
	if (r.includes(s)) throw new RangeError(`largestUnit must be one of ${a.join(", ")}, not ${s}`);
	const c = Ft(t);
	let d = Ut(t, "trunc");
	"since" === e && (d = function(e) {
		switch (e) {
			case "ceil": return "floor";
			case "floor": return "ceil";
			case "halfCeil": return "halfFloor";
			case "halfFloor": return "halfCeil";
			default: return e;
		}
	}(d));
	const h = Wt(t, "smallestUnit", n, o);
	if (r.includes(h)) throw new RangeError(`smallestUnit must be one of ${a.join(", ")}, not ${h}`);
	const u = Gt(i, h);
	if ("auto" === s && (s = u), Gt(s, h) !== s) throw new RangeError(`largestUnit ${s} cannot be smaller than smallestUnit ${h}`);
	const l = {
		hour: 24,
		minute: 60,
		second: 60,
		millisecond: 1e3,
		microsecond: 1e3,
		nanosecond: 1e3
	}[h];
	return void 0 !== l && Ht(c, l, !1), {
		largestUnit: s,
		roundingIncrement: c,
		roundingMode: d,
		smallestUnit: h
	};
}
function so(e, t, n, r) {
	const o = cn(n), i = ao(e, Zo(r), "time", [], "nanosecond", "second");
	let a = _r(Xr(re(t, b), re(o, b), i.roundingIncrement, i.smallestUnit, i.roundingMode), i.largestUnit);
	return "since" === e && (a = Sr(a)), a;
}
function co(e, t, n, r) {
	const o = rn(n), i = re(t, E), a = re(o, E);
	if (!xn(i, a)) throw new RangeError(`cannot compute difference between dates of ${i} and ${a} calendars`);
	const s = ao(e, Zo(r), "date", [], "day", "day"), c = ce("%Temporal.Duration%"), d = re(t, D), h = re(o, D);
	if (0 === Ro(d, h)) return new c();
	let u = {
		date: jn(i, d, h, s.largestUnit),
		time: TimeDuration.ZERO
	};
	if ("day" !== s.smallestUnit || 1 !== s.roundingIncrement) {
		const e = xt(d, {
			deltaDays: 0,
			hour: 0,
			minute: 0,
			second: 0,
			millisecond: 0,
			microsecond: 0,
			nanosecond: 0
		});
		u = no(u, pr(xt(h, {
			deltaDays: 0,
			hour: 0,
			minute: 0,
			second: 0,
			millisecond: 0,
			microsecond: 0,
			nanosecond: 0
		})), e, null, i, s.largestUnit, s.roundingIncrement, s.smallestUnit, s.roundingMode);
	}
	let l = _r(u, "day");
	return "since" === e && (l = Sr(l)), l;
}
function ho(e, t, n, r) {
	const o = an(n), i = re(t, E), a = re(o, E);
	if (!xn(i, a)) throw new RangeError(`cannot compute difference between dates of ${i} and ${a} calendars`);
	const s = ao(e, Zo(r), "datetime", [], "nanosecond", "day"), c = ce("%Temporal.Duration%"), d = re(t, T), h = re(o, T);
	if (0 === jo(d, h)) return new c();
	let u = _r(oo(d, h, i, s.largestUnit, s.roundingIncrement, s.smallestUnit, s.roundingMode), s.largestUnit);
	return "since" === e && (u = Sr(u)), u;
}
function uo(e, t, n, r) {
	const o = hn(n), i = ao(e, Zo(r), "time", [], "nanosecond", "hour");
	let a = Vr(re(t, M), re(o, M));
	a = $o(a, i.roundingIncrement, i.smallestUnit, i.roundingMode);
	let s = _r(Jr({
		years: 0,
		months: 0,
		weeks: 0,
		days: 0
	}, a), i.largestUnit);
	return "since" === e && (s = Sr(s)), s;
}
function lo(e, t, n, r) {
	const o = ln(n), i = re(t, E), a = re(o, E);
	if (!xn(i, a)) throw new RangeError(`cannot compute difference between months of ${i} and ${a} calendars`);
	const s = ao(e, Zo(r), "date", ["week", "day"], "month", "year"), c = ce("%Temporal.Duration%");
	if (0 == Ro(re(t, D), re(o, D))) return new c();
	const d = en(i, re(t, D), "year-month");
	d.day = 1;
	const h = Ln(i, d, "constrain"), u = en(i, re(o, D), "year-month");
	u.day = 1;
	const l = Ln(i, u, "constrain");
	let m = {
		date: Nt(jn(i, h, l, s.largestUnit), 0, 0),
		time: TimeDuration.ZERO
	};
	if ("month" !== s.smallestUnit || 1 !== s.roundingIncrement) {
		const e = xt(h, {
			deltaDays: 0,
			hour: 0,
			minute: 0,
			second: 0,
			millisecond: 0,
			microsecond: 0,
			nanosecond: 0
		});
		m = no(m, pr(xt(l, {
			deltaDays: 0,
			hour: 0,
			minute: 0,
			second: 0,
			millisecond: 0,
			microsecond: 0,
			nanosecond: 0
		})), e, null, i, s.largestUnit, s.roundingIncrement, s.smallestUnit, s.roundingMode);
	}
	let f = _r(m, "day");
	return "since" === e && (f = Sr(f)), f;
}
function mo(t, n, r, o) {
	const i = fn(r), a = re(n, E), s = re(i, E);
	if (!xn(a, s)) throw new RangeError(`cannot compute difference between dates of ${a} and ${s} calendars`);
	const c = ao(t, Zo(o), "datetime", [], "nanosecond", "hour"), d = re(n, b), h = re(i, b), u = ce("%Temporal.Duration%");
	let l;
	if ("date" !== Vt(c.largestUnit)) l = _r(Xr(d, h, c.roundingIncrement, c.smallestUnit, c.roundingMode), c.largestUnit);
	else {
		const t = re(n, $);
		if (!Zn(t, re(i, $))) throw new RangeError("When calculating difference between time zones, largestUnit must be 'hours' or smaller because day lengths can vary between time zones due to DST or time zone offset changes.");
		if (import_jsbi_umd.default.equal(d, h)) return new u();
		l = _r(io(d, h, t, a, c.largestUnit, c.roundingIncrement, c.smallestUnit, c.roundingMode), "hour");
	}
	return "since" === t && (l = Sr(l)), l;
}
function fo({ hour: e, minute: t, second: n, millisecond: r, microsecond: o, nanosecond: i }, a) {
	let s = n, c = i;
	return s += a.sec, c += a.subsec, Yr(e, t, s, r, o, c);
}
function yo(e, t) {
	const n = t.addToEpochNs(e);
	return Fr(n), n;
}
function po(e, t, n, r, o = "constrain") {
	if (0 === Er(r.date)) return yo(e, r.time);
	const i = zn(t, e);
	return yo(An(t, xt(Sn(n, i.isoDate, r.date, o), i.time), "compatible"), r.time);
}
function go(e, t, n) {
	let r = sn(n);
	"subtract" === e && (r = Sr(r));
	const o = Gt(Jt(t), Jt(r));
	if (Kt(o)) throw new RangeError("For years, months, or weeks arithmetic, use date arithmetic relative to a starting point");
	const i = qr(t), a = qr(r);
	return _r(Jr({
		years: 0,
		months: 0,
		weeks: 0,
		days: 0
	}, i.time.add(a.time)), o);
}
function wo(e, t, n) {
	let r = sn(n);
	"subtract" === e && (r = Sr(r));
	const o = Jt(r);
	if ("date" === Vt(o)) throw new RangeError(`Duration field ${o} not supported by Temporal.Instant. Try Temporal.ZonedDateTime instead.`);
	const i = qr(r);
	return Cn(yo(re(t, b), i.time));
}
function vo(e, t, n, r) {
	const o = re(t, E);
	let i = sn(n);
	"subtract" === e && (i = Sr(i));
	const a = Wr(i), s = Lt(Zo(r));
	return pn(Sn(o, re(t, D), a, s), o);
}
function bo(e, t, n, r) {
	let o = sn(n);
	"subtract" === e && (o = Sr(o));
	const i = Lt(Zo(r)), a = re(t, E), s = qr(o), c = re(t, T), d = fo(c.time, s.time), h = Nt(s.date, d.deltaDays);
	return zr(h.years, h.months, h.weeks, h.days, 0, 0, 0, 0, 0, 0), wn(xt(Sn(a, c.isoDate, h, i), d), a);
}
function Do(e, t, n) {
	let r = sn(n);
	"subtract" === e && (r = Sr(r));
	const o = qr(r), { hour: i, minute: a, second: s, millisecond: c, microsecond: d, nanosecond: h } = fo(re(t, M), o.time);
	return Tn(jt(i, a, s, c, d, h, "reject"));
}
function To(e, t, n, r) {
	let o = sn(n);
	"subtract" === e && (o = Sr(o));
	const i = Lt(Zo(r)), a = Mr(o), s = re(t, E), c = en(s, re(t, D), "year-month");
	c.day = 1;
	let d = Ln(s, c, "constrain");
	if (a < 0) {
		const e = Sn(s, d, { months: 1 }, "constrain");
		d = Or(e.year, e.month, e.day - 1);
	}
	const h = Wr(o);
	return Lr(d), En(Pn(s, en(s, Sn(s, d, h, i), "year-month"), i), s);
}
function Mo(e, t, n, r) {
	let o = sn(n);
	"subtract" === e && (o = Sr(o));
	const i = Lt(Zo(r)), a = re(t, $), s = re(t, E), c = Ar(o);
	return $n(po(re(t, b), a, s, c, i), a, s);
}
function Eo(e, t, n) {
	const r = Math.trunc(e / t), o = e % t, i = e < 0 ? "negative" : "positive", a = Math.abs(r), s = a + 1, c = Bo(Math.abs(2 * o) - t), d = a % 2 == 0, h = ue(n, i), u = 0 === o ? a : le(a, s, c, d, h);
	return t * ("positive" === i ? u : -u);
}
function Io(o, i, a, s) {
	const c = at[a] * i;
	return function(o, i, a) {
		const s = m(o), c = m(i), d = import_jsbi_umd.default.divide(s, c), h = import_jsbi_umd.default.remainder(s, c), u = ue(a, "positive");
		let l, g;
		import_jsbi_umd.default.lessThan(s, t) ? (l = import_jsbi_umd.default.subtract(d, n), g = d) : (l = d, g = import_jsbi_umd.default.add(d, n));
		const w = p(y(import_jsbi_umd.default.multiply(h, r)), c) * (import_jsbi_umd.default.lessThan(s, t) ? -1 : 1) + 0, v = import_jsbi_umd.default.equal(h, t) ? d : le(l, g, w, f(l), u);
		return import_jsbi_umd.default.multiply(v, c);
	}(o, import_jsbi_umd.default.BigInt(c), s);
}
function Co(e, t, n, r) {
	Zr(e);
	const { year: o, month: i, day: a } = e.isoDate, s = Oo(e.time, t, n, r);
	return xt(Or(o, i, a + s.deltaDays), s);
}
function Oo({ hour: e, minute: t, second: n, millisecond: r, microsecond: o, nanosecond: i }, a, s, c) {
	let d;
	switch (s) {
		case "day":
		case "hour":
			d = 1e3 * (1e3 * (1e3 * (60 * (60 * e + t) + n) + r) + o) + i;
			break;
		case "minute":
			d = 1e3 * (1e3 * (1e3 * (60 * t + n) + r) + o) + i;
			break;
		case "second":
			d = 1e3 * (1e3 * (1e3 * n + r) + o) + i;
			break;
		case "millisecond":
			d = 1e3 * (1e3 * r + o) + i;
			break;
		case "microsecond":
			d = 1e3 * o + i;
			break;
		case "nanosecond": d = i;
	}
	const h = at[s], u = Eo(d, h * a, c) / h;
	switch (s) {
		case "day": return {
			deltaDays: u,
			hour: 0,
			minute: 0,
			second: 0,
			millisecond: 0,
			microsecond: 0,
			nanosecond: 0
		};
		case "hour": return Yr(u, 0, 0, 0, 0, 0);
		case "minute": return Yr(e, u, 0, 0, 0, 0);
		case "second": return Yr(e, t, u, 0, 0, 0);
		case "millisecond": return Yr(e, t, n, u, 0, 0);
		case "microsecond": return Yr(e, t, n, r, u, 0);
		case "nanosecond": return Yr(e, t, n, r, o, u);
		default: throw new Error(`Invalid unit ${s}`);
	}
}
function $o(t, n, r, o) {
	const i = at[r];
	return t.round(import_jsbi_umd.default.BigInt(i * n), o);
}
function Yo(t, n) {
	const r = at[n];
	return t.fdiv(import_jsbi_umd.default.BigInt(r));
}
function Ro(e, t) {
	return e.year !== t.year ? Bo(e.year - t.year) : e.month !== t.month ? Bo(e.month - t.month) : e.day !== t.day ? Bo(e.day - t.day) : 0;
}
function So(e, t) {
	return e.hour !== t.hour ? Bo(e.hour - t.hour) : e.minute !== t.minute ? Bo(e.minute - t.minute) : e.second !== t.second ? Bo(e.second - t.second) : e.millisecond !== t.millisecond ? Bo(e.millisecond - t.millisecond) : e.microsecond !== t.microsecond ? Bo(e.microsecond - t.microsecond) : e.nanosecond !== t.nanosecond ? Bo(e.nanosecond - t.nanosecond) : 0;
}
function jo(e, t) {
	const n = Ro(e.isoDate, t.isoDate);
	return 0 !== n ? n : So(e.time, t.time);
}
function ko(e) {
	const t = Lo(e);
	return void 0 !== globalThis.BigInt ? globalThis.BigInt(t.toString(10)) : t;
}
function No(t, n) {
	const { quotient: o, remainder: i } = g(m(t), c);
	let a = import_jsbi_umd.default.toNumber(o);
	return "floor" === n && import_jsbi_umd.default.toNumber(i) < 0 && (a -= 1), "ceil" === n && import_jsbi_umd.default.toNumber(i) > 0 && (a += 1), a;
}
function xo(t) {
	if (!Number.isInteger(t)) throw new RangeError("epoch milliseconds must be an integer");
	return import_jsbi_umd.default.multiply(import_jsbi_umd.default.BigInt(t), c);
}
function Lo(t) {
	let n = t;
	if ("object" == typeof t) {
		const e = t[Symbol.toPrimitive];
		e && "function" == typeof e && (n = e.call(t, "number"));
	}
	if ("number" == typeof n) throw new TypeError("cannot convert number to bigint");
	return "bigint" == typeof n ? import_jsbi_umd.default.BigInt(n.toString(10)) : import_jsbi_umd.default.BigInt(n);
}
const Po = (() => {
	let t = import_jsbi_umd.default.BigInt(Date.now() % 1e6);
	return () => {
		const n = Date.now(), r = import_jsbi_umd.default.BigInt(n), o = import_jsbi_umd.default.add(xo(n), t);
		return t = import_jsbi_umd.default.remainder(r, c), import_jsbi_umd.default.greaterThan(o, Ne) ? Ne : import_jsbi_umd.default.lessThan(o, xe) ? xe : o;
	};
})();
function Uo() {
	return new Intl.DateTimeFormat().resolvedOptions().timeZone;
}
function Bo(e) {
	return e < 0 ? -1 : e > 0 ? 1 : e;
}
function Zo(e) {
	if (void 0 === e) return Object.create(null);
	if (Ae(e) && null !== e) return e;
	throw new TypeError("Options parameter must be an object, not " + (null === e ? "null" : typeof e));
}
function Fo(e, t) {
	const n = Object.create(null);
	return n[e] = t, n;
}
function Ho(e, t, n, r) {
	let o = e[t];
	if (void 0 !== o) {
		if (o = We(o), !n.includes(o)) throw new RangeError(`${t} must be one of ${n.join(", ")}, not ${o}`);
		return o;
	}
	if (r === qt) throw new RangeError(`${t} option is required`);
	return r;
}
function zo(e) {
	const t = Ao(e);
	if (!He.includes(Ao(t))) throw new RangeError(`invalid calendar identifier ${t}`);
	switch (t) {
		case "ethiopic-amete-alem": return "ethioaa";
		case "islamicc": return "islamic-civil";
	}
	return t;
}
function Ao(e) {
	let t = "";
	for (let n = 0; n < e.length; n++) {
		const r = e.charCodeAt(n);
		t += r >= 65 && r <= 90 ? String.fromCharCode(r + 32) : String.fromCharCode(r);
	}
	return t;
}
function qo(e) {
	throw new TypeError(`Do not use built-in arithmetic operators with Temporal objects. When comparing, use ${"PlainMonthDay" === e ? "Temporal.PlainDate.compare(obj1.toPlainDate(year), obj2.toPlainDate(year))" : `Temporal.${e}.compare(obj1, obj2)`}, not obj1 > obj2. When coercing to strings, use \`\${obj}\` or String(obj), not '' + obj. When coercing to numbers, use properties or methods of the object, not \`+obj\`. When concatenating with strings, use \`\${str}\${obj}\` or str.concat(obj), not str + obj. In React, coerce to a string before rendering a Temporal object.`);
}
const Wo = new RegExp(`^${be.source}$`), _o = new RegExp(`^${/([+-])([01][0-9]|2[0-3])(?::?([0-5][0-9])(?::?([0-5][0-9])(?:[.,](\d{1,9}))?)?)?/.source}$`);
function Jo(e, t, n, r = e(t), o = e(n)) {
	let i = t, a = n, s = r, c = o;
	for (; a - i > 1;) {
		let t = Math.trunc((i + a) / 2);
		const n = e(t);
		n === s ? (i = t, s = n) : n === c && (a = t, c = n);
	}
	return a;
}
function Go(e) {
	return [...e];
}
function Ko(e, t) {
	if ("gregory" !== e && "iso8601" !== e) return;
	const n = Xo[e];
	let r = t.year;
	const { dayOfWeek: o, dayOfYear: i, daysInYear: a } = n.isoToDate(t, {
		dayOfWeek: !0,
		dayOfYear: !0,
		daysInYear: !0
	}), s = n.getFirstDayOfWeek(), c = n.getMinimalDaysInFirstWeek();
	let d = (o + 7 - s) % 7, h = (o - i + 7001 - s) % 7, u = Math.floor((i - 1 + h) / 7);
	if (7 - h >= c && ++u, 0 == u) u = function(e, t, n, r) {
		let o = (r - e - n + 1) % 7;
		o < 0 && (o += 7);
		let i = Math.floor((n + o - 1) / 7);
		return 7 - o >= t && ++i, i;
	}(s, c, i + n.isoToDate(n.dateAdd(t, { years: -1 }, "constrain"), { daysInYear: !0 }).daysInYear, o), r--;
	else if (i >= a - 5) {
		let e = (d + a - i) % 7;
		e < 0 && (e += 7), 6 - e >= c && i + 7 - d > a && (u = 1, r++);
	}
	return {
		week: u,
		year: r
	};
}
function Vo(e, t, n, r, o) {
	if (t !== o.year) {
		if (e * (t - o.year) > 0) return !0;
	} else if (n !== o.month) {
		if (e * (n - o.month) > 0) return !0;
	} else if (r !== o.day && e * (r - o.day) > 0) return !0;
	return !1;
}
const Xo = {};
function Qo(e) {
	if (!e.startsWith("M")) throw new RangeError(`Invalid month code: ${e}.  Month codes must start with M.`);
	const t = +e.slice(1);
	if (Number.isNaN(t)) throw new RangeError(`Invalid month code: ${e}`);
	return t;
}
function ei(e, t = !1) {
	return `M${`${e}`.padStart(2, "0")}${t ? "L" : ""}`;
}
function ti(e, t = void 0, n = 12) {
	let { month: r, monthCode: o } = e;
	if (void 0 === o) {
		if (void 0 === r) throw new TypeError("Either month or monthCode are required");
		"reject" === t && Nr(r, 1, n), "constrain" === t && (r = jr(r, 1, n)), o = ei(r);
	} else {
		const e = Qo(o);
		if (o !== ei(e)) throw new RangeError(`Invalid month code: ${o}`);
		if (void 0 !== r && r !== e) throw new RangeError(`monthCode ${o} and month ${r} must match if both are present`);
		if (r = e, r < 1 || r > n) throw new RangeError(`Invalid monthCode: ${o}`);
	}
	return {
		...e,
		month: r,
		monthCode: o
	};
}
Xo.iso8601 = {
	resolveFields(e, t) {
		if (("date" === t || "year-month" === t) && void 0 === e.year) throw new TypeError("year is required");
		if (("date" === t || "month-day" === t) && void 0 === e.day) throw new TypeError("day is required");
		Object.assign(e, ti(e));
	},
	dateToISO: (e, t) => St(e.year, e.month, e.day, t),
	monthDayToISOReferenceDate(e, t) {
		const { month: n, day: r } = St(e.year ?? 1972, e.month, e.day, t);
		return {
			month: n,
			day: r,
			year: 1972
		};
	},
	extraFields: () => [],
	fieldKeysToIgnore(e) {
		const t = /* @__PURE__ */ new Set();
		for (let n = 0; n < e.length; n++) {
			const r = e[n];
			t.add(r), "month" === r ? t.add("monthCode") : "monthCode" === r && t.add("month");
		}
		return Go(t);
	},
	dateAdd(e, { years: t = 0, months: n = 0, weeks: r = 0, days: o = 0 }, i) {
		let { year: a, month: s, day: c } = e;
		return a += t, s += n, {year: a, month: s} = Cr(a, s), {year: a, month: s, day: c} = St(a, s, c, i), c += o + 7 * r, Or(a, s, c);
	},
	dateUntil(e, t, n) {
		const r = -Ro(e, t);
		if (0 === r) return {
			years: 0,
			months: 0,
			weeks: 0,
			days: 0
		};
		let o, i = 0, a = 0;
		if ("year" === n || "month" === n) {
			let s = t.year - e.year;
			for (0 !== s && (s -= r); !Vo(r, e.year + s, e.month, e.day, t);) i = s, s += r;
			let c = r;
			for (o = Cr(e.year + i, e.month + c); !Vo(r, o.year, o.month, e.day, t);) a = c, c += r, o = Cr(o.year, o.month + r);
			"month" === n && (a += 12 * i, i = 0);
		}
		o = Cr(e.year + i, e.month + a);
		const s = kr(o.year, o.month, e.day);
		let c = 0, d = Gr(t.year, t.month - 1, t.day) - Gr(s.year, s.month - 1, s.day);
		return "week" === n && (c = Math.trunc(d / 7), d %= 7), {
			years: i,
			months: a,
			weeks: c,
			days: d
		};
	},
	isoToDate({ year: e, month: t, day: n }, r) {
		const o = {
			era: void 0,
			eraYear: void 0,
			year: e,
			month: t,
			day: n,
			daysInWeek: 7,
			monthsInYear: 12
		};
		if (r.monthCode && (o.monthCode = ei(t)), r.dayOfWeek) {
			const r = t + (t < 3 ? 10 : -2), i = e - (t < 3 ? 1 : 0), a = Math.floor(i / 100), s = i - 100 * a, c = (n + Math.floor(2.6 * r - .2) + (s + Math.floor(s / 4)) + (Math.floor(a / 4) - 2 * a)) % 7;
			o.dayOfWeek = c + (c <= 0 ? 7 : 0);
		}
		if (r.dayOfYear) {
			let r = n;
			for (let n = t - 1; n > 0; n--) r += Tr(e, n);
			o.dayOfYear = r;
		}
		return r.weekOfYear && (o.weekOfYear = Ko("iso8601", {
			year: e,
			month: t,
			day: n
		})), r.daysInMonth && (o.daysInMonth = Tr(e, t)), (r.daysInYear || r.inLeapYear) && (o.inLeapYear = Dr(e), o.daysInYear = o.inLeapYear ? 366 : 365), o;
	},
	getFirstDayOfWeek: () => 1,
	getMinimalDaysInFirstWeek: () => 4
};
var OneObjectCache = class OneObjectCache {
	constructor(e) {
		if (this.map = /* @__PURE__ */ new Map(), this.calls = 0, this.hits = 0, this.misses = 0, void 0 !== e) {
			let t = 0;
			for (const n of e.map.entries()) {
				if (++t > OneObjectCache.MAX_CACHE_ENTRIES) break;
				this.map.set(...n);
			}
		}
	}
	get(e) {
		const t = this.map.get(e);
		return t && (this.hits++, this.report()), this.calls++, t;
	}
	set(e, t) {
		this.map.set(e, t), this.misses++, this.report();
	}
	report() {}
	setObject(e) {
		if (OneObjectCache.objectMap.get(e)) throw new RangeError("object already cached");
		OneObjectCache.objectMap.set(e, this), this.report();
	}
	static getCacheForObject(e) {
		let t = OneObjectCache.objectMap.get(e);
		return t || (t = new OneObjectCache(), OneObjectCache.objectMap.set(e, t)), t;
	}
};
function ni({ isoYear: e, isoMonth: t, isoDay: n }) {
	return `${Jn(e)}-${Gn(t)}-${Gn(n)}T00:00Z`;
}
function ri(e, t) {
	return {
		years: e.year - t.year,
		months: e.month - t.month,
		days: e.day - t.day
	};
}
OneObjectCache.objectMap = /* @__PURE__ */ new WeakMap(), OneObjectCache.MAX_CACHE_ENTRIES = 1e3;
var HelperBase = class {
	constructor() {
		this.eras = [], this.hasEra = !1, this.erasBeginMidYear = !1;
	}
	getFormatter() {
		return void 0 === this.formatter && (this.formatter = new Intl.DateTimeFormat(`en-US-u-ca-${this.id}`, {
			day: "numeric",
			month: "numeric",
			year: "numeric",
			era: "short",
			timeZone: "UTC"
		})), this.formatter;
	}
	getCalendarParts(e) {
		let t = this.getFormatter(), n = new Date(e);
		if ("-271821-04-19T00:00Z" === e) {
			const e = t.resolvedOptions();
			t = new Intl.DateTimeFormat(e.locale, {
				...e,
				timeZone: "Etc/GMT+1"
			}), n = /* @__PURE__ */ new Date("-271821-04-20T00:00Z");
		}
		try {
			return t.formatToParts(n);
		} catch (t) {
			throw new RangeError(`Invalid ISO date: ${e}`);
		}
	}
	isoToCalendarDate(e, t) {
		const { year: n, month: r, day: o } = e, i = JSON.stringify({
			func: "isoToCalendarDate",
			isoYear: n,
			isoMonth: r,
			isoDay: o,
			id: this.id
		}), a = t.get(i);
		if (a) return a;
		const s = ni({
			isoYear: n,
			isoMonth: r,
			isoDay: o
		}), c = this.getCalendarParts(s), d = {};
		for (let e = 0; e < c.length; e++) {
			const { type: t, value: n } = c[e];
			if ("year" !== t && "relatedYear" !== t || (this.hasEra ? d.eraYear = +n : d.year = +n), "month" === t) {
				const e = /^([0-9]*)(.*?)$/.exec(n);
				if (!e || 3 != e.length || !e[1] && !e[2]) throw new RangeError(`Unexpected month: ${n}`);
				if (d.month = e[1] ? +e[1] : 1, d.month < 1) throw new RangeError(`Invalid month ${n} from ${s}[u-ca-${this.id}] (probably due to https://bugs.chromium.org/p/v8/issues/detail?id=10527)`);
				if (d.month > 13) throw new RangeError(`Invalid month ${n} from ${s}[u-ca-${this.id}] (probably due to https://bugs.chromium.org/p/v8/issues/detail?id=10529)`);
				e[2] && (d.monthExtra = e[2]);
			}
			"day" === t && (d.day = +n), this.hasEra && "era" === t && null != n && "" !== n && (d.era = n.split(" (")[0].normalize("NFD").replace(/[^-0-9 \p{L}]/gu, "").replace(/ /g, "-").toLowerCase());
		}
		if (this.hasEra && void 0 === d.eraYear) throw new RangeError(`Intl.DateTimeFormat.formatToParts lacks relatedYear in ${this.id} calendar. Try Node 14+ or modern browsers.`);
		if (this.hasEra) {
			const e = this.eras.find(((e) => d.era === e.genericName));
			e && (d.era = e.code);
		}
		if (this.reviseIntlEra) {
			const { era: t, eraYear: n } = this.reviseIntlEra(d, e);
			d.era = t, d.eraYear = n;
		}
		this.checkIcuBugs && this.checkIcuBugs(e);
		const h = this.adjustCalendarDate(d, t, "constrain", !0);
		if (void 0 === h.year) throw new RangeError(`Missing year converting ${JSON.stringify(e)}`);
		if (void 0 === h.month) throw new RangeError(`Missing month converting ${JSON.stringify(e)}`);
		if (void 0 === h.day) throw new RangeError(`Missing day converting ${JSON.stringify(e)}`);
		return t.set(i, h), ["constrain", "reject"].forEach(((n) => {
			const r = JSON.stringify({
				func: "calendarToIsoDate",
				year: h.year,
				month: h.month,
				day: h.day,
				overflow: n,
				id: this.id
			});
			t.set(r, e);
		})), h;
	}
	validateCalendarDate(e) {
		const { month: t, year: n, day: r, eraYear: o, monthCode: i, monthExtra: a } = e;
		if (void 0 !== a) throw new RangeError("Unexpected `monthExtra` value");
		if (void 0 === n && void 0 === o) throw new TypeError("year or eraYear is required");
		if (void 0 === t && void 0 === i) throw new TypeError("month or monthCode is required");
		if (void 0 === r) throw new RangeError("Missing day");
		if (void 0 !== i) {
			if ("string" != typeof i) throw new RangeError("monthCode must be a string, not " + typeof i);
			if (!/^M([01]?\d)(L?)$/.test(i)) throw new RangeError(`Invalid monthCode: ${i}`);
		}
		if (this.hasEra && void 0 === e.era != (void 0 === e.eraYear)) throw new TypeError("properties era and eraYear must be provided together");
	}
	adjustCalendarDate(e, t = void 0, n = "constrain", r = !1) {
		if ("lunisolar" === this.calendarType) throw new RangeError("Override required for lunisolar calendars");
		let o = e;
		this.validateCalendarDate(o);
		const i = this.monthsInYear(o, t);
		let { month: a, monthCode: s } = o;
		return {month: a, monthCode: s} = ti(o, n, i), {
			...o,
			month: a,
			monthCode: s
		};
	}
	regulateMonthDayNaive(e, t, n) {
		const r = this.monthsInYear(e, n);
		let { month: o, day: i } = e;
		return "reject" === t ? (Nr(o, 1, r), Nr(i, 1, this.maximumMonthLength(e))) : (o = jr(o, 1, r), i = jr(i, 1, this.maximumMonthLength({
			...e,
			month: o
		}))), {
			...e,
			month: o,
			day: i
		};
	}
	calendarToIsoDate(e, t = "constrain", n) {
		const r = e;
		let o = this.adjustCalendarDate(e, n, t, !1);
		o = this.regulateMonthDayNaive(o, t, n);
		const { year: i, month: a, day: s } = o, c = JSON.stringify({
			func: "calendarToIsoDate",
			year: i,
			month: a,
			day: s,
			overflow: t,
			id: this.id
		});
		let d, h = n.get(c);
		if (h) return h;
		if (void 0 !== r.year && void 0 !== r.month && void 0 !== r.day && (r.year !== o.year || r.month !== o.month || r.day !== o.day) && (d = JSON.stringify({
			func: "calendarToIsoDate",
			year: r.year,
			month: r.month,
			day: r.day,
			overflow: t,
			id: this.id
		}), h = n.get(d), h)) return h;
		let u = this.estimateIsoDate({
			year: i,
			month: a,
			day: s
		});
		const l = (e) => {
			let r = this.addDaysIso(u, e);
			if (o.day > this.minimumMonthLength(o)) {
				let e = this.isoToCalendarDate(r, n);
				for (; e.month !== a || e.year !== i;) {
					if ("reject" === t) throw new RangeError(`day ${s} does not exist in month ${a} of year ${i}`);
					r = this.addDaysIso(r, -1), e = this.isoToCalendarDate(r, n);
				}
			}
			return r;
		};
		let m = 0, f = this.isoToCalendarDate(u, n), y = ri(o, f);
		if (0 !== y.years || 0 !== y.months || 0 !== y.days) {
			const e = 365 * y.years + 30 * y.months + y.days;
			u = this.addDaysIso(u, e), f = this.isoToCalendarDate(u, n), y = ri(o, f), 0 === y.years && 0 === y.months ? u = l(y.days) : m = this.compareCalendarDates(o, f);
		}
		let p = 8;
		for (; m;) {
			u = this.addDaysIso(u, m * p);
			const e = f;
			f = this.isoToCalendarDate(u, n);
			const i = m;
			if (m = this.compareCalendarDates(o, f), m) {
				if (y = ri(o, f), 0 === y.years && 0 === y.months) u = l(y.days), m = 0;
				else if (i && m !== i) if (p > 1) p /= 2;
				else {
					if ("reject" === t) throw new RangeError(`Can't find ISO date from calendar date: ${JSON.stringify({ ...r })}`);
					this.compareCalendarDates(f, e) > 0 && (u = this.addDaysIso(u, -1)), m = 0;
				}
			}
		}
		if (n.set(c, u), d && n.set(d, u), void 0 === o.year || void 0 === o.month || void 0 === o.day || void 0 === o.monthCode || this.hasEra && (void 0 === o.era || void 0 === o.eraYear)) throw new RangeError("Unexpected missing property");
		return u;
	}
	compareCalendarDates(e, t) {
		return e.year !== t.year ? Bo(e.year - t.year) : e.month !== t.month ? Bo(e.month - t.month) : e.day !== t.day ? Bo(e.day - t.day) : 0;
	}
	regulateDate(e, t = "constrain", n) {
		const r = this.calendarToIsoDate(e, t, n);
		return this.isoToCalendarDate(r, n);
	}
	addDaysIso(e, t) {
		return Or(e.year, e.month, e.day + t);
	}
	addDaysCalendar(e, t, n) {
		const r = this.calendarToIsoDate(e, "constrain", n), o = this.addDaysIso(r, t);
		return this.isoToCalendarDate(o, n);
	}
	addMonthsCalendar(e, t, n, r) {
		let o = e;
		const { day: i } = o;
		for (let e = 0, n = Math.abs(t); e < n; e++) {
			const { month: e } = o, n = o, a = t < 0 ? -Math.max(i, this.daysInPreviousMonth(o, r)) : this.daysInMonth(o, r), s = this.calendarToIsoDate(o, "constrain", r);
			let c = this.addDaysIso(s, a);
			if (o = this.isoToCalendarDate(c, r), t > 0) {
				const t = this.monthsInYear(n, r);
				for (; o.month - 1 != e % t;) c = this.addDaysIso(c, -1), o = this.isoToCalendarDate(c, r);
			}
			o.day !== i && (o = this.regulateDate({
				...o,
				day: i
			}, "constrain", r));
		}
		if ("reject" === n && o.day !== i) throw new RangeError(`Day ${i} does not exist in resulting calendar month`);
		return o;
	}
	addCalendar(e, { years: t = 0, months: n = 0, weeks: r = 0, days: o = 0 }, i, a) {
		const { year: s, day: c, monthCode: d } = e, h = this.adjustCalendarDate({
			year: s + t,
			monthCode: d,
			day: c
		}, a), u = this.addMonthsCalendar(h, n, i, a), l = o + 7 * r;
		return this.addDaysCalendar(u, l, a);
	}
	untilCalendar(e, t, n, r) {
		let o = 0, i = 0, a = 0, s = 0;
		switch (n) {
			case "day":
				o = this.calendarDaysUntil(e, t, r);
				break;
			case "week": {
				const n = this.calendarDaysUntil(e, t, r);
				o = n % 7, i = (n - o) / 7;
				break;
			}
			case "month":
			case "year": {
				const i = this.compareCalendarDates(t, e);
				if (!i) return {
					years: 0,
					months: 0,
					weeks: 0,
					days: 0
				};
				const c = t.year - e.year, d = t.day - e.day;
				if ("year" === n && c) {
					let n = 0;
					t.monthCode > e.monthCode && (n = 1), t.monthCode < e.monthCode && (n = -1), n || (n = Math.sign(d)), s = n * i < 0 ? c - i : c;
				}
				let h, u = s ? this.addCalendar(e, { years: s }, "constrain", r) : e;
				do
					a += i, h = u, u = this.addMonthsCalendar(h, i, "constrain", r), u.day !== e.day && (u = this.regulateDate({
						...u,
						day: e.day
					}, "constrain", r));
				while (this.compareCalendarDates(t, u) * i >= 0);
				a -= i, o = this.calendarDaysUntil(h, t, r);
				break;
			}
		}
		return {
			years: s,
			months: a,
			weeks: i,
			days: o
		};
	}
	daysInMonth(e, t) {
		const { day: n } = e, r = this.maximumMonthLength(e), o = this.minimumMonthLength(e);
		if (o === r) return o;
		const i = n <= r - o ? r : o, a = this.calendarToIsoDate(e, "constrain", t), s = this.addDaysIso(a, i), c = this.isoToCalendarDate(s, t), d = this.addDaysIso(s, -c.day);
		return this.isoToCalendarDate(d, t).day;
	}
	daysInPreviousMonth(e, t) {
		const { day: n, month: r, year: o } = e;
		let i = {
			year: r > 1 ? o : o - 1,
			month: r,
			day: 1
		};
		const a = r > 1 ? r - 1 : this.monthsInYear(i, t);
		i = {
			...i,
			month: a
		};
		const s = this.minimumMonthLength(i), c = this.maximumMonthLength(i);
		if (s === c) return c;
		const d = this.calendarToIsoDate(e, "constrain", t), h = this.addDaysIso(d, -n);
		return this.isoToCalendarDate(h, t).day;
	}
	startOfCalendarYear(e) {
		return {
			year: e.year,
			month: 1,
			monthCode: "M01",
			day: 1
		};
	}
	startOfCalendarMonth(e) {
		return {
			year: e.year,
			month: e.month,
			day: 1
		};
	}
	calendarDaysUntil(e, t, n) {
		const r = this.calendarToIsoDate(e, "constrain", n), o = this.calendarToIsoDate(t, "constrain", n);
		return Gr(o.year, o.month - 1, o.day) - Gr(r.year, r.month - 1, r.day);
	}
	monthDaySearchStartYear(e, t) {
		return 1972;
	}
	monthDayFromFields(e, t, n) {
		let r, o, i, a, s, { era: c, eraYear: d, year: h, month: u, monthCode: l, day: m } = e;
		if (void 0 !== u && void 0 === h && (!this.hasEra || void 0 === c || void 0 === d)) throw new TypeError("when month is present, year (or era and eraYear) are required");
		(void 0 === l || void 0 !== h || this.hasEra && void 0 !== d) && ({monthCode: l, day: m} = this.isoToCalendarDate(this.calendarToIsoDate(e, t, n), n));
		const f = {
			year: this.monthDaySearchStartYear(l, m),
			month: 12,
			day: 31
		}, y = this.isoToCalendarDate(f, n), p = y.monthCode > l || y.monthCode === l && y.day >= m ? y.year : y.year - 1;
		for (let e = 0; e < 20; e++) {
			const c = this.adjustCalendarDate({
				day: m,
				monthCode: l,
				year: p - e
			}, n), d = this.calendarToIsoDate(c, "constrain", n), h = this.isoToCalendarDate(d, n);
			if ({year: r, month: o, day: i} = d, h.monthCode === l && h.day === m) return {
				month: o,
				day: i,
				year: r
			};
			if ("constrain" === t) {
				const e = this.maxLengthOfMonthCodeInAnyYear(h.monthCode);
				if (h.monthCode === l && h.day === e && m > e) return {
					month: o,
					day: i,
					year: r
				};
				(void 0 === a || h.monthCode === a.monthCode && h.day > a.day) && (a = h, s = d);
			}
		}
		if ("constrain" === t && void 0 !== s) return s;
		throw new RangeError(`No recent ${this.id} year with monthCode ${l} and day ${m}`);
	}
	getFirstDayOfWeek() {}
	getMinimalDaysInFirstWeek() {}
};
var HebrewHelper = class extends HelperBase {
	constructor() {
		super(...arguments), this.id = "hebrew", this.calendarType = "lunisolar", this.months = {
			Tishri: {
				leap: 1,
				regular: 1,
				monthCode: "M01",
				days: 30
			},
			Heshvan: {
				leap: 2,
				regular: 2,
				monthCode: "M02",
				days: {
					min: 29,
					max: 30
				}
			},
			Kislev: {
				leap: 3,
				regular: 3,
				monthCode: "M03",
				days: {
					min: 29,
					max: 30
				}
			},
			Tevet: {
				leap: 4,
				regular: 4,
				monthCode: "M04",
				days: 29
			},
			Shevat: {
				leap: 5,
				regular: 5,
				monthCode: "M05",
				days: 30
			},
			Adar: {
				leap: void 0,
				regular: 6,
				monthCode: "M06",
				days: 29
			},
			"Adar I": {
				leap: 6,
				regular: void 0,
				monthCode: "M05L",
				days: 30
			},
			"Adar II": {
				leap: 7,
				regular: void 0,
				monthCode: "M06",
				days: 29
			},
			Nisan: {
				leap: 8,
				regular: 7,
				monthCode: "M07",
				days: 30
			},
			Iyar: {
				leap: 9,
				regular: 8,
				monthCode: "M08",
				days: 29
			},
			Sivan: {
				leap: 10,
				regular: 9,
				monthCode: "M09",
				days: 30
			},
			Tamuz: {
				leap: 11,
				regular: 10,
				monthCode: "M10",
				days: 29
			},
			Av: {
				leap: 12,
				regular: 11,
				monthCode: "M11",
				days: 30
			},
			Elul: {
				leap: 13,
				regular: 12,
				monthCode: "M12",
				days: 29
			}
		};
	}
	inLeapYear(e) {
		const { year: t } = e;
		return (7 * t + 1) % 19 < 7;
	}
	monthsInYear(e) {
		return this.inLeapYear(e) ? 13 : 12;
	}
	minimumMonthLength(e) {
		return this.minMaxMonthLength(e, "min");
	}
	maximumMonthLength(e) {
		return this.minMaxMonthLength(e, "max");
	}
	minMaxMonthLength(e, t) {
		const { month: n, year: r } = e, o = this.getMonthCode(r, n), i = Object.entries(this.months).find(((e) => e[1].monthCode === o));
		if (void 0 === i) throw new RangeError(`unmatched Hebrew month: ${n}`);
		const a = i[1].days;
		return "number" == typeof a ? a : a[t];
	}
	maxLengthOfMonthCodeInAnyYear(e) {
		return [
			"M04",
			"M06",
			"M08",
			"M10",
			"M12"
		].includes(e) ? 29 : 30;
	}
	estimateIsoDate(e) {
		const { year: t } = e;
		return {
			year: t - 3760,
			month: 1,
			day: 1
		};
	}
	getMonthCode(e, t) {
		return this.inLeapYear({ year: e }) ? 6 === t ? ei(5, !0) : ei(t < 6 ? t : t - 1) : ei(t);
	}
	adjustCalendarDate(e, t, n = "constrain", r = !1) {
		let { year: o, month: i, monthCode: a, day: s, monthExtra: c } = e;
		if (void 0 === o) throw new TypeError("Missing property: year");
		if (r) {
			if (c) {
				const e = this.months[c];
				if (!e) throw new RangeError(`Unrecognized month from formatToParts: ${c}`);
				i = this.inLeapYear({ year: o }) ? e.leap : e.regular;
			}
			return a = this.getMonthCode(o, i), {
				year: o,
				month: i,
				day: s,
				monthCode: a
			};
		}
		if (this.validateCalendarDate(e), void 0 === i) if (a.endsWith("L")) {
			if ("M05L" !== a) throw new RangeError(`Hebrew leap month must have monthCode M05L, not ${a}`);
			if (i = 6, !this.inLeapYear({ year: o })) {
				if ("reject" === n) throw new RangeError(`Hebrew monthCode M05L is invalid in year ${o} which is not a leap year`);
				i = 6, a = "M06";
			}
		} else {
			i = Qo(a), this.inLeapYear({ year: o }) && i >= 6 && i++;
			const e = this.monthsInYear({ year: o });
			if (i < 1 || i > e) throw new RangeError(`Invalid monthCode: ${a}`);
		}
		else if ("reject" === n ? (Nr(i, 1, this.monthsInYear({ year: o })), Nr(s, 1, this.maximumMonthLength({
			year: o,
			month: i
		}))) : (i = jr(i, 1, this.monthsInYear({ year: o })), s = jr(s, 1, this.maximumMonthLength({
			year: o,
			month: i
		}))), void 0 === a) a = this.getMonthCode(o, i);
		else if (this.getMonthCode(o, i) !== a) throw new RangeError(`monthCode ${a} doesn't correspond to month ${i} in Hebrew year ${o}`);
		return {
			...e,
			day: s,
			month: i,
			monthCode: a,
			year: o
		};
	}
};
var IslamicBaseHelper = class extends HelperBase {
	constructor() {
		super(...arguments), this.calendarType = "lunar", this.DAYS_PER_ISLAMIC_YEAR = 354.3666666666667, this.DAYS_PER_ISO_YEAR = 365.2425;
	}
	inLeapYear(e, t) {
		const n = {
			year: e.year,
			month: 1,
			monthCode: "M01",
			day: 1
		}, r = {
			year: e.year + 1,
			month: 1,
			monthCode: "M01",
			day: 1
		};
		return 355 === this.calendarDaysUntil(n, r, t);
	}
	monthsInYear() {
		return 12;
	}
	minimumMonthLength() {
		return 29;
	}
	maximumMonthLength() {
		return 30;
	}
	maxLengthOfMonthCodeInAnyYear() {
		return 30;
	}
	estimateIsoDate(e) {
		const { year: t } = this.adjustCalendarDate(e);
		return {
			year: Math.floor(t * this.DAYS_PER_ISLAMIC_YEAR / this.DAYS_PER_ISO_YEAR) + 622,
			month: 1,
			day: 1
		};
	}
};
var IslamicHelper = class extends IslamicBaseHelper {
	constructor() {
		super(...arguments), this.id = "islamic";
	}
};
var IslamicUmalquraHelper = class extends IslamicBaseHelper {
	constructor() {
		super(...arguments), this.id = "islamic-umalqura";
	}
};
var IslamicTblaHelper = class extends IslamicBaseHelper {
	constructor() {
		super(...arguments), this.id = "islamic-tbla";
	}
};
var IslamicCivilHelper = class extends IslamicBaseHelper {
	constructor() {
		super(...arguments), this.id = "islamic-civil";
	}
};
var IslamicRgsaHelper = class extends IslamicBaseHelper {
	constructor() {
		super(...arguments), this.id = "islamic-rgsa";
	}
};
var IslamicCcHelper = class extends IslamicBaseHelper {
	constructor() {
		super(...arguments), this.id = "islamicc";
	}
};
var PersianHelper = class extends HelperBase {
	constructor() {
		super(...arguments), this.id = "persian", this.calendarType = "solar";
	}
	inLeapYear(e, t) {
		return 30 === this.daysInMonth({
			year: e.year,
			month: 12,
			day: 1
		}, t);
	}
	monthsInYear() {
		return 12;
	}
	minimumMonthLength(e) {
		const { month: t } = e;
		return 12 === t ? 29 : t <= 6 ? 31 : 30;
	}
	maximumMonthLength(e) {
		const { month: t } = e;
		return 12 === t ? 30 : t <= 6 ? 31 : 30;
	}
	maxLengthOfMonthCodeInAnyYear(e) {
		return Qo(e) <= 6 ? 31 : 30;
	}
	estimateIsoDate(e) {
		const { year: t } = this.adjustCalendarDate(e);
		return {
			year: t + 621,
			month: 1,
			day: 1
		};
	}
};
var IndianHelper = class extends HelperBase {
	constructor() {
		super(...arguments), this.id = "indian", this.calendarType = "solar", this.months = {
			1: {
				length: 30,
				month: 3,
				day: 22,
				leap: {
					length: 31,
					month: 3,
					day: 21
				}
			},
			2: {
				length: 31,
				month: 4,
				day: 21
			},
			3: {
				length: 31,
				month: 5,
				day: 22
			},
			4: {
				length: 31,
				month: 6,
				day: 22
			},
			5: {
				length: 31,
				month: 7,
				day: 23
			},
			6: {
				length: 31,
				month: 8,
				day: 23
			},
			7: {
				length: 30,
				month: 9,
				day: 23
			},
			8: {
				length: 30,
				month: 10,
				day: 23
			},
			9: {
				length: 30,
				month: 11,
				day: 22
			},
			10: {
				length: 30,
				month: 12,
				day: 22
			},
			11: {
				length: 30,
				month: 1,
				nextYear: !0,
				day: 21
			},
			12: {
				length: 30,
				month: 2,
				nextYear: !0,
				day: 20
			}
		}, this.vulnerableToBceBug = "10/11/-79 Saka" !== (/* @__PURE__ */ new Date("0000-01-01T00:00Z")).toLocaleDateString("en-US-u-ca-indian", { timeZone: "UTC" });
	}
	inLeapYear(e) {
		return oi(e.year + 78);
	}
	monthsInYear() {
		return 12;
	}
	minimumMonthLength(e) {
		return this.getMonthInfo(e).length;
	}
	maximumMonthLength(e) {
		return this.getMonthInfo(e).length;
	}
	maxLengthOfMonthCodeInAnyYear(e) {
		const t = Qo(e);
		let n = this.months[t];
		return n = n.leap ?? n, n.length;
	}
	getMonthInfo(e) {
		const { month: t } = e;
		let n = this.months[t];
		if (void 0 === n) throw new RangeError(`Invalid month: ${t}`);
		return this.inLeapYear(e) && n.leap && (n = n.leap), n;
	}
	estimateIsoDate(e) {
		const t = this.adjustCalendarDate(e), n = this.getMonthInfo(t);
		return Or(t.year + 78 + (n.nextYear ? 1 : 0), n.month, n.day + t.day - 1);
	}
	checkIcuBugs(e) {
		if (this.vulnerableToBceBug && e.year < 1) throw new RangeError(`calendar '${this.id}' is broken for ISO dates before 0001-01-01 (see https://bugs.chromium.org/p/v8/issues/detail?id=10529)`);
	}
};
function oi(e) {
	return e % 4 == 0 && (e % 100 != 0 || e % 400 == 0);
}
var GregorianBaseHelperFixedEpoch = class extends HelperBase {
	constructor(e, t) {
		super(), this.calendarType = "solar", this.id = e, this.isoEpoch = t;
	}
	inLeapYear(e) {
		const { year: t } = this.estimateIsoDate({
			month: 1,
			day: 1,
			year: e.year
		});
		return oi(t);
	}
	monthsInYear() {
		return 12;
	}
	minimumMonthLength(e) {
		const { month: t } = e;
		return 2 === t ? this.inLeapYear(e) ? 29 : 28 : [
			4,
			6,
			9,
			11
		].indexOf(t) >= 0 ? 30 : 31;
	}
	maximumMonthLength(e) {
		return this.minimumMonthLength(e);
	}
	maxLengthOfMonthCodeInAnyYear(e) {
		return [
			31,
			29,
			31,
			30,
			31,
			30,
			31,
			31,
			30,
			31,
			30,
			31
		][Qo(e) - 1];
	}
	estimateIsoDate(e) {
		const t = this.adjustCalendarDate(e);
		return St(t.year + this.isoEpoch.year, t.month + this.isoEpoch.month, t.day + this.isoEpoch.day, "constrain");
	}
};
var GregorianBaseHelper = class extends HelperBase {
	constructor(e, t) {
		super(), this.hasEra = !0, this.calendarType = "solar", this.id = e;
		const { eras: n, anchorEra: r } = function(e) {
			let t, n = e;
			if (0 === n.length) throw new RangeError("Invalid era data: eras are required");
			if (1 === n.length && n[0].reverseOf) throw new RangeError("Invalid era data: anchor era cannot count years backwards");
			if (1 === n.length && !n[0].code) throw new RangeError("Invalid era data: at least one named era is required");
			if (n.filter(((e) => null != e.reverseOf)).length > 1) throw new RangeError("Invalid era data: only one era can count years backwards");
			n.forEach(((e) => {
				if (e.isAnchor || !e.anchorEpoch && !e.reverseOf) {
					if (t) throw new RangeError("Invalid era data: cannot have multiple anchor eras");
					t = e, e.anchorEpoch = { year: e.hasYearZero ? 0 : 1 };
				} else if (!e.code) throw new RangeError("If era name is blank, it must be the anchor era");
			})), n = n.filter(((e) => e.code)), n.forEach(((e) => {
				const { reverseOf: t } = e;
				if (t) {
					const r = n.find(((e) => e.code === t));
					if (void 0 === r) throw new RangeError(`Invalid era data: unmatched reverseOf era: ${t}`);
					e.reverseOf = r, e.anchorEpoch = r.anchorEpoch, e.isoEpoch = r.isoEpoch;
				}
				void 0 === e.anchorEpoch.month && (e.anchorEpoch.month = 1), void 0 === e.anchorEpoch.day && (e.anchorEpoch.day = 1);
			})), n.sort(((e, t) => {
				if (e.reverseOf) return 1;
				if (t.reverseOf) return -1;
				if (!e.isoEpoch || !t.isoEpoch) throw new RangeError("Invalid era data: missing ISO epoch");
				return t.isoEpoch.year - e.isoEpoch.year;
			}));
			const r = n[n.length - 1].reverseOf;
			if (r && r !== n[n.length - 2]) throw new RangeError("Invalid era data: invalid reverse-sign era");
			return n.forEach(((e, t) => {
				e.genericName = "era" + (n.length - 1 - t);
			})), {
				eras: n,
				anchorEra: t || n[0]
			};
		}(t);
		this.anchorEra = r, this.eras = n;
	}
	inLeapYear(e) {
		const { year: t } = this.estimateIsoDate({
			month: 1,
			day: 1,
			year: e.year
		});
		return oi(t);
	}
	monthsInYear() {
		return 12;
	}
	minimumMonthLength(e) {
		const { month: t } = e;
		return 2 === t ? this.inLeapYear(e) ? 29 : 28 : [
			4,
			6,
			9,
			11
		].indexOf(t) >= 0 ? 30 : 31;
	}
	maximumMonthLength(e) {
		return this.minimumMonthLength(e);
	}
	maxLengthOfMonthCodeInAnyYear(e) {
		return [
			31,
			29,
			31,
			30,
			31,
			30,
			31,
			31,
			30,
			31,
			30,
			31
		][Qo(e) - 1];
	}
	completeEraYear(e) {
		const t = (t, n, r) => {
			const o = e[t];
			if (null != o && o != n && !(r || []).includes(o)) {
				const e = r?.[0];
				throw new RangeError(`Input ${t} ${o} doesn't match calculated value ${e ? `${n} (also called ${e})` : n}`);
			}
		}, n = (t) => {
			let n;
			const r = {
				...e,
				year: t
			}, o = this.eras.find(((e, o) => {
				if (o === this.eras.length - 1) {
					if (e.reverseOf) {
						if (t > 0) throw new RangeError(`Signed year ${t} is invalid for era ${e.code}`);
						return n = e.anchorEpoch.year - t, !0;
					}
					return n = t - e.anchorEpoch.year + (e.hasYearZero ? 0 : 1), !0;
				}
				return this.compareCalendarDates(r, e.anchorEpoch) >= 0 && (n = t - e.anchorEpoch.year + (e.hasYearZero ? 0 : 1), !0);
			}));
			if (!o) throw new RangeError(`Year ${t} was not matched by any era`);
			return {
				eraYear: n,
				era: o.code,
				eraNames: o.names
			};
		};
		let { year: r, eraYear: o, era: i } = e;
		if (null != r) {
			const e = n(r);
			({eraYear: o, era: i} = e), t("era", i, e?.eraNames), t("eraYear", o);
		} else {
			if (null == o) throw new RangeError("Either year or eraYear and era are required");
			{
				if (void 0 === i) throw new RangeError("era and eraYear must be provided together");
				const e = this.eras.find((({ code: e, names: t = [] }) => e === i || t.includes(i)));
				if (!e) throw new RangeError(`Era ${i} (ISO year ${o}) was not matched by any era`);
				r = e.reverseOf ? e.anchorEpoch.year - o : o + e.anchorEpoch.year - (e.hasYearZero ? 0 : 1), t("year", r), {eraYear: o, era: i} = n(r);
			}
		}
		return {
			...e,
			year: r,
			eraYear: o,
			era: i
		};
	}
	adjustCalendarDate(e, t, n = "constrain") {
		let r = e;
		const { month: o, monthCode: i } = r;
		return void 0 === o && (r = {
			...r,
			month: Qo(i)
		}), this.validateCalendarDate(r), r = this.completeEraYear(r), super.adjustCalendarDate(r, t, n);
	}
	estimateIsoDate(e) {
		const { year: n, month: r, day: o } = this.adjustCalendarDate(e), { anchorEra: i } = this;
		return St(n + i.isoEpoch.year - (i.hasYearZero ? 0 : 1), r, o, "constrain");
	}
};
var SameMonthDayAsGregorianBaseHelper = class extends GregorianBaseHelper {
	constructor(e, t) {
		super(e, t);
	}
	isoToCalendarDate(e) {
		const { year: t, month: n, day: r } = e, o = ei(n), i = t - this.anchorEra.isoEpoch.year + 1;
		return this.completeEraYear({
			year: i,
			month: n,
			monthCode: o,
			day: r
		});
	}
};
const ii = {
	inLeapYear(e) {
		const { year: t } = e;
		return (t + 1) % 4 == 0;
	},
	monthsInYear: () => 13,
	minimumMonthLength(e) {
		const { month: t } = e;
		return 13 === t ? this.inLeapYear(e) ? 6 : 5 : 30;
	},
	maximumMonthLength(e) {
		return this.minimumMonthLength(e);
	},
	maxLengthOfMonthCodeInAnyYear: (e) => "M13" === e ? 6 : 30
};
var OrthodoxBaseHelperFixedEpoch = class extends GregorianBaseHelperFixedEpoch {
	constructor(e, t) {
		super(e, t), this.inLeapYear = ii.inLeapYear, this.monthsInYear = ii.monthsInYear, this.minimumMonthLength = ii.minimumMonthLength, this.maximumMonthLength = ii.maximumMonthLength, this.maxLengthOfMonthCodeInAnyYear = ii.maxLengthOfMonthCodeInAnyYear;
	}
};
var OrthodoxBaseHelper = class extends GregorianBaseHelper {
	constructor(e, t) {
		super(e, t), this.inLeapYear = ii.inLeapYear, this.monthsInYear = ii.monthsInYear, this.minimumMonthLength = ii.minimumMonthLength, this.maximumMonthLength = ii.maximumMonthLength, this.maxLengthOfMonthCodeInAnyYear = ii.maxLengthOfMonthCodeInAnyYear;
	}
};
var EthioaaHelper = class extends OrthodoxBaseHelperFixedEpoch {
	constructor() {
		super("ethioaa", {
			year: -5492,
			month: 7,
			day: 17
		});
	}
};
var CopticHelper = class extends OrthodoxBaseHelper {
	constructor() {
		super("coptic", [{
			code: "coptic",
			isoEpoch: {
				year: 284,
				month: 8,
				day: 29
			}
		}, {
			code: "coptic-inverse",
			reverseOf: "coptic"
		}]);
	}
};
var EthiopicHelper = class extends OrthodoxBaseHelper {
	constructor() {
		super("ethiopic", [{
			code: "ethioaa",
			names: ["ethiopic-amete-alem", "mundi"],
			isoEpoch: {
				year: -5492,
				month: 7,
				day: 17
			}
		}, {
			code: "ethiopic",
			names: ["incar"],
			isoEpoch: {
				year: 8,
				month: 8,
				day: 27
			},
			anchorEpoch: { year: 5501 }
		}]);
	}
};
var RocHelper = class extends SameMonthDayAsGregorianBaseHelper {
	constructor() {
		super("roc", [{
			code: "roc",
			names: ["minguo"],
			isoEpoch: {
				year: 1912,
				month: 1,
				day: 1
			}
		}, {
			code: "roc-inverse",
			names: ["before-roc"],
			reverseOf: "roc"
		}]);
	}
};
var BuddhistHelper = class extends GregorianBaseHelperFixedEpoch {
	constructor() {
		super("buddhist", {
			year: -543,
			month: 1,
			day: 1
		});
	}
};
var GregoryHelper = class extends SameMonthDayAsGregorianBaseHelper {
	constructor() {
		super("gregory", [{
			code: "gregory",
			names: ["ad", "ce"],
			isoEpoch: {
				year: 1,
				month: 1,
				day: 1
			}
		}, {
			code: "gregory-inverse",
			names: ["be", "bce"],
			reverseOf: "gregory"
		}]);
	}
	reviseIntlEra(e) {
		let { era: t, eraYear: n } = e;
		return "b" === t && (t = "gregory-inverse"), "a" === t && (t = "gregory"), {
			era: t,
			eraYear: n
		};
	}
	getFirstDayOfWeek() {
		return 1;
	}
	getMinimalDaysInFirstWeek() {
		return 1;
	}
};
var JapaneseHelper = class extends SameMonthDayAsGregorianBaseHelper {
	constructor() {
		super("japanese", [
			{
				code: "reiwa",
				isoEpoch: {
					year: 2019,
					month: 5,
					day: 1
				},
				anchorEpoch: {
					year: 2019,
					month: 5,
					day: 1
				}
			},
			{
				code: "heisei",
				isoEpoch: {
					year: 1989,
					month: 1,
					day: 8
				},
				anchorEpoch: {
					year: 1989,
					month: 1,
					day: 8
				}
			},
			{
				code: "showa",
				isoEpoch: {
					year: 1926,
					month: 12,
					day: 25
				},
				anchorEpoch: {
					year: 1926,
					month: 12,
					day: 25
				}
			},
			{
				code: "taisho",
				isoEpoch: {
					year: 1912,
					month: 7,
					day: 30
				},
				anchorEpoch: {
					year: 1912,
					month: 7,
					day: 30
				}
			},
			{
				code: "meiji",
				isoEpoch: {
					year: 1868,
					month: 9,
					day: 8
				},
				anchorEpoch: {
					year: 1868,
					month: 9,
					day: 8
				}
			},
			{
				code: "japanese",
				names: [
					"japanese",
					"gregory",
					"ad",
					"ce"
				],
				isoEpoch: {
					year: 1,
					month: 1,
					day: 1
				}
			},
			{
				code: "japanese-inverse",
				names: [
					"japanese-inverse",
					"gregory-inverse",
					"bc",
					"bce"
				],
				reverseOf: "japanese"
			}
		]), this.erasBeginMidYear = !0;
	}
	reviseIntlEra(e, t) {
		const { era: n, eraYear: r } = e, { year: o } = t;
		return this.eras.find(((e) => e.code === n)) ? {
			era: n,
			eraYear: r
		} : o < 1 ? {
			era: "japanese-inverse",
			eraYear: 1 - o
		} : {
			era: "japanese",
			eraYear: o
		};
	}
};
var ChineseBaseHelper = class extends HelperBase {
	constructor() {
		super(...arguments), this.calendarType = "lunisolar";
	}
	inLeapYear(e, t) {
		const n = this.getMonthList(e.year, t);
		return 13 === Object.entries(n).length;
	}
	monthsInYear(e, t) {
		return this.inLeapYear(e, t) ? 13 : 12;
	}
	minimumMonthLength() {
		return 29;
	}
	maximumMonthLength() {
		return 30;
	}
	maxLengthOfMonthCodeInAnyYear(e) {
		return [
			"M01L",
			"M09L",
			"M10L",
			"M11L",
			"M12L"
		].includes(e) ? 29 : 30;
	}
	monthDaySearchStartYear(e, t) {
		const n = {
			M01L: [1651, 1651],
			M02L: [1947, 1765],
			M03L: [1966, 1955],
			M04L: [1963, 1944],
			M05L: [1971, 1952],
			M06L: [1960, 1941],
			M07L: [1968, 1938],
			M08L: [1957, 1718],
			M09L: [1832, 1832],
			M10L: [1870, 1870],
			M11L: [1814, 1814],
			M12L: [1890, 1890]
		}[e] ?? [1972, 1972];
		return t < 30 ? n[0] : n[1];
	}
	getMonthList(e, t) {
		if (void 0 === e) throw new TypeError("Missing year");
		const n = JSON.stringify({
			func: "getMonthList",
			calendarYear: e,
			id: this.id
		}), r = t.get(n);
		if (r) return r;
		const o = this.getFormatter(), i = (e, t) => {
			const n = ni({
				isoYear: e,
				isoMonth: 2,
				isoDay: 1
			}), r = new Date(n);
			r.setUTCDate(t + 1);
			const i = o.formatToParts(r), a = i.find(((e) => "month" === e.type)).value, s = +i.find(((e) => "day" === e.type)).value, c = i.find(((e) => "relatedYear" === e.type));
			let d;
			if (void 0 === c) throw new RangeError(`Intl.DateTimeFormat.formatToParts lacks relatedYear in ${this.id} calendar. Try Node 14+ or modern browsers.`);
			return d = +c.value, {
				calendarMonthString: a,
				calendarDay: s,
				calendarYearToVerify: d
			};
		};
		let a = 17, { calendarMonthString: s, calendarDay: c, calendarYearToVerify: d } = i(e, a);
		"1" !== s && (a += 29, {calendarMonthString: s, calendarDay: c} = i(e, a)), a -= c - 5;
		const h = {};
		let u, l, m = 1, f = !1;
		do
			({calendarMonthString: s, calendarDay: c, calendarYearToVerify: d} = i(e, a)), u && (h[l].daysInMonth = u + 30 - c), d !== e ? f = !0 : (h[s] = { monthIndex: m++ }, a += 30), u = c, l = s;
		while (!f);
		return h[l].daysInMonth = u + 30 - c, t.set(n, h), h;
	}
	estimateIsoDate(e) {
		const { year: t, month: n } = e;
		return {
			year: t,
			month: n >= 12 ? 12 : n + 1,
			day: 1
		};
	}
	adjustCalendarDate(e, t, n = "constrain", r = !1) {
		let { year: o, month: i, monthExtra: a, day: s, monthCode: c } = e;
		if (void 0 === o) throw new TypeError("Missing property: year");
		if (r) {
			if (a && "bis" !== a) throw new RangeError(`Unexpected leap month suffix: ${a}`);
			const e = ei(i, void 0 !== a), n = `${i}${a || ""}`, r = this.getMonthList(o, t)[n];
			if (void 0 === r) throw new RangeError(`Unmatched month ${n} in Chinese year ${o}`);
			return i = r.monthIndex, {
				year: o,
				month: i,
				day: s,
				monthCode: e
			};
		}
		if (this.validateCalendarDate(e), void 0 === i) {
			const e = this.getMonthList(o, t);
			let r = c.replace(/^M|L$/g, ((e) => "L" === e ? "bis" : ""));
			"0" === r[0] && (r = r.slice(1));
			let a = e[r];
			if (i = a && a.monthIndex, void 0 === i && c.endsWith("L") && "M13L" != c && "constrain" === n) {
				const t = +c.replace(/^M0?|L$/g, "");
				a = e[t], a && (i = a.monthIndex, c = ei(t));
			}
			if (void 0 === i) throw new RangeError(`Unmatched month ${c} in Chinese year ${o}`);
		} else if (void 0 === c) {
			const e = this.getMonthList(o, t), r = Object.entries(e), a = r.length;
			"reject" === n ? (Nr(i, 1, a), Nr(s, 1, this.maximumMonthLength())) : (i = jr(i, 1, a), s = jr(s, 1, this.maximumMonthLength()));
			const d = r.find(((e) => e[1].monthIndex === i));
			if (void 0 === d) throw new RangeError(`Invalid month ${i} in Chinese year ${o}`);
			c = ei(+d[0].replace("bis", ""), -1 !== d[0].indexOf("bis"));
		} else {
			const e = this.getMonthList(o, t);
			let n = c.replace(/^M|L$/g, ((e) => "L" === e ? "bis" : ""));
			"0" === n[0] && (n = n.slice(1));
			const r = e[n];
			if (!r) throw new RangeError(`Unmatched monthCode ${c} in Chinese year ${o}`);
			if (i !== r.monthIndex) throw new RangeError(`monthCode ${c} doesn't correspond to month ${i} in Chinese year ${o}`);
		}
		return {
			...e,
			year: o,
			month: i,
			monthCode: c,
			day: s
		};
	}
};
var ChineseHelper = class extends ChineseBaseHelper {
	constructor() {
		super(...arguments), this.id = "chinese";
	}
};
var DangiHelper = class extends ChineseBaseHelper {
	constructor() {
		super(...arguments), this.id = "dangi";
	}
};
var NonIsoCalendar = class {
	constructor(e) {
		this.helper = e;
	}
	extraFields(e) {
		return this.helper.hasEra && e.includes("year") ? ["era", "eraYear"] : [];
	}
	resolveFields(e) {
		if ("lunisolar" !== this.helper.calendarType) {
			const t = new OneObjectCache();
			ti(e, void 0, this.helper.monthsInYear({ year: e.year ?? 1972 }, t));
		}
	}
	dateToISO(e, t) {
		const n = new OneObjectCache(), r = this.helper.calendarToIsoDate(e, t, n);
		return n.setObject(r), r;
	}
	monthDayToISOReferenceDate(e, t) {
		const n = new OneObjectCache(), r = this.helper.monthDayFromFields(e, t, n);
		return n.setObject(r), r;
	}
	fieldKeysToIgnore(e) {
		const t = /* @__PURE__ */ new Set();
		for (let n = 0; n < e.length; n++) {
			const r = e[n];
			switch (t.add(r), r) {
				case "era":
					t.add("eraYear"), t.add("year");
					break;
				case "eraYear":
					t.add("era"), t.add("year");
					break;
				case "year":
					t.add("era"), t.add("eraYear");
					break;
				case "month":
					t.add("monthCode"), this.helper.erasBeginMidYear && (t.add("era"), t.add("eraYear"));
					break;
				case "monthCode":
					t.add("month"), this.helper.erasBeginMidYear && (t.add("era"), t.add("eraYear"));
					break;
				case "day": this.helper.erasBeginMidYear && (t.add("era"), t.add("eraYear"));
			}
		}
		return Go(t);
	}
	dateAdd(e, { years: t, months: n, weeks: r, days: o }, i) {
		const a = OneObjectCache.getCacheForObject(e), s = this.helper.isoToCalendarDate(e, a), c = this.helper.addCalendar(s, {
			years: t,
			months: n,
			weeks: r,
			days: o
		}, i, a), d = this.helper.calendarToIsoDate(c, "constrain", a);
		return OneObjectCache.getCacheForObject(d) || new OneObjectCache(a).setObject(d), d;
	}
	dateUntil(e, t, n) {
		const r = OneObjectCache.getCacheForObject(e), o = OneObjectCache.getCacheForObject(t), i = this.helper.isoToCalendarDate(e, r), a = this.helper.isoToCalendarDate(t, o);
		return this.helper.untilCalendar(i, a, n, r);
	}
	isoToDate(e, t) {
		const n = OneObjectCache.getCacheForObject(e), r = this.helper.isoToCalendarDate(e, n);
		if (t.dayOfWeek && (r.dayOfWeek = Xo.iso8601.isoToDate(e, { dayOfWeek: !0 }).dayOfWeek), t.dayOfYear) {
			const e = this.helper.startOfCalendarYear(r);
			r.dayOfYear = this.helper.calendarDaysUntil(e, r, n) + 1;
		}
		if (t.weekOfYear && (r.weekOfYear = Ko(this.helper.id, e)), r.daysInWeek = 7, t.daysInMonth && (r.daysInMonth = this.helper.daysInMonth(r, n)), t.daysInYear) {
			const e = this.helper.startOfCalendarYear(r), t = this.helper.addCalendar(e, { years: 1 }, "constrain", n);
			r.daysInYear = this.helper.calendarDaysUntil(e, t, n);
		}
		return t.monthsInYear && (r.monthsInYear = this.helper.monthsInYear(r, n)), t.inLeapYear && (r.inLeapYear = this.helper.inLeapYear(r, n)), r;
	}
	getFirstDayOfWeek() {
		return this.helper.getFirstDayOfWeek();
	}
	getMinimalDaysInFirstWeek() {
		return this.helper.getMinimalDaysInFirstWeek();
	}
};
for (const e of [
	HebrewHelper,
	PersianHelper,
	EthiopicHelper,
	EthioaaHelper,
	CopticHelper,
	ChineseHelper,
	DangiHelper,
	RocHelper,
	IndianHelper,
	BuddhistHelper,
	GregoryHelper,
	JapaneseHelper,
	IslamicHelper,
	IslamicUmalquraHelper,
	IslamicTblaHelper,
	IslamicCivilHelper,
	IslamicRgsaHelper,
	IslamicCcHelper
]) {
	const t = new e();
	Xo[t.id] = new NonIsoCalendar(t);
}
se("calendarImpl", (function(e) {
	return Xo[e];
}));
const ai = Intl.DateTimeFormat;
function si(e, t) {
	let n = re(e, t);
	return "function" == typeof n && (n = new ai(re(e, G), n(re(e, K))), function(e, t, n) {
		const r = Q(e);
		if (void 0 === r) throw new TypeError("Missing slots for the given container");
		if (void 0 === r[t]) throw new TypeError(`tried to reset ${t} which was not set`);
		r[t] = n;
	}(e, t, n)), n;
}
function ci(e) {
	return ne(e, q);
}
var DateTimeFormatImpl = class {
	constructor(e = void 0, t = void 0) {
		(function(e, t, n) {
			const r = void 0 !== n;
			let o;
			if (r) {
				const e = [
					"localeMatcher",
					"calendar",
					"numberingSystem",
					"hour12",
					"hourCycle",
					"timeZone",
					"weekday",
					"era",
					"year",
					"month",
					"day",
					"dayPeriod",
					"hour",
					"minute",
					"second",
					"fractionalSecondDigits",
					"timeZoneName",
					"formatMatcher",
					"dateStyle",
					"timeStyle"
				];
				o = function(e) {
					if (null == e) throw new TypeError(`Expected object not ${e}`);
					return Object(e);
				}(n);
				const t = Object.create(null);
				for (let n = 0; n < e.length; n++) {
					const r = e[n];
					Object.prototype.hasOwnProperty.call(o, r) && (t[r] = o[r]);
				}
				o = t;
			} else o = Object.create(null);
			const i = new ai(t, o), a = i.resolvedOptions();
			if (te(e), r) {
				const t = Object.assign(Object.create(null), a);
				for (const e in t) Object.prototype.hasOwnProperty.call(o, e) || delete t[e];
				t.hour12 = o.hour12, t.hourCycle = o.hourCycle, oe(e, K, t);
			} else oe(e, K, o);
			oe(e, G, a.locale), oe(e, q, i), oe(e, W, a.timeZone), oe(e, J, a.calendar), oe(e, B, vi), oe(e, Z, gi), oe(e, F, wi), oe(e, H, pi), oe(e, z, bi), oe(e, A, Di);
			const s = r ? o.timeZone : void 0;
			if (void 0 === s) oe(e, _, a.timeZone);
			else {
				const t = We(s);
				if (t.startsWith("−")) throw new RangeError("Unicode minus (U+2212) is not supported in time zone offsets");
				oe(e, _, Bn(t));
			}
		})(this, e, t);
	}
	get format() {
		vt(this, ci);
		const e = ui.bind(this);
		return Object.defineProperties(e, {
			length: {
				value: 1,
				enumerable: !1,
				writable: !1,
				configurable: !0
			},
			name: {
				value: "",
				enumerable: !1,
				writable: !1,
				configurable: !0
			}
		}), e;
	}
	formatRange(e, t) {
		return vt(this, ci), mi.call(this, e, t);
	}
	formatToParts(e, ...t) {
		return vt(this, ci), li.call(this, e, ...t);
	}
	formatRangeToParts(e, t) {
		return vt(this, ci), fi.call(this, e, t);
	}
	resolvedOptions() {
		return vt(this, ci), hi.call(this);
	}
};
"formatToParts" in ai.prototype || delete DateTimeFormatImpl.prototype.formatToParts, "formatRangeToParts" in ai.prototype || delete DateTimeFormatImpl.prototype.formatRangeToParts;
const di = function(e = void 0, t = void 0) {
	return new DateTimeFormatImpl(e, t);
};
function hi() {
	const e = re(this, q).resolvedOptions();
	return e.timeZone = re(this, _), e;
}
function ui(e, ...t) {
	let n, r, o = $i(e, this);
	return o.formatter ? (n = o.formatter, r = [No(o.epochNs, "floor")]) : (n = re(this, q), r = [e, ...t]), n.format(...r);
}
function li(e, ...t) {
	let n, r, o = $i(e, this);
	return o.formatter ? (n = o.formatter, r = [No(o.epochNs, "floor")]) : (n = re(this, q), r = [e, ...t]), n.formatToParts(...r);
}
function mi(e, t) {
	if (void 0 === e || void 0 === t) throw new TypeError("Intl.DateTimeFormat.formatRange requires two values");
	const n = Ci(e), r = Ci(t);
	let o, i = [n, r];
	if (Ii(n) !== Ii(r)) throw new TypeError("Intl.DateTimeFormat.formatRange accepts two values of the same type");
	if (Ii(n)) {
		if (!Oi(n, r)) throw new TypeError("Intl.DateTimeFormat.formatRange accepts two values of the same type");
		const { epochNs: e, formatter: t } = $i(n, this), { epochNs: a, formatter: s } = $i(r, this);
		t && (o = t, i = [No(e, "floor"), No(a, "floor")]);
	}
	return o || (o = re(this, q)), o.formatRange(...i);
}
function fi(e, t) {
	if (void 0 === e || void 0 === t) throw new TypeError("Intl.DateTimeFormat.formatRange requires two values");
	const n = Ci(e), r = Ci(t);
	let o, i = [n, r];
	if (Ii(n) !== Ii(r)) throw new TypeError("Intl.DateTimeFormat.formatRangeToParts accepts two values of the same type");
	if (Ii(n)) {
		if (!Oi(n, r)) throw new TypeError("Intl.DateTimeFormat.formatRangeToParts accepts two values of the same type");
		const { epochNs: e, formatter: t } = $i(n, this), { epochNs: a, formatter: s } = $i(r, this);
		t && (o = t, i = [No(e, "floor"), No(a, "floor")]);
	}
	return o || (o = re(this, q)), o.formatRangeToParts(...i);
}
function yi(e = {}, t = {}) {
	const n = Object.assign({}, e), r = [
		"year",
		"month",
		"day",
		"hour",
		"minute",
		"second",
		"weekday",
		"dayPeriod",
		"timeZoneName",
		"dateStyle",
		"timeStyle"
	];
	for (let e = 0; e < r.length; e++) {
		const o = r[e];
		n[o] = o in t ? t[o] : n[o], !1 !== n[o] && void 0 !== n[o] || delete n[o];
	}
	return n;
}
function pi(e) {
	const t = yi(e, {
		year: !1,
		month: !1,
		day: !1,
		weekday: !1,
		timeZoneName: !1,
		dateStyle: !1
	});
	if ("long" !== t.timeStyle && "full" !== t.timeStyle || (delete t.timeStyle, Object.assign(t, {
		hour: "numeric",
		minute: "2-digit",
		second: "2-digit"
	})), !Mi(t)) {
		if (Ei(e)) throw new TypeError(`cannot format Temporal.PlainTime with options [${Object.keys(e)}]`);
		Object.assign(t, {
			hour: "numeric",
			minute: "numeric",
			second: "numeric"
		});
	}
	return t;
}
function gi(e) {
	const t = {
		short: {
			year: "2-digit",
			month: "numeric"
		},
		medium: {
			year: "numeric",
			month: "short"
		},
		long: {
			year: "numeric",
			month: "long"
		},
		full: {
			year: "numeric",
			month: "long"
		}
	}, n = yi(e, {
		day: !1,
		hour: !1,
		minute: !1,
		second: !1,
		weekday: !1,
		dayPeriod: !1,
		timeZoneName: !1,
		timeStyle: !1
	});
	if ("dateStyle" in n && n.dateStyle) {
		const e = n.dateStyle;
		delete n.dateStyle, Object.assign(n, t[e]);
	}
	if (!("year" in n || "month" in n || "era" in n)) {
		if (Ei(e)) throw new TypeError(`cannot format PlainYearMonth with options [${Object.keys(e)}]`);
		Object.assign(n, {
			year: "numeric",
			month: "numeric"
		});
	}
	return n;
}
function wi(e) {
	const t = {
		short: {
			month: "numeric",
			day: "numeric"
		},
		medium: {
			month: "short",
			day: "numeric"
		},
		long: {
			month: "long",
			day: "numeric"
		},
		full: {
			month: "long",
			day: "numeric"
		}
	}, n = yi(e, {
		year: !1,
		hour: !1,
		minute: !1,
		second: !1,
		weekday: !1,
		dayPeriod: !1,
		timeZoneName: !1,
		timeStyle: !1
	});
	if ("dateStyle" in n && n.dateStyle) {
		const e = n.dateStyle;
		delete n.dateStyle, Object.assign(n, t[e]);
	}
	if (!("month" in n) && !("day" in n)) {
		if (Ei(e)) throw new TypeError(`cannot format PlainMonthDay with options [${Object.keys(e)}]`);
		Object.assign(n, {
			month: "numeric",
			day: "numeric"
		});
	}
	return n;
}
function vi(e) {
	const t = yi(e, {
		hour: !1,
		minute: !1,
		second: !1,
		dayPeriod: !1,
		timeZoneName: !1,
		timeStyle: !1
	});
	if (!Ti(t)) {
		if (Ei(e)) throw new TypeError(`cannot format PlainDate with options [${Object.keys(e)}]`);
		Object.assign(t, {
			year: "numeric",
			month: "numeric",
			day: "numeric"
		});
	}
	return t;
}
function bi(e) {
	const t = yi(e, { timeZoneName: !1 });
	if (("long" === t.timeStyle || "full" === t.timeStyle) && (delete t.timeStyle, Object.assign(t, {
		hour: "numeric",
		minute: "2-digit",
		second: "2-digit"
	}), t.dateStyle)) Object.assign(t, {
		short: {
			year: "numeric",
			month: "numeric",
			day: "numeric"
		},
		medium: {
			year: "numeric",
			month: "short",
			day: "numeric"
		},
		long: {
			year: "numeric",
			month: "long",
			day: "numeric"
		},
		full: {
			year: "numeric",
			month: "long",
			day: "numeric",
			weekday: "long"
		}
	}[t.dateStyle]), delete t.dateStyle;
	if (!Mi(t) && !Ti(t)) {
		if (Ei(e)) throw new TypeError(`cannot format PlainDateTime with options [${Object.keys(e)}]`);
		Object.assign(t, {
			year: "numeric",
			month: "numeric",
			day: "numeric",
			hour: "numeric",
			minute: "numeric",
			second: "numeric"
		});
	}
	return t;
}
function Di(e) {
	let t = e;
	return Mi(t) || Ti(t) || (t = Object.assign({}, t, {
		year: "numeric",
		month: "numeric",
		day: "numeric",
		hour: "numeric",
		minute: "numeric",
		second: "numeric"
	})), t;
}
function Ti(e) {
	return "year" in e || "month" in e || "day" in e || "weekday" in e || "dateStyle" in e || "era" in e;
}
function Mi(e) {
	return "hour" in e || "minute" in e || "second" in e || "timeStyle" in e || "dayPeriod" in e || "fractionalSecondDigits" in e;
}
function Ei(e) {
	return Ti(e) || Mi(e) || "dateStyle" in e || "timeStyle" in e || "timeZoneName" in e;
}
function Ii(e) {
	return mt(e) || ft(e) || yt(e) || wt(e) || pt(e) || gt(e) || ut(e);
}
function Ci(e) {
	return Ii(e) ? e : qe(e);
}
function Oi(e, t) {
	return !(!Ii(e) || !Ii(t) || ft(e) && !ft(t) || mt(e) && !mt(t) || yt(e) && !yt(t) || wt(e) && !wt(t) || pt(e) && !pt(t) || gt(e) && !gt(t) || ut(e) && !ut(t));
}
function $i(e, t) {
	if (ft(e)) {
		const n = {
			isoDate: {
				year: 1970,
				month: 1,
				day: 1
			},
			time: re(e, M)
		};
		return {
			epochNs: An(re(t, W), n, "compatible"),
			formatter: si(t, H)
		};
	}
	if (pt(e)) {
		const n = re(e, E), r = re(t, J);
		if (n !== r) throw new RangeError(`cannot format PlainYearMonth with calendar ${n} in locale with calendar ${r}`);
		const o = xt(re(e, D), {
			deltaDays: 0,
			hour: 12,
			minute: 0,
			second: 0,
			millisecond: 0,
			microsecond: 0,
			nanosecond: 0
		});
		return {
			epochNs: An(re(t, W), o, "compatible"),
			formatter: si(t, Z)
		};
	}
	if (gt(e)) {
		const n = re(e, E), r = re(t, J);
		if (n !== r) throw new RangeError(`cannot format PlainMonthDay with calendar ${n} in locale with calendar ${r}`);
		const o = xt(re(e, D), {
			deltaDays: 0,
			hour: 12,
			minute: 0,
			second: 0,
			millisecond: 0,
			microsecond: 0,
			nanosecond: 0
		});
		return {
			epochNs: An(re(t, W), o, "compatible"),
			formatter: si(t, F)
		};
	}
	if (mt(e)) {
		const n = re(e, E), r = re(t, J);
		if ("iso8601" !== n && n !== r) throw new RangeError(`cannot format PlainDate with calendar ${n} in locale with calendar ${r}`);
		const o = xt(re(e, D), {
			deltaDays: 0,
			hour: 12,
			minute: 0,
			second: 0,
			millisecond: 0,
			microsecond: 0,
			nanosecond: 0
		});
		return {
			epochNs: An(re(t, W), o, "compatible"),
			formatter: si(t, B)
		};
	}
	if (yt(e)) {
		const n = re(e, E), r = re(t, J);
		if ("iso8601" !== n && n !== r) throw new RangeError(`cannot format PlainDateTime with calendar ${n} in locale with calendar ${r}`);
		const o = re(e, T);
		return {
			epochNs: An(re(t, W), o, "compatible"),
			formatter: si(t, z)
		};
	}
	if (wt(e)) throw new TypeError("Temporal.ZonedDateTime not supported in DateTimeFormat methods. Use toLocaleString() instead.");
	return ut(e) ? {
		epochNs: re(e, b),
		formatter: si(t, A)
	} : {};
}
function Yi(e) {
	const t = Object.create(null);
	return t.years = re(e, Y), t.months = re(e, R), t.weeks = re(e, S), t.days = re(e, j), t.hours = re(e, k), t.minutes = re(e, N), t.seconds = re(e, x), t.milliseconds = re(e, L), t.microseconds = re(e, P), t.nanoseconds = re(e, U), t;
}
DateTimeFormatImpl.prototype.constructor = di, Object.defineProperty(di, "prototype", {
	value: DateTimeFormatImpl.prototype,
	writable: !1,
	enumerable: !1,
	configurable: !1
}), di.supportedLocalesOf = ai.supportedLocalesOf, ae(di, "Intl.DateTimeFormat");
const { format: Ri, formatToParts: Si } = Intl.DurationFormat?.prototype ?? Object.create(null);
function ji(e) {
	Intl.DurationFormat.prototype.resolvedOptions.call(this);
	const t = Yi(sn(e));
	return Ri.call(this, t);
}
Intl.DurationFormat?.prototype && (Intl.DurationFormat.prototype.format = ji, Intl.DurationFormat.prototype.formatToParts = function(e) {
	Intl.DurationFormat.prototype.resolvedOptions.call(this);
	const t = Yi(sn(e));
	return Si.call(this, t);
});
Object.freeze({
	__proto__: null,
	DateTimeFormat: di,
	ModifiedIntlDurationFormatPrototypeFormat: ji
});
var Instant = class {
	constructor(e) {
		if (arguments.length < 1) throw new TypeError("missing argument: epochNanoseconds is required");
		In(this, Lo(e));
	}
	get epochMilliseconds() {
		return vt(this, ut), No(re(this, b), "floor");
	}
	get epochNanoseconds() {
		return vt(this, ut), ko(import_jsbi_umd.default.BigInt(re(this, b)));
	}
	add(e) {
		return vt(this, ut), wo("add", this, e);
	}
	subtract(e) {
		return vt(this, ut), wo("subtract", this, e);
	}
	until(e, t = void 0) {
		return vt(this, ut), so("until", this, e, t);
	}
	since(e, t = void 0) {
		return vt(this, ut), so("since", this, e, t);
	}
	round(e) {
		if (vt(this, ut), void 0 === e) throw new TypeError("options parameter is required");
		const t = "string" == typeof e ? Fo("smallestUnit", e) : Zo(e), n = Ft(t), r = Ut(t, "halfExpand"), o = Wt(t, "smallestUnit", "time", qt);
		return Ht(n, {
			hour: 24,
			minute: 1440,
			second: 86400,
			millisecond: 864e5,
			microsecond: 864e8,
			nanosecond: 864e11
		}[o], !0), Cn(Io(re(this, b), n, o, r));
	}
	equals(t) {
		vt(this, ut);
		const n = cn(t), r = re(this, b), o = re(n, b);
		return import_jsbi_umd.default.equal(import_jsbi_umd.default.BigInt(r), import_jsbi_umd.default.BigInt(o));
	}
	toString(e = void 0) {
		vt(this, ut);
		const t = Zo(e), n = zt(t), r = Ut(t, "trunc"), o = Wt(t, "smallestUnit", "time", void 0);
		if ("hour" === o) throw new RangeError("smallestUnit must be a time unit other than \"hour\"");
		let i = t.timeZone;
		void 0 !== i && (i = Bn(i));
		const { precision: a, unit: s, increment: c } = At(o, n);
		return Xn(Cn(Io(re(this, b), c, s, r)), i, a);
	}
	toJSON() {
		return vt(this, ut), Xn(this, void 0, "auto");
	}
	toLocaleString(e = void 0, t = void 0) {
		return vt(this, ut), new di(e, t).format(this);
	}
	valueOf() {
		qo("Instant");
	}
	toZonedDateTimeISO(e) {
		vt(this, ut);
		const t = Bn(e);
		return $n(re(this, b), t, "iso8601");
	}
	static fromEpochMilliseconds(e) {
		return Cn(xo(qe(e)));
	}
	static fromEpochNanoseconds(e) {
		return Cn(Lo(e));
	}
	static from(e) {
		return cn(e);
	}
	static compare(t, n) {
		const r = cn(t), o = cn(n), i = re(r, b), a = re(o, b);
		return import_jsbi_umd.default.lessThan(i, a) ? -1 : import_jsbi_umd.default.greaterThan(i, a) ? 1 : 0;
	}
};
ae(Instant, "Temporal.Instant");
var PlainDate = class {
	constructor(e, t, n, r = "iso8601") {
		const o = _e(e), i = _e(t), a = _e(n), s = zo(void 0 === r ? "iso8601" : Ve(r));
		xr(o, i, a), yn(this, {
			year: o,
			month: i,
			day: a
		}, s);
	}
	get calendarId() {
		return vt(this, mt), re(this, E);
	}
	get era() {
		return Ni(this, "era");
	}
	get eraYear() {
		return Ni(this, "eraYear");
	}
	get year() {
		return Ni(this, "year");
	}
	get month() {
		return Ni(this, "month");
	}
	get monthCode() {
		return Ni(this, "monthCode");
	}
	get day() {
		return Ni(this, "day");
	}
	get dayOfWeek() {
		return Ni(this, "dayOfWeek");
	}
	get dayOfYear() {
		return Ni(this, "dayOfYear");
	}
	get weekOfYear() {
		return Ni(this, "weekOfYear")?.week;
	}
	get yearOfWeek() {
		return Ni(this, "weekOfYear")?.year;
	}
	get daysInWeek() {
		return Ni(this, "daysInWeek");
	}
	get daysInMonth() {
		return Ni(this, "daysInMonth");
	}
	get daysInYear() {
		return Ni(this, "daysInYear");
	}
	get monthsInYear() {
		return Ni(this, "monthsInYear");
	}
	get inLeapYear() {
		return Ni(this, "inLeapYear");
	}
	with(e, t = void 0) {
		if (vt(this, mt), !Ae(e)) throw new TypeError("invalid argument");
		bt(e);
		const n = re(this, E);
		let r = en(n, re(this, D));
		return r = Rn(n, r, tn(n, e, [
			"year",
			"month",
			"monthCode",
			"day"
		], [], "partial")), pn(Ln(n, r, Lt(Zo(t))), n);
	}
	withCalendar(e) {
		vt(this, mt);
		const t = kn(e);
		return pn(re(this, D), t);
	}
	add(e, t = void 0) {
		return vt(this, mt), vo("add", this, e, t);
	}
	subtract(e, t = void 0) {
		return vt(this, mt), vo("subtract", this, e, t);
	}
	until(e, t = void 0) {
		return vt(this, mt), co("until", this, e, t);
	}
	since(e, t = void 0) {
		return vt(this, mt), co("since", this, e, t);
	}
	equals(e) {
		vt(this, mt);
		const t = rn(e);
		return 0 === Ro(re(this, D), re(t, D)) && xn(re(this, E), re(t, E));
	}
	toString(e = void 0) {
		return vt(this, mt), er(this, Zt(Zo(e)));
	}
	toJSON() {
		return vt(this, mt), er(this);
	}
	toLocaleString(e = void 0, t = void 0) {
		return vt(this, mt), new di(e, t).format(this);
	}
	valueOf() {
		qo("PlainDate");
	}
	toPlainDateTime(e = void 0) {
		vt(this, mt);
		const t = un(e);
		return wn(xt(re(this, D), t), re(this, E));
	}
	toZonedDateTime(e) {
		let t, n;
		if (vt(this, mt), Ae(e)) {
			const r = e.timeZone;
			void 0 === r ? t = Bn(e) : (t = Bn(r), n = e.plainTime);
		} else t = Bn(e);
		const r = re(this, D);
		let o;
		return void 0 === n ? o = _n(t, r) : (n = hn(n), o = An(t, xt(r, re(n, M)), "compatible")), $n(o, t, re(this, E));
	}
	toPlainYearMonth() {
		vt(this, mt);
		const e = re(this, E);
		return En(Pn(e, en(e, re(this, D)), "constrain"), e);
	}
	toPlainMonthDay() {
		vt(this, mt);
		const e = re(this, E);
		return bn(Un(e, en(e, re(this, D)), "constrain"), e);
	}
	static from(e, t = void 0) {
		return rn(e, t);
	}
	static compare(e, t) {
		const n = rn(e), r = rn(t);
		return Ro(re(n, D), re(r, D));
	}
};
function Ni(e, t) {
	vt(e, mt);
	const n = re(e, D);
	return Qt(e).isoToDate(n, { [t]: !0 })[t];
}
ae(PlainDate, "Temporal.PlainDate");
var PlainDateTime = class {
	constructor(e, t, n, r = 0, o = 0, i = 0, a = 0, s = 0, c = 0, d = "iso8601") {
		const h = _e(e), u = _e(t), l = _e(n), m = void 0 === r ? 0 : _e(r), f = void 0 === o ? 0 : _e(o), y = void 0 === i ? 0 : _e(i), p = void 0 === a ? 0 : _e(a), g = void 0 === s ? 0 : _e(s), w = void 0 === c ? 0 : _e(c), v = zo(void 0 === d ? "iso8601" : Ve(d));
		Ur(h, u, l, m, f, y, p, g, w), gn(this, {
			isoDate: {
				year: h,
				month: u,
				day: l
			},
			time: {
				hour: m,
				minute: f,
				second: y,
				millisecond: p,
				microsecond: g,
				nanosecond: w
			}
		}, v);
	}
	get calendarId() {
		return vt(this, yt), re(this, E);
	}
	get year() {
		return xi(this, "year");
	}
	get month() {
		return xi(this, "month");
	}
	get monthCode() {
		return xi(this, "monthCode");
	}
	get day() {
		return xi(this, "day");
	}
	get hour() {
		return Li(this, "hour");
	}
	get minute() {
		return Li(this, "minute");
	}
	get second() {
		return Li(this, "second");
	}
	get millisecond() {
		return Li(this, "millisecond");
	}
	get microsecond() {
		return Li(this, "microsecond");
	}
	get nanosecond() {
		return Li(this, "nanosecond");
	}
	get era() {
		return xi(this, "era");
	}
	get eraYear() {
		return xi(this, "eraYear");
	}
	get dayOfWeek() {
		return xi(this, "dayOfWeek");
	}
	get dayOfYear() {
		return xi(this, "dayOfYear");
	}
	get weekOfYear() {
		return xi(this, "weekOfYear")?.week;
	}
	get yearOfWeek() {
		return xi(this, "weekOfYear")?.year;
	}
	get daysInWeek() {
		return xi(this, "daysInWeek");
	}
	get daysInYear() {
		return xi(this, "daysInYear");
	}
	get daysInMonth() {
		return xi(this, "daysInMonth");
	}
	get monthsInYear() {
		return xi(this, "monthsInYear");
	}
	get inLeapYear() {
		return xi(this, "inLeapYear");
	}
	with(e, t = void 0) {
		if (vt(this, yt), !Ae(e)) throw new TypeError("invalid argument");
		bt(e);
		const n = re(this, E), r = re(this, T);
		let o = {
			...en(n, r.isoDate),
			...r.time
		};
		return o = Rn(n, o, tn(n, e, [
			"year",
			"month",
			"monthCode",
			"day"
		], [
			"hour",
			"minute",
			"second",
			"millisecond",
			"microsecond",
			"nanosecond"
		], "partial")), wn(on(n, o, Lt(Zo(t))), n);
	}
	withPlainTime(e = void 0) {
		vt(this, yt);
		const t = un(e);
		return wn(xt(re(this, T).isoDate, t), re(this, E));
	}
	withCalendar(e) {
		vt(this, yt);
		const t = kn(e);
		return wn(re(this, T), t);
	}
	add(e, t = void 0) {
		return vt(this, yt), bo("add", this, e, t);
	}
	subtract(e, t = void 0) {
		return vt(this, yt), bo("subtract", this, e, t);
	}
	until(e, t = void 0) {
		return vt(this, yt), ho("until", this, e, t);
	}
	since(e, t = void 0) {
		return vt(this, yt), ho("since", this, e, t);
	}
	round(e) {
		if (vt(this, yt), void 0 === e) throw new TypeError("options parameter is required");
		const t = "string" == typeof e ? Fo("smallestUnit", e) : Zo(e), n = Ft(t), r = Ut(t, "halfExpand"), o = Wt(t, "smallestUnit", "time", qt, ["day"]), i = {
			day: 1,
			hour: 24,
			minute: 60,
			second: 60,
			millisecond: 1e3,
			microsecond: 1e3,
			nanosecond: 1e3
		}[o];
		Ht(n, i, 1 === i);
		const a = re(this, T);
		return wn(1 === n && "nanosecond" === o ? a : Co(a, n, o, r), re(this, E));
	}
	equals(e) {
		vt(this, yt);
		const t = an(e);
		return 0 === jo(re(this, T), re(t, T)) && xn(re(this, E), re(t, E));
	}
	toString(e = void 0) {
		vt(this, yt);
		const t = Zo(e), n = Zt(t), r = zt(t), o = Ut(t, "trunc"), i = Wt(t, "smallestUnit", "time", void 0);
		if ("hour" === i) throw new RangeError("smallestUnit must be a time unit other than \"hour\"");
		const { precision: a, unit: s, increment: c } = At(i, r), d = Co(re(this, T), c, s, o);
		return Br(d), nr(d, re(this, E), a, n);
	}
	toJSON() {
		return vt(this, yt), nr(re(this, T), re(this, E), "auto");
	}
	toLocaleString(e = void 0, t = void 0) {
		return vt(this, yt), new di(e, t).format(this);
	}
	valueOf() {
		qo("PlainDateTime");
	}
	toZonedDateTime(e, t = void 0) {
		vt(this, yt);
		const n = Bn(e), r = Pt(Zo(t));
		return $n(An(n, re(this, T), r), n, re(this, E));
	}
	toPlainDate() {
		return vt(this, yt), pn(re(this, T).isoDate, re(this, E));
	}
	toPlainTime() {
		return vt(this, yt), Tn(re(this, T).time);
	}
	static from(e, t = void 0) {
		return an(e, t);
	}
	static compare(e, t) {
		const n = an(e), r = an(t);
		return jo(re(n, T), re(r, T));
	}
};
function xi(e, t) {
	vt(e, yt);
	const n = re(e, T).isoDate;
	return Qt(e).isoToDate(n, { [t]: !0 })[t];
}
function Li(e, t) {
	return vt(e, yt), re(e, T).time[t];
}
ae(PlainDateTime, "Temporal.PlainDateTime");
var Duration = class Duration {
	constructor(e = 0, t = 0, n = 0, r = 0, o = 0, i = 0, a = 0, s = 0, c = 0, d = 0) {
		const h = void 0 === e ? 0 : Ge(e), u = void 0 === t ? 0 : Ge(t), l = void 0 === n ? 0 : Ge(n), m = void 0 === r ? 0 : Ge(r), f = void 0 === o ? 0 : Ge(o), y = void 0 === i ? 0 : Ge(i), p = void 0 === a ? 0 : Ge(a), g = void 0 === s ? 0 : Ge(s), w = void 0 === c ? 0 : Ge(c), v = void 0 === d ? 0 : Ge(d);
		zr(h, u, l, m, f, y, p, g, w, v), te(this), oe(this, Y, h), oe(this, R, u), oe(this, S, l), oe(this, j, m), oe(this, k, f), oe(this, N, y), oe(this, x, p), oe(this, L, g), oe(this, P, w), oe(this, U, v);
	}
	get years() {
		return vt(this, lt), re(this, Y);
	}
	get months() {
		return vt(this, lt), re(this, R);
	}
	get weeks() {
		return vt(this, lt), re(this, S);
	}
	get days() {
		return vt(this, lt), re(this, j);
	}
	get hours() {
		return vt(this, lt), re(this, k);
	}
	get minutes() {
		return vt(this, lt), re(this, N);
	}
	get seconds() {
		return vt(this, lt), re(this, x);
	}
	get milliseconds() {
		return vt(this, lt), re(this, L);
	}
	get microseconds() {
		return vt(this, lt), re(this, P);
	}
	get nanoseconds() {
		return vt(this, lt), re(this, U);
	}
	get sign() {
		return vt(this, lt), Mr(this);
	}
	get blank() {
		return vt(this, lt), 0 === Mr(this);
	}
	with(e) {
		vt(this, lt);
		const { years: n = re(this, Y), months: r = re(this, R), weeks: o = re(this, S), days: i = re(this, j), hours: a = re(this, k), minutes: s = re(this, N), seconds: c = re(this, x), milliseconds: d = re(this, L), microseconds: h = re(this, P), nanoseconds: u = re(this, U) } = kt(e);
		return new Duration(n, r, o, i, a, s, c, d, h, u);
	}
	negated() {
		return vt(this, lt), Sr(this);
	}
	abs() {
		return vt(this, lt), new Duration(Math.abs(re(this, Y)), Math.abs(re(this, R)), Math.abs(re(this, S)), Math.abs(re(this, j)), Math.abs(re(this, k)), Math.abs(re(this, N)), Math.abs(re(this, x)), Math.abs(re(this, L)), Math.abs(re(this, P)), Math.abs(re(this, U)));
	}
	add(e) {
		return vt(this, lt), go("add", this, e);
	}
	subtract(e) {
		return vt(this, lt), go("subtract", this, e);
	}
	round(e) {
		if (vt(this, lt), void 0 === e) throw new TypeError("options parameter is required");
		const t = Jt(this), n = "string" == typeof e ? Fo("smallestUnit", e) : Zo(e);
		let r = Wt(n, "largestUnit", "datetime", void 0, ["auto"]), { plainRelativeTo: o, zonedRelativeTo: i } = _t(n);
		const a = Ft(n), s = Ut(n, "halfExpand");
		let c = Wt(n, "smallestUnit", "datetime", void 0), d = !0;
		c || (d = !1, c = "nanosecond");
		const h = Gt(t, c);
		let u = !0;
		if (r || (u = !1, r = h), "auto" === r && (r = h), !d && !u) throw new RangeError("at least one of smallestUnit or largestUnit is required");
		if (Gt(r, c) !== r) throw new RangeError(`largestUnit ${r} cannot be smaller than smallestUnit ${c}`);
		const l = {
			hour: 24,
			minute: 60,
			second: 60,
			millisecond: 1e3,
			microsecond: 1e3,
			nanosecond: 1e3
		}[c];
		if (void 0 !== l && Ht(a, l, !1), a > 1 && "date" === Vt(c) && r !== c) throw new RangeError("For calendar units with roundingIncrement > 1, use largestUnit = smallestUnit");
		if (i) {
			let e = Ar(this);
			const t = re(i, $), n = re(i, E), o = re(i, b);
			return e = io(o, po(o, t, n, e), t, n, r, a, c, s), "date" === Vt(r) && (r = "hour"), _r(e, r);
		}
		if (o) {
			let e = qr(this);
			const t = fo({
				deltaDays: 0,
				hour: 0,
				minute: 0,
				second: 0,
				millisecond: 0,
				microsecond: 0,
				nanosecond: 0
			}, e.time), n = re(o, D), i = re(o, E), d = Sn(i, n, Nt(e.date, t.deltaDays), "constrain");
			return e = oo(xt(n, {
				deltaDays: 0,
				hour: 0,
				minute: 0,
				second: 0,
				millisecond: 0,
				microsecond: 0,
				nanosecond: 0
			}), xt(d, t), i, r, a, c, s), _r(e, r);
		}
		if (Kt(t)) throw new RangeError(`a starting point is required for ${t}s balancing`);
		if (Kt(r)) throw new RangeError(`a starting point is required for ${r}s balancing`);
		let m = qr(this);
		if ("day" === c) {
			const { quotient: e, remainder: t } = m.time.divmod(Se);
			let n = m.date.days + e + Yo(t, "day");
			n = Eo(n, a, s), m = Jr({
				years: 0,
				months: 0,
				weeks: 0,
				days: n
			}, TimeDuration.ZERO);
		} else m = Jr({
			years: 0,
			months: 0,
			weeks: 0,
			days: 0
		}, $o(m.time, a, c, s));
		return _r(m, r);
	}
	total(t) {
		if (vt(this, lt), void 0 === t) throw new TypeError("options argument is required");
		const n = "string" == typeof t ? Fo("unit", t) : Zo(t);
		let { plainRelativeTo: r, zonedRelativeTo: o } = _t(n);
		const i = Wt(n, "unit", "datetime", qt);
		if (o) {
			const e = Ar(this), t = re(o, $), n = re(o, E), r = re(o, b);
			return function(e, t, n, r, o) {
				return "time" === Vt(o) ? Yo(TimeDuration.fromEpochNsDiff(t, e), o) : ro(eo(e, t, n, r, o), t, zn(n, e), n, r, o);
			}(r, po(r, t, n, e), t, n, i);
		}
		if (r) {
			const t = qr(this);
			let n = fo({
				deltaDays: 0,
				hour: 0,
				minute: 0,
				second: 0,
				millisecond: 0,
				microsecond: 0,
				nanosecond: 0
			}, t.time);
			const o = re(r, D), a = re(r, E), s = Sn(a, o, Nt(t.date, n.deltaDays), "constrain");
			return function(t, n, r, o) {
				if (0 == jo(t, n)) return 0;
				Br(t), Br(n);
				const i = Qr(t, n, r, o);
				return "nanosecond" === o ? import_jsbi_umd.default.toNumber(i.time.totalNs) : ro(i, pr(n), t, null, r, o);
			}(xt(o, {
				deltaDays: 0,
				hour: 0,
				minute: 0,
				second: 0,
				millisecond: 0,
				microsecond: 0,
				nanosecond: 0
			}), xt(s, n), a, i);
		}
		const a = Jt(this);
		if (Kt(a)) throw new RangeError(`a starting point is required for ${a}s total`);
		if (Kt(i)) throw new RangeError(`a starting point is required for ${i}s total`);
		return Yo(qr(this).time, i);
	}
	toString(e = void 0) {
		vt(this, lt);
		const t = Zo(e), n = zt(t), r = Ut(t, "trunc"), o = Wt(t, "smallestUnit", "time", void 0);
		if ("hour" === o || "minute" === o) throw new RangeError("smallestUnit must be a time unit other than \"hours\" or \"minutes\"");
		const { precision: i, unit: a, increment: s } = At(o, n);
		if ("nanosecond" === a && 1 === s) return Qn(this, i);
		const c = Jt(this);
		let d = Ar(this);
		const h = $o(d.time, s, a, r);
		return d = Jr(d.date, h), Qn(_r(d, Gt(c, "second")), i);
	}
	toJSON() {
		return vt(this, lt), Qn(this, "auto");
	}
	toLocaleString(e = void 0, t = void 0) {
		if (vt(this, lt), "function" == typeof Intl.DurationFormat) {
			const n = new Intl.DurationFormat(e, t);
			return ji.call(n, this);
		}
		return console.warn("Temporal.Duration.prototype.toLocaleString() requires Intl.DurationFormat."), Qn(this, "auto");
	}
	valueOf() {
		qo("Duration");
	}
	static from(e) {
		return sn(e);
	}
	static compare(t, n, r = void 0) {
		const o = sn(t), i = sn(n), { plainRelativeTo: s, zonedRelativeTo: c } = _t(Zo(r));
		if (re(o, Y) === re(i, Y) && re(o, R) === re(i, R) && re(o, S) === re(i, S) && re(o, j) === re(i, j) && re(o, k) === re(i, k) && re(o, N) === re(i, N) && re(o, x) === re(i, x) && re(o, L) === re(i, L) && re(o, P) === re(i, P) && re(o, U) === re(i, U)) return 0;
		const d = Jt(o), h = Jt(i), u = Ar(o), l = Ar(i);
		if (c && ("date" === Vt(d) || "date" === Vt(h))) {
			const t = re(c, $), n = re(c, E), r = re(c, b), o = po(r, t, n, u), i = po(r, t, n, l);
			return Bo(import_jsbi_umd.default.toNumber(import_jsbi_umd.default.subtract(o, i)));
		}
		let m = u.date.days, f = l.date.days;
		if (Kt(d) || Kt(h)) {
			if (!s) throw new RangeError("A starting point is required for years, months, or weeks comparison");
			m = Rr(u.date, s), f = Rr(l.date, s);
		}
		const y = u.time.add24HourDays(m), p = l.time.add24HourDays(f);
		return y.cmp(p);
	}
};
ae(Duration, "Temporal.Duration");
var PlainMonthDay = class {
	constructor(e, t, n = "iso8601", r = 1972) {
		const o = _e(e), i = _e(t), a = zo(void 0 === n ? "iso8601" : Ve(n)), s = _e(r);
		xr(s, o, i), vn(this, {
			year: s,
			month: o,
			day: i
		}, a);
	}
	get monthCode() {
		return Pi(this, "monthCode");
	}
	get day() {
		return Pi(this, "day");
	}
	get calendarId() {
		return vt(this, gt), re(this, E);
	}
	with(e, t = void 0) {
		if (vt(this, gt), !Ae(e)) throw new TypeError("invalid argument");
		bt(e);
		const n = re(this, E);
		let r = en(n, re(this, D), "month-day");
		return r = Rn(n, r, tn(n, e, [
			"year",
			"month",
			"monthCode",
			"day"
		], [], "partial")), bn(Un(n, r, Lt(Zo(t))), n);
	}
	equals(e) {
		vt(this, gt);
		const t = dn(e);
		return 0 === Ro(re(this, D), re(t, D)) && xn(re(this, E), re(t, E));
	}
	toString(e = void 0) {
		return vt(this, gt), rr(this, Zt(Zo(e)));
	}
	toJSON() {
		return vt(this, gt), rr(this);
	}
	toLocaleString(e = void 0, t = void 0) {
		return vt(this, gt), new di(e, t).format(this);
	}
	valueOf() {
		qo("PlainMonthDay");
	}
	toPlainDate(e) {
		if (vt(this, gt), !Ae(e)) throw new TypeError("argument should be an object");
		const t = re(this, E);
		return pn(Ln(t, Rn(t, en(t, re(this, D), "month-day"), tn(t, e, ["year"], [], [])), "constrain"), t);
	}
	static from(e, t = void 0) {
		return dn(e, t);
	}
};
function Pi(e, t) {
	vt(e, gt);
	const n = re(e, D);
	return Qt(e).isoToDate(n, { [t]: !0 })[t];
}
function Ui(e) {
	return zn(e, Po());
}
ae(PlainMonthDay, "Temporal.PlainMonthDay");
const Bi = {
	instant: () => Cn(Po()),
	plainDateTimeISO: (e = Uo()) => wn(Ui(Bn(e)), "iso8601"),
	plainDateISO: (e = Uo()) => pn(Ui(Bn(e)).isoDate, "iso8601"),
	plainTimeISO: (e = Uo()) => Tn(Ui(Bn(e)).time),
	timeZoneId: () => Uo(),
	zonedDateTimeISO: (e = Uo()) => {
		const t = Bn(e);
		return $n(Po(), t, "iso8601");
	},
	[Symbol.toStringTag]: "Temporal.Now"
};
Object.defineProperty(Bi, Symbol.toStringTag, {
	value: "Temporal.Now",
	writable: !1,
	enumerable: !1,
	configurable: !0
});
var PlainTime = class PlainTime {
	constructor(e = 0, t = 0, n = 0, r = 0, o = 0, i = 0) {
		const a = void 0 === e ? 0 : _e(e), s = void 0 === t ? 0 : _e(t), c = void 0 === n ? 0 : _e(n), d = void 0 === r ? 0 : _e(r), h = void 0 === o ? 0 : _e(o), u = void 0 === i ? 0 : _e(i);
		Pr(a, s, c, d, h, u), Dn(this, {
			hour: a,
			minute: s,
			second: c,
			millisecond: d,
			microsecond: h,
			nanosecond: u
		});
	}
	get hour() {
		return vt(this, ft), re(this, M).hour;
	}
	get minute() {
		return vt(this, ft), re(this, M).minute;
	}
	get second() {
		return vt(this, ft), re(this, M).second;
	}
	get millisecond() {
		return vt(this, ft), re(this, M).millisecond;
	}
	get microsecond() {
		return vt(this, ft), re(this, M).microsecond;
	}
	get nanosecond() {
		return vt(this, ft), re(this, M).nanosecond;
	}
	with(e, t = void 0) {
		if (vt(this, ft), !Ae(e)) throw new TypeError("invalid argument");
		bt(e);
		const n = nn(e, "partial"), r = nn(this);
		let { hour: o, minute: i, second: a, millisecond: s, microsecond: c, nanosecond: d } = Object.assign(r, n);
		const h = Lt(Zo(t));
		return {hour: o, minute: i, second: a, millisecond: s, microsecond: c, nanosecond: d} = jt(o, i, a, s, c, d, h), new PlainTime(o, i, a, s, c, d);
	}
	add(e) {
		return vt(this, ft), Do("add", this, e);
	}
	subtract(e) {
		return vt(this, ft), Do("subtract", this, e);
	}
	until(e, t = void 0) {
		return vt(this, ft), uo("until", this, e, t);
	}
	since(e, t = void 0) {
		return vt(this, ft), uo("since", this, e, t);
	}
	round(e) {
		if (vt(this, ft), void 0 === e) throw new TypeError("options parameter is required");
		const t = "string" == typeof e ? Fo("smallestUnit", e) : Zo(e), n = Ft(t), r = Ut(t, "halfExpand"), o = Wt(t, "smallestUnit", "time", qt);
		return Ht(n, {
			hour: 24,
			minute: 60,
			second: 60,
			millisecond: 1e3,
			microsecond: 1e3,
			nanosecond: 1e3
		}[o], !1), Tn(Oo(re(this, M), n, o, r));
	}
	equals(e) {
		vt(this, ft);
		const t = hn(e);
		return 0 === So(re(this, M), re(t, M));
	}
	toString(e = void 0) {
		vt(this, ft);
		const t = Zo(e), n = zt(t), r = Ut(t, "trunc"), o = Wt(t, "smallestUnit", "time", void 0);
		if ("hour" === o) throw new RangeError("smallestUnit must be a time unit other than \"hour\"");
		const { precision: i, unit: a, increment: s } = At(o, n);
		return tr(Oo(re(this, M), s, a, r), i);
	}
	toJSON() {
		return vt(this, ft), tr(re(this, M), "auto");
	}
	toLocaleString(e = void 0, t = void 0) {
		return vt(this, ft), new di(e, t).format(this);
	}
	valueOf() {
		qo("PlainTime");
	}
	static from(e, t = void 0) {
		return hn(e, t);
	}
	static compare(e, t) {
		const n = hn(e), r = hn(t);
		return So(re(n, M), re(r, M));
	}
};
ae(PlainTime, "Temporal.PlainTime");
var PlainYearMonth = class {
	constructor(e, t, n = "iso8601", r = 1) {
		const o = _e(e), i = _e(t), a = zo(void 0 === n ? "iso8601" : Ve(n)), s = _e(r);
		xr(o, i, s), Mn(this, {
			year: o,
			month: i,
			day: s
		}, a);
	}
	get year() {
		return Zi(this, "year");
	}
	get month() {
		return Zi(this, "month");
	}
	get monthCode() {
		return Zi(this, "monthCode");
	}
	get calendarId() {
		return vt(this, pt), re(this, E);
	}
	get era() {
		return Zi(this, "era");
	}
	get eraYear() {
		return Zi(this, "eraYear");
	}
	get daysInMonth() {
		return Zi(this, "daysInMonth");
	}
	get daysInYear() {
		return Zi(this, "daysInYear");
	}
	get monthsInYear() {
		return Zi(this, "monthsInYear");
	}
	get inLeapYear() {
		return Zi(this, "inLeapYear");
	}
	with(e, t = void 0) {
		if (vt(this, pt), !Ae(e)) throw new TypeError("invalid argument");
		bt(e);
		const n = re(this, E);
		let r = en(n, re(this, D), "year-month");
		return r = Rn(n, r, tn(n, e, [
			"year",
			"month",
			"monthCode"
		], [], "partial")), En(Pn(n, r, Lt(Zo(t))), n);
	}
	add(e, t = void 0) {
		return vt(this, pt), To("add", this, e, t);
	}
	subtract(e, t = void 0) {
		return vt(this, pt), To("subtract", this, e, t);
	}
	until(e, t = void 0) {
		return vt(this, pt), lo("until", this, e, t);
	}
	since(e, t = void 0) {
		return vt(this, pt), lo("since", this, e, t);
	}
	equals(e) {
		vt(this, pt);
		const t = ln(e);
		return 0 === Ro(re(this, D), re(t, D)) && xn(re(this, E), re(t, E));
	}
	toString(e = void 0) {
		return vt(this, pt), or(this, Zt(Zo(e)));
	}
	toJSON() {
		return vt(this, pt), or(this);
	}
	toLocaleString(e = void 0, t = void 0) {
		return vt(this, pt), new di(e, t).format(this);
	}
	valueOf() {
		qo("PlainYearMonth");
	}
	toPlainDate(e) {
		if (vt(this, pt), !Ae(e)) throw new TypeError("argument should be an object");
		const t = re(this, E);
		return pn(Ln(t, Rn(t, en(t, re(this, D), "year-month"), tn(t, e, ["day"], [], [])), "constrain"), t);
	}
	static from(e, t = void 0) {
		return ln(e, t);
	}
	static compare(e, t) {
		const n = ln(e), r = ln(t);
		return Ro(re(n, D), re(r, D));
	}
};
function Zi(e, t) {
	vt(e, pt);
	const n = re(e, D);
	return Qt(e).isoToDate(n, { [t]: !0 })[t];
}
ae(PlainYearMonth, "Temporal.PlainYearMonth");
const Fi = di.prototype.resolvedOptions;
var ZonedDateTime = class {
	constructor(e, t, n = "iso8601") {
		if (arguments.length < 1) throw new TypeError("missing argument: epochNanoseconds is required");
		const r = Lo(e);
		let o = Ve(t);
		const { tzName: i, offsetMinutes: a } = Rt(o);
		if (void 0 === a) {
			const e = hr(i);
			if (!e) throw new RangeError(`unknown time zone ${i}`);
			o = e.identifier;
		} else o = mr(a);
		On(this, r, o, zo(void 0 === n ? "iso8601" : Ve(n)));
	}
	get calendarId() {
		return vt(this, wt), re(this, E);
	}
	get timeZoneId() {
		return vt(this, wt), re(this, $);
	}
	get year() {
		return zi(this, "year");
	}
	get month() {
		return zi(this, "month");
	}
	get monthCode() {
		return zi(this, "monthCode");
	}
	get day() {
		return zi(this, "day");
	}
	get hour() {
		return Ai(this, "hour");
	}
	get minute() {
		return Ai(this, "minute");
	}
	get second() {
		return Ai(this, "second");
	}
	get millisecond() {
		return Ai(this, "millisecond");
	}
	get microsecond() {
		return Ai(this, "microsecond");
	}
	get nanosecond() {
		return Ai(this, "nanosecond");
	}
	get era() {
		return zi(this, "era");
	}
	get eraYear() {
		return zi(this, "eraYear");
	}
	get epochMilliseconds() {
		return vt(this, wt), No(re(this, b), "floor");
	}
	get epochNanoseconds() {
		return vt(this, wt), ko(re(this, b));
	}
	get dayOfWeek() {
		return zi(this, "dayOfWeek");
	}
	get dayOfYear() {
		return zi(this, "dayOfYear");
	}
	get weekOfYear() {
		return zi(this, "weekOfYear")?.week;
	}
	get yearOfWeek() {
		return zi(this, "weekOfYear")?.year;
	}
	get hoursInDay() {
		vt(this, wt);
		const e = re(this, $), t = Hi(this).isoDate, n = Or(t.year, t.month, t.day + 1), r = _n(e, t), o = _n(e, n);
		return Yo(TimeDuration.fromEpochNsDiff(o, r), "hour");
	}
	get daysInWeek() {
		return zi(this, "daysInWeek");
	}
	get daysInMonth() {
		return zi(this, "daysInMonth");
	}
	get daysInYear() {
		return zi(this, "daysInYear");
	}
	get monthsInYear() {
		return zi(this, "monthsInYear");
	}
	get inLeapYear() {
		return zi(this, "inLeapYear");
	}
	get offset() {
		return vt(this, wt), Hn(Fn(re(this, $), re(this, b)));
	}
	get offsetNanoseconds() {
		return vt(this, wt), Fn(re(this, $), re(this, b));
	}
	with(e, t = void 0) {
		if (vt(this, wt), !Ae(e)) throw new TypeError("invalid zoned-date-time-like");
		bt(e);
		const n = re(this, E), r = re(this, $), o = Fn(r, re(this, b)), i = Hi(this);
		let a = {
			...en(n, i.isoDate),
			...i.time,
			offset: Hn(o)
		};
		a = Rn(n, a, tn(n, e, [
			"year",
			"month",
			"monthCode",
			"day"
		], [
			"hour",
			"minute",
			"second",
			"millisecond",
			"microsecond",
			"nanosecond",
			"offset"
		], "partial"));
		const s = Zo(t), c = Pt(s), d = Bt(s, "prefer"), h = on(n, a, Lt(s)), u = sr(a.offset);
		return $n(mn(h.isoDate, h.time, "option", u, r, c, d, !1), r, n);
	}
	withPlainTime(e = void 0) {
		vt(this, wt);
		const t = re(this, $), n = re(this, E), r = Hi(this).isoDate;
		let o;
		return o = void 0 === e ? _n(t, r) : An(t, xt(r, re(hn(e), M)), "compatible"), $n(o, t, n);
	}
	withTimeZone(e) {
		vt(this, wt);
		const t = Bn(e);
		return $n(re(this, b), t, re(this, E));
	}
	withCalendar(e) {
		vt(this, wt);
		const t = kn(e);
		return $n(re(this, b), re(this, $), t);
	}
	add(e, t = void 0) {
		return vt(this, wt), Mo("add", this, e, t);
	}
	subtract(e, t = void 0) {
		return vt(this, wt), Mo("subtract", this, e, t);
	}
	until(e, t = void 0) {
		return vt(this, wt), mo("until", this, e, t);
	}
	since(e, t = void 0) {
		return vt(this, wt), mo("since", this, e, t);
	}
	round(t) {
		if (vt(this, wt), void 0 === t) throw new TypeError("options parameter is required");
		const n = "string" == typeof t ? Fo("smallestUnit", t) : Zo(t), r = Ft(n), o = Ut(n, "halfExpand"), i = Wt(n, "smallestUnit", "time", qt, ["day"]), a = {
			day: 1,
			hour: 24,
			minute: 60,
			second: 60,
			millisecond: 1e3,
			microsecond: 1e3,
			nanosecond: 1e3
		}[i];
		if (Ht(r, a, 1 === a), "nanosecond" === i && 1 === r) return $n(re(this, b), re(this, $), re(this, E));
		const s = re(this, $), c = re(this, b), d = Hi(this);
		let h;
		if ("day" === i) {
			const t = d.isoDate, n = Or(t.year, t.month, t.day + 1), r = _n(s, t), i = _n(s, n), a = import_jsbi_umd.default.subtract(i, r);
			h = TimeDuration.fromEpochNsDiff(c, r).round(a, o).addToEpochNs(r);
		} else {
			const e = Co(d, r, i, o), t = Fn(s, c);
			h = mn(e.isoDate, e.time, "option", t, s, "compatible", "prefer", !1);
		}
		return $n(h, s, re(this, E));
	}
	equals(t) {
		vt(this, wt);
		const n = fn(t), r = re(this, b), o = re(n, b);
		return !!import_jsbi_umd.default.equal(import_jsbi_umd.default.BigInt(r), import_jsbi_umd.default.BigInt(o)) && !!Zn(re(this, $), re(n, $)) && xn(re(this, E), re(n, E));
	}
	toString(e = void 0) {
		vt(this, wt);
		const t = Zo(e), n = Zt(t), r = zt(t), o = function(e) {
			return Ho(e, "offset", ["auto", "never"], "auto");
		}(t), i = Ut(t, "trunc"), a = Wt(t, "smallestUnit", "time", void 0);
		if ("hour" === a) throw new RangeError("smallestUnit must be a time unit other than \"hour\"");
		const s = function(e) {
			return Ho(e, "timeZoneName", [
				"auto",
				"never",
				"critical"
			], "auto");
		}(t), { precision: c, unit: d, increment: h } = At(a, r);
		return ir(this, c, n, s, o, {
			unit: d,
			increment: h,
			roundingMode: i
		});
	}
	toLocaleString(e = void 0, t = void 0) {
		vt(this, wt);
		const n = Zo(t), r = Object.create(null);
		if (function(e, t, n, r) {
			if (null == t) return;
			const o = Reflect.ownKeys(t);
			for (let i = 0; i < o.length; i++) {
				const a = o[i];
				if (!n.some(((e) => Object.is(e, a))) && Object.prototype.propertyIsEnumerable.call(t, a)) e[a] = t[a];
			}
		}(r, n, ["timeZone"]), void 0 !== n.timeZone) throw new TypeError("ZonedDateTime toLocaleString does not accept a timeZone option");
		if (void 0 === r.year && void 0 === r.month && void 0 === r.day && void 0 === r.era && void 0 === r.weekday && void 0 === r.dateStyle && void 0 === r.hour && void 0 === r.minute && void 0 === r.second && void 0 === r.fractionalSecondDigits && void 0 === r.timeStyle && void 0 === r.dayPeriod && void 0 === r.timeZoneName && (r.timeZoneName = "short"), r.timeZone = re(this, $), ar(r.timeZone)) throw new RangeError("toLocaleString does not currently support offset time zones");
		const o = new di(e, r), i = Fi.call(o).calendar, a = re(this, E);
		if ("iso8601" !== a && "iso8601" !== i && !xn(i, a)) throw new RangeError(`cannot format ZonedDateTime with calendar ${a} in locale with calendar ${i}`);
		return o.format(Cn(re(this, b)));
	}
	toJSON() {
		return vt(this, wt), ir(this, "auto");
	}
	valueOf() {
		qo("ZonedDateTime");
	}
	startOfDay() {
		vt(this, wt);
		const e = re(this, $);
		return $n(_n(e, Hi(this).isoDate), e, re(this, E));
	}
	getTimeZoneTransition(e) {
		vt(this, wt);
		const t = re(this, $);
		if (void 0 === e) throw new TypeError("options parameter is required");
		const n = Ho("string" == typeof e ? Fo("direction", e) : Zo(e), "direction", ["next", "previous"], qt);
		if (void 0 === n) throw new TypeError("direction option is required");
		if (ar(t) || "UTC" === t) return null;
		const r = re(this, b), o = "next" === n ? wr(t, r) : vr(t, r);
		return null === o ? null : $n(o, t, re(this, E));
	}
	toInstant() {
		return vt(this, wt), Cn(re(this, b));
	}
	toPlainDate() {
		return vt(this, wt), pn(Hi(this).isoDate, re(this, E));
	}
	toPlainTime() {
		return vt(this, wt), Tn(Hi(this).time);
	}
	toPlainDateTime() {
		return vt(this, wt), wn(Hi(this), re(this, E));
	}
	static from(e, t = void 0) {
		return fn(e, t);
	}
	static compare(t, n) {
		const r = fn(t), o = fn(n), i = re(r, b), a = re(o, b);
		return import_jsbi_umd.default.lessThan(import_jsbi_umd.default.BigInt(i), import_jsbi_umd.default.BigInt(a)) ? -1 : import_jsbi_umd.default.greaterThan(import_jsbi_umd.default.BigInt(i), import_jsbi_umd.default.BigInt(a)) ? 1 : 0;
	}
};
function Hi(e) {
	return zn(re(e, $), re(e, b));
}
function zi(e, t) {
	vt(e, wt);
	const n = Hi(e).isoDate;
	return Qt(e).isoToDate(n, { [t]: !0 })[t];
}
function Ai(e, t) {
	return vt(e, wt), Hi(e).time[t];
}
ae(ZonedDateTime, "Temporal.ZonedDateTime");
var qi = Object.freeze({
	__proto__: null,
	Duration,
	Instant,
	Now: Bi,
	PlainDate,
	PlainDateTime,
	PlainMonthDay,
	PlainTime,
	PlainYearMonth,
	ZonedDateTime
});
(class LegacyDateImpl {
	toTemporalInstant() {
		return Cn(xo(Date.prototype.valueOf.call(this)));
	}
}).prototype.toTemporalInstant;
const _i = [
	Instant,
	PlainDate,
	PlainDateTime,
	Duration,
	PlainMonthDay,
	PlainTime,
	PlainYearMonth,
	ZonedDateTime
];
for (const e of _i) {
	const t = Object.getOwnPropertyDescriptor(e, "prototype");
	(t.configurable || t.enumerable || t.writable) && (t.configurable = !1, t.enumerable = !1, t.writable = !1, Object.defineProperty(e, "prototype", t));
}
//#endregion
//#region src/utils/index.ts
function assertUnreachable(_x) {
	throw new Error("Didn't expect to get here");
}
function escapeSingleQuotes(str) {
	return str.replace(/'/g, "''");
}
const prepareMigrationRenames = (renames) => {
	return renames.map((it) => {
		const schema1 = it.from.schema ? `${it.from.schema}.` : "";
		const schema2 = it.to.schema ? `${it.to.schema}.` : "";
		const table1 = it.from.table ? `${it.from.table}.` : "";
		const table2 = it.to.table ? `${it.to.table}.` : "";
		return `${schema1}${table1}${it.from.name}->${schema2}${table2}${it.to.name}`;
	});
};
function stringifyArray(value, mode, mapCallback, depth = 0) {
	if (!Array.isArray(value)) return mapCallback(value, depth);
	depth += 1;
	const res = value.map((e) => {
		if (Array.isArray(e)) return stringifyArray(e, mode, mapCallback, depth);
		return mapCallback(e, depth);
	}).join(",");
	return mode === "ts" ? `[${res}]` : mode === "geometry-sql" ? `ARRAY[${res}]` : `{${res}}`;
}
function stringifyTuplesArray(array, mode, mapCallback, depth = 0) {
	if (!array.find((n) => Array.isArray(n))) return mapCallback(array, depth);
	depth += 1;
	const res = array.map((e) => {
		if (Array.isArray(e) && e.find((n) => Array.isArray(n))) return stringifyTuplesArray(e, mode, mapCallback, depth);
		return mapCallback(e, depth);
	}).join(",");
	return mode === "ts" ? `[${res}]` : mode === "geometry-sql" ? `ARRAY[${res}]` : `{${res}}`;
}
const trimChar = (str, char) => {
	if (str.length < 2) return str;
	if (typeof char === "string" && str.startsWith(char) && str.endsWith(char)) return str.substring(1, str.length - 1);
	if (Array.isArray(char) && str.startsWith(char[0]) && str.endsWith(char[1])) return str.substring(1, str.length - 1);
	return str;
};
const wrapWith = (it, char) => {
	if (!it.startsWith(char) || !it.endsWith(char)) return `${char}${it}${char}`;
	return it;
};
const timeTzRegex = /\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}(?::?\d{2})?)?/;
const isTime = (it) => {
	return timeTzRegex.test(it);
};
const dateExtractRegex = /^\d{4}-\d{2}-\d{2}/;
const isDate = (it) => {
	return dateExtractRegex.test(it);
};
const timestampRegexp = /^(\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}(?::?\d{2})?)?|\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}(?::?\d{2})?)?)$/;
const isTimestamp = (it) => {
	return timestampRegexp.test(it);
};
const timezoneSuffixRegexp = /([+-]\d{2}(:\d{2})?|Z)$/i;
function hasTimeZoneSuffix(s) {
	return timezoneSuffixRegexp.test(s);
}
const possibleIntervals = [
	"year",
	"month",
	"day",
	"hour",
	"minute",
	"second",
	"year to month",
	"day to hour",
	"day to minute",
	"day to second",
	"hour to minute",
	"hour to second",
	"minute to second"
];
function parseIntervalFields(type) {
	const options = {};
	const splitted = type.split(" ");
	if (splitted.length === 1) return options;
	const rest = splitted.slice(1, splitted.length).join(" ");
	if (possibleIntervals.includes(rest)) return {
		...options,
		fields: rest
	};
	for (const s of possibleIntervals) if (rest.startsWith(`${s}(`)) return {
		...options,
		fields: s
	};
	return options;
}
function parseEWKB(hex) {
	const hexToBytes = (hex) => {
		const bytes = [];
		for (let c = 0; c < hex.length; c += 2) bytes.push(Number.parseInt(hex.slice(c, c + 2), 16));
		return new Uint8Array(bytes);
	};
	const bytesToFloat64 = (bytes, offset) => {
		const buffer = /* @__PURE__ */ new ArrayBuffer(8);
		const view = new DataView(buffer);
		for (let i = 0; i < 8; i++) view.setUint8(i, bytes[offset + i]);
		return view.getFloat64(0, true);
	};
	const bytes = hexToBytes(hex);
	let offset = 0;
	const byteOrder = bytes[offset];
	offset += 1;
	const view = new DataView(bytes.buffer);
	const geomType = view.getUint32(offset, byteOrder === 1);
	offset += 4;
	let srid;
	if (geomType & 536870912) {
		srid = view.getUint32(offset, byteOrder === 1);
		offset += 4;
	}
	if ((geomType & 65535) === 1) {
		const x = bytesToFloat64(bytes, offset);
		offset += 8;
		const y = bytesToFloat64(bytes, offset);
		offset += 8;
		return {
			srid,
			point: [x, y]
		};
	}
	throw new Error("Unsupported geometry type");
}
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/common.js
var common_exports = /* @__PURE__ */ __exportAll({
	StringBuffer: () => StringBuffer,
	abstract: () => abstract,
	assert: () => assert,
	checkNotNull: () => checkNotNull,
	clone: () => clone,
	copyWithoutDuplicates: () => copyWithoutDuplicates,
	defineLazyProperty: () => defineLazyProperty,
	getDuplicates: () => getDuplicates,
	isLexical: () => isLexical,
	isSyntactic: () => isSyntactic,
	padLeft: () => padLeft,
	repeat: () => repeat,
	repeatFn: () => repeatFn,
	repeatStr: () => repeatStr,
	unescapeCodePoint: () => unescapeCodePoint,
	unexpectedObjToString: () => unexpectedObjToString
});
const escapeStringFor = {};
for (let c = 0; c < 128; c++) escapeStringFor[c] = String.fromCharCode(c);
escapeStringFor["'".charCodeAt(0)] = "\\'";
escapeStringFor["\"".charCodeAt(0)] = "\\\"";
escapeStringFor["\\".charCodeAt(0)] = "\\\\";
escapeStringFor["\b".charCodeAt(0)] = "\\b";
escapeStringFor["\f".charCodeAt(0)] = "\\f";
escapeStringFor["\n".charCodeAt(0)] = "\\n";
escapeStringFor["\r".charCodeAt(0)] = "\\r";
escapeStringFor["	".charCodeAt(0)] = "\\t";
escapeStringFor["\v".charCodeAt(0)] = "\\v";
function abstract(optMethodName) {
	const methodName = optMethodName || "";
	return function() {
		throw new Error("this method " + methodName + " is abstract! (it has no implementation in class " + this.constructor.name + ")");
	};
}
function assert(cond, message) {
	if (!cond) throw new Error(message || "Assertion failed");
}
function defineLazyProperty(obj, propName, getterFn) {
	let memo;
	Object.defineProperty(obj, propName, { get() {
		if (!memo) memo = getterFn.call(this);
		return memo;
	} });
}
function clone(obj) {
	if (obj) return Object.assign({}, obj);
	return obj;
}
function repeatFn(fn, n) {
	const arr = [];
	while (n-- > 0) arr.push(fn());
	return arr;
}
function repeatStr(str, n) {
	return new Array(n + 1).join(str);
}
function repeat(x, n) {
	return repeatFn(() => x, n);
}
function getDuplicates(array) {
	const duplicates = [];
	for (let idx = 0; idx < array.length; idx++) {
		const x = array[idx];
		if (array.lastIndexOf(x) !== idx && duplicates.indexOf(x) < 0) duplicates.push(x);
	}
	return duplicates;
}
function copyWithoutDuplicates(array) {
	const noDuplicates = [];
	array.forEach((entry) => {
		if (noDuplicates.indexOf(entry) < 0) noDuplicates.push(entry);
	});
	return noDuplicates;
}
function isSyntactic(ruleName) {
	const firstChar = ruleName[0];
	return firstChar === firstChar.toUpperCase();
}
function isLexical(ruleName) {
	return !isSyntactic(ruleName);
}
function padLeft(str, len, optChar) {
	const ch = optChar || " ";
	if (str.length < len) return repeatStr(ch, len - str.length) + str;
	return str;
}
function StringBuffer() {
	this.strings = [];
}
StringBuffer.prototype.append = function(str) {
	this.strings.push(str);
};
StringBuffer.prototype.contents = function() {
	return this.strings.join("");
};
const escapeUnicode = (str) => String.fromCodePoint(parseInt(str, 16));
function unescapeCodePoint(s) {
	if (s.charAt(0) === "\\") switch (s.charAt(1)) {
		case "b": return "\b";
		case "f": return "\f";
		case "n": return "\n";
		case "r": return "\r";
		case "t": return "	";
		case "v": return "\v";
		case "x": return escapeUnicode(s.slice(2, 4));
		case "u": return s.charAt(2) === "{" ? escapeUnicode(s.slice(3, -1)) : escapeUnicode(s.slice(2, 6));
		default: return s.charAt(1);
	}
	else return s;
}
function unexpectedObjToString(obj) {
	if (obj == null) return String(obj);
	const baseToString = Object.prototype.toString.call(obj);
	try {
		let typeName;
		if (obj.constructor && obj.constructor.name) typeName = obj.constructor.name;
		else if (baseToString.indexOf("[object ") === 0) typeName = baseToString.slice(8, -1);
		else typeName = typeof obj;
		return typeName + ": " + JSON.stringify(String(obj));
	} catch (e) {
		return baseToString;
	}
}
function checkNotNull(obj, message = "unexpected null value") {
	if (obj == null) throw new Error(message);
	return obj;
}
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/UnicodeCategories.js
const UnicodeCategories = {
	Lu: /\p{Lu}/u,
	Ll: /\p{Ll}/u,
	Lt: /\p{Lt}/u,
	Lm: /\p{Lm}/u,
	Lo: /\p{Lo}/u,
	Nl: /\p{Nl}/u,
	Nd: /\p{Nd}/u,
	Mn: /\p{Mn}/u,
	Mc: /\p{Mc}/u,
	Pc: /\p{Pc}/u,
	Zs: /\p{Zs}/u,
	L: /\p{Letter}/u,
	Ltmo: /\p{Lt}|\p{Lm}|\p{Lo}/u
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-main.js
var PExpr = class PExpr {
	constructor() {
		if (this.constructor === PExpr) throw new Error("PExpr cannot be instantiated -- it's abstract");
	}
	withSource(interval) {
		if (interval) this.source = interval.trimmed();
		return this;
	}
};
const any = Object.create(PExpr.prototype);
const end = Object.create(PExpr.prototype);
var Terminal = class extends PExpr {
	constructor(obj) {
		super();
		this.obj = obj;
	}
};
var Range = class extends PExpr {
	constructor(from, to) {
		super();
		this.from = from;
		this.to = to;
		this.matchCodePoint = from.length > 1 || to.length > 1;
	}
};
var Param = class extends PExpr {
	constructor(index) {
		super();
		this.index = index;
	}
};
var Alt = class extends PExpr {
	constructor(terms) {
		super();
		this.terms = terms;
	}
};
var Extend = class extends Alt {
	constructor(superGrammar, name, body) {
		const origBody = superGrammar.rules[name].body;
		super([body, origBody]);
		this.superGrammar = superGrammar;
		this.name = name;
		this.body = body;
	}
};
var Splice = class extends Alt {
	constructor(superGrammar, ruleName, beforeTerms, afterTerms) {
		const origBody = superGrammar.rules[ruleName].body;
		super([
			...beforeTerms,
			origBody,
			...afterTerms
		]);
		this.superGrammar = superGrammar;
		this.ruleName = ruleName;
		this.expansionPos = beforeTerms.length;
	}
};
var Seq = class extends PExpr {
	constructor(factors) {
		super();
		this.factors = factors;
	}
};
var Iter = class extends PExpr {
	constructor(expr) {
		super();
		this.expr = expr;
	}
};
var Star = class extends Iter {};
var Plus = class extends Iter {};
var Opt = class extends Iter {};
Star.prototype.operator = "*";
Plus.prototype.operator = "+";
Opt.prototype.operator = "?";
Star.prototype.minNumMatches = 0;
Plus.prototype.minNumMatches = 1;
Opt.prototype.minNumMatches = 0;
Star.prototype.maxNumMatches = Number.POSITIVE_INFINITY;
Plus.prototype.maxNumMatches = Number.POSITIVE_INFINITY;
Opt.prototype.maxNumMatches = 1;
var Not = class extends PExpr {
	constructor(expr) {
		super();
		this.expr = expr;
	}
};
var Lookahead = class extends PExpr {
	constructor(expr) {
		super();
		this.expr = expr;
	}
};
var Lex = class extends PExpr {
	constructor(expr) {
		super();
		this.expr = expr;
	}
};
var Apply = class extends PExpr {
	constructor(ruleName, args = []) {
		super();
		this.ruleName = ruleName;
		this.args = args;
	}
	isSyntactic() {
		return isSyntactic(this.ruleName);
	}
	toMemoKey() {
		if (!this._memoKey) Object.defineProperty(this, "_memoKey", { value: this.toString() });
		return this._memoKey;
	}
};
var UnicodeChar = class extends PExpr {
	constructor(category) {
		super();
		this.category = category;
		this.pattern = UnicodeCategories[category];
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/errors.js
function createError(message, optInterval) {
	let e;
	if (optInterval) {
		e = new Error(optInterval.getLineAndColumnMessage() + message);
		e.shortMessage = message;
		e.interval = optInterval;
	} else e = new Error(message);
	return e;
}
function intervalSourcesDontMatch() {
	return createError("Interval sources don't match");
}
function undeclaredGrammar(grammarName, namespace, interval) {
	return createError(namespace ? `Grammar ${grammarName} is not declared in namespace '${namespace}'` : "Undeclared grammar " + grammarName, interval);
}
function duplicateGrammarDeclaration(grammar, namespace) {
	return createError("Grammar " + grammar.name + " is already declared in this namespace");
}
function grammarDoesNotSupportIncrementalParsing(grammar) {
	return createError(`Grammar '${grammar.name}' does not support incremental parsing`);
}
function undeclaredRule(ruleName, grammarName, optInterval) {
	return createError("Rule " + ruleName + " is not declared in grammar " + grammarName, optInterval);
}
function cannotOverrideUndeclaredRule(ruleName, grammarName, optSource) {
	return createError("Cannot override rule " + ruleName + " because it is not declared in " + grammarName, optSource);
}
function cannotExtendUndeclaredRule(ruleName, grammarName, optSource) {
	return createError("Cannot extend rule " + ruleName + " because it is not declared in " + grammarName, optSource);
}
function duplicateRuleDeclaration(ruleName, grammarName, declGrammarName, optSource) {
	let message = "Duplicate declaration for rule '" + ruleName + "' in grammar '" + grammarName + "'";
	if (grammarName !== declGrammarName) message += " (originally declared in '" + declGrammarName + "')";
	return createError(message, optSource);
}
function wrongNumberOfParameters(ruleName, expected, actual, source) {
	return createError("Wrong number of parameters for rule " + ruleName + " (expected " + expected + ", got " + actual + ")", source);
}
function wrongNumberOfArguments(ruleName, expected, actual, expr) {
	return createError("Wrong number of arguments for rule " + ruleName + " (expected " + expected + ", got " + actual + ")", expr);
}
function duplicateParameterNames(ruleName, duplicates, source) {
	return createError("Duplicate parameter names in rule " + ruleName + ": " + duplicates.join(", "), source);
}
function invalidParameter(ruleName, expr) {
	return createError("Invalid parameter to rule " + ruleName + ": " + expr + " has arity " + expr.getArity() + ", but parameter expressions must have arity 1", expr.source);
}
function applicationOfSyntacticRuleFromLexicalContext(ruleName, applyExpr) {
	return createError("Cannot apply syntactic rule " + ruleName + " from here (inside a lexical context)", applyExpr.source);
}
function applySyntacticWithLexicalRuleApplication(applyExpr) {
	const { ruleName } = applyExpr;
	return createError(`applySyntactic is for syntactic rules, but '${ruleName}' is a lexical rule. NOTE: A _syntactic rule_ is a rule whose name begins with a capital letter. See https://ohmjs.org/d/svl for more details.`, applyExpr.source);
}
function unnecessaryExperimentalApplySyntactic(applyExpr) {
	return createError("applySyntactic is not required here (in a syntactic context)", applyExpr.source);
}
function incorrectArgumentType(expectedType, expr) {
	return createError("Incorrect argument type: expected " + expectedType, expr.source);
}
function multipleSuperSplices(expr) {
	return createError("'...' can appear at most once in a rule body", expr.source);
}
function invalidCodePoint(applyWrapper) {
	const node = applyWrapper._node;
	assert(node && node.isNonterminal() && node.ctorName === "escapeChar_unicodeCodePoint");
	const digitIntervals = applyWrapper.children.slice(1, -1).map((d) => d.source);
	const fullInterval = digitIntervals[0].coverageWith(...digitIntervals.slice(1));
	return createError(`U+${fullInterval.contents} is not a valid Unicode code point`, fullInterval);
}
function kleeneExprHasNullableOperand(kleeneExpr, applicationStack) {
	const actuals = applicationStack.length > 0 ? applicationStack[applicationStack.length - 1].args : [];
	let message = "Nullable expression " + kleeneExpr.expr.substituteParams(actuals) + " is not allowed inside '" + kleeneExpr.operator + "' (possible infinite loop)";
	if (applicationStack.length > 0) {
		const stackTrace = applicationStack.map((app) => new Apply(app.ruleName, app.args)).join("\n");
		message += "\nApplication stack (most recent application last):\n" + stackTrace;
	}
	return createError(message, kleeneExpr.expr.source);
}
function inconsistentArity(ruleName, expected, actual, expr) {
	return createError("Rule " + ruleName + " involves an alternation which has inconsistent arity (expected " + expected + ", got " + actual + ")", expr.source);
}
function multipleErrors(errors) {
	const messages = errors.map((e) => e.message);
	return createError(["Errors:"].concat(messages).join("\n- "), errors[0].interval);
}
function missingSemanticAction(ctorName, name, type, stack) {
	let stackTrace = stack.slice(0, -1).map((info) => {
		const ans = "  " + info[0].name + " > " + info[1];
		return info.length === 3 ? ans + " for '" + info[2] + "'" : ans;
	}).join("\n");
	stackTrace += "\n  " + name + " > " + ctorName;
	let moreInfo = "";
	if (ctorName === "_iter") moreInfo = ["\nNOTE: as of Ohm v16, there is no default action for iteration nodes — see ", "  https://ohmjs.org/d/dsa for details."].join("\n");
	const e = createError([
		`Missing semantic action for '${ctorName}' in ${type} '${name}'.${moreInfo}`,
		"Action stack (most recent call last):",
		stackTrace
	].join("\n"));
	e.name = "missingSemanticAction";
	return e;
}
function throwErrors(errors) {
	if (errors.length === 1) throw errors[0];
	if (errors.length > 1) throw multipleErrors(errors);
}
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/util.js
function padNumbersToEqualLength(arr) {
	let maxLen = 0;
	return arr.map((n) => {
		const str = n.toString();
		maxLen = Math.max(maxLen, str.length);
		return str;
	}).map((s) => padLeft(s, maxLen));
}
function strcpy(dest, src, offset) {
	const origDestLen = dest.length;
	const start = dest.slice(0, offset);
	const end = dest.slice(offset + src.length);
	return (start + src + end).substr(0, origDestLen);
}
function lineAndColumnToMessage(...ranges) {
	const lineAndCol = this;
	const { offset } = lineAndCol;
	const { repeatStr } = common_exports;
	const sb = new StringBuffer();
	sb.append("Line " + lineAndCol.lineNum + ", col " + lineAndCol.colNum + ":\n");
	const lineNumbers = padNumbersToEqualLength([
		lineAndCol.prevLine == null ? 0 : lineAndCol.lineNum - 1,
		lineAndCol.lineNum,
		lineAndCol.nextLine == null ? 0 : lineAndCol.lineNum + 1
	]);
	const appendLine = (num, content, prefix) => {
		sb.append(prefix + lineNumbers[num] + " | " + content + "\n");
	};
	if (lineAndCol.prevLine != null) appendLine(0, lineAndCol.prevLine, "  ");
	appendLine(1, lineAndCol.line, "> ");
	const lineLen = lineAndCol.line.length;
	let indicationLine = repeatStr(" ", lineLen + 1);
	for (let i = 0; i < ranges.length; ++i) {
		let startIdx = ranges[i][0];
		let endIdx = ranges[i][1];
		assert(startIdx >= 0 && startIdx <= endIdx, "range start must be >= 0 and <= end");
		const lineStartOffset = offset - lineAndCol.colNum + 1;
		startIdx = Math.max(0, startIdx - lineStartOffset);
		endIdx = Math.min(endIdx - lineStartOffset, lineLen);
		indicationLine = strcpy(indicationLine, repeatStr("~", endIdx - startIdx), startIdx);
	}
	const gutterWidth = 2 + lineNumbers[1].length + 3;
	sb.append(repeatStr(" ", gutterWidth));
	indicationLine = strcpy(indicationLine, "^", lineAndCol.colNum - 1);
	sb.append(indicationLine.replace(/ +$/, "") + "\n");
	if (lineAndCol.nextLine != null) appendLine(2, lineAndCol.nextLine, "  ");
	return sb.contents();
}
let builtInRulesCallbacks = [];
function awaitBuiltInRules(cb) {
	builtInRulesCallbacks.push(cb);
}
function announceBuiltInRules(grammar) {
	builtInRulesCallbacks.forEach((cb) => {
		cb(grammar);
	});
	builtInRulesCallbacks = null;
}
function getLineAndColumn(str, offset) {
	let lineNum = 1;
	let colNum = 1;
	let currOffset = 0;
	let lineStartOffset = 0;
	let nextLine = null;
	let prevLine = null;
	let prevLineStartOffset = -1;
	while (currOffset < offset) {
		const c = str.charAt(currOffset++);
		if (c === "\n") {
			lineNum++;
			colNum = 1;
			prevLineStartOffset = lineStartOffset;
			lineStartOffset = currOffset;
		} else if (c !== "\r") colNum++;
	}
	let lineEndOffset = str.indexOf("\n", lineStartOffset);
	if (lineEndOffset === -1) lineEndOffset = str.length;
	else {
		const nextLineEndOffset = str.indexOf("\n", lineEndOffset + 1);
		nextLine = nextLineEndOffset === -1 ? str.slice(lineEndOffset) : str.slice(lineEndOffset, nextLineEndOffset);
		nextLine = nextLine.replace(/^\r?\n/, "").replace(/\r$/, "");
	}
	if (prevLineStartOffset >= 0) prevLine = str.slice(prevLineStartOffset, lineStartOffset).replace(/\r?\n$/, "");
	const line = str.slice(lineStartOffset, lineEndOffset).replace(/\r$/, "");
	return {
		offset,
		lineNum,
		colNum,
		line,
		prevLine,
		nextLine,
		toString: lineAndColumnToMessage
	};
}
function getLineAndColumnMessage(str, offset, ...ranges) {
	return getLineAndColumn(str, offset).toString(...ranges);
}
const uniqueId = (() => {
	let idCounter = 0;
	return (prefix) => "" + prefix + idCounter++;
})();
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/Interval.js
var Interval$1 = class Interval$1 {
	constructor(sourceString, startIdx, endIdx) {
		this.sourceString = sourceString;
		this.startIdx = startIdx;
		this.endIdx = endIdx;
	}
	get contents() {
		if (this._contents === void 0) this._contents = this.sourceString.slice(this.startIdx, this.endIdx);
		return this._contents;
	}
	get length() {
		return this.endIdx - this.startIdx;
	}
	coverageWith(...intervals) {
		return Interval$1.coverage(...intervals, this);
	}
	collapsedLeft() {
		return new Interval$1(this.sourceString, this.startIdx, this.startIdx);
	}
	collapsedRight() {
		return new Interval$1(this.sourceString, this.endIdx, this.endIdx);
	}
	getLineAndColumn() {
		return getLineAndColumn(this.sourceString, this.startIdx);
	}
	getLineAndColumnMessage() {
		const range = [this.startIdx, this.endIdx];
		return getLineAndColumnMessage(this.sourceString, this.startIdx, range);
	}
	minus(that) {
		if (this.sourceString !== that.sourceString) throw intervalSourcesDontMatch();
		else if (this.startIdx === that.startIdx && this.endIdx === that.endIdx) return [];
		else if (this.startIdx < that.startIdx && that.endIdx < this.endIdx) return [new Interval$1(this.sourceString, this.startIdx, that.startIdx), new Interval$1(this.sourceString, that.endIdx, this.endIdx)];
		else if (this.startIdx < that.endIdx && that.endIdx < this.endIdx) return [new Interval$1(this.sourceString, that.endIdx, this.endIdx)];
		else if (this.startIdx < that.startIdx && that.startIdx < this.endIdx) return [new Interval$1(this.sourceString, this.startIdx, that.startIdx)];
		else return [this];
	}
	relativeTo(that) {
		if (this.sourceString !== that.sourceString) throw intervalSourcesDontMatch();
		assert(this.startIdx >= that.startIdx && this.endIdx <= that.endIdx, "other interval does not cover this one");
		return new Interval$1(this.sourceString, this.startIdx - that.startIdx, this.endIdx - that.startIdx);
	}
	trimmed() {
		const { contents } = this;
		const startIdx = this.startIdx + contents.match(/^\s*/)[0].length;
		const endIdx = this.endIdx - contents.match(/\s*$/)[0].length;
		return new Interval$1(this.sourceString, startIdx, endIdx);
	}
	subInterval(offset, len) {
		const newStartIdx = this.startIdx + offset;
		return new Interval$1(this.sourceString, newStartIdx, newStartIdx + len);
	}
};
Interval$1.coverage = function(firstInterval, ...intervals) {
	let { startIdx, endIdx } = firstInterval;
	for (const interval of intervals) if (interval.sourceString !== firstInterval.sourceString) throw intervalSourcesDontMatch();
	else {
		startIdx = Math.min(startIdx, interval.startIdx);
		endIdx = Math.max(endIdx, interval.endIdx);
	}
	return new Interval$1(firstInterval.sourceString, startIdx, endIdx);
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/InputStream.js
const MAX_CHAR_CODE = 65535;
var InputStream = class {
	constructor(source) {
		this.source = source;
		this.pos = 0;
		this.examinedLength = 0;
	}
	atEnd() {
		const ans = this.pos >= this.source.length;
		this.examinedLength = Math.max(this.examinedLength, this.pos + 1);
		return ans;
	}
	next() {
		const ans = this.source[this.pos++];
		this.examinedLength = Math.max(this.examinedLength, this.pos);
		return ans;
	}
	nextCharCode() {
		const nextChar = this.next();
		return nextChar && nextChar.charCodeAt(0);
	}
	nextCodePoint() {
		const cp = this.source.slice(this.pos++).codePointAt(0);
		if (cp > MAX_CHAR_CODE) this.pos += 1;
		this.examinedLength = Math.max(this.examinedLength, this.pos);
		return cp;
	}
	matchString(s, optIgnoreCase) {
		let idx;
		if (optIgnoreCase) {
			for (idx = 0; idx < s.length; idx++) {
				const actual = this.next();
				const expected = s[idx];
				if (actual == null || actual.toUpperCase() !== expected.toUpperCase()) return false;
			}
			return true;
		}
		for (idx = 0; idx < s.length; idx++) if (this.next() !== s[idx]) return false;
		return true;
	}
	sourceSlice(startIdx, endIdx) {
		return this.source.slice(startIdx, endIdx);
	}
	interval(startIdx, optEndIdx) {
		return new Interval$1(this.source, startIdx, optEndIdx ? optEndIdx : this.pos);
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/MatchResult.js
var MatchResult = class {
	constructor(matcher, input, startExpr, cst, cstOffset, rightmostFailurePosition, optRecordedFailures) {
		this.matcher = matcher;
		this.input = input;
		this.startExpr = startExpr;
		this._cst = cst;
		this._cstOffset = cstOffset;
		this._rightmostFailurePosition = rightmostFailurePosition;
		this._rightmostFailures = optRecordedFailures;
		if (this.failed()) {
			defineLazyProperty(this, "message", function() {
				const detail = "Expected " + this.getExpectedText();
				return getLineAndColumnMessage(this.input, this.getRightmostFailurePosition()) + detail;
			});
			defineLazyProperty(this, "shortMessage", function() {
				const detail = "expected " + this.getExpectedText();
				const errorInfo = getLineAndColumn(this.input, this.getRightmostFailurePosition());
				return "Line " + errorInfo.lineNum + ", col " + errorInfo.colNum + ": " + detail;
			});
		}
	}
	succeeded() {
		return !!this._cst;
	}
	failed() {
		return !this.succeeded();
	}
	getRightmostFailurePosition() {
		return this._rightmostFailurePosition;
	}
	getRightmostFailures() {
		if (!this._rightmostFailures) {
			this.matcher.setInput(this.input);
			this._rightmostFailures = this.matcher._match(this.startExpr, {
				tracing: false,
				positionToRecordFailures: this.getRightmostFailurePosition()
			}).getRightmostFailures();
		}
		return this._rightmostFailures;
	}
	toString() {
		return this.succeeded() ? "[match succeeded]" : "[match failed at position " + this.getRightmostFailurePosition() + "]";
	}
	getExpectedText() {
		if (this.succeeded()) throw new Error("cannot get expected text of a successful MatchResult");
		const sb = new StringBuffer();
		let failures = this.getRightmostFailures();
		failures = failures.filter((failure) => !failure.isFluffy());
		for (let idx = 0; idx < failures.length; idx++) {
			if (idx > 0) if (idx === failures.length - 1) sb.append(failures.length > 2 ? ", or " : " or ");
			else sb.append(", ");
			sb.append(failures[idx].toString());
		}
		return sb.contents();
	}
	getInterval() {
		const pos = this.getRightmostFailurePosition();
		return new Interval$1(this.input, pos, pos);
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/PosInfo.js
var PosInfo = class {
	constructor() {
		this.applicationMemoKeyStack = [];
		this.memo = {};
		this.maxExaminedLength = 0;
		this.maxRightmostFailureOffset = -1;
		this.currentLeftRecursion = void 0;
	}
	isActive(application) {
		return this.applicationMemoKeyStack.indexOf(application.toMemoKey()) >= 0;
	}
	enter(application) {
		this.applicationMemoKeyStack.push(application.toMemoKey());
	}
	exit() {
		this.applicationMemoKeyStack.pop();
	}
	startLeftRecursion(headApplication, memoRec) {
		memoRec.isLeftRecursion = true;
		memoRec.headApplication = headApplication;
		memoRec.nextLeftRecursion = this.currentLeftRecursion;
		this.currentLeftRecursion = memoRec;
		const { applicationMemoKeyStack } = this;
		const indexOfFirstInvolvedRule = applicationMemoKeyStack.indexOf(headApplication.toMemoKey()) + 1;
		const involvedApplicationMemoKeys = applicationMemoKeyStack.slice(indexOfFirstInvolvedRule);
		memoRec.isInvolved = function(applicationMemoKey) {
			return involvedApplicationMemoKeys.indexOf(applicationMemoKey) >= 0;
		};
		memoRec.updateInvolvedApplicationMemoKeys = function() {
			for (let idx = indexOfFirstInvolvedRule; idx < applicationMemoKeyStack.length; idx++) {
				const applicationMemoKey = applicationMemoKeyStack[idx];
				if (!this.isInvolved(applicationMemoKey)) involvedApplicationMemoKeys.push(applicationMemoKey);
			}
		};
	}
	endLeftRecursion() {
		this.currentLeftRecursion = this.currentLeftRecursion.nextLeftRecursion;
	}
	shouldUseMemoizedResult(memoRec) {
		if (!memoRec.isLeftRecursion) return true;
		const { applicationMemoKeyStack } = this;
		for (let idx = 0; idx < applicationMemoKeyStack.length; idx++) {
			const applicationMemoKey = applicationMemoKeyStack[idx];
			if (memoRec.isInvolved(applicationMemoKey)) return false;
		}
		return true;
	}
	memoize(memoKey, memoRec) {
		this.memo[memoKey] = memoRec;
		this.maxExaminedLength = Math.max(this.maxExaminedLength, memoRec.examinedLength);
		this.maxRightmostFailureOffset = Math.max(this.maxRightmostFailureOffset, memoRec.rightmostFailureOffset);
		return memoRec;
	}
	clearObsoleteEntries(pos, invalidatedIdx) {
		if (pos + this.maxExaminedLength <= invalidatedIdx) return;
		const { memo } = this;
		this.maxExaminedLength = 0;
		this.maxRightmostFailureOffset = -1;
		Object.keys(memo).forEach((k) => {
			const memoRec = memo[k];
			if (pos + memoRec.examinedLength > invalidatedIdx) delete memo[k];
			else {
				this.maxExaminedLength = Math.max(this.maxExaminedLength, memoRec.examinedLength);
				this.maxRightmostFailureOffset = Math.max(this.maxRightmostFailureOffset, memoRec.rightmostFailureOffset);
			}
		});
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/Trace.js
const BALLOT_X = "✗";
const CHECK_MARK = "✓";
const DOT_OPERATOR = "⋅";
const RIGHTWARDS_DOUBLE_ARROW = "⇒";
const SYMBOL_FOR_HORIZONTAL_TABULATION = "␉";
const SYMBOL_FOR_LINE_FEED = "␊";
const SYMBOL_FOR_CARRIAGE_RETURN = "␍";
const Flags = {
	succeeded: 1,
	isRootNode: 2,
	isImplicitSpaces: 4,
	isMemoized: 8,
	isHeadOfLeftRecursion: 16,
	terminatesLR: 32
};
function spaces(n) {
	return repeat(" ", n).join("");
}
function getInputExcerpt(input, pos, len) {
	const excerpt = asEscapedString(input.slice(pos, pos + len));
	if (excerpt.length < len) return excerpt + repeat(" ", len - excerpt.length).join("");
	return excerpt;
}
function asEscapedString(obj) {
	if (typeof obj === "string") return obj.replace(/ /g, DOT_OPERATOR).replace(/\t/g, SYMBOL_FOR_HORIZONTAL_TABULATION).replace(/\n/g, SYMBOL_FOR_LINE_FEED).replace(/\r/g, SYMBOL_FOR_CARRIAGE_RETURN);
	return String(obj);
}
var Trace = class Trace {
	constructor(input, pos1, pos2, expr, succeeded, bindings, optChildren) {
		this.input = input;
		this.pos = this.pos1 = pos1;
		this.pos2 = pos2;
		this.source = new Interval$1(input, pos1, pos2);
		this.expr = expr;
		this.bindings = bindings;
		this.children = optChildren || [];
		this.terminatingLREntry = null;
		this._flags = succeeded ? Flags.succeeded : 0;
	}
	get displayString() {
		return this.expr.toDisplayString();
	}
	clone() {
		return this.cloneWithExpr(this.expr);
	}
	cloneWithExpr(expr) {
		const ans = new Trace(this.input, this.pos, this.pos2, expr, this.succeeded, this.bindings, this.children);
		ans.isHeadOfLeftRecursion = this.isHeadOfLeftRecursion;
		ans.isImplicitSpaces = this.isImplicitSpaces;
		ans.isMemoized = this.isMemoized;
		ans.isRootNode = this.isRootNode;
		ans.terminatesLR = this.terminatesLR;
		ans.terminatingLREntry = this.terminatingLREntry;
		return ans;
	}
	recordLRTermination(ruleBodyTrace, value) {
		this.terminatingLREntry = new Trace(this.input, this.pos, this.pos2, this.expr, false, [value], [ruleBodyTrace]);
		this.terminatingLREntry.terminatesLR = true;
	}
	walk(visitorObjOrFn, optThisArg) {
		let visitor = visitorObjOrFn;
		if (typeof visitor === "function") visitor = { enter: visitor };
		function _walk(node, parent, depth) {
			let recurse = true;
			if (visitor.enter) {
				if (visitor.enter.call(optThisArg, node, parent, depth) === Trace.prototype.SKIP) recurse = false;
			}
			if (recurse) {
				node.children.forEach((child) => {
					_walk(child, node, depth + 1);
				});
				if (visitor.exit) visitor.exit.call(optThisArg, node, parent, depth);
			}
		}
		if (this.isRootNode) this.children.forEach((c) => {
			_walk(c, null, 0);
		});
		else _walk(this, null, 0);
	}
	toString() {
		const sb = new StringBuffer();
		this.walk((node, parent, depth) => {
			if (!node) return this.SKIP;
			if (node.expr.constructor.name === "Alt") return;
			sb.append(getInputExcerpt(node.input, node.pos, 10) + spaces(depth * 2 + 1));
			sb.append((node.succeeded ? CHECK_MARK : BALLOT_X) + " " + node.displayString);
			if (node.isHeadOfLeftRecursion) sb.append(" (LR)");
			if (node.succeeded) {
				const contents = asEscapedString(node.source.contents);
				sb.append(" " + RIGHTWARDS_DOUBLE_ARROW + "  ");
				sb.append(typeof contents === "string" ? "\"" + contents + "\"" : contents);
			}
			sb.append("\n");
		});
		return sb.contents();
	}
};
Trace.prototype.SKIP = {};
Object.keys(Flags).forEach((name) => {
	const mask = Flags[name];
	Object.defineProperty(Trace.prototype, name, {
		get() {
			return (this._flags & mask) !== 0;
		},
		set(val) {
			if (val) this._flags |= mask;
			else this._flags &= ~mask;
		}
	});
});
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-allowsSkippingPrecedingSpace.js
PExpr.prototype.allowsSkippingPrecedingSpace = abstract("allowsSkippingPrecedingSpace");
any.allowsSkippingPrecedingSpace = end.allowsSkippingPrecedingSpace = Apply.prototype.allowsSkippingPrecedingSpace = Terminal.prototype.allowsSkippingPrecedingSpace = Range.prototype.allowsSkippingPrecedingSpace = UnicodeChar.prototype.allowsSkippingPrecedingSpace = function() {
	return true;
};
Alt.prototype.allowsSkippingPrecedingSpace = Iter.prototype.allowsSkippingPrecedingSpace = Lex.prototype.allowsSkippingPrecedingSpace = Lookahead.prototype.allowsSkippingPrecedingSpace = Not.prototype.allowsSkippingPrecedingSpace = Param.prototype.allowsSkippingPrecedingSpace = Seq.prototype.allowsSkippingPrecedingSpace = function() {
	return false;
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-assertAllApplicationsAreValid.js
let BuiltInRules;
awaitBuiltInRules((g) => {
	BuiltInRules = g;
});
let lexifyCount;
PExpr.prototype.assertAllApplicationsAreValid = function(ruleName, grammar) {
	lexifyCount = 0;
	this._assertAllApplicationsAreValid(ruleName, grammar);
};
PExpr.prototype._assertAllApplicationsAreValid = abstract("_assertAllApplicationsAreValid");
any._assertAllApplicationsAreValid = end._assertAllApplicationsAreValid = Terminal.prototype._assertAllApplicationsAreValid = Range.prototype._assertAllApplicationsAreValid = Param.prototype._assertAllApplicationsAreValid = UnicodeChar.prototype._assertAllApplicationsAreValid = function(ruleName, grammar) {};
Lex.prototype._assertAllApplicationsAreValid = function(ruleName, grammar) {
	lexifyCount++;
	this.expr._assertAllApplicationsAreValid(ruleName, grammar);
	lexifyCount--;
};
Alt.prototype._assertAllApplicationsAreValid = function(ruleName, grammar) {
	for (let idx = 0; idx < this.terms.length; idx++) this.terms[idx]._assertAllApplicationsAreValid(ruleName, grammar);
};
Seq.prototype._assertAllApplicationsAreValid = function(ruleName, grammar) {
	for (let idx = 0; idx < this.factors.length; idx++) this.factors[idx]._assertAllApplicationsAreValid(ruleName, grammar);
};
Iter.prototype._assertAllApplicationsAreValid = Not.prototype._assertAllApplicationsAreValid = Lookahead.prototype._assertAllApplicationsAreValid = function(ruleName, grammar) {
	this.expr._assertAllApplicationsAreValid(ruleName, grammar);
};
Apply.prototype._assertAllApplicationsAreValid = function(ruleName, grammar, skipSyntacticCheck = false) {
	const ruleInfo = grammar.rules[this.ruleName];
	const isContextSyntactic = isSyntactic(ruleName) && lexifyCount === 0;
	if (!ruleInfo) throw undeclaredRule(this.ruleName, grammar.name, this.source);
	if (!skipSyntacticCheck && isSyntactic(this.ruleName) && !isContextSyntactic) throw applicationOfSyntacticRuleFromLexicalContext(this.ruleName, this);
	const actual = this.args.length;
	const expected = ruleInfo.formals.length;
	if (actual !== expected) throw wrongNumberOfArguments(this.ruleName, expected, actual, this.source);
	const isBuiltInApplySyntactic = BuiltInRules && ruleInfo === BuiltInRules.rules.applySyntactic;
	if (BuiltInRules && ruleInfo === BuiltInRules.rules.caseInsensitive) {
		if (!(this.args[0] instanceof Terminal)) throw incorrectArgumentType("a Terminal (e.g. \"abc\")", this.args[0]);
	}
	if (isBuiltInApplySyntactic) {
		const arg = this.args[0];
		if (!(arg instanceof Apply)) throw incorrectArgumentType("a syntactic rule application", arg);
		if (!isSyntactic(arg.ruleName)) throw applySyntacticWithLexicalRuleApplication(arg);
		if (isContextSyntactic) throw unnecessaryExperimentalApplySyntactic(this);
	}
	this.args.forEach((arg) => {
		arg._assertAllApplicationsAreValid(ruleName, grammar, isBuiltInApplySyntactic);
		if (arg.getArity() !== 1) throw invalidParameter(this.ruleName, arg);
	});
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-assertChoicesHaveUniformArity.js
PExpr.prototype.assertChoicesHaveUniformArity = abstract("assertChoicesHaveUniformArity");
any.assertChoicesHaveUniformArity = end.assertChoicesHaveUniformArity = Terminal.prototype.assertChoicesHaveUniformArity = Range.prototype.assertChoicesHaveUniformArity = Param.prototype.assertChoicesHaveUniformArity = Lex.prototype.assertChoicesHaveUniformArity = UnicodeChar.prototype.assertChoicesHaveUniformArity = function(ruleName) {};
Alt.prototype.assertChoicesHaveUniformArity = function(ruleName) {
	if (this.terms.length === 0) return;
	const arity = this.terms[0].getArity();
	for (let idx = 0; idx < this.terms.length; idx++) {
		const term = this.terms[idx];
		term.assertChoicesHaveUniformArity();
		const otherArity = term.getArity();
		if (arity !== otherArity) throw inconsistentArity(ruleName, arity, otherArity, term);
	}
};
Extend.prototype.assertChoicesHaveUniformArity = function(ruleName) {
	const actualArity = this.terms[0].getArity();
	const expectedArity = this.terms[1].getArity();
	if (actualArity !== expectedArity) throw inconsistentArity(ruleName, expectedArity, actualArity, this.terms[0]);
};
Seq.prototype.assertChoicesHaveUniformArity = function(ruleName) {
	for (let idx = 0; idx < this.factors.length; idx++) this.factors[idx].assertChoicesHaveUniformArity(ruleName);
};
Iter.prototype.assertChoicesHaveUniformArity = function(ruleName) {
	this.expr.assertChoicesHaveUniformArity(ruleName);
};
Not.prototype.assertChoicesHaveUniformArity = function(ruleName) {};
Lookahead.prototype.assertChoicesHaveUniformArity = function(ruleName) {
	this.expr.assertChoicesHaveUniformArity(ruleName);
};
Apply.prototype.assertChoicesHaveUniformArity = function(ruleName) {};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-assertIteratedExprsAreNotNullable.js
PExpr.prototype.assertIteratedExprsAreNotNullable = abstract("assertIteratedExprsAreNotNullable");
any.assertIteratedExprsAreNotNullable = end.assertIteratedExprsAreNotNullable = Terminal.prototype.assertIteratedExprsAreNotNullable = Range.prototype.assertIteratedExprsAreNotNullable = Param.prototype.assertIteratedExprsAreNotNullable = UnicodeChar.prototype.assertIteratedExprsAreNotNullable = function(grammar) {};
Alt.prototype.assertIteratedExprsAreNotNullable = function(grammar) {
	for (let idx = 0; idx < this.terms.length; idx++) this.terms[idx].assertIteratedExprsAreNotNullable(grammar);
};
Seq.prototype.assertIteratedExprsAreNotNullable = function(grammar) {
	for (let idx = 0; idx < this.factors.length; idx++) this.factors[idx].assertIteratedExprsAreNotNullable(grammar);
};
Iter.prototype.assertIteratedExprsAreNotNullable = function(grammar) {
	this.expr.assertIteratedExprsAreNotNullable(grammar);
	if (this.expr.isNullable(grammar)) throw kleeneExprHasNullableOperand(this, []);
};
Opt.prototype.assertIteratedExprsAreNotNullable = Not.prototype.assertIteratedExprsAreNotNullable = Lookahead.prototype.assertIteratedExprsAreNotNullable = Lex.prototype.assertIteratedExprsAreNotNullable = function(grammar) {
	this.expr.assertIteratedExprsAreNotNullable(grammar);
};
Apply.prototype.assertIteratedExprsAreNotNullable = function(grammar) {
	this.args.forEach((arg) => {
		arg.assertIteratedExprsAreNotNullable(grammar);
	});
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/nodes.js
var Node = class {
	constructor(matchLength) {
		this.matchLength = matchLength;
	}
	get ctorName() {
		throw new Error("subclass responsibility");
	}
	numChildren() {
		return this.children ? this.children.length : 0;
	}
	childAt(idx) {
		if (this.children) return this.children[idx];
	}
	indexOfChild(arg) {
		return this.children.indexOf(arg);
	}
	hasChildren() {
		return this.numChildren() > 0;
	}
	hasNoChildren() {
		return !this.hasChildren();
	}
	onlyChild() {
		if (this.numChildren() !== 1) throw new Error("cannot get only child of a node of type " + this.ctorName + " (it has " + this.numChildren() + " children)");
		else return this.firstChild();
	}
	firstChild() {
		if (this.hasNoChildren()) throw new Error("cannot get first child of a " + this.ctorName + " node, which has no children");
		else return this.childAt(0);
	}
	lastChild() {
		if (this.hasNoChildren()) throw new Error("cannot get last child of a " + this.ctorName + " node, which has no children");
		else return this.childAt(this.numChildren() - 1);
	}
	childBefore(child) {
		const childIdx = this.indexOfChild(child);
		if (childIdx < 0) throw new Error("Node.childBefore() called w/ an argument that is not a child");
		else if (childIdx === 0) throw new Error("cannot get child before first child");
		else return this.childAt(childIdx - 1);
	}
	childAfter(child) {
		const childIdx = this.indexOfChild(child);
		if (childIdx < 0) throw new Error("Node.childAfter() called w/ an argument that is not a child");
		else if (childIdx === this.numChildren() - 1) throw new Error("cannot get child after last child");
		else return this.childAt(childIdx + 1);
	}
	isTerminal() {
		return false;
	}
	isNonterminal() {
		return false;
	}
	isIteration() {
		return false;
	}
	isOptional() {
		return false;
	}
};
var TerminalNode = class extends Node {
	get ctorName() {
		return "_terminal";
	}
	isTerminal() {
		return true;
	}
	get primitiveValue() {
		throw new Error("The `primitiveValue` property was removed in Ohm v17.");
	}
};
var NonterminalNode = class extends Node {
	constructor(ruleName, children, childOffsets, matchLength) {
		super(matchLength);
		this.ruleName = ruleName;
		this.children = children;
		this.childOffsets = childOffsets;
	}
	get ctorName() {
		return this.ruleName;
	}
	isNonterminal() {
		return true;
	}
	isLexical() {
		return isLexical(this.ctorName);
	}
	isSyntactic() {
		return isSyntactic(this.ctorName);
	}
};
var IterationNode = class extends Node {
	constructor(children, childOffsets, matchLength, isOptional) {
		super(matchLength);
		this.children = children;
		this.childOffsets = childOffsets;
		this.optional = isOptional;
	}
	get ctorName() {
		return "_iter";
	}
	isIteration() {
		return true;
	}
	isOptional() {
		return this.optional;
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-eval.js
PExpr.prototype.eval = abstract("eval");
any.eval = function(state) {
	const { inputStream } = state;
	const origPos = inputStream.pos;
	const cp = inputStream.nextCodePoint();
	if (cp !== void 0) {
		state.pushBinding(new TerminalNode(String.fromCodePoint(cp).length), origPos);
		return true;
	} else {
		state.processFailure(origPos, this);
		return false;
	}
};
end.eval = function(state) {
	const { inputStream } = state;
	const origPos = inputStream.pos;
	if (inputStream.atEnd()) {
		state.pushBinding(new TerminalNode(0), origPos);
		return true;
	} else {
		state.processFailure(origPos, this);
		return false;
	}
};
Terminal.prototype.eval = function(state) {
	const { inputStream } = state;
	const origPos = inputStream.pos;
	if (!inputStream.matchString(this.obj)) {
		state.processFailure(origPos, this);
		return false;
	} else {
		state.pushBinding(new TerminalNode(this.obj.length), origPos);
		return true;
	}
};
Range.prototype.eval = function(state) {
	const { inputStream } = state;
	const origPos = inputStream.pos;
	const cp = this.matchCodePoint ? inputStream.nextCodePoint() : inputStream.nextCharCode();
	if (cp !== void 0 && this.from.codePointAt(0) <= cp && cp <= this.to.codePointAt(0)) {
		state.pushBinding(new TerminalNode(String.fromCodePoint(cp).length), origPos);
		return true;
	} else {
		state.processFailure(origPos, this);
		return false;
	}
};
Param.prototype.eval = function(state) {
	return state.eval(state.currentApplication().args[this.index]);
};
Lex.prototype.eval = function(state) {
	state.enterLexifiedContext();
	const ans = state.eval(this.expr);
	state.exitLexifiedContext();
	return ans;
};
Alt.prototype.eval = function(state) {
	for (let idx = 0; idx < this.terms.length; idx++) if (state.eval(this.terms[idx])) return true;
	return false;
};
Seq.prototype.eval = function(state) {
	for (let idx = 0; idx < this.factors.length; idx++) {
		const factor = this.factors[idx];
		if (!state.eval(factor)) return false;
	}
	return true;
};
Iter.prototype.eval = function(state) {
	const { inputStream } = state;
	const origPos = inputStream.pos;
	const arity = this.getArity();
	const cols = [];
	const colOffsets = [];
	while (cols.length < arity) {
		cols.push([]);
		colOffsets.push([]);
	}
	let numMatches = 0;
	let prevPos = origPos;
	let idx;
	while (numMatches < this.maxNumMatches && state.eval(this.expr)) {
		if (inputStream.pos === prevPos) throw kleeneExprHasNullableOperand(this, state._applicationStack);
		prevPos = inputStream.pos;
		numMatches++;
		const row = state._bindings.splice(state._bindings.length - arity, arity);
		const rowOffsets = state._bindingOffsets.splice(state._bindingOffsets.length - arity, arity);
		for (idx = 0; idx < row.length; idx++) {
			cols[idx].push(row[idx]);
			colOffsets[idx].push(rowOffsets[idx]);
		}
	}
	if (numMatches < this.minNumMatches) return false;
	let offset = state.posToOffset(origPos);
	let matchLength = 0;
	if (numMatches > 0) {
		const lastCol = cols[arity - 1];
		const lastColOffsets = colOffsets[arity - 1];
		const endOffset = lastColOffsets[lastColOffsets.length - 1] + lastCol[lastCol.length - 1].matchLength;
		offset = colOffsets[0][0];
		matchLength = endOffset - offset;
	}
	const isOptional = this instanceof Opt;
	for (idx = 0; idx < cols.length; idx++) {
		state._bindings.push(new IterationNode(cols[idx], colOffsets[idx], matchLength, isOptional));
		state._bindingOffsets.push(offset);
	}
	return true;
};
Not.prototype.eval = function(state) {
	const { inputStream } = state;
	const origPos = inputStream.pos;
	state.pushFailuresInfo();
	const ans = state.eval(this.expr);
	state.popFailuresInfo();
	if (ans) {
		state.processFailure(origPos, this);
		return false;
	}
	inputStream.pos = origPos;
	return true;
};
Lookahead.prototype.eval = function(state) {
	const { inputStream } = state;
	const origPos = inputStream.pos;
	if (state.eval(this.expr)) {
		inputStream.pos = origPos;
		return true;
	} else return false;
};
Apply.prototype.eval = function(state) {
	const caller = state.currentApplication();
	const actuals = caller ? caller.args : [];
	const app = this.substituteParams(actuals);
	const posInfo = state.getCurrentPosInfo();
	if (posInfo.isActive(app)) return app.handleCycle(state);
	const memoKey = app.toMemoKey();
	const memoRec = posInfo.memo[memoKey];
	if (memoRec && posInfo.shouldUseMemoizedResult(memoRec)) {
		if (state.hasNecessaryInfo(memoRec)) return state.useMemoizedResult(state.inputStream.pos, memoRec);
		delete posInfo.memo[memoKey];
	}
	return app.reallyEval(state);
};
Apply.prototype.handleCycle = function(state) {
	const posInfo = state.getCurrentPosInfo();
	const { currentLeftRecursion } = posInfo;
	const memoKey = this.toMemoKey();
	let memoRec = posInfo.memo[memoKey];
	if (currentLeftRecursion && currentLeftRecursion.headApplication.toMemoKey() === memoKey) memoRec.updateInvolvedApplicationMemoKeys();
	else if (!memoRec) {
		memoRec = posInfo.memoize(memoKey, {
			matchLength: 0,
			examinedLength: 0,
			value: false,
			rightmostFailureOffset: -1
		});
		posInfo.startLeftRecursion(this, memoRec);
	}
	return state.useMemoizedResult(state.inputStream.pos, memoRec);
};
Apply.prototype.reallyEval = function(state) {
	const { inputStream } = state;
	const origPos = inputStream.pos;
	const origPosInfo = state.getCurrentPosInfo();
	const ruleInfo = state.grammar.rules[this.ruleName];
	const { body } = ruleInfo;
	const { description } = ruleInfo;
	state.enterApplication(origPosInfo, this);
	if (description) state.pushFailuresInfo();
	const origInputStreamExaminedLength = inputStream.examinedLength;
	inputStream.examinedLength = 0;
	let value = this.evalOnce(body, state);
	const currentLR = origPosInfo.currentLeftRecursion;
	const memoKey = this.toMemoKey();
	const isHeadOfLeftRecursion = currentLR && currentLR.headApplication.toMemoKey() === memoKey;
	let memoRec;
	if (state.doNotMemoize) state.doNotMemoize = false;
	else if (isHeadOfLeftRecursion) {
		value = this.growSeedResult(body, state, origPos, currentLR, value);
		origPosInfo.endLeftRecursion();
		memoRec = currentLR;
		memoRec.examinedLength = inputStream.examinedLength - origPos;
		memoRec.rightmostFailureOffset = state._getRightmostFailureOffset();
		origPosInfo.memoize(memoKey, memoRec);
	} else if (!currentLR || !currentLR.isInvolved(memoKey)) memoRec = origPosInfo.memoize(memoKey, {
		matchLength: inputStream.pos - origPos,
		examinedLength: inputStream.examinedLength - origPos,
		value,
		failuresAtRightmostPosition: state.cloneRecordedFailures(),
		rightmostFailureOffset: state._getRightmostFailureOffset()
	});
	const succeeded = !!value;
	if (description) {
		state.popFailuresInfo();
		if (!succeeded) state.processFailure(origPos, this);
		if (memoRec) memoRec.failuresAtRightmostPosition = state.cloneRecordedFailures();
	}
	if (state.isTracing() && memoRec) {
		const entry = state.getTraceEntry(origPos, this, succeeded, succeeded ? [value] : []);
		if (isHeadOfLeftRecursion) {
			assert(entry.terminatingLREntry != null || !succeeded);
			entry.isHeadOfLeftRecursion = true;
		}
		memoRec.traceEntry = entry;
	}
	inputStream.examinedLength = Math.max(inputStream.examinedLength, origInputStreamExaminedLength);
	state.exitApplication(origPosInfo, value);
	return succeeded;
};
Apply.prototype.evalOnce = function(expr, state) {
	const { inputStream } = state;
	const origPos = inputStream.pos;
	if (state.eval(expr)) {
		const arity = expr.getArity();
		const bindings = state._bindings.splice(state._bindings.length - arity, arity);
		const offsets = state._bindingOffsets.splice(state._bindingOffsets.length - arity, arity);
		const matchLength = inputStream.pos - origPos;
		return new NonterminalNode(this.ruleName, bindings, offsets, matchLength);
	} else return false;
};
Apply.prototype.growSeedResult = function(body, state, origPos, lrMemoRec, newValue) {
	if (!newValue) return false;
	const { inputStream } = state;
	while (true) {
		lrMemoRec.matchLength = inputStream.pos - origPos;
		lrMemoRec.value = newValue;
		lrMemoRec.failuresAtRightmostPosition = state.cloneRecordedFailures();
		if (state.isTracing()) {
			const seedTrace = state.trace[state.trace.length - 1];
			lrMemoRec.traceEntry = new Trace(state.input, origPos, inputStream.pos, this, true, [newValue], [seedTrace.clone()]);
		}
		inputStream.pos = origPos;
		newValue = this.evalOnce(body, state);
		if (inputStream.pos - origPos <= lrMemoRec.matchLength) break;
		if (state.isTracing()) state.trace.splice(-2, 1);
	}
	if (state.isTracing()) lrMemoRec.traceEntry.recordLRTermination(state.trace.pop(), newValue);
	inputStream.pos = origPos + lrMemoRec.matchLength;
	return lrMemoRec.value;
};
UnicodeChar.prototype.eval = function(state) {
	const { inputStream } = state;
	const origPos = inputStream.pos;
	const ch = inputStream.next();
	if (ch && this.pattern.test(ch)) {
		state.pushBinding(new TerminalNode(ch.length), origPos);
		return true;
	} else {
		state.processFailure(origPos, this);
		return false;
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-getArity.js
PExpr.prototype.getArity = abstract("getArity");
any.getArity = end.getArity = Terminal.prototype.getArity = Range.prototype.getArity = Param.prototype.getArity = Apply.prototype.getArity = UnicodeChar.prototype.getArity = function() {
	return 1;
};
Alt.prototype.getArity = function() {
	return this.terms.length === 0 ? 0 : this.terms[0].getArity();
};
Seq.prototype.getArity = function() {
	let arity = 0;
	for (let idx = 0; idx < this.factors.length; idx++) arity += this.factors[idx].getArity();
	return arity;
};
Iter.prototype.getArity = function() {
	return this.expr.getArity();
};
Not.prototype.getArity = function() {
	return 0;
};
Lookahead.prototype.getArity = Lex.prototype.getArity = function() {
	return this.expr.getArity();
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-outputRecipe.js
function getMetaInfo(expr, grammarInterval) {
	const metaInfo = {};
	if (expr.source && grammarInterval) {
		const adjusted = expr.source.relativeTo(grammarInterval);
		metaInfo.sourceInterval = [adjusted.startIdx, adjusted.endIdx];
	}
	return metaInfo;
}
PExpr.prototype.outputRecipe = abstract("outputRecipe");
any.outputRecipe = function(formals, grammarInterval) {
	return ["any", getMetaInfo(this, grammarInterval)];
};
end.outputRecipe = function(formals, grammarInterval) {
	return ["end", getMetaInfo(this, grammarInterval)];
};
Terminal.prototype.outputRecipe = function(formals, grammarInterval) {
	return [
		"terminal",
		getMetaInfo(this, grammarInterval),
		this.obj
	];
};
Range.prototype.outputRecipe = function(formals, grammarInterval) {
	return [
		"range",
		getMetaInfo(this, grammarInterval),
		this.from,
		this.to
	];
};
Param.prototype.outputRecipe = function(formals, grammarInterval) {
	return [
		"param",
		getMetaInfo(this, grammarInterval),
		this.index
	];
};
Alt.prototype.outputRecipe = function(formals, grammarInterval) {
	return ["alt", getMetaInfo(this, grammarInterval)].concat(this.terms.map((term) => term.outputRecipe(formals, grammarInterval)));
};
Extend.prototype.outputRecipe = function(formals, grammarInterval) {
	return this.terms[0].outputRecipe(formals, grammarInterval);
};
Splice.prototype.outputRecipe = function(formals, grammarInterval) {
	const beforeTerms = this.terms.slice(0, this.expansionPos);
	const afterTerms = this.terms.slice(this.expansionPos + 1);
	return [
		"splice",
		getMetaInfo(this, grammarInterval),
		beforeTerms.map((term) => term.outputRecipe(formals, grammarInterval)),
		afterTerms.map((term) => term.outputRecipe(formals, grammarInterval))
	];
};
Seq.prototype.outputRecipe = function(formals, grammarInterval) {
	return ["seq", getMetaInfo(this, grammarInterval)].concat(this.factors.map((factor) => factor.outputRecipe(formals, grammarInterval)));
};
Star.prototype.outputRecipe = Plus.prototype.outputRecipe = Opt.prototype.outputRecipe = Not.prototype.outputRecipe = Lookahead.prototype.outputRecipe = Lex.prototype.outputRecipe = function(formals, grammarInterval) {
	return [
		this.constructor.name.toLowerCase(),
		getMetaInfo(this, grammarInterval),
		this.expr.outputRecipe(formals, grammarInterval)
	];
};
Apply.prototype.outputRecipe = function(formals, grammarInterval) {
	return [
		"app",
		getMetaInfo(this, grammarInterval),
		this.ruleName,
		this.args.map((arg) => arg.outputRecipe(formals, grammarInterval))
	];
};
UnicodeChar.prototype.outputRecipe = function(formals, grammarInterval) {
	return [
		"unicodeChar",
		getMetaInfo(this, grammarInterval),
		this.category
	];
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-introduceParams.js
PExpr.prototype.introduceParams = abstract("introduceParams");
any.introduceParams = end.introduceParams = Terminal.prototype.introduceParams = Range.prototype.introduceParams = Param.prototype.introduceParams = UnicodeChar.prototype.introduceParams = function(formals) {
	return this;
};
Alt.prototype.introduceParams = function(formals) {
	this.terms.forEach((term, idx, terms) => {
		terms[idx] = term.introduceParams(formals);
	});
	return this;
};
Seq.prototype.introduceParams = function(formals) {
	this.factors.forEach((factor, idx, factors) => {
		factors[idx] = factor.introduceParams(formals);
	});
	return this;
};
Iter.prototype.introduceParams = Not.prototype.introduceParams = Lookahead.prototype.introduceParams = Lex.prototype.introduceParams = function(formals) {
	this.expr = this.expr.introduceParams(formals);
	return this;
};
Apply.prototype.introduceParams = function(formals) {
	const index = formals.indexOf(this.ruleName);
	if (index >= 0) {
		if (this.args.length > 0) throw new Error("Parameterized rules cannot be passed as arguments to another rule.");
		return new Param(index).withSource(this.source);
	} else {
		this.args.forEach((arg, idx, args) => {
			args[idx] = arg.introduceParams(formals);
		});
		return this;
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-isNullable.js
PExpr.prototype.isNullable = function(grammar) {
	return this._isNullable(grammar, Object.create(null));
};
PExpr.prototype._isNullable = abstract("_isNullable");
any._isNullable = Range.prototype._isNullable = Param.prototype._isNullable = Plus.prototype._isNullable = UnicodeChar.prototype._isNullable = function(grammar, memo) {
	return false;
};
end._isNullable = function(grammar, memo) {
	return true;
};
Terminal.prototype._isNullable = function(grammar, memo) {
	if (typeof this.obj === "string") return this.obj === "";
	else return false;
};
Alt.prototype._isNullable = function(grammar, memo) {
	return this.terms.length === 0 || this.terms.some((term) => term._isNullable(grammar, memo));
};
Seq.prototype._isNullable = function(grammar, memo) {
	return this.factors.every((factor) => factor._isNullable(grammar, memo));
};
Star.prototype._isNullable = Opt.prototype._isNullable = Not.prototype._isNullable = Lookahead.prototype._isNullable = function(grammar, memo) {
	return true;
};
Lex.prototype._isNullable = function(grammar, memo) {
	return this.expr._isNullable(grammar, memo);
};
Apply.prototype._isNullable = function(grammar, memo) {
	const key = this.toMemoKey();
	if (!Object.prototype.hasOwnProperty.call(memo, key)) {
		const { body } = grammar.rules[this.ruleName];
		const inlined = body.substituteParams(this.args);
		memo[key] = false;
		memo[key] = inlined._isNullable(grammar, memo);
	}
	return memo[key];
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-substituteParams.js
PExpr.prototype.substituteParams = abstract("substituteParams");
any.substituteParams = end.substituteParams = Terminal.prototype.substituteParams = Range.prototype.substituteParams = UnicodeChar.prototype.substituteParams = function(actuals) {
	return this;
};
Param.prototype.substituteParams = function(actuals) {
	return checkNotNull(actuals[this.index]);
};
Alt.prototype.substituteParams = function(actuals) {
	return new Alt(this.terms.map((term) => term.substituteParams(actuals)));
};
Seq.prototype.substituteParams = function(actuals) {
	return new Seq(this.factors.map((factor) => factor.substituteParams(actuals)));
};
Iter.prototype.substituteParams = Not.prototype.substituteParams = Lookahead.prototype.substituteParams = Lex.prototype.substituteParams = function(actuals) {
	return new this.constructor(this.expr.substituteParams(actuals));
};
Apply.prototype.substituteParams = function(actuals) {
	if (this.args.length === 0) return this;
	else {
		const args = this.args.map((arg) => arg.substituteParams(actuals));
		return new Apply(this.ruleName, args);
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-toArgumentNameList.js
function isRestrictedJSIdentifier(str) {
	return /^[a-zA-Z_$][0-9a-zA-Z_$]*$/.test(str);
}
function resolveDuplicatedNames(argumentNameList) {
	const count = Object.create(null);
	argumentNameList.forEach((argName) => {
		count[argName] = (count[argName] || 0) + 1;
	});
	Object.keys(count).forEach((dupArgName) => {
		if (count[dupArgName] <= 1) return;
		let subscript = 1;
		argumentNameList.forEach((argName, idx) => {
			if (argName === dupArgName) argumentNameList[idx] = argName + "_" + subscript++;
		});
	});
}
PExpr.prototype.toArgumentNameList = abstract("toArgumentNameList");
any.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	return ["any"];
};
end.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	return ["end"];
};
Terminal.prototype.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	if (typeof this.obj === "string" && /^[_a-zA-Z0-9]+$/.test(this.obj)) return ["_" + this.obj];
	else return ["$" + firstArgIndex];
};
Range.prototype.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	let argName = this.from + "_to_" + this.to;
	if (!isRestrictedJSIdentifier(argName)) argName = "_" + argName;
	if (!isRestrictedJSIdentifier(argName)) argName = "$" + firstArgIndex;
	return [argName];
};
Alt.prototype.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	const termArgNameLists = this.terms.map((term) => term.toArgumentNameList(firstArgIndex, true));
	const argumentNameList = [];
	const numArgs = termArgNameLists[0].length;
	for (let colIdx = 0; colIdx < numArgs; colIdx++) {
		const col = [];
		for (let rowIdx = 0; rowIdx < this.terms.length; rowIdx++) col.push(termArgNameLists[rowIdx][colIdx]);
		const uniqueNames = copyWithoutDuplicates(col);
		argumentNameList.push(uniqueNames.join("_or_"));
	}
	if (!noDupCheck) resolveDuplicatedNames(argumentNameList);
	return argumentNameList;
};
Seq.prototype.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	let argumentNameList = [];
	this.factors.forEach((factor) => {
		const factorArgumentNameList = factor.toArgumentNameList(firstArgIndex, true);
		argumentNameList = argumentNameList.concat(factorArgumentNameList);
		firstArgIndex += factorArgumentNameList.length;
	});
	if (!noDupCheck) resolveDuplicatedNames(argumentNameList);
	return argumentNameList;
};
Iter.prototype.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	const argumentNameList = this.expr.toArgumentNameList(firstArgIndex, noDupCheck).map((exprArgumentString) => exprArgumentString[exprArgumentString.length - 1] === "s" ? exprArgumentString + "es" : exprArgumentString + "s");
	if (!noDupCheck) resolveDuplicatedNames(argumentNameList);
	return argumentNameList;
};
Opt.prototype.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	return this.expr.toArgumentNameList(firstArgIndex, noDupCheck).map((argName) => {
		return "opt" + argName[0].toUpperCase() + argName.slice(1);
	});
};
Not.prototype.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	return [];
};
Lookahead.prototype.toArgumentNameList = Lex.prototype.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	return this.expr.toArgumentNameList(firstArgIndex, noDupCheck);
};
Apply.prototype.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	return [this.ruleName];
};
UnicodeChar.prototype.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	return ["$" + firstArgIndex];
};
Param.prototype.toArgumentNameList = function(firstArgIndex, noDupCheck) {
	return ["param" + this.index];
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-toDisplayString.js
PExpr.prototype.toDisplayString = abstract("toDisplayString");
Alt.prototype.toDisplayString = Seq.prototype.toDisplayString = function() {
	if (this.source) return this.source.trimmed().contents;
	return "[" + this.constructor.name + "]";
};
any.toDisplayString = end.toDisplayString = Iter.prototype.toDisplayString = Not.prototype.toDisplayString = Lookahead.prototype.toDisplayString = Lex.prototype.toDisplayString = Terminal.prototype.toDisplayString = Range.prototype.toDisplayString = Param.prototype.toDisplayString = function() {
	return this.toString();
};
Apply.prototype.toDisplayString = function() {
	if (this.args.length > 0) {
		const ps = this.args.map((arg) => arg.toDisplayString());
		return this.ruleName + "<" + ps.join(",") + ">";
	} else return this.ruleName;
};
UnicodeChar.prototype.toDisplayString = function() {
	return "Unicode [" + this.category + "] character";
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/Failure.js
function isValidType(type) {
	return type === "description" || type === "string" || type === "code";
}
var Failure = class Failure {
	constructor(pexpr, text, type) {
		if (!isValidType(type)) throw new Error("invalid Failure type: " + type);
		this.pexpr = pexpr;
		this.text = text;
		this.type = type;
		this.fluffy = false;
	}
	getPExpr() {
		return this.pexpr;
	}
	getText() {
		return this.text;
	}
	getType() {
		return this.type;
	}
	isDescription() {
		return this.type === "description";
	}
	isStringTerminal() {
		return this.type === "string";
	}
	isCode() {
		return this.type === "code";
	}
	isFluffy() {
		return this.fluffy;
	}
	makeFluffy() {
		this.fluffy = true;
	}
	clearFluffy() {
		this.fluffy = false;
	}
	subsumes(that) {
		return this.getText() === that.getText() && this.type === that.type && (!this.isFluffy() || this.isFluffy() && that.isFluffy());
	}
	toString() {
		return this.type === "string" ? JSON.stringify(this.getText()) : this.getText();
	}
	clone() {
		const failure = new Failure(this.pexpr, this.text, this.type);
		if (this.isFluffy()) failure.makeFluffy();
		return failure;
	}
	toKey() {
		return this.toString() + "#" + this.type;
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-toFailure.js
PExpr.prototype.toFailure = abstract("toFailure");
any.toFailure = function(grammar) {
	return new Failure(this, "any object", "description");
};
end.toFailure = function(grammar) {
	return new Failure(this, "end of input", "description");
};
Terminal.prototype.toFailure = function(grammar) {
	return new Failure(this, this.obj, "string");
};
Range.prototype.toFailure = function(grammar) {
	return new Failure(this, JSON.stringify(this.from) + ".." + JSON.stringify(this.to), "code");
};
Not.prototype.toFailure = function(grammar) {
	const description = this.expr === any ? "nothing" : "not " + this.expr.toFailure(grammar);
	return new Failure(this, description, "description");
};
Lookahead.prototype.toFailure = function(grammar) {
	return this.expr.toFailure(grammar);
};
Apply.prototype.toFailure = function(grammar) {
	let { description } = grammar.rules[this.ruleName];
	if (!description) description = (/^[aeiouAEIOU]/.test(this.ruleName) ? "an" : "a") + " " + this.ruleName;
	return new Failure(this, description, "description");
};
UnicodeChar.prototype.toFailure = function(grammar) {
	return new Failure(this, "a Unicode [" + this.category + "] character", "description");
};
Alt.prototype.toFailure = function(grammar) {
	const description = "(" + this.terms.map((t) => t.toFailure(grammar)).join(" or ") + ")";
	return new Failure(this, description, "description");
};
Seq.prototype.toFailure = function(grammar) {
	const description = "(" + this.factors.map((f) => f.toFailure(grammar)).join(" ") + ")";
	return new Failure(this, description, "description");
};
Iter.prototype.toFailure = function(grammar) {
	const description = "(" + this.expr.toFailure(grammar) + this.operator + ")";
	return new Failure(this, description, "description");
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/pexprs-toString.js
PExpr.prototype.toString = abstract("toString");
any.toString = function() {
	return "any";
};
end.toString = function() {
	return "end";
};
Terminal.prototype.toString = function() {
	return JSON.stringify(this.obj);
};
Range.prototype.toString = function() {
	return JSON.stringify(this.from) + ".." + JSON.stringify(this.to);
};
Param.prototype.toString = function() {
	return "$" + this.index;
};
Lex.prototype.toString = function() {
	return "#(" + this.expr.toString() + ")";
};
Alt.prototype.toString = function() {
	return this.terms.length === 1 ? this.terms[0].toString() : "(" + this.terms.map((term) => term.toString()).join(" | ") + ")";
};
Seq.prototype.toString = function() {
	return this.factors.length === 1 ? this.factors[0].toString() : "(" + this.factors.map((factor) => factor.toString()).join(" ") + ")";
};
Iter.prototype.toString = function() {
	return this.expr + this.operator;
};
Not.prototype.toString = function() {
	return "~" + this.expr;
};
Lookahead.prototype.toString = function() {
	return "&" + this.expr;
};
Apply.prototype.toString = function() {
	if (this.args.length > 0) {
		const ps = this.args.map((arg) => arg.toString());
		return this.ruleName + "<" + ps.join(",") + ">";
	} else return this.ruleName;
};
UnicodeChar.prototype.toString = function() {
	return "\\p{" + this.category + "}";
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/CaseInsensitiveTerminal.js
var CaseInsensitiveTerminal = class CaseInsensitiveTerminal extends PExpr {
	constructor(param) {
		super();
		this.obj = param;
	}
	_getString(state) {
		const terminal = state.currentApplication().args[this.obj.index];
		assert(terminal instanceof Terminal, "expected a Terminal expression");
		return terminal.obj;
	}
	allowsSkippingPrecedingSpace() {
		return true;
	}
	eval(state) {
		const { inputStream } = state;
		const origPos = inputStream.pos;
		const matchStr = this._getString(state);
		if (!inputStream.matchString(matchStr, true)) {
			state.processFailure(origPos, this);
			return false;
		} else {
			state.pushBinding(new TerminalNode(matchStr.length), origPos);
			return true;
		}
	}
	getArity() {
		return 1;
	}
	substituteParams(actuals) {
		return new CaseInsensitiveTerminal(this.obj.substituteParams(actuals));
	}
	toDisplayString() {
		return this.obj.toDisplayString() + " (case-insensitive)";
	}
	toFailure(grammar) {
		return new Failure(this, this.obj.toFailure(grammar) + " (case-insensitive)", "description");
	}
	_isNullable(grammar, memo) {
		return this.obj._isNullable(grammar, memo);
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/MatchState.js
let builtInApplySyntacticBody;
awaitBuiltInRules((builtInRules) => {
	builtInApplySyntacticBody = builtInRules.rules.applySyntactic.body;
});
const applySpaces = new Apply("spaces");
var MatchState = class {
	constructor(matcher, startExpr, optPositionToRecordFailures) {
		this.matcher = matcher;
		this.startExpr = startExpr;
		this.grammar = matcher.grammar;
		this.input = matcher.getInput();
		this.inputStream = new InputStream(this.input);
		this.memoTable = matcher._memoTable;
		this.userData = void 0;
		this.doNotMemoize = false;
		this._bindings = [];
		this._bindingOffsets = [];
		this._applicationStack = [];
		this._posStack = [0];
		this.inLexifiedContextStack = [false];
		this.rightmostFailurePosition = -1;
		this._rightmostFailurePositionStack = [];
		this._recordedFailuresStack = [];
		if (optPositionToRecordFailures !== void 0) {
			this.positionToRecordFailures = optPositionToRecordFailures;
			this.recordedFailures = Object.create(null);
		}
	}
	posToOffset(pos) {
		return pos - this._posStack[this._posStack.length - 1];
	}
	enterApplication(posInfo, app) {
		this._posStack.push(this.inputStream.pos);
		this._applicationStack.push(app);
		this.inLexifiedContextStack.push(false);
		posInfo.enter(app);
		this._rightmostFailurePositionStack.push(this.rightmostFailurePosition);
		this.rightmostFailurePosition = -1;
	}
	exitApplication(posInfo, optNode) {
		const origPos = this._posStack.pop();
		this._applicationStack.pop();
		this.inLexifiedContextStack.pop();
		posInfo.exit();
		this.rightmostFailurePosition = Math.max(this.rightmostFailurePosition, this._rightmostFailurePositionStack.pop());
		if (optNode) this.pushBinding(optNode, origPos);
	}
	enterLexifiedContext() {
		this.inLexifiedContextStack.push(true);
	}
	exitLexifiedContext() {
		this.inLexifiedContextStack.pop();
	}
	currentApplication() {
		return this._applicationStack[this._applicationStack.length - 1];
	}
	inSyntacticContext() {
		const currentApplication = this.currentApplication();
		if (currentApplication) return currentApplication.isSyntactic() && !this.inLexifiedContext();
		else return this.startExpr.factors[0].isSyntactic();
	}
	inLexifiedContext() {
		return this.inLexifiedContextStack[this.inLexifiedContextStack.length - 1];
	}
	skipSpaces() {
		this.pushFailuresInfo();
		this.eval(applySpaces);
		this.popBinding();
		this.popFailuresInfo();
		return this.inputStream.pos;
	}
	skipSpacesIfInSyntacticContext() {
		return this.inSyntacticContext() ? this.skipSpaces() : this.inputStream.pos;
	}
	maybeSkipSpacesBefore(expr) {
		if (expr.allowsSkippingPrecedingSpace() && expr !== applySpaces) return this.skipSpacesIfInSyntacticContext();
		else return this.inputStream.pos;
	}
	pushBinding(node, origPos) {
		this._bindings.push(node);
		this._bindingOffsets.push(this.posToOffset(origPos));
	}
	popBinding() {
		this._bindings.pop();
		this._bindingOffsets.pop();
	}
	numBindings() {
		return this._bindings.length;
	}
	truncateBindings(newLength) {
		while (this._bindings.length > newLength) this.popBinding();
	}
	getCurrentPosInfo() {
		return this.getPosInfo(this.inputStream.pos);
	}
	getPosInfo(pos) {
		let posInfo = this.memoTable[pos];
		if (!posInfo) posInfo = this.memoTable[pos] = new PosInfo();
		return posInfo;
	}
	processFailure(pos, expr) {
		this.rightmostFailurePosition = Math.max(this.rightmostFailurePosition, pos);
		if (this.recordedFailures && pos === this.positionToRecordFailures) {
			const app = this.currentApplication();
			if (app) expr = expr.substituteParams(app.args);
			this.recordFailure(expr.toFailure(this.grammar), false);
		}
	}
	recordFailure(failure, shouldCloneIfNew) {
		const key = failure.toKey();
		if (!this.recordedFailures[key]) this.recordedFailures[key] = shouldCloneIfNew ? failure.clone() : failure;
		else if (this.recordedFailures[key].isFluffy() && !failure.isFluffy()) this.recordedFailures[key].clearFluffy();
	}
	recordFailures(failures, shouldCloneIfNew) {
		Object.keys(failures).forEach((key) => {
			this.recordFailure(failures[key], shouldCloneIfNew);
		});
	}
	cloneRecordedFailures() {
		if (!this.recordedFailures) return;
		const ans = Object.create(null);
		Object.keys(this.recordedFailures).forEach((key) => {
			ans[key] = this.recordedFailures[key].clone();
		});
		return ans;
	}
	getRightmostFailurePosition() {
		return this.rightmostFailurePosition;
	}
	_getRightmostFailureOffset() {
		return this.rightmostFailurePosition >= 0 ? this.posToOffset(this.rightmostFailurePosition) : -1;
	}
	getMemoizedTraceEntry(pos, expr) {
		const posInfo = this.memoTable[pos];
		if (posInfo && expr instanceof Apply) {
			const memoRec = posInfo.memo[expr.toMemoKey()];
			if (memoRec && memoRec.traceEntry) {
				const entry = memoRec.traceEntry.cloneWithExpr(expr);
				entry.isMemoized = true;
				return entry;
			}
		}
		return null;
	}
	getTraceEntry(pos, expr, succeeded, bindings) {
		if (expr instanceof Apply) {
			const app = this.currentApplication();
			const actuals = app ? app.args : [];
			expr = expr.substituteParams(actuals);
		}
		return this.getMemoizedTraceEntry(pos, expr) || new Trace(this.input, pos, this.inputStream.pos, expr, succeeded, bindings, this.trace);
	}
	isTracing() {
		return !!this.trace;
	}
	hasNecessaryInfo(memoRec) {
		if (this.trace && !memoRec.traceEntry) return false;
		if (this.recordedFailures && this.inputStream.pos + memoRec.rightmostFailureOffset === this.positionToRecordFailures) return !!memoRec.failuresAtRightmostPosition;
		return true;
	}
	useMemoizedResult(origPos, memoRec) {
		if (this.trace) this.trace.push(memoRec.traceEntry);
		const memoRecRightmostFailurePosition = this.inputStream.pos + memoRec.rightmostFailureOffset;
		this.rightmostFailurePosition = Math.max(this.rightmostFailurePosition, memoRecRightmostFailurePosition);
		if (this.recordedFailures && this.positionToRecordFailures === memoRecRightmostFailurePosition && memoRec.failuresAtRightmostPosition) this.recordFailures(memoRec.failuresAtRightmostPosition, true);
		this.inputStream.examinedLength = Math.max(this.inputStream.examinedLength, memoRec.examinedLength + origPos);
		if (memoRec.value) {
			this.inputStream.pos += memoRec.matchLength;
			this.pushBinding(memoRec.value, origPos);
			return true;
		}
		return false;
	}
	eval(expr) {
		const { inputStream } = this;
		const origNumBindings = this._bindings.length;
		const origUserData = this.userData;
		let origRecordedFailures;
		if (this.recordedFailures) {
			origRecordedFailures = this.recordedFailures;
			this.recordedFailures = Object.create(null);
		}
		const origPos = inputStream.pos;
		const memoPos = this.maybeSkipSpacesBefore(expr);
		let origTrace;
		if (this.trace) {
			origTrace = this.trace;
			this.trace = [];
		}
		const ans = expr.eval(this);
		if (this.trace) {
			const bindings = this._bindings.slice(origNumBindings);
			const traceEntry = this.getTraceEntry(memoPos, expr, ans, bindings);
			traceEntry.isImplicitSpaces = expr === applySpaces;
			traceEntry.isRootNode = expr === this.startExpr;
			origTrace.push(traceEntry);
			this.trace = origTrace;
		}
		if (ans) {
			if (this.recordedFailures && inputStream.pos === this.positionToRecordFailures) Object.keys(this.recordedFailures).forEach((key) => {
				this.recordedFailures[key].makeFluffy();
			});
		} else {
			inputStream.pos = origPos;
			this.truncateBindings(origNumBindings);
			this.userData = origUserData;
		}
		if (this.recordedFailures) this.recordFailures(origRecordedFailures, false);
		if (expr === builtInApplySyntacticBody) this.skipSpaces();
		return ans;
	}
	getMatchResult() {
		this.grammar._setUpMatchState(this);
		this.eval(this.startExpr);
		let rightmostFailures;
		if (this.recordedFailures) rightmostFailures = Object.keys(this.recordedFailures).map((key) => this.recordedFailures[key]);
		const cst = this._bindings[0];
		if (cst) cst.grammar = this.grammar;
		return new MatchResult(this.matcher, this.input, this.startExpr, cst, this._bindingOffsets[0], this.rightmostFailurePosition, rightmostFailures);
	}
	getTrace() {
		this.trace = [];
		const matchResult = this.getMatchResult();
		const rootTrace = this.trace[this.trace.length - 1];
		rootTrace.result = matchResult;
		return rootTrace;
	}
	pushFailuresInfo() {
		this._rightmostFailurePositionStack.push(this.rightmostFailurePosition);
		this._recordedFailuresStack.push(this.recordedFailures);
	}
	popFailuresInfo() {
		this.rightmostFailurePosition = this._rightmostFailurePositionStack.pop();
		this.recordedFailures = this._recordedFailuresStack.pop();
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/Matcher.js
var Matcher = class {
	constructor(grammar) {
		this.grammar = grammar;
		this._memoTable = [];
		this._input = "";
		this._isMemoTableStale = false;
	}
	_resetMemoTable() {
		this._memoTable = [];
		this._isMemoTableStale = false;
	}
	getInput() {
		return this._input;
	}
	setInput(str) {
		if (this._input !== str) this.replaceInputRange(0, this._input.length, str);
		return this;
	}
	replaceInputRange(startIdx, endIdx, str) {
		const prevInput = this._input;
		const memoTable = this._memoTable;
		if (startIdx < 0 || startIdx > prevInput.length || endIdx < 0 || endIdx > prevInput.length || startIdx > endIdx) throw new Error("Invalid indices: " + startIdx + " and " + endIdx);
		this._input = prevInput.slice(0, startIdx) + str + prevInput.slice(endIdx);
		if (this._input !== prevInput && memoTable.length > 0) this._isMemoTableStale = true;
		const restOfMemoTable = memoTable.slice(endIdx);
		memoTable.length = startIdx;
		for (let idx = 0; idx < str.length; idx++) memoTable.push(void 0);
		for (const posInfo of restOfMemoTable) memoTable.push(posInfo);
		for (let pos = 0; pos < startIdx; pos++) {
			const posInfo = memoTable[pos];
			if (posInfo) posInfo.clearObsoleteEntries(pos, startIdx);
		}
		return this;
	}
	match(optStartApplicationStr, options = { incremental: true }) {
		return this._match(this._getStartExpr(optStartApplicationStr), {
			incremental: options.incremental,
			tracing: false
		});
	}
	trace(optStartApplicationStr, options = { incremental: true }) {
		return this._match(this._getStartExpr(optStartApplicationStr), {
			incremental: options.incremental,
			tracing: true
		});
	}
	_match(startExpr, options = {}) {
		const opts = {
			tracing: false,
			incremental: true,
			positionToRecordFailures: void 0,
			...options
		};
		if (!opts.incremental) this._resetMemoTable();
		else if (this._isMemoTableStale && !this.grammar.supportsIncrementalParsing) throw grammarDoesNotSupportIncrementalParsing(this.grammar);
		const state = new MatchState(this, startExpr, opts.positionToRecordFailures);
		return opts.tracing ? state.getTrace() : state.getMatchResult();
	}
	_getStartExpr(optStartApplicationStr) {
		const applicationStr = optStartApplicationStr || this.grammar.defaultStartRule;
		if (!applicationStr) throw new Error("Missing start rule argument -- the grammar has no default start rule.");
		return new Seq([this.grammar.parseApplication(applicationStr), end]);
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/Semantics.js
const globalActionStack = [];
const hasOwnProperty = (x, prop) => Object.prototype.hasOwnProperty.call(x, prop);
var Wrapper = class {
	constructor(node, sourceInterval, baseInterval) {
		this._node = node;
		this.source = sourceInterval;
		this._baseInterval = baseInterval;
		if (node.isNonterminal()) assert(sourceInterval === baseInterval);
		this._childWrappers = [];
	}
	_forgetMemoizedResultFor(attributeName) {
		delete this._node[this._semantics.attributeKeys[attributeName]];
		this.children.forEach((child) => {
			child._forgetMemoizedResultFor(attributeName);
		});
	}
	child(idx) {
		if (!(0 <= idx && idx < this._node.numChildren())) return;
		let childWrapper = this._childWrappers[idx];
		if (!childWrapper) {
			const childNode = this._node.childAt(idx);
			const offset = this._node.childOffsets[idx];
			const source = this._baseInterval.subInterval(offset, childNode.matchLength);
			const base = childNode.isNonterminal() ? source : this._baseInterval;
			childWrapper = this._childWrappers[idx] = this._semantics.wrap(childNode, source, base);
		}
		return childWrapper;
	}
	_children() {
		for (let idx = 0; idx < this._node.numChildren(); idx++) this.child(idx);
		return this._childWrappers;
	}
	isIteration() {
		return this._node.isIteration();
	}
	isTerminal() {
		return this._node.isTerminal();
	}
	isNonterminal() {
		return this._node.isNonterminal();
	}
	isSyntactic() {
		return this.isNonterminal() && this._node.isSyntactic();
	}
	isLexical() {
		return this.isNonterminal() && this._node.isLexical();
	}
	isOptional() {
		return this._node.isOptional();
	}
	iteration(optChildWrappers) {
		const childWrappers = optChildWrappers || [];
		const iter = new IterationNode(childWrappers.map((c) => c._node), [], -1, false);
		const wrapper = this._semantics.wrap(iter, null, null);
		wrapper._childWrappers = childWrappers;
		return wrapper;
	}
	get children() {
		return this._children();
	}
	get ctorName() {
		return this._node.ctorName;
	}
	get numChildren() {
		return this._node.numChildren();
	}
	get sourceString() {
		return this.source.contents;
	}
};
var Semantics = class Semantics {
	constructor(grammar, superSemantics) {
		const self = this;
		this.grammar = grammar;
		this.checkedActionDicts = false;
		this.Wrapper = class extends (superSemantics ? superSemantics.Wrapper : Wrapper) {
			constructor(node, sourceInterval, baseInterval) {
				super(node, sourceInterval, baseInterval);
				self.checkActionDictsIfHaventAlready();
				this._semantics = self;
			}
			toString() {
				return "[semantics wrapper for " + self.grammar.name + "]";
			}
		};
		this.super = superSemantics;
		if (superSemantics) {
			if (!(grammar.equals(this.super.grammar) || grammar._inheritsFrom(this.super.grammar))) throw new Error("Cannot extend a semantics for grammar '" + this.super.grammar.name + "' for use with grammar '" + grammar.name + "' (not a sub-grammar)");
			this.operations = Object.create(this.super.operations);
			this.attributes = Object.create(this.super.attributes);
			this.attributeKeys = Object.create(null);
			for (const attributeName in this.attributes) Object.defineProperty(this.attributeKeys, attributeName, { value: uniqueId(attributeName) });
		} else {
			this.operations = Object.create(null);
			this.attributes = Object.create(null);
			this.attributeKeys = Object.create(null);
		}
	}
	toString() {
		return "[semantics for " + this.grammar.name + "]";
	}
	checkActionDictsIfHaventAlready() {
		if (!this.checkedActionDicts) {
			this.checkActionDicts();
			this.checkedActionDicts = true;
		}
	}
	checkActionDicts() {
		let name;
		for (name in this.operations) this.operations[name].checkActionDict(this.grammar);
		for (name in this.attributes) this.attributes[name].checkActionDict(this.grammar);
	}
	toRecipe(semanticsOnly) {
		function hasSuperSemantics(s) {
			return s.super !== Semantics.BuiltInSemantics._getSemantics();
		}
		let str = "(function(g) {\n";
		if (hasSuperSemantics(this)) {
			str += "  var semantics = " + this.super.toRecipe(true) + "(g";
			const superSemanticsGrammar = this.super.grammar;
			let relatedGrammar = this.grammar;
			while (relatedGrammar !== superSemanticsGrammar) {
				str += ".superGrammar";
				relatedGrammar = relatedGrammar.superGrammar;
			}
			str += ");\n";
			str += "  return g.extendSemantics(semantics)";
		} else str += "  return g.createSemantics()";
		["Operation", "Attribute"].forEach((type) => {
			const semanticOperations = this[type.toLowerCase() + "s"];
			Object.keys(semanticOperations).forEach((name) => {
				const { actionDict, formals, builtInDefault } = semanticOperations[name];
				let signature = name;
				if (formals.length > 0) signature += "(" + formals.join(", ") + ")";
				let method;
				if (hasSuperSemantics(this) && this.super[type.toLowerCase() + "s"][name]) method = "extend" + type;
				else method = "add" + type;
				str += "\n    ." + method + "(" + JSON.stringify(signature) + ", {";
				const srcArray = [];
				Object.keys(actionDict).forEach((actionName) => {
					if (actionDict[actionName] !== builtInDefault) {
						let source = actionDict[actionName].toString().trim();
						source = source.replace(/^.*\(/, "function(");
						srcArray.push("\n      " + JSON.stringify(actionName) + ": " + source);
					}
				});
				str += srcArray.join(",") + "\n    })";
			});
		});
		str += ";\n  })";
		if (!semanticsOnly) str = "(function() {\n  var grammar = this.fromRecipe(" + this.grammar.toRecipe() + ");\n  var semantics = " + str + "(grammar);\n  return semantics;\n});\n";
		return str;
	}
	addOperationOrAttribute(type, signature, actionDict) {
		const typePlural = type + "s";
		const parsedNameAndFormalArgs = parseSignature(signature, type);
		const { name } = parsedNameAndFormalArgs;
		const { formals } = parsedNameAndFormalArgs;
		this.assertNewName(name, type);
		const builtInDefault = newDefaultAction(type, name, doIt);
		const realActionDict = { _default: builtInDefault };
		Object.keys(actionDict).forEach((name) => {
			realActionDict[name] = actionDict[name];
		});
		const entry = type === "operation" ? new Operation(name, formals, realActionDict, builtInDefault) : new Attribute(name, realActionDict, builtInDefault);
		entry.checkActionDict(this.grammar);
		this[typePlural][name] = entry;
		function doIt(...args) {
			const thisThing = this._semantics[typePlural][name];
			if (arguments.length !== thisThing.formals.length) throw new Error("Invalid number of arguments passed to " + name + " " + type + " (expected " + thisThing.formals.length + ", got " + arguments.length + ")");
			const argsObj = Object.create(null);
			for (const [idx, val] of Object.entries(args)) {
				const formal = thisThing.formals[idx];
				argsObj[formal] = val;
			}
			const oldArgs = this.args;
			this.args = argsObj;
			const ans = thisThing.execute(this._semantics, this);
			this.args = oldArgs;
			return ans;
		}
		if (type === "operation") {
			this.Wrapper.prototype[name] = doIt;
			this.Wrapper.prototype[name].toString = function() {
				return "[" + name + " operation]";
			};
		} else {
			Object.defineProperty(this.Wrapper.prototype, name, {
				get: doIt,
				configurable: true
			});
			Object.defineProperty(this.attributeKeys, name, { value: uniqueId(name) });
		}
	}
	extendOperationOrAttribute(type, name, actionDict) {
		const typePlural = type + "s";
		parseSignature(name, "attribute");
		if (!(this.super && name in this.super[typePlural])) throw new Error("Cannot extend " + type + " '" + name + "': did not inherit an " + type + " with that name");
		if (hasOwnProperty(this[typePlural], name)) throw new Error("Cannot extend " + type + " '" + name + "' again");
		const inheritedFormals = this[typePlural][name].formals;
		const inheritedActionDict = this[typePlural][name].actionDict;
		const newActionDict = Object.create(inheritedActionDict);
		Object.keys(actionDict).forEach((name) => {
			newActionDict[name] = actionDict[name];
		});
		this[typePlural][name] = type === "operation" ? new Operation(name, inheritedFormals, newActionDict) : new Attribute(name, newActionDict);
		this[typePlural][name].checkActionDict(this.grammar);
	}
	assertNewName(name, type) {
		if (hasOwnProperty(Wrapper.prototype, name)) throw new Error("Cannot add " + type + " '" + name + "': that's a reserved name");
		if (name in this.operations) throw new Error("Cannot add " + type + " '" + name + "': an operation with that name already exists");
		if (name in this.attributes) throw new Error("Cannot add " + type + " '" + name + "': an attribute with that name already exists");
	}
	wrap(node, source, optBaseInterval) {
		const baseInterval = optBaseInterval || source;
		return node instanceof this.Wrapper ? node : new this.Wrapper(node, source, baseInterval);
	}
};
function parseSignature(signature, type) {
	if (!Semantics.prototypeGrammar) {
		assert(signature.indexOf("(") === -1);
		return {
			name: signature,
			formals: []
		};
	}
	const r = Semantics.prototypeGrammar.match(signature, type === "operation" ? "OperationSignature" : "AttributeSignature");
	if (r.failed()) throw new Error(r.message);
	return Semantics.prototypeGrammarSemantics(r).parse();
}
function newDefaultAction(type, name, doIt) {
	return function(...children) {
		const args = (this._semantics.operations[name] || this._semantics.attributes[name]).formals.map((formal) => this.args[formal]);
		if (!this.isIteration() && children.length === 1) return doIt.apply(children[0], args);
		else throw missingSemanticAction(this.ctorName, name, type, globalActionStack);
	};
}
Semantics.createSemantics = function(grammar, optSuperSemantics) {
	const s = new Semantics(grammar, optSuperSemantics !== void 0 ? optSuperSemantics : Semantics.BuiltInSemantics._getSemantics());
	const proxy = function ASemantics(matchResult) {
		if (!(matchResult instanceof MatchResult)) throw new TypeError("Semantics expected a MatchResult, but got " + unexpectedObjToString(matchResult));
		if (matchResult.failed()) throw new TypeError("cannot apply Semantics to " + matchResult.toString());
		const cst = matchResult._cst;
		if (cst.grammar !== grammar) throw new Error("Cannot use a MatchResult from grammar '" + cst.grammar.name + "' with a semantics for '" + grammar.name + "'");
		const inputStream = new InputStream(matchResult.input);
		return s.wrap(cst, inputStream.interval(matchResult._cstOffset, matchResult.input.length));
	};
	proxy.addOperation = function(signature, actionDict) {
		s.addOperationOrAttribute("operation", signature, actionDict);
		return proxy;
	};
	proxy.extendOperation = function(name, actionDict) {
		s.extendOperationOrAttribute("operation", name, actionDict);
		return proxy;
	};
	proxy.addAttribute = function(name, actionDict) {
		s.addOperationOrAttribute("attribute", name, actionDict);
		return proxy;
	};
	proxy.extendAttribute = function(name, actionDict) {
		s.extendOperationOrAttribute("attribute", name, actionDict);
		return proxy;
	};
	proxy._getActionDict = function(operationOrAttributeName) {
		const action = s.operations[operationOrAttributeName] || s.attributes[operationOrAttributeName];
		if (!action) throw new Error("\"" + operationOrAttributeName + "\" is not a valid operation or attribute name in this semantics for \"" + grammar.name + "\"");
		return action.actionDict;
	};
	proxy._remove = function(operationOrAttributeName) {
		let semantic;
		if (operationOrAttributeName in s.operations) {
			semantic = s.operations[operationOrAttributeName];
			delete s.operations[operationOrAttributeName];
		} else if (operationOrAttributeName in s.attributes) {
			semantic = s.attributes[operationOrAttributeName];
			delete s.attributes[operationOrAttributeName];
		}
		delete s.Wrapper.prototype[operationOrAttributeName];
		return semantic;
	};
	proxy.getOperationNames = function() {
		return Object.keys(s.operations);
	};
	proxy.getAttributeNames = function() {
		return Object.keys(s.attributes);
	};
	proxy.getGrammar = function() {
		return s.grammar;
	};
	proxy.toRecipe = function(semanticsOnly) {
		return s.toRecipe(semanticsOnly);
	};
	proxy.toString = s.toString.bind(s);
	proxy._getSemantics = function() {
		return s;
	};
	return proxy;
};
var Operation = class {
	constructor(name, formals, actionDict, builtInDefault) {
		this.name = name;
		this.formals = formals;
		this.actionDict = actionDict;
		this.builtInDefault = builtInDefault;
	}
	checkActionDict(grammar) {
		grammar._checkTopDownActionDict(this.typeName, this.name, this.actionDict);
	}
	execute(semantics, nodeWrapper) {
		try {
			const { ctorName } = nodeWrapper._node;
			let actionFn = this.actionDict[ctorName];
			if (actionFn) {
				globalActionStack.push([this, ctorName]);
				return actionFn.apply(nodeWrapper, nodeWrapper._children());
			}
			if (nodeWrapper.isNonterminal()) {
				actionFn = this.actionDict._nonterminal;
				if (actionFn) {
					globalActionStack.push([
						this,
						"_nonterminal",
						ctorName
					]);
					return actionFn.apply(nodeWrapper, nodeWrapper._children());
				}
			}
			globalActionStack.push([
				this,
				"default action",
				ctorName
			]);
			return this.actionDict._default.apply(nodeWrapper, nodeWrapper._children());
		} finally {
			globalActionStack.pop();
		}
	}
};
Operation.prototype.typeName = "operation";
var Attribute = class extends Operation {
	constructor(name, actionDict, builtInDefault) {
		super(name, [], actionDict, builtInDefault);
	}
	execute(semantics, nodeWrapper) {
		const node = nodeWrapper._node;
		const key = semantics.attributeKeys[this.name];
		if (!hasOwnProperty(node, key)) node[key] = Operation.prototype.execute.call(this, semantics, nodeWrapper);
		return node[key];
	}
};
Attribute.prototype.typeName = "attribute";
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/Grammar.js
const SPECIAL_ACTION_NAMES = [
	"_iter",
	"_terminal",
	"_nonterminal",
	"_default"
];
function getSortedRuleValues(grammar) {
	return Object.keys(grammar.rules).sort().map((name) => grammar.rules[name]);
}
const jsonToJS = (str) => str.replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
let ohmGrammar;
let buildGrammar$1;
var Grammar = class Grammar {
	constructor(name, superGrammar, rules, optDefaultStartRule) {
		this.name = name;
		this.superGrammar = superGrammar;
		this.rules = rules;
		if (optDefaultStartRule) {
			if (!(optDefaultStartRule in rules)) throw new Error("Invalid start rule: '" + optDefaultStartRule + "' is not a rule in grammar '" + name + "'");
			this.defaultStartRule = optDefaultStartRule;
		}
		this._matchStateInitializer = void 0;
		this.supportsIncrementalParsing = true;
	}
	matcher() {
		return new Matcher(this);
	}
	isBuiltIn() {
		return this === Grammar.ProtoBuiltInRules || this === Grammar.BuiltInRules;
	}
	equals(g) {
		if (this === g) return true;
		if (g == null || this.name !== g.name || this.defaultStartRule !== g.defaultStartRule || !(this.superGrammar === g.superGrammar || this.superGrammar.equals(g.superGrammar))) return false;
		const myRules = getSortedRuleValues(this);
		const otherRules = getSortedRuleValues(g);
		return myRules.length === otherRules.length && myRules.every((rule, i) => {
			return rule.description === otherRules[i].description && rule.formals.join(",") === otherRules[i].formals.join(",") && rule.body.toString() === otherRules[i].body.toString();
		});
	}
	match(input, optStartApplication) {
		const m = this.matcher();
		m.replaceInputRange(0, 0, input);
		return m.match(optStartApplication);
	}
	trace(input, optStartApplication) {
		const m = this.matcher();
		m.replaceInputRange(0, 0, input);
		return m.trace(optStartApplication);
	}
	createSemantics() {
		return Semantics.createSemantics(this);
	}
	extendSemantics(superSemantics) {
		return Semantics.createSemantics(this, superSemantics._getSemantics());
	}
	_checkTopDownActionDict(what, name, actionDict) {
		const problems = [];
		for (const k in actionDict) {
			const v = actionDict[k];
			if (!SPECIAL_ACTION_NAMES.includes(k) && !(k in this.rules)) {
				problems.push(`'${k}' is not a valid semantic action for '${this.name}'`);
				continue;
			}
			if (typeof v !== "function") {
				problems.push(`'${k}' must be a function in an action dictionary for '${this.name}'`);
				continue;
			}
			const actual = v.length;
			const expected = this._topDownActionArity(k);
			if (actual !== expected) {
				let details;
				if (k === "_iter" || k === "_nonterminal") details = `it should use a rest parameter, e.g. \`${k}(...children) {}\`. NOTE: this is new in Ohm v16 — see https://ohmjs.org/d/ati for details.`;
				else details = `expected ${expected}, got ${actual}`;
				problems.push(`Semantic action '${k}' has the wrong arity: ${details}`);
			}
		}
		if (problems.length > 0) {
			const prettyProblems = problems.map((problem) => "- " + problem);
			const error = new Error([`Found errors in the action dictionary of the '${name}' ${what}:`, ...prettyProblems].join("\n"));
			error.problems = problems;
			throw error;
		}
	}
	_topDownActionArity(actionName) {
		return SPECIAL_ACTION_NAMES.includes(actionName) ? 0 : this.rules[actionName].body.getArity();
	}
	_inheritsFrom(grammar) {
		let g = this.superGrammar;
		while (g) {
			if (g.equals(grammar, true)) return true;
			g = g.superGrammar;
		}
		return false;
	}
	toRecipe(superGrammarExpr = void 0) {
		const metaInfo = {};
		if (this.source) metaInfo.source = this.source.contents;
		let startRule = null;
		if (this.defaultStartRule) startRule = this.defaultStartRule;
		const rules = {};
		Object.keys(this.rules).forEach((ruleName) => {
			const ruleInfo = this.rules[ruleName];
			const { body } = ruleInfo;
			const isDefinition = !this.superGrammar || !this.superGrammar.rules[ruleName];
			let operation;
			if (isDefinition) operation = "define";
			else operation = body instanceof Extend ? "extend" : "override";
			const metaInfo = {};
			if (ruleInfo.source && this.source) {
				const adjusted = ruleInfo.source.relativeTo(this.source);
				metaInfo.sourceInterval = [adjusted.startIdx, adjusted.endIdx];
			}
			const description = isDefinition ? ruleInfo.description : null;
			const bodyRecipe = body.outputRecipe(ruleInfo.formals, this.source);
			rules[ruleName] = [
				operation,
				metaInfo,
				description,
				ruleInfo.formals,
				bodyRecipe
			];
		});
		let superGrammarOutput = "null";
		if (superGrammarExpr) superGrammarOutput = superGrammarExpr;
		else if (this.superGrammar && !this.superGrammar.isBuiltIn()) superGrammarOutput = this.superGrammar.toRecipe();
		return jsonToJS(`[${[
			...[
				"grammar",
				metaInfo,
				this.name
			].map(JSON.stringify),
			superGrammarOutput,
			...[startRule, rules].map(JSON.stringify)
		].join(",")}]`);
	}
	toOperationActionDictionaryTemplate() {
		return this._toOperationOrAttributeActionDictionaryTemplate();
	}
	toAttributeActionDictionaryTemplate() {
		return this._toOperationOrAttributeActionDictionaryTemplate();
	}
	_toOperationOrAttributeActionDictionaryTemplate() {
		const sb = new StringBuffer();
		sb.append("{");
		let first = true;
		for (const ruleName in this.rules) {
			const { body } = this.rules[ruleName];
			if (first) first = false;
			else sb.append(",");
			sb.append("\n");
			sb.append("  ");
			this.addSemanticActionTemplate(ruleName, body, sb);
		}
		sb.append("\n}");
		return sb.contents();
	}
	addSemanticActionTemplate(ruleName, body, sb) {
		sb.append(ruleName);
		sb.append(": function(");
		const arity = this._topDownActionArity(ruleName);
		sb.append(repeat("_", arity).join(", "));
		sb.append(") {\n");
		sb.append("  }");
	}
	parseApplication(str) {
		let app;
		if (str.indexOf("<") === -1) app = new Apply(str);
		else {
			const cst = ohmGrammar.match(str, "Base_application");
			app = buildGrammar$1(cst, {});
		}
		if (!(app.ruleName in this.rules)) throw undeclaredRule(app.ruleName, this.name);
		const { formals } = this.rules[app.ruleName];
		if (formals.length !== app.args.length) {
			const { source } = this.rules[app.ruleName];
			throw wrongNumberOfParameters(app.ruleName, formals.length, app.args.length, source);
		}
		return app;
	}
	_setUpMatchState(state) {
		if (this._matchStateInitializer) this._matchStateInitializer(state);
	}
};
Grammar.ProtoBuiltInRules = new Grammar("ProtoBuiltInRules", void 0, {
	any: {
		body: any,
		formals: [],
		description: "any character",
		primitive: true
	},
	end: {
		body: end,
		formals: [],
		description: "end of input",
		primitive: true
	},
	caseInsensitive: {
		body: new CaseInsensitiveTerminal(new Param(0)),
		formals: ["str"],
		primitive: true
	},
	lower: {
		body: new UnicodeChar("Ll"),
		formals: [],
		description: "a lowercase letter",
		primitive: true
	},
	upper: {
		body: new UnicodeChar("Lu"),
		formals: [],
		description: "an uppercase letter",
		primitive: true
	},
	unicodeLtmo: {
		body: new UnicodeChar("Ltmo"),
		formals: [],
		description: "a Unicode character in Lt, Lm, or Lo",
		primitive: true
	},
	spaces: {
		body: new Star(new Apply("space")),
		formals: []
	},
	space: {
		body: new Range("\0", " "),
		formals: [],
		description: "a space"
	}
});
Grammar.initApplicationParser = function(grammar, builderFn) {
	ohmGrammar = grammar;
	buildGrammar$1 = builderFn;
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/GrammarDecl.js
var GrammarDecl = class {
	constructor(name) {
		this.name = name;
	}
	sourceInterval(startIdx, endIdx) {
		return this.source.subInterval(startIdx, endIdx - startIdx);
	}
	ensureSuperGrammar() {
		if (!this.superGrammar) this.withSuperGrammar(this.name === "BuiltInRules" ? Grammar.ProtoBuiltInRules : Grammar.BuiltInRules);
		return this.superGrammar;
	}
	ensureSuperGrammarRuleForOverriding(name, source) {
		const ruleInfo = this.ensureSuperGrammar().rules[name];
		if (!ruleInfo) throw cannotOverrideUndeclaredRule(name, this.superGrammar.name, source);
		return ruleInfo;
	}
	installOverriddenOrExtendedRule(name, formals, body, source) {
		const duplicateParameterNames$2 = getDuplicates(formals);
		if (duplicateParameterNames$2.length > 0) throw duplicateParameterNames(name, duplicateParameterNames$2, source);
		const ruleInfo = this.ensureSuperGrammar().rules[name];
		const expectedFormals = ruleInfo.formals;
		const expectedNumFormals = expectedFormals ? expectedFormals.length : 0;
		if (formals.length !== expectedNumFormals) throw wrongNumberOfParameters(name, expectedNumFormals, formals.length, source);
		return this.install(name, formals, body, ruleInfo.description, source);
	}
	install(name, formals, body, description, source, primitive = false) {
		this.rules[name] = {
			body: body.introduceParams(formals),
			formals,
			description,
			source,
			primitive
		};
		return this;
	}
	withSuperGrammar(superGrammar) {
		if (this.superGrammar) throw new Error("the super grammar of a GrammarDecl cannot be set more than once");
		this.superGrammar = superGrammar;
		this.rules = Object.create(superGrammar.rules);
		if (!superGrammar.isBuiltIn()) this.defaultStartRule = superGrammar.defaultStartRule;
		return this;
	}
	withDefaultStartRule(ruleName) {
		this.defaultStartRule = ruleName;
		return this;
	}
	withSource(source) {
		this.source = new InputStream(source).interval(0, source.length);
		return this;
	}
	build() {
		const grammar = new Grammar(this.name, this.ensureSuperGrammar(), this.rules, this.defaultStartRule);
		grammar._matchStateInitializer = grammar.superGrammar._matchStateInitializer;
		grammar.supportsIncrementalParsing = grammar.superGrammar.supportsIncrementalParsing;
		const grammarErrors = [];
		let grammarHasInvalidApplications = false;
		Object.keys(grammar.rules).forEach((ruleName) => {
			const { body } = grammar.rules[ruleName];
			try {
				body.assertChoicesHaveUniformArity(ruleName);
			} catch (e) {
				grammarErrors.push(e);
			}
			try {
				body.assertAllApplicationsAreValid(ruleName, grammar);
			} catch (e) {
				grammarErrors.push(e);
				grammarHasInvalidApplications = true;
			}
		});
		if (!grammarHasInvalidApplications) Object.keys(grammar.rules).forEach((ruleName) => {
			const { body } = grammar.rules[ruleName];
			try {
				body.assertIteratedExprsAreNotNullable(grammar, []);
			} catch (e) {
				grammarErrors.push(e);
			}
		});
		if (grammarErrors.length > 0) throwErrors(grammarErrors);
		if (this.source) grammar.source = this.source;
		return grammar;
	}
	define(name, formals, body, description, source, primitive) {
		this.ensureSuperGrammar();
		if (this.superGrammar.rules[name]) throw duplicateRuleDeclaration(name, this.name, this.superGrammar.name, source);
		else if (this.rules[name]) throw duplicateRuleDeclaration(name, this.name, this.name, source);
		const duplicateParameterNames$1 = getDuplicates(formals);
		if (duplicateParameterNames$1.length > 0) throw duplicateParameterNames(name, duplicateParameterNames$1, source);
		return this.install(name, formals, body, description, source, primitive);
	}
	override(name, formals, body, descIgnored, source) {
		this.ensureSuperGrammarRuleForOverriding(name, source);
		this.installOverriddenOrExtendedRule(name, formals, body, source);
		return this;
	}
	extend(name, formals, fragment, descIgnored, source) {
		if (!this.ensureSuperGrammar().rules[name]) throw cannotExtendUndeclaredRule(name, this.superGrammar.name, source);
		const body = new Extend(this.superGrammar, name, fragment);
		body.source = fragment.source;
		this.installOverriddenOrExtendedRule(name, formals, body, source);
		return this;
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/Builder.js
var Builder = class {
	constructor() {
		this.currentDecl = null;
		this.currentRuleName = null;
	}
	newGrammar(name) {
		return new GrammarDecl(name);
	}
	grammar(metaInfo, name, superGrammar, defaultStartRule, rules) {
		const gDecl = new GrammarDecl(name);
		if (superGrammar) gDecl.withSuperGrammar(superGrammar instanceof Grammar ? superGrammar : this.fromRecipe(superGrammar));
		if (defaultStartRule) gDecl.withDefaultStartRule(defaultStartRule);
		if (metaInfo && metaInfo.source) gDecl.withSource(metaInfo.source);
		this.currentDecl = gDecl;
		Object.keys(rules).forEach((ruleName) => {
			this.currentRuleName = ruleName;
			const ruleRecipe = rules[ruleName];
			const action = ruleRecipe[0];
			const metaInfo = ruleRecipe[1];
			const description = ruleRecipe[2];
			const formals = ruleRecipe[3];
			const body = this.fromRecipe(ruleRecipe[4]);
			let source;
			if (gDecl.source && metaInfo && metaInfo.sourceInterval) source = gDecl.source.subInterval(metaInfo.sourceInterval[0], metaInfo.sourceInterval[1] - metaInfo.sourceInterval[0]);
			gDecl[action](ruleName, formals, body, description, source);
		});
		this.currentRuleName = this.currentDecl = null;
		return gDecl.build();
	}
	terminal(x) {
		return new Terminal(x);
	}
	range(from, to) {
		return new Range(from, to);
	}
	param(index) {
		return new Param(index);
	}
	alt(...termArgs) {
		let terms = [];
		for (let arg of termArgs) {
			if (!(arg instanceof PExpr)) arg = this.fromRecipe(arg);
			if (arg instanceof Alt) terms = terms.concat(arg.terms);
			else terms.push(arg);
		}
		return terms.length === 1 ? terms[0] : new Alt(terms);
	}
	seq(...factorArgs) {
		let factors = [];
		for (let arg of factorArgs) {
			if (!(arg instanceof PExpr)) arg = this.fromRecipe(arg);
			if (arg instanceof Seq) factors = factors.concat(arg.factors);
			else factors.push(arg);
		}
		return factors.length === 1 ? factors[0] : new Seq(factors);
	}
	star(expr) {
		if (!(expr instanceof PExpr)) expr = this.fromRecipe(expr);
		return new Star(expr);
	}
	plus(expr) {
		if (!(expr instanceof PExpr)) expr = this.fromRecipe(expr);
		return new Plus(expr);
	}
	opt(expr) {
		if (!(expr instanceof PExpr)) expr = this.fromRecipe(expr);
		return new Opt(expr);
	}
	not(expr) {
		if (!(expr instanceof PExpr)) expr = this.fromRecipe(expr);
		return new Not(expr);
	}
	lookahead(expr) {
		if (!(expr instanceof PExpr)) expr = this.fromRecipe(expr);
		return new Lookahead(expr);
	}
	lex(expr) {
		if (!(expr instanceof PExpr)) expr = this.fromRecipe(expr);
		return new Lex(expr);
	}
	app(ruleName, optParams) {
		if (optParams && optParams.length > 0) optParams = optParams.map(function(param) {
			return param instanceof PExpr ? param : this.fromRecipe(param);
		}, this);
		return new Apply(ruleName, optParams);
	}
	splice(beforeTerms, afterTerms) {
		return new Splice(this.currentDecl.superGrammar, this.currentRuleName, beforeTerms.map((term) => this.fromRecipe(term)), afterTerms.map((term) => this.fromRecipe(term)));
	}
	fromRecipe(recipe) {
		const args = recipe[0] === "grammar" ? recipe.slice(1) : recipe.slice(2);
		const result = this[recipe[0]](...args);
		const metaInfo = recipe[1];
		if (metaInfo) {
			if (metaInfo.sourceInterval && this.currentDecl) result.withSource(this.currentDecl.sourceInterval(...metaInfo.sourceInterval));
		}
		return result;
	}
};
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/makeRecipe.js
function makeRecipe(recipe) {
	if (typeof recipe === "function") return recipe.call(new Builder());
	else {
		if (typeof recipe === "string") recipe = JSON.parse(recipe);
		return new Builder().fromRecipe(recipe);
	}
}
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/dist/built-in-rules.js
var built_in_rules_default = makeRecipe([
	"grammar",
	{ "source": "BuiltInRules {\n\n  alnum  (an alpha-numeric character)\n    = letter\n    | digit\n\n  letter  (a letter)\n    = lower\n    | upper\n    | unicodeLtmo\n\n  digit  (a digit)\n    = \"0\"..\"9\"\n\n  hexDigit  (a hexadecimal digit)\n    = digit\n    | \"a\"..\"f\"\n    | \"A\"..\"F\"\n\n  ListOf<elem, sep>\n    = NonemptyListOf<elem, sep>\n    | EmptyListOf<elem, sep>\n\n  NonemptyListOf<elem, sep>\n    = elem (sep elem)*\n\n  EmptyListOf<elem, sep>\n    = /* nothing */\n\n  listOf<elem, sep>\n    = nonemptyListOf<elem, sep>\n    | emptyListOf<elem, sep>\n\n  nonemptyListOf<elem, sep>\n    = elem (sep elem)*\n\n  emptyListOf<elem, sep>\n    = /* nothing */\n\n  // Allows a syntactic rule application within a lexical context.\n  applySyntactic<app> = app\n}" },
	"BuiltInRules",
	null,
	null,
	{
		"alnum": [
			"define",
			{ "sourceInterval": [18, 78] },
			"an alpha-numeric character",
			[],
			[
				"alt",
				{ "sourceInterval": [60, 78] },
				[
					"app",
					{ "sourceInterval": [60, 66] },
					"letter",
					[]
				],
				[
					"app",
					{ "sourceInterval": [73, 78] },
					"digit",
					[]
				]
			]
		],
		"letter": [
			"define",
			{ "sourceInterval": [82, 142] },
			"a letter",
			[],
			[
				"alt",
				{ "sourceInterval": [107, 142] },
				[
					"app",
					{ "sourceInterval": [107, 112] },
					"lower",
					[]
				],
				[
					"app",
					{ "sourceInterval": [119, 124] },
					"upper",
					[]
				],
				[
					"app",
					{ "sourceInterval": [131, 142] },
					"unicodeLtmo",
					[]
				]
			]
		],
		"digit": [
			"define",
			{ "sourceInterval": [146, 177] },
			"a digit",
			[],
			[
				"range",
				{ "sourceInterval": [169, 177] },
				"0",
				"9"
			]
		],
		"hexDigit": [
			"define",
			{ "sourceInterval": [181, 254] },
			"a hexadecimal digit",
			[],
			[
				"alt",
				{ "sourceInterval": [219, 254] },
				[
					"app",
					{ "sourceInterval": [219, 224] },
					"digit",
					[]
				],
				[
					"range",
					{ "sourceInterval": [231, 239] },
					"a",
					"f"
				],
				[
					"range",
					{ "sourceInterval": [246, 254] },
					"A",
					"F"
				]
			]
		],
		"ListOf": [
			"define",
			{ "sourceInterval": [258, 336] },
			null,
			["elem", "sep"],
			[
				"alt",
				{ "sourceInterval": [282, 336] },
				[
					"app",
					{ "sourceInterval": [282, 307] },
					"NonemptyListOf",
					[[
						"param",
						{ "sourceInterval": [297, 301] },
						0
					], [
						"param",
						{ "sourceInterval": [303, 306] },
						1
					]]
				],
				[
					"app",
					{ "sourceInterval": [314, 336] },
					"EmptyListOf",
					[[
						"param",
						{ "sourceInterval": [326, 330] },
						0
					], [
						"param",
						{ "sourceInterval": [332, 335] },
						1
					]]
				]
			]
		],
		"NonemptyListOf": [
			"define",
			{ "sourceInterval": [340, 388] },
			null,
			["elem", "sep"],
			[
				"seq",
				{ "sourceInterval": [372, 388] },
				[
					"param",
					{ "sourceInterval": [372, 376] },
					0
				],
				[
					"star",
					{ "sourceInterval": [377, 388] },
					[
						"seq",
						{ "sourceInterval": [378, 386] },
						[
							"param",
							{ "sourceInterval": [378, 381] },
							1
						],
						[
							"param",
							{ "sourceInterval": [382, 386] },
							0
						]
					]
				]
			]
		],
		"EmptyListOf": [
			"define",
			{ "sourceInterval": [392, 434] },
			null,
			["elem", "sep"],
			["seq", { "sourceInterval": [438, 438] }]
		],
		"listOf": [
			"define",
			{ "sourceInterval": [438, 516] },
			null,
			["elem", "sep"],
			[
				"alt",
				{ "sourceInterval": [462, 516] },
				[
					"app",
					{ "sourceInterval": [462, 487] },
					"nonemptyListOf",
					[[
						"param",
						{ "sourceInterval": [477, 481] },
						0
					], [
						"param",
						{ "sourceInterval": [483, 486] },
						1
					]]
				],
				[
					"app",
					{ "sourceInterval": [494, 516] },
					"emptyListOf",
					[[
						"param",
						{ "sourceInterval": [506, 510] },
						0
					], [
						"param",
						{ "sourceInterval": [512, 515] },
						1
					]]
				]
			]
		],
		"nonemptyListOf": [
			"define",
			{ "sourceInterval": [520, 568] },
			null,
			["elem", "sep"],
			[
				"seq",
				{ "sourceInterval": [552, 568] },
				[
					"param",
					{ "sourceInterval": [552, 556] },
					0
				],
				[
					"star",
					{ "sourceInterval": [557, 568] },
					[
						"seq",
						{ "sourceInterval": [558, 566] },
						[
							"param",
							{ "sourceInterval": [558, 561] },
							1
						],
						[
							"param",
							{ "sourceInterval": [562, 566] },
							0
						]
					]
				]
			]
		],
		"emptyListOf": [
			"define",
			{ "sourceInterval": [572, 682] },
			null,
			["elem", "sep"],
			["seq", { "sourceInterval": [685, 685] }]
		],
		"applySyntactic": [
			"define",
			{ "sourceInterval": [685, 710] },
			null,
			["app"],
			[
				"param",
				{ "sourceInterval": [707, 710] },
				0
			]
		]
	}
]);
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/main-kernel.js
Grammar.BuiltInRules = built_in_rules_default;
announceBuiltInRules(Grammar.BuiltInRules);
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/dist/ohm-grammar.js
var ohm_grammar_default = makeRecipe([
	"grammar",
	{ "source": "Ohm {\n\n  Grammars\n    = Grammar*\n\n  Grammar\n    = ident SuperGrammar? \"{\" Rule* \"}\"\n\n  SuperGrammar\n    = \"<:\" ident\n\n  Rule\n    = ident Formals? ruleDescr? \"=\"  RuleBody  -- define\n    | ident Formals?            \":=\" OverrideRuleBody  -- override\n    | ident Formals?            \"+=\" RuleBody  -- extend\n\n  RuleBody\n    = \"|\"? NonemptyListOf<TopLevelTerm, \"|\">\n\n  TopLevelTerm\n    = Seq caseName  -- inline\n    | Seq\n\n  OverrideRuleBody\n    = \"|\"? NonemptyListOf<OverrideTopLevelTerm, \"|\">\n\n  OverrideTopLevelTerm\n    = \"...\"  -- superSplice\n    | TopLevelTerm\n\n  Formals\n    = \"<\" ListOf<ident, \",\"> \">\"\n\n  Params\n    = \"<\" ListOf<Seq, \",\"> \">\"\n\n  Alt\n    = NonemptyListOf<Seq, \"|\">\n\n  Seq\n    = Iter*\n\n  Iter\n    = Pred \"*\"  -- star\n    | Pred \"+\"  -- plus\n    | Pred \"?\"  -- opt\n    | Pred\n\n  Pred\n    = \"~\" Lex  -- not\n    | \"&\" Lex  -- lookahead\n    | Lex\n\n  Lex\n    = \"#\" Base  -- lex\n    | Base\n\n  Base\n    = ident Params? ~(ruleDescr? \"=\" | \":=\" | \"+=\")  -- application\n    | oneCharTerminal \"..\" oneCharTerminal           -- range\n    | terminal                                       -- terminal\n    | \"(\" Alt \")\"                                    -- paren\n\n  ruleDescr  (a rule description)\n    = \"(\" ruleDescrText \")\"\n\n  ruleDescrText\n    = (~\")\" any)*\n\n  caseName\n    = \"--\" (~\"\\n\" space)* name (~\"\\n\" space)* (\"\\n\" | &\"}\")\n\n  name  (a name)\n    = nameFirst nameRest*\n\n  nameFirst\n    = \"_\"\n    | letter\n\n  nameRest\n    = \"_\"\n    | alnum\n\n  ident  (an identifier)\n    = name\n\n  terminal\n    = \"\\\"\" terminalChar* \"\\\"\"\n\n  oneCharTerminal\n    = \"\\\"\" terminalChar \"\\\"\"\n\n  terminalChar\n    = escapeChar\n      | ~\"\\\\\" ~\"\\\"\" ~\"\\n\" \"\\u{0}\"..\"\\u{10FFFF}\"\n\n  escapeChar  (an escape sequence)\n    = \"\\\\\\\\\"                                     -- backslash\n    | \"\\\\\\\"\"                                     -- doubleQuote\n    | \"\\\\\\'\"                                     -- singleQuote\n    | \"\\\\b\"                                      -- backspace\n    | \"\\\\n\"                                      -- lineFeed\n    | \"\\\\r\"                                      -- carriageReturn\n    | \"\\\\t\"                                      -- tab\n    | \"\\\\u{\" hexDigit hexDigit? hexDigit?\n             hexDigit? hexDigit? hexDigit? \"}\"   -- unicodeCodePoint\n    | \"\\\\u\" hexDigit hexDigit hexDigit hexDigit  -- unicodeEscape\n    | \"\\\\x\" hexDigit hexDigit                    -- hexEscape\n\n  space\n   += comment\n\n  comment\n    = \"//\" (~\"\\n\" any)* &(\"\\n\" | end)  -- singleLine\n    | \"/*\" (~\"*/\" any)* \"*/\"  -- multiLine\n\n  tokens = token*\n\n  token = caseName | comment | ident | operator | punctuation | terminal | any\n\n  operator = \"<:\" | \"=\" | \":=\" | \"+=\" | \"*\" | \"+\" | \"?\" | \"~\" | \"&\"\n\n  punctuation = \"<\" | \">\" | \",\" | \"--\"\n}" },
	"Ohm",
	null,
	"Grammars",
	{
		"Grammars": [
			"define",
			{ "sourceInterval": [9, 32] },
			null,
			[],
			[
				"star",
				{ "sourceInterval": [24, 32] },
				[
					"app",
					{ "sourceInterval": [24, 31] },
					"Grammar",
					[]
				]
			]
		],
		"Grammar": [
			"define",
			{ "sourceInterval": [36, 83] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [50, 83] },
				[
					"app",
					{ "sourceInterval": [50, 55] },
					"ident",
					[]
				],
				[
					"opt",
					{ "sourceInterval": [56, 69] },
					[
						"app",
						{ "sourceInterval": [56, 68] },
						"SuperGrammar",
						[]
					]
				],
				[
					"terminal",
					{ "sourceInterval": [70, 73] },
					"{"
				],
				[
					"star",
					{ "sourceInterval": [74, 79] },
					[
						"app",
						{ "sourceInterval": [74, 78] },
						"Rule",
						[]
					]
				],
				[
					"terminal",
					{ "sourceInterval": [80, 83] },
					"}"
				]
			]
		],
		"SuperGrammar": [
			"define",
			{ "sourceInterval": [87, 116] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [106, 116] },
				[
					"terminal",
					{ "sourceInterval": [106, 110] },
					"<:"
				],
				[
					"app",
					{ "sourceInterval": [111, 116] },
					"ident",
					[]
				]
			]
		],
		"Rule_define": [
			"define",
			{ "sourceInterval": [131, 181] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [131, 170] },
				[
					"app",
					{ "sourceInterval": [131, 136] },
					"ident",
					[]
				],
				[
					"opt",
					{ "sourceInterval": [137, 145] },
					[
						"app",
						{ "sourceInterval": [137, 144] },
						"Formals",
						[]
					]
				],
				[
					"opt",
					{ "sourceInterval": [146, 156] },
					[
						"app",
						{ "sourceInterval": [146, 155] },
						"ruleDescr",
						[]
					]
				],
				[
					"terminal",
					{ "sourceInterval": [157, 160] },
					"="
				],
				[
					"app",
					{ "sourceInterval": [162, 170] },
					"RuleBody",
					[]
				]
			]
		],
		"Rule_override": [
			"define",
			{ "sourceInterval": [188, 248] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [188, 235] },
				[
					"app",
					{ "sourceInterval": [188, 193] },
					"ident",
					[]
				],
				[
					"opt",
					{ "sourceInterval": [194, 202] },
					[
						"app",
						{ "sourceInterval": [194, 201] },
						"Formals",
						[]
					]
				],
				[
					"terminal",
					{ "sourceInterval": [214, 218] },
					":="
				],
				[
					"app",
					{ "sourceInterval": [219, 235] },
					"OverrideRuleBody",
					[]
				]
			]
		],
		"Rule_extend": [
			"define",
			{ "sourceInterval": [255, 305] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [255, 294] },
				[
					"app",
					{ "sourceInterval": [255, 260] },
					"ident",
					[]
				],
				[
					"opt",
					{ "sourceInterval": [261, 269] },
					[
						"app",
						{ "sourceInterval": [261, 268] },
						"Formals",
						[]
					]
				],
				[
					"terminal",
					{ "sourceInterval": [281, 285] },
					"+="
				],
				[
					"app",
					{ "sourceInterval": [286, 294] },
					"RuleBody",
					[]
				]
			]
		],
		"Rule": [
			"define",
			{ "sourceInterval": [120, 305] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [131, 305] },
				[
					"app",
					{ "sourceInterval": [131, 170] },
					"Rule_define",
					[]
				],
				[
					"app",
					{ "sourceInterval": [188, 235] },
					"Rule_override",
					[]
				],
				[
					"app",
					{ "sourceInterval": [255, 294] },
					"Rule_extend",
					[]
				]
			]
		],
		"RuleBody": [
			"define",
			{ "sourceInterval": [309, 362] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [324, 362] },
				[
					"opt",
					{ "sourceInterval": [324, 328] },
					[
						"terminal",
						{ "sourceInterval": [324, 327] },
						"|"
					]
				],
				[
					"app",
					{ "sourceInterval": [329, 362] },
					"NonemptyListOf",
					[[
						"app",
						{ "sourceInterval": [344, 356] },
						"TopLevelTerm",
						[]
					], [
						"terminal",
						{ "sourceInterval": [358, 361] },
						"|"
					]]
				]
			]
		],
		"TopLevelTerm_inline": [
			"define",
			{ "sourceInterval": [385, 408] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [385, 397] },
				[
					"app",
					{ "sourceInterval": [385, 388] },
					"Seq",
					[]
				],
				[
					"app",
					{ "sourceInterval": [389, 397] },
					"caseName",
					[]
				]
			]
		],
		"TopLevelTerm": [
			"define",
			{ "sourceInterval": [366, 418] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [385, 418] },
				[
					"app",
					{ "sourceInterval": [385, 397] },
					"TopLevelTerm_inline",
					[]
				],
				[
					"app",
					{ "sourceInterval": [415, 418] },
					"Seq",
					[]
				]
			]
		],
		"OverrideRuleBody": [
			"define",
			{ "sourceInterval": [422, 491] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [445, 491] },
				[
					"opt",
					{ "sourceInterval": [445, 449] },
					[
						"terminal",
						{ "sourceInterval": [445, 448] },
						"|"
					]
				],
				[
					"app",
					{ "sourceInterval": [450, 491] },
					"NonemptyListOf",
					[[
						"app",
						{ "sourceInterval": [465, 485] },
						"OverrideTopLevelTerm",
						[]
					], [
						"terminal",
						{ "sourceInterval": [487, 490] },
						"|"
					]]
				]
			]
		],
		"OverrideTopLevelTerm_superSplice": [
			"define",
			{ "sourceInterval": [522, 543] },
			null,
			[],
			[
				"terminal",
				{ "sourceInterval": [522, 527] },
				"..."
			]
		],
		"OverrideTopLevelTerm": [
			"define",
			{ "sourceInterval": [495, 562] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [522, 562] },
				[
					"app",
					{ "sourceInterval": [522, 527] },
					"OverrideTopLevelTerm_superSplice",
					[]
				],
				[
					"app",
					{ "sourceInterval": [550, 562] },
					"TopLevelTerm",
					[]
				]
			]
		],
		"Formals": [
			"define",
			{ "sourceInterval": [566, 606] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [580, 606] },
				[
					"terminal",
					{ "sourceInterval": [580, 583] },
					"<"
				],
				[
					"app",
					{ "sourceInterval": [584, 602] },
					"ListOf",
					[[
						"app",
						{ "sourceInterval": [591, 596] },
						"ident",
						[]
					], [
						"terminal",
						{ "sourceInterval": [598, 601] },
						","
					]]
				],
				[
					"terminal",
					{ "sourceInterval": [603, 606] },
					">"
				]
			]
		],
		"Params": [
			"define",
			{ "sourceInterval": [610, 647] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [623, 647] },
				[
					"terminal",
					{ "sourceInterval": [623, 626] },
					"<"
				],
				[
					"app",
					{ "sourceInterval": [627, 643] },
					"ListOf",
					[[
						"app",
						{ "sourceInterval": [634, 637] },
						"Seq",
						[]
					], [
						"terminal",
						{ "sourceInterval": [639, 642] },
						","
					]]
				],
				[
					"terminal",
					{ "sourceInterval": [644, 647] },
					">"
				]
			]
		],
		"Alt": [
			"define",
			{ "sourceInterval": [651, 685] },
			null,
			[],
			[
				"app",
				{ "sourceInterval": [661, 685] },
				"NonemptyListOf",
				[[
					"app",
					{ "sourceInterval": [676, 679] },
					"Seq",
					[]
				], [
					"terminal",
					{ "sourceInterval": [681, 684] },
					"|"
				]]
			]
		],
		"Seq": [
			"define",
			{ "sourceInterval": [689, 704] },
			null,
			[],
			[
				"star",
				{ "sourceInterval": [699, 704] },
				[
					"app",
					{ "sourceInterval": [699, 703] },
					"Iter",
					[]
				]
			]
		],
		"Iter_star": [
			"define",
			{ "sourceInterval": [719, 736] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [719, 727] },
				[
					"app",
					{ "sourceInterval": [719, 723] },
					"Pred",
					[]
				],
				[
					"terminal",
					{ "sourceInterval": [724, 727] },
					"*"
				]
			]
		],
		"Iter_plus": [
			"define",
			{ "sourceInterval": [743, 760] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [743, 751] },
				[
					"app",
					{ "sourceInterval": [743, 747] },
					"Pred",
					[]
				],
				[
					"terminal",
					{ "sourceInterval": [748, 751] },
					"+"
				]
			]
		],
		"Iter_opt": [
			"define",
			{ "sourceInterval": [767, 783] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [767, 775] },
				[
					"app",
					{ "sourceInterval": [767, 771] },
					"Pred",
					[]
				],
				[
					"terminal",
					{ "sourceInterval": [772, 775] },
					"?"
				]
			]
		],
		"Iter": [
			"define",
			{ "sourceInterval": [708, 794] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [719, 794] },
				[
					"app",
					{ "sourceInterval": [719, 727] },
					"Iter_star",
					[]
				],
				[
					"app",
					{ "sourceInterval": [743, 751] },
					"Iter_plus",
					[]
				],
				[
					"app",
					{ "sourceInterval": [767, 775] },
					"Iter_opt",
					[]
				],
				[
					"app",
					{ "sourceInterval": [790, 794] },
					"Pred",
					[]
				]
			]
		],
		"Pred_not": [
			"define",
			{ "sourceInterval": [809, 824] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [809, 816] },
				[
					"terminal",
					{ "sourceInterval": [809, 812] },
					"~"
				],
				[
					"app",
					{ "sourceInterval": [813, 816] },
					"Lex",
					[]
				]
			]
		],
		"Pred_lookahead": [
			"define",
			{ "sourceInterval": [831, 852] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [831, 838] },
				[
					"terminal",
					{ "sourceInterval": [831, 834] },
					"&"
				],
				[
					"app",
					{ "sourceInterval": [835, 838] },
					"Lex",
					[]
				]
			]
		],
		"Pred": [
			"define",
			{ "sourceInterval": [798, 862] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [809, 862] },
				[
					"app",
					{ "sourceInterval": [809, 816] },
					"Pred_not",
					[]
				],
				[
					"app",
					{ "sourceInterval": [831, 838] },
					"Pred_lookahead",
					[]
				],
				[
					"app",
					{ "sourceInterval": [859, 862] },
					"Lex",
					[]
				]
			]
		],
		"Lex_lex": [
			"define",
			{ "sourceInterval": [876, 892] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [876, 884] },
				[
					"terminal",
					{ "sourceInterval": [876, 879] },
					"#"
				],
				[
					"app",
					{ "sourceInterval": [880, 884] },
					"Base",
					[]
				]
			]
		],
		"Lex": [
			"define",
			{ "sourceInterval": [866, 903] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [876, 903] },
				[
					"app",
					{ "sourceInterval": [876, 884] },
					"Lex_lex",
					[]
				],
				[
					"app",
					{ "sourceInterval": [899, 903] },
					"Base",
					[]
				]
			]
		],
		"Base_application": [
			"define",
			{ "sourceInterval": [918, 979] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [918, 963] },
				[
					"app",
					{ "sourceInterval": [918, 923] },
					"ident",
					[]
				],
				[
					"opt",
					{ "sourceInterval": [924, 931] },
					[
						"app",
						{ "sourceInterval": [924, 930] },
						"Params",
						[]
					]
				],
				[
					"not",
					{ "sourceInterval": [932, 963] },
					[
						"alt",
						{ "sourceInterval": [934, 962] },
						[
							"seq",
							{ "sourceInterval": [934, 948] },
							[
								"opt",
								{ "sourceInterval": [934, 944] },
								[
									"app",
									{ "sourceInterval": [934, 943] },
									"ruleDescr",
									[]
								]
							],
							[
								"terminal",
								{ "sourceInterval": [945, 948] },
								"="
							]
						],
						[
							"terminal",
							{ "sourceInterval": [951, 955] },
							":="
						],
						[
							"terminal",
							{ "sourceInterval": [958, 962] },
							"+="
						]
					]
				]
			]
		],
		"Base_range": [
			"define",
			{ "sourceInterval": [986, 1041] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [986, 1022] },
				[
					"app",
					{ "sourceInterval": [986, 1001] },
					"oneCharTerminal",
					[]
				],
				[
					"terminal",
					{ "sourceInterval": [1002, 1006] },
					".."
				],
				[
					"app",
					{ "sourceInterval": [1007, 1022] },
					"oneCharTerminal",
					[]
				]
			]
		],
		"Base_terminal": [
			"define",
			{ "sourceInterval": [1048, 1106] },
			null,
			[],
			[
				"app",
				{ "sourceInterval": [1048, 1056] },
				"terminal",
				[]
			]
		],
		"Base_paren": [
			"define",
			{ "sourceInterval": [1113, 1168] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [1113, 1124] },
				[
					"terminal",
					{ "sourceInterval": [1113, 1116] },
					"("
				],
				[
					"app",
					{ "sourceInterval": [1117, 1120] },
					"Alt",
					[]
				],
				[
					"terminal",
					{ "sourceInterval": [1121, 1124] },
					")"
				]
			]
		],
		"Base": [
			"define",
			{ "sourceInterval": [907, 1168] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [918, 1168] },
				[
					"app",
					{ "sourceInterval": [918, 963] },
					"Base_application",
					[]
				],
				[
					"app",
					{ "sourceInterval": [986, 1022] },
					"Base_range",
					[]
				],
				[
					"app",
					{ "sourceInterval": [1048, 1056] },
					"Base_terminal",
					[]
				],
				[
					"app",
					{ "sourceInterval": [1113, 1124] },
					"Base_paren",
					[]
				]
			]
		],
		"ruleDescr": [
			"define",
			{ "sourceInterval": [1172, 1231] },
			"a rule description",
			[],
			[
				"seq",
				{ "sourceInterval": [1210, 1231] },
				[
					"terminal",
					{ "sourceInterval": [1210, 1213] },
					"("
				],
				[
					"app",
					{ "sourceInterval": [1214, 1227] },
					"ruleDescrText",
					[]
				],
				[
					"terminal",
					{ "sourceInterval": [1228, 1231] },
					")"
				]
			]
		],
		"ruleDescrText": [
			"define",
			{ "sourceInterval": [1235, 1266] },
			null,
			[],
			[
				"star",
				{ "sourceInterval": [1255, 1266] },
				[
					"seq",
					{ "sourceInterval": [1256, 1264] },
					[
						"not",
						{ "sourceInterval": [1256, 1260] },
						[
							"terminal",
							{ "sourceInterval": [1257, 1260] },
							")"
						]
					],
					[
						"app",
						{ "sourceInterval": [1261, 1264] },
						"any",
						[]
					]
				]
			]
		],
		"caseName": [
			"define",
			{ "sourceInterval": [1270, 1338] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [1285, 1338] },
				[
					"terminal",
					{ "sourceInterval": [1285, 1289] },
					"--"
				],
				[
					"star",
					{ "sourceInterval": [1290, 1304] },
					[
						"seq",
						{ "sourceInterval": [1291, 1302] },
						[
							"not",
							{ "sourceInterval": [1291, 1296] },
							[
								"terminal",
								{ "sourceInterval": [1292, 1296] },
								"\n"
							]
						],
						[
							"app",
							{ "sourceInterval": [1297, 1302] },
							"space",
							[]
						]
					]
				],
				[
					"app",
					{ "sourceInterval": [1305, 1309] },
					"name",
					[]
				],
				[
					"star",
					{ "sourceInterval": [1310, 1324] },
					[
						"seq",
						{ "sourceInterval": [1311, 1322] },
						[
							"not",
							{ "sourceInterval": [1311, 1316] },
							[
								"terminal",
								{ "sourceInterval": [1312, 1316] },
								"\n"
							]
						],
						[
							"app",
							{ "sourceInterval": [1317, 1322] },
							"space",
							[]
						]
					]
				],
				[
					"alt",
					{ "sourceInterval": [1326, 1337] },
					[
						"terminal",
						{ "sourceInterval": [1326, 1330] },
						"\n"
					],
					[
						"lookahead",
						{ "sourceInterval": [1333, 1337] },
						[
							"terminal",
							{ "sourceInterval": [1334, 1337] },
							"}"
						]
					]
				]
			]
		],
		"name": [
			"define",
			{ "sourceInterval": [1342, 1382] },
			"a name",
			[],
			[
				"seq",
				{ "sourceInterval": [1363, 1382] },
				[
					"app",
					{ "sourceInterval": [1363, 1372] },
					"nameFirst",
					[]
				],
				[
					"star",
					{ "sourceInterval": [1373, 1382] },
					[
						"app",
						{ "sourceInterval": [1373, 1381] },
						"nameRest",
						[]
					]
				]
			]
		],
		"nameFirst": [
			"define",
			{ "sourceInterval": [1386, 1418] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [1402, 1418] },
				[
					"terminal",
					{ "sourceInterval": [1402, 1405] },
					"_"
				],
				[
					"app",
					{ "sourceInterval": [1412, 1418] },
					"letter",
					[]
				]
			]
		],
		"nameRest": [
			"define",
			{ "sourceInterval": [1422, 1452] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [1437, 1452] },
				[
					"terminal",
					{ "sourceInterval": [1437, 1440] },
					"_"
				],
				[
					"app",
					{ "sourceInterval": [1447, 1452] },
					"alnum",
					[]
				]
			]
		],
		"ident": [
			"define",
			{ "sourceInterval": [1456, 1489] },
			"an identifier",
			[],
			[
				"app",
				{ "sourceInterval": [1485, 1489] },
				"name",
				[]
			]
		],
		"terminal": [
			"define",
			{ "sourceInterval": [1493, 1531] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [1508, 1531] },
				[
					"terminal",
					{ "sourceInterval": [1508, 1512] },
					"\""
				],
				[
					"star",
					{ "sourceInterval": [1513, 1526] },
					[
						"app",
						{ "sourceInterval": [1513, 1525] },
						"terminalChar",
						[]
					]
				],
				[
					"terminal",
					{ "sourceInterval": [1527, 1531] },
					"\""
				]
			]
		],
		"oneCharTerminal": [
			"define",
			{ "sourceInterval": [1535, 1579] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [1557, 1579] },
				[
					"terminal",
					{ "sourceInterval": [1557, 1561] },
					"\""
				],
				[
					"app",
					{ "sourceInterval": [1562, 1574] },
					"terminalChar",
					[]
				],
				[
					"terminal",
					{ "sourceInterval": [1575, 1579] },
					"\""
				]
			]
		],
		"terminalChar": [
			"define",
			{ "sourceInterval": [1583, 1660] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [1602, 1660] },
				[
					"app",
					{ "sourceInterval": [1602, 1612] },
					"escapeChar",
					[]
				],
				[
					"seq",
					{ "sourceInterval": [1621, 1660] },
					[
						"not",
						{ "sourceInterval": [1621, 1626] },
						[
							"terminal",
							{ "sourceInterval": [1622, 1626] },
							"\\"
						]
					],
					[
						"not",
						{ "sourceInterval": [1627, 1632] },
						[
							"terminal",
							{ "sourceInterval": [1628, 1632] },
							"\""
						]
					],
					[
						"not",
						{ "sourceInterval": [1633, 1638] },
						[
							"terminal",
							{ "sourceInterval": [1634, 1638] },
							"\n"
						]
					],
					[
						"range",
						{ "sourceInterval": [1639, 1660] },
						"\0",
						"􏿿"
					]
				]
			]
		],
		"escapeChar_backslash": [
			"define",
			{ "sourceInterval": [1703, 1758] },
			null,
			[],
			[
				"terminal",
				{ "sourceInterval": [1703, 1709] },
				"\\\\"
			]
		],
		"escapeChar_doubleQuote": [
			"define",
			{ "sourceInterval": [1765, 1822] },
			null,
			[],
			[
				"terminal",
				{ "sourceInterval": [1765, 1771] },
				"\\\""
			]
		],
		"escapeChar_singleQuote": [
			"define",
			{ "sourceInterval": [1829, 1886] },
			null,
			[],
			[
				"terminal",
				{ "sourceInterval": [1829, 1835] },
				"\\'"
			]
		],
		"escapeChar_backspace": [
			"define",
			{ "sourceInterval": [1893, 1948] },
			null,
			[],
			[
				"terminal",
				{ "sourceInterval": [1893, 1898] },
				"\\b"
			]
		],
		"escapeChar_lineFeed": [
			"define",
			{ "sourceInterval": [1955, 2009] },
			null,
			[],
			[
				"terminal",
				{ "sourceInterval": [1955, 1960] },
				"\\n"
			]
		],
		"escapeChar_carriageReturn": [
			"define",
			{ "sourceInterval": [2016, 2076] },
			null,
			[],
			[
				"terminal",
				{ "sourceInterval": [2016, 2021] },
				"\\r"
			]
		],
		"escapeChar_tab": [
			"define",
			{ "sourceInterval": [2083, 2132] },
			null,
			[],
			[
				"terminal",
				{ "sourceInterval": [2083, 2088] },
				"\\t"
			]
		],
		"escapeChar_unicodeCodePoint": [
			"define",
			{ "sourceInterval": [2139, 2243] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [2139, 2221] },
				[
					"terminal",
					{ "sourceInterval": [2139, 2145] },
					"\\u{"
				],
				[
					"app",
					{ "sourceInterval": [2146, 2154] },
					"hexDigit",
					[]
				],
				[
					"opt",
					{ "sourceInterval": [2155, 2164] },
					[
						"app",
						{ "sourceInterval": [2155, 2163] },
						"hexDigit",
						[]
					]
				],
				[
					"opt",
					{ "sourceInterval": [2165, 2174] },
					[
						"app",
						{ "sourceInterval": [2165, 2173] },
						"hexDigit",
						[]
					]
				],
				[
					"opt",
					{ "sourceInterval": [2188, 2197] },
					[
						"app",
						{ "sourceInterval": [2188, 2196] },
						"hexDigit",
						[]
					]
				],
				[
					"opt",
					{ "sourceInterval": [2198, 2207] },
					[
						"app",
						{ "sourceInterval": [2198, 2206] },
						"hexDigit",
						[]
					]
				],
				[
					"opt",
					{ "sourceInterval": [2208, 2217] },
					[
						"app",
						{ "sourceInterval": [2208, 2216] },
						"hexDigit",
						[]
					]
				],
				[
					"terminal",
					{ "sourceInterval": [2218, 2221] },
					"}"
				]
			]
		],
		"escapeChar_unicodeEscape": [
			"define",
			{ "sourceInterval": [2250, 2309] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [2250, 2291] },
				[
					"terminal",
					{ "sourceInterval": [2250, 2255] },
					"\\u"
				],
				[
					"app",
					{ "sourceInterval": [2256, 2264] },
					"hexDigit",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2265, 2273] },
					"hexDigit",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2274, 2282] },
					"hexDigit",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2283, 2291] },
					"hexDigit",
					[]
				]
			]
		],
		"escapeChar_hexEscape": [
			"define",
			{ "sourceInterval": [2316, 2371] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [2316, 2339] },
				[
					"terminal",
					{ "sourceInterval": [2316, 2321] },
					"\\x"
				],
				[
					"app",
					{ "sourceInterval": [2322, 2330] },
					"hexDigit",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2331, 2339] },
					"hexDigit",
					[]
				]
			]
		],
		"escapeChar": [
			"define",
			{ "sourceInterval": [1664, 2371] },
			"an escape sequence",
			[],
			[
				"alt",
				{ "sourceInterval": [1703, 2371] },
				[
					"app",
					{ "sourceInterval": [1703, 1709] },
					"escapeChar_backslash",
					[]
				],
				[
					"app",
					{ "sourceInterval": [1765, 1771] },
					"escapeChar_doubleQuote",
					[]
				],
				[
					"app",
					{ "sourceInterval": [1829, 1835] },
					"escapeChar_singleQuote",
					[]
				],
				[
					"app",
					{ "sourceInterval": [1893, 1898] },
					"escapeChar_backspace",
					[]
				],
				[
					"app",
					{ "sourceInterval": [1955, 1960] },
					"escapeChar_lineFeed",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2016, 2021] },
					"escapeChar_carriageReturn",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2083, 2088] },
					"escapeChar_tab",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2139, 2221] },
					"escapeChar_unicodeCodePoint",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2250, 2291] },
					"escapeChar_unicodeEscape",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2316, 2339] },
					"escapeChar_hexEscape",
					[]
				]
			]
		],
		"space": [
			"extend",
			{ "sourceInterval": [2375, 2394] },
			null,
			[],
			[
				"app",
				{ "sourceInterval": [2387, 2394] },
				"comment",
				[]
			]
		],
		"comment_singleLine": [
			"define",
			{ "sourceInterval": [2412, 2458] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [2412, 2443] },
				[
					"terminal",
					{ "sourceInterval": [2412, 2416] },
					"//"
				],
				[
					"star",
					{ "sourceInterval": [2417, 2429] },
					[
						"seq",
						{ "sourceInterval": [2418, 2427] },
						[
							"not",
							{ "sourceInterval": [2418, 2423] },
							[
								"terminal",
								{ "sourceInterval": [2419, 2423] },
								"\n"
							]
						],
						[
							"app",
							{ "sourceInterval": [2424, 2427] },
							"any",
							[]
						]
					]
				],
				[
					"lookahead",
					{ "sourceInterval": [2430, 2443] },
					[
						"alt",
						{ "sourceInterval": [2432, 2442] },
						[
							"terminal",
							{ "sourceInterval": [2432, 2436] },
							"\n"
						],
						[
							"app",
							{ "sourceInterval": [2439, 2442] },
							"end",
							[]
						]
					]
				]
			]
		],
		"comment_multiLine": [
			"define",
			{ "sourceInterval": [2465, 2501] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [2465, 2487] },
				[
					"terminal",
					{ "sourceInterval": [2465, 2469] },
					"/*"
				],
				[
					"star",
					{ "sourceInterval": [2470, 2482] },
					[
						"seq",
						{ "sourceInterval": [2471, 2480] },
						[
							"not",
							{ "sourceInterval": [2471, 2476] },
							[
								"terminal",
								{ "sourceInterval": [2472, 2476] },
								"*/"
							]
						],
						[
							"app",
							{ "sourceInterval": [2477, 2480] },
							"any",
							[]
						]
					]
				],
				[
					"terminal",
					{ "sourceInterval": [2483, 2487] },
					"*/"
				]
			]
		],
		"comment": [
			"define",
			{ "sourceInterval": [2398, 2501] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [2412, 2501] },
				[
					"app",
					{ "sourceInterval": [2412, 2443] },
					"comment_singleLine",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2465, 2487] },
					"comment_multiLine",
					[]
				]
			]
		],
		"tokens": [
			"define",
			{ "sourceInterval": [2505, 2520] },
			null,
			[],
			[
				"star",
				{ "sourceInterval": [2514, 2520] },
				[
					"app",
					{ "sourceInterval": [2514, 2519] },
					"token",
					[]
				]
			]
		],
		"token": [
			"define",
			{ "sourceInterval": [2524, 2600] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [2532, 2600] },
				[
					"app",
					{ "sourceInterval": [2532, 2540] },
					"caseName",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2543, 2550] },
					"comment",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2553, 2558] },
					"ident",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2561, 2569] },
					"operator",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2572, 2583] },
					"punctuation",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2586, 2594] },
					"terminal",
					[]
				],
				[
					"app",
					{ "sourceInterval": [2597, 2600] },
					"any",
					[]
				]
			]
		],
		"operator": [
			"define",
			{ "sourceInterval": [2604, 2669] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [2615, 2669] },
				[
					"terminal",
					{ "sourceInterval": [2615, 2619] },
					"<:"
				],
				[
					"terminal",
					{ "sourceInterval": [2622, 2625] },
					"="
				],
				[
					"terminal",
					{ "sourceInterval": [2628, 2632] },
					":="
				],
				[
					"terminal",
					{ "sourceInterval": [2635, 2639] },
					"+="
				],
				[
					"terminal",
					{ "sourceInterval": [2642, 2645] },
					"*"
				],
				[
					"terminal",
					{ "sourceInterval": [2648, 2651] },
					"+"
				],
				[
					"terminal",
					{ "sourceInterval": [2654, 2657] },
					"?"
				],
				[
					"terminal",
					{ "sourceInterval": [2660, 2663] },
					"~"
				],
				[
					"terminal",
					{ "sourceInterval": [2666, 2669] },
					"&"
				]
			]
		],
		"punctuation": [
			"define",
			{ "sourceInterval": [2673, 2709] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [2687, 2709] },
				[
					"terminal",
					{ "sourceInterval": [2687, 2690] },
					"<"
				],
				[
					"terminal",
					{ "sourceInterval": [2693, 2696] },
					">"
				],
				[
					"terminal",
					{ "sourceInterval": [2699, 2702] },
					","
				],
				[
					"terminal",
					{ "sourceInterval": [2705, 2709] },
					"--"
				]
			]
		]
	}
]);
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/buildGrammar.js
const superSplicePlaceholder = Object.create(PExpr.prototype);
function namespaceHas(ns, name) {
	for (const prop in ns) if (prop === name) return true;
	return false;
}
function buildGrammar(match, namespace, optOhmGrammarForTesting) {
	const builder = new Builder();
	let decl;
	let currentRuleName;
	let currentRuleFormals;
	let overriding = false;
	return (optOhmGrammarForTesting || ohm_grammar_default).createSemantics().addOperation("visit", {
		Grammars(grammarIter) {
			return grammarIter.children.map((c) => c.visit());
		},
		Grammar(id, s, _open, rules, _close) {
			const grammarName = id.visit();
			decl = builder.newGrammar(grammarName);
			s.child(0) && s.child(0).visit();
			rules.children.map((c) => c.visit());
			const g = decl.build();
			g.source = this.source.trimmed();
			if (namespaceHas(namespace, grammarName)) throw duplicateGrammarDeclaration(g, namespace);
			namespace[grammarName] = g;
			return g;
		},
		SuperGrammar(_, n) {
			const superGrammarName = n.visit();
			if (superGrammarName === "null") decl.withSuperGrammar(null);
			else {
				if (!namespace || !namespaceHas(namespace, superGrammarName)) throw undeclaredGrammar(superGrammarName, namespace, n.source);
				decl.withSuperGrammar(namespace[superGrammarName]);
			}
		},
		Rule_define(n, fs, d, _, b) {
			currentRuleName = n.visit();
			currentRuleFormals = fs.children.map((c) => c.visit())[0] || [];
			if (!decl.defaultStartRule && decl.ensureSuperGrammar() !== Grammar.ProtoBuiltInRules) decl.withDefaultStartRule(currentRuleName);
			const body = b.visit();
			const description = d.children.map((c) => c.visit())[0];
			const source = this.source.trimmed();
			return decl.define(currentRuleName, currentRuleFormals, body, description, source);
		},
		Rule_override(n, fs, _, b) {
			currentRuleName = n.visit();
			currentRuleFormals = fs.children.map((c) => c.visit())[0] || [];
			const source = this.source.trimmed();
			decl.ensureSuperGrammarRuleForOverriding(currentRuleName, source);
			overriding = true;
			const body = b.visit();
			overriding = false;
			return decl.override(currentRuleName, currentRuleFormals, body, null, source);
		},
		Rule_extend(n, fs, _, b) {
			currentRuleName = n.visit();
			currentRuleFormals = fs.children.map((c) => c.visit())[0] || [];
			const body = b.visit();
			const source = this.source.trimmed();
			return decl.extend(currentRuleName, currentRuleFormals, body, null, source);
		},
		RuleBody(_, terms) {
			return builder.alt(...terms.visit()).withSource(this.source);
		},
		OverrideRuleBody(_, terms) {
			const args = terms.visit();
			const expansionPos = args.indexOf(superSplicePlaceholder);
			if (expansionPos >= 0) {
				const beforeTerms = args.slice(0, expansionPos);
				const afterTerms = args.slice(expansionPos + 1);
				afterTerms.forEach((t) => {
					if (t === superSplicePlaceholder) throw multipleSuperSplices(t);
				});
				return new Splice(decl.superGrammar, currentRuleName, beforeTerms, afterTerms).withSource(this.source);
			} else return builder.alt(...args).withSource(this.source);
		},
		Formals(opointy, fs, cpointy) {
			return fs.visit();
		},
		Params(opointy, ps, cpointy) {
			return ps.visit();
		},
		Alt(seqs) {
			return builder.alt(...seqs.visit()).withSource(this.source);
		},
		TopLevelTerm_inline(b, n) {
			const inlineRuleName = currentRuleName + "_" + n.visit();
			const body = b.visit();
			const source = this.source.trimmed();
			const isNewRuleDeclaration = !(decl.superGrammar && decl.superGrammar.rules[inlineRuleName]);
			if (overriding && !isNewRuleDeclaration) decl.override(inlineRuleName, currentRuleFormals, body, null, source);
			else decl.define(inlineRuleName, currentRuleFormals, body, null, source);
			const params = currentRuleFormals.map((formal) => builder.app(formal));
			return builder.app(inlineRuleName, params).withSource(body.source);
		},
		OverrideTopLevelTerm_superSplice(_) {
			return superSplicePlaceholder;
		},
		Seq(expr) {
			return builder.seq(...expr.children.map((c) => c.visit())).withSource(this.source);
		},
		Iter_star(x, _) {
			return builder.star(x.visit()).withSource(this.source);
		},
		Iter_plus(x, _) {
			return builder.plus(x.visit()).withSource(this.source);
		},
		Iter_opt(x, _) {
			return builder.opt(x.visit()).withSource(this.source);
		},
		Pred_not(_, x) {
			return builder.not(x.visit()).withSource(this.source);
		},
		Pred_lookahead(_, x) {
			return builder.lookahead(x.visit()).withSource(this.source);
		},
		Lex_lex(_, x) {
			return builder.lex(x.visit()).withSource(this.source);
		},
		Base_application(rule, ps) {
			const params = ps.children.map((c) => c.visit())[0] || [];
			return builder.app(rule.visit(), params).withSource(this.source);
		},
		Base_range(from, _, to) {
			return builder.range(from.visit(), to.visit()).withSource(this.source);
		},
		Base_terminal(expr) {
			return builder.terminal(expr.visit()).withSource(this.source);
		},
		Base_paren(open, x, close) {
			return x.visit();
		},
		ruleDescr(open, t, close) {
			return t.visit();
		},
		ruleDescrText(_) {
			return this.sourceString.trim();
		},
		caseName(_, space1, n, space2, end) {
			return n.visit();
		},
		name(first, rest) {
			return this.sourceString;
		},
		nameFirst(expr) {},
		nameRest(expr) {},
		terminal(open, cs, close) {
			return cs.children.map((c) => c.visit()).join("");
		},
		oneCharTerminal(open, c, close) {
			return c.visit();
		},
		escapeChar(c) {
			try {
				return unescapeCodePoint(this.sourceString);
			} catch (err) {
				if (err instanceof RangeError && err.message.startsWith("Invalid code point ")) throw invalidCodePoint(c);
				throw err;
			}
		},
		NonemptyListOf(x, _, xs) {
			return [x.visit()].concat(xs.children.map((c) => c.visit()));
		},
		EmptyListOf() {
			return [];
		},
		_terminal() {
			return this.sourceString;
		}
	})(match).visit();
}
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/dist/operations-and-attributes.js
var operations_and_attributes_default = makeRecipe([
	"grammar",
	{ "source": "OperationsAndAttributes {\n\n  AttributeSignature =\n    name\n\n  OperationSignature =\n    name Formals?\n\n  Formals\n    = \"(\" ListOf<name, \",\"> \")\"\n\n  name  (a name)\n    = nameFirst nameRest*\n\n  nameFirst\n    = \"_\"\n    | letter\n\n  nameRest\n    = \"_\"\n    | alnum\n\n}" },
	"OperationsAndAttributes",
	null,
	"AttributeSignature",
	{
		"AttributeSignature": [
			"define",
			{ "sourceInterval": [29, 58] },
			null,
			[],
			[
				"app",
				{ "sourceInterval": [54, 58] },
				"name",
				[]
			]
		],
		"OperationSignature": [
			"define",
			{ "sourceInterval": [62, 100] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [87, 100] },
				[
					"app",
					{ "sourceInterval": [87, 91] },
					"name",
					[]
				],
				[
					"opt",
					{ "sourceInterval": [92, 100] },
					[
						"app",
						{ "sourceInterval": [92, 99] },
						"Formals",
						[]
					]
				]
			]
		],
		"Formals": [
			"define",
			{ "sourceInterval": [104, 143] },
			null,
			[],
			[
				"seq",
				{ "sourceInterval": [118, 143] },
				[
					"terminal",
					{ "sourceInterval": [118, 121] },
					"("
				],
				[
					"app",
					{ "sourceInterval": [122, 139] },
					"ListOf",
					[[
						"app",
						{ "sourceInterval": [129, 133] },
						"name",
						[]
					], [
						"terminal",
						{ "sourceInterval": [135, 138] },
						","
					]]
				],
				[
					"terminal",
					{ "sourceInterval": [140, 143] },
					")"
				]
			]
		],
		"name": [
			"define",
			{ "sourceInterval": [147, 187] },
			"a name",
			[],
			[
				"seq",
				{ "sourceInterval": [168, 187] },
				[
					"app",
					{ "sourceInterval": [168, 177] },
					"nameFirst",
					[]
				],
				[
					"star",
					{ "sourceInterval": [178, 187] },
					[
						"app",
						{ "sourceInterval": [178, 186] },
						"nameRest",
						[]
					]
				]
			]
		],
		"nameFirst": [
			"define",
			{ "sourceInterval": [191, 223] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [207, 223] },
				[
					"terminal",
					{ "sourceInterval": [207, 210] },
					"_"
				],
				[
					"app",
					{ "sourceInterval": [217, 223] },
					"letter",
					[]
				]
			]
		],
		"nameRest": [
			"define",
			{ "sourceInterval": [227, 257] },
			null,
			[],
			[
				"alt",
				{ "sourceInterval": [242, 257] },
				[
					"terminal",
					{ "sourceInterval": [242, 245] },
					"_"
				],
				[
					"app",
					{ "sourceInterval": [252, 257] },
					"alnum",
					[]
				]
			]
		]
	}
]);
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/semanticsDeferredInit.js
initBuiltInSemantics(Grammar.BuiltInRules);
initPrototypeParser(operations_and_attributes_default);
function initBuiltInSemantics(builtInRules) {
	const actions = {
		empty() {
			return this.iteration();
		},
		nonEmpty(first, _, rest) {
			return this.iteration([first].concat(rest.children));
		},
		self(..._children) {
			return this;
		}
	};
	Semantics.BuiltInSemantics = Semantics.createSemantics(builtInRules, null).addOperation("asIteration", {
		emptyListOf: actions.empty,
		nonemptyListOf: actions.nonEmpty,
		EmptyListOf: actions.empty,
		NonemptyListOf: actions.nonEmpty,
		_iter: actions.self
	});
}
function initPrototypeParser(grammar) {
	Semantics.prototypeGrammarSemantics = grammar.createSemantics().addOperation("parse", {
		AttributeSignature(name) {
			return {
				name: name.parse(),
				formals: []
			};
		},
		OperationSignature(name, optFormals) {
			return {
				name: name.parse(),
				formals: optFormals.children.map((c) => c.parse())[0] || []
			};
		},
		Formals(oparen, fs, cparen) {
			return fs.asIteration().children.map((c) => c.parse());
		},
		name(first, rest) {
			return this.sourceString;
		}
	});
	Semantics.prototypeGrammar = grammar;
}
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/findIndentation.js
function findIndentation(input) {
	let pos = 0;
	const stack = [0];
	const topOfStack = () => stack[stack.length - 1];
	const result = {};
	const regex = /( *).*(?:$|\r?\n|\r)/g;
	let match;
	while ((match = regex.exec(input)) != null) {
		const [line, indent] = match;
		if (line.length === 0) break;
		const indentSize = indent.length;
		const prevSize = topOfStack();
		const indentPos = pos + indentSize;
		if (indentSize > prevSize) {
			stack.push(indentSize);
			result[indentPos] = 1;
		} else if (indentSize < prevSize) {
			const prevLength = stack.length;
			while (topOfStack() !== indentSize) stack.pop();
			result[indentPos] = -1 * (prevLength - stack.length);
		}
		pos += line.length;
	}
	if (stack.length > 1) result[pos] = 1 - stack.length;
	return result;
}
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/IndentationSensitive.js
const INDENT_DESCRIPTION = "an indented block";
const DEDENT_DESCRIPTION = "a dedent";
const INVALID_CODE_POINT = 1114112;
var InputStreamWithIndentation = class extends InputStream {
	constructor(state) {
		super(state.input);
		this.state = state;
	}
	_indentationAt(pos) {
		return this.state.userData[pos] || 0;
	}
	atEnd() {
		return super.atEnd() && this._indentationAt(this.pos) === 0;
	}
	next() {
		if (this._indentationAt(this.pos) !== 0) {
			this.examinedLength = Math.max(this.examinedLength, this.pos);
			return;
		}
		return super.next();
	}
	nextCharCode() {
		if (this._indentationAt(this.pos) !== 0) {
			this.examinedLength = Math.max(this.examinedLength, this.pos);
			return INVALID_CODE_POINT;
		}
		return super.nextCharCode();
	}
	nextCodePoint() {
		if (this._indentationAt(this.pos) !== 0) {
			this.examinedLength = Math.max(this.examinedLength, this.pos);
			return INVALID_CODE_POINT;
		}
		return super.nextCodePoint();
	}
};
var Indentation = class extends PExpr {
	constructor(isIndent = true) {
		super();
		this.isIndent = isIndent;
	}
	allowsSkippingPrecedingSpace() {
		return true;
	}
	eval(state) {
		const { inputStream } = state;
		const pseudoTokens = state.userData;
		state.doNotMemoize = true;
		const origPos = inputStream.pos;
		const sign = this.isIndent ? 1 : -1;
		if ((pseudoTokens[origPos] || 0) * sign > 0) {
			state.userData = Object.create(pseudoTokens);
			state.userData[origPos] -= sign;
			state.pushBinding(new TerminalNode(0), origPos);
			return true;
		} else {
			state.processFailure(origPos, this);
			return false;
		}
	}
	getArity() {
		return 1;
	}
	_assertAllApplicationsAreValid(ruleName, grammar) {}
	_isNullable(grammar, memo) {
		return false;
	}
	assertChoicesHaveUniformArity(ruleName) {}
	assertIteratedExprsAreNotNullable(grammar) {}
	introduceParams(formals) {
		return this;
	}
	substituteParams(actuals) {
		return this;
	}
	toString() {
		return this.isIndent ? "indent" : "dedent";
	}
	toDisplayString() {
		return this.toString();
	}
	toFailure(grammar) {
		const description = this.isIndent ? INDENT_DESCRIPTION : DEDENT_DESCRIPTION;
		return new Failure(this, description, "description");
	}
};
const newAnyBody = new Splice(built_in_rules_default, "any", [new Apply("indent"), new Apply("dedent")], []);
const IndentationSensitive = new Builder().newGrammar("IndentationSensitive").withSuperGrammar(built_in_rules_default).define("indent", [], new Indentation(true), INDENT_DESCRIPTION, void 0, true).define("dedent", [], new Indentation(false), DEDENT_DESCRIPTION, void 0, true).extend("any", [], newAnyBody, "any character", void 0).build();
Object.assign(IndentationSensitive, {
	_matchStateInitializer(state) {
		state.userData = findIndentation(state.input);
		state.inputStream = new InputStreamWithIndentation(state);
	},
	supportsIncrementalParsing: false
});
//#endregion
//#region ../node_modules/.pnpm/ohm-js@17.2.1/node_modules/ohm-js/src/main.js
Grammar.initApplicationParser(ohm_grammar_default, buildGrammar);
//#endregion
//#region src/utils/parse-pgarray/grammar/grammar.ohm-bundle.js
const result = {};
result.PGArrayExpression = makeRecipe([
	"grammar",
	{ source: "PGArrayExpression {    \n    Array = \"ARRAY[\" ListOf<ArrayItem, \",\"> \"]\"\n\n    ArrayItem = stringLiteral | Array | quotelessString  | nullLiteral\n\n    stringLiteral = \"\\\"\" ((~(\"\\\"\" | escapedSymbol) any) | escapedSymbol)* \"\\\"\"\n    \n    quotelessString = (~forbiddenSymbolForQuoteless any)+\n\n	escapedSymbol = \"\\\\\" any\n\n    nullLiteral = \"NULL\"\n\n	forbiddenSymbolForQuoteless = \"[\" | \"]\" | \" , \" | \"\\\"\"  | nullLiteral\n}" },
	"PGArrayExpression",
	null,
	"Array",
	{
		Array: [
			"define",
			{ sourceInterval: [28, 71] },
			null,
			[],
			[
				"seq",
				{ sourceInterval: [36, 71] },
				[
					"terminal",
					{ sourceInterval: [36, 44] },
					"ARRAY["
				],
				[
					"app",
					{ sourceInterval: [45, 67] },
					"ListOf",
					[[
						"app",
						{ sourceInterval: [52, 61] },
						"ArrayItem",
						[]
					], [
						"terminal",
						{ sourceInterval: [63, 66] },
						","
					]]
				],
				[
					"terminal",
					{ sourceInterval: [68, 71] },
					"]"
				]
			]
		],
		ArrayItem: [
			"define",
			{ sourceInterval: [77, 143] },
			null,
			[],
			[
				"alt",
				{ sourceInterval: [89, 143] },
				[
					"app",
					{ sourceInterval: [89, 102] },
					"stringLiteral",
					[]
				],
				[
					"app",
					{ sourceInterval: [105, 110] },
					"Array",
					[]
				],
				[
					"app",
					{ sourceInterval: [113, 128] },
					"quotelessString",
					[]
				],
				[
					"app",
					{ sourceInterval: [132, 143] },
					"nullLiteral",
					[]
				]
			]
		],
		stringLiteral: [
			"define",
			{ sourceInterval: [149, 223] },
			null,
			[],
			[
				"seq",
				{ sourceInterval: [165, 223] },
				[
					"terminal",
					{ sourceInterval: [165, 169] },
					"\""
				],
				[
					"star",
					{ sourceInterval: [170, 218] },
					[
						"alt",
						{ sourceInterval: [171, 216] },
						[
							"seq",
							{ sourceInterval: [171, 200] },
							[
								"not",
								{ sourceInterval: [172, 195] },
								[
									"alt",
									{ sourceInterval: [174, 194] },
									[
										"terminal",
										{ sourceInterval: [174, 178] },
										"\""
									],
									[
										"app",
										{ sourceInterval: [181, 194] },
										"escapedSymbol",
										[]
									]
								]
							],
							[
								"app",
								{ sourceInterval: [196, 199] },
								"any",
								[]
							]
						],
						[
							"app",
							{ sourceInterval: [203, 216] },
							"escapedSymbol",
							[]
						]
					]
				],
				[
					"terminal",
					{ sourceInterval: [219, 223] },
					"\""
				]
			]
		],
		quotelessString: [
			"define",
			{ sourceInterval: [233, 286] },
			null,
			[],
			[
				"plus",
				{ sourceInterval: [251, 286] },
				[
					"seq",
					{ sourceInterval: [252, 284] },
					[
						"not",
						{ sourceInterval: [252, 280] },
						[
							"app",
							{ sourceInterval: [253, 280] },
							"forbiddenSymbolForQuoteless",
							[]
						]
					],
					[
						"app",
						{ sourceInterval: [281, 284] },
						"any",
						[]
					]
				]
			]
		],
		escapedSymbol: [
			"define",
			{ sourceInterval: [289, 313] },
			null,
			[],
			[
				"seq",
				{ sourceInterval: [305, 313] },
				[
					"terminal",
					{ sourceInterval: [305, 309] },
					"\\"
				],
				[
					"app",
					{ sourceInterval: [310, 313] },
					"any",
					[]
				]
			]
		],
		nullLiteral: [
			"define",
			{ sourceInterval: [319, 339] },
			null,
			[],
			[
				"terminal",
				{ sourceInterval: [333, 339] },
				"NULL"
			]
		],
		forbiddenSymbolForQuoteless: [
			"define",
			{ sourceInterval: [342, 411] },
			null,
			[],
			[
				"alt",
				{ sourceInterval: [372, 411] },
				[
					"terminal",
					{ sourceInterval: [372, 375] },
					"["
				],
				[
					"terminal",
					{ sourceInterval: [378, 381] },
					"]"
				],
				[
					"terminal",
					{ sourceInterval: [384, 389] },
					" , "
				],
				[
					"terminal",
					{ sourceInterval: [392, 396] },
					"\""
				],
				[
					"app",
					{ sourceInterval: [400, 411] },
					"nullLiteral",
					[]
				]
			]
		]
	}
]);
result.PGArrayLiteral = makeRecipe([
	"grammar",
	{ source: "PGArrayLiteral {    \n    Array = \"{\" ListOf<ArrayItem, \",\"> \"}\"\n\n    ArrayItem = stringLiteral | quotelessString | nullLiteral | Array\n\n    stringLiteral = \"\\\"\" ((~(\"\\\"\" | escapedSymbol) any) | escapedSymbol)* \"\\\"\"\n    \n    quotelessString = (~forbiddenSymbolForQuoteless any)+\n\n	escapedSymbol = \"\\\\\" any \n\n    nullLiteral = \"NULL\"\n\n	forbiddenSymbolForQuoteless = \"{\" | \"}\" | \",\" | \"\\\"\"  | nullLiteral\n}" },
	"PGArrayLiteral",
	null,
	"Array",
	{
		Array: [
			"define",
			{ sourceInterval: [25, 63] },
			null,
			[],
			[
				"seq",
				{ sourceInterval: [33, 63] },
				[
					"terminal",
					{ sourceInterval: [33, 36] },
					"{"
				],
				[
					"app",
					{ sourceInterval: [37, 59] },
					"ListOf",
					[[
						"app",
						{ sourceInterval: [44, 53] },
						"ArrayItem",
						[]
					], [
						"terminal",
						{ sourceInterval: [55, 58] },
						","
					]]
				],
				[
					"terminal",
					{ sourceInterval: [60, 63] },
					"}"
				]
			]
		],
		ArrayItem: [
			"define",
			{ sourceInterval: [69, 134] },
			null,
			[],
			[
				"alt",
				{ sourceInterval: [81, 134] },
				[
					"app",
					{ sourceInterval: [81, 94] },
					"stringLiteral",
					[]
				],
				[
					"app",
					{ sourceInterval: [97, 112] },
					"quotelessString",
					[]
				],
				[
					"app",
					{ sourceInterval: [115, 126] },
					"nullLiteral",
					[]
				],
				[
					"app",
					{ sourceInterval: [129, 134] },
					"Array",
					[]
				]
			]
		],
		stringLiteral: [
			"define",
			{ sourceInterval: [140, 214] },
			null,
			[],
			[
				"seq",
				{ sourceInterval: [156, 214] },
				[
					"terminal",
					{ sourceInterval: [156, 160] },
					"\""
				],
				[
					"star",
					{ sourceInterval: [161, 209] },
					[
						"alt",
						{ sourceInterval: [162, 207] },
						[
							"seq",
							{ sourceInterval: [162, 191] },
							[
								"not",
								{ sourceInterval: [163, 186] },
								[
									"alt",
									{ sourceInterval: [165, 185] },
									[
										"terminal",
										{ sourceInterval: [165, 169] },
										"\""
									],
									[
										"app",
										{ sourceInterval: [172, 185] },
										"escapedSymbol",
										[]
									]
								]
							],
							[
								"app",
								{ sourceInterval: [187, 190] },
								"any",
								[]
							]
						],
						[
							"app",
							{ sourceInterval: [194, 207] },
							"escapedSymbol",
							[]
						]
					]
				],
				[
					"terminal",
					{ sourceInterval: [210, 214] },
					"\""
				]
			]
		],
		quotelessString: [
			"define",
			{ sourceInterval: [224, 277] },
			null,
			[],
			[
				"plus",
				{ sourceInterval: [242, 277] },
				[
					"seq",
					{ sourceInterval: [243, 275] },
					[
						"not",
						{ sourceInterval: [243, 271] },
						[
							"app",
							{ sourceInterval: [244, 271] },
							"forbiddenSymbolForQuoteless",
							[]
						]
					],
					[
						"app",
						{ sourceInterval: [272, 275] },
						"any",
						[]
					]
				]
			]
		],
		escapedSymbol: [
			"define",
			{ sourceInterval: [280, 304] },
			null,
			[],
			[
				"seq",
				{ sourceInterval: [296, 304] },
				[
					"terminal",
					{ sourceInterval: [296, 300] },
					"\\"
				],
				[
					"app",
					{ sourceInterval: [301, 304] },
					"any",
					[]
				]
			]
		],
		nullLiteral: [
			"define",
			{ sourceInterval: [311, 331] },
			null,
			[],
			[
				"terminal",
				{ sourceInterval: [325, 331] },
				"NULL"
			]
		],
		forbiddenSymbolForQuoteless: [
			"define",
			{ sourceInterval: [334, 401] },
			null,
			[],
			[
				"alt",
				{ sourceInterval: [364, 401] },
				[
					"terminal",
					{ sourceInterval: [364, 367] },
					"{"
				],
				[
					"terminal",
					{ sourceInterval: [370, 373] },
					"}"
				],
				[
					"terminal",
					{ sourceInterval: [376, 379] },
					","
				],
				[
					"terminal",
					{ sourceInterval: [382, 386] },
					"\""
				],
				[
					"app",
					{ sourceInterval: [390, 401] },
					"nullLiteral",
					[]
				]
			]
		]
	}
]);
//#endregion
//#region src/utils/parse-pgarray/index.ts
const literalArraySemantics = result.PGArrayLiteral.createSemantics();
literalArraySemantics.addOperation("parseArray", {
	Array(_lBracket, argList, _rBracket) {
		return argList["parseArray"]();
	},
	ArrayItem(arg0) {
		return arg0["parseArray"]();
	},
	NonemptyListOf(arg0, arg1, arg2) {
		return [
			arg0["parseArray"](),
			...arg1["parseArray"](),
			...arg2["parseArray"]()
		];
	},
	EmptyListOf() {
		return [];
	},
	_iter(...children) {
		return children.map((c) => c["parseArray"]()).filter((e) => e !== void 0);
	},
	_terminal() {},
	stringLiteral(_lQuote, string, _rQuote) {
		return JSON.parse("\"" + string.sourceString.replaceAll("''", "'") + "\"");
	},
	quotelessString(string) {
		return string.sourceString.replaceAll("''", "'");
	},
	nullLiteral(_) {
		return null;
	}
});
const expressionArraySemantics = result.PGArrayExpression.createSemantics();
expressionArraySemantics.addOperation("parseExpressionArray", {
	Array(_lBracket, argList, _rBracket) {
		return argList["parseExpressionArray"]();
	},
	ArrayItem(arg0) {
		return arg0["parseExpressionArray"]();
	},
	NonemptyListOf(arg0, arg1, arg2) {
		return [
			arg0["parseExpressionArray"](),
			...arg1["parseExpressionArray"](),
			...arg2["parseExpressionArray"]()
		];
	},
	EmptyListOf() {
		return [];
	},
	_iter(...children) {
		return children.map((c) => c["parseExpressionArray"]()).filter((e) => e !== void 0);
	},
	_terminal() {},
	stringLiteral(_lQuote, string, _rQuote) {
		return JSON.parse("\"" + string.sourceString.replaceAll("''", "'") + "\"");
	},
	quotelessString(string) {
		return string.sourceString.replaceAll("''", "'");
	},
	nullLiteral(_) {
		return null;
	}
});
function parseArray(array) {
	const match = result.PGArrayLiteral.match(array, "Array");
	if (match.failed()) throw new Error(`Failed to parse array: '${array}'`);
	return literalArraySemantics(match)["parseArray"]();
}
function parseExpressionArray(array) {
	const match = result.PGArrayExpression.match(array, "Array");
	if (match.failed()) throw new Error(`Failed to parse array: '${array}'`);
	return expressionArraySemantics(match)["parseExpressionArray"]();
}
//#endregion
//#region src/utils/when-json-met-bigint/lib.ts
const error = `error`;
const ignore = `ignore`;
const preserve = `preserve`;
const CONSTRUCTOR_ACTIONS = [
	error,
	ignore,
	preserve
];
const PROTO_ACTIONS = CONSTRUCTOR_ACTIONS;
const isNonNullObject = (o) => {
	return o !== null && typeof o === `object`;
};
var Cache = class {
	_cache = {};
	_size = 0;
	_old = {};
	constructor(_max = 1e6 / 2) {
		this._max = _max;
	}
	get(key) {
		return this.has(key) ? this._cache[key] : void 0;
	}
	set(key, value) {
		if (this._size >= this._max) {
			this._old = this._cache;
			this._cache = {};
			this._size = 0;
		}
		this._cache[key] = value;
		this._size++;
		return value;
	}
	has(key) {
		if (Object.prototype.hasOwnProperty.call(this._cache, key)) return true;
		if (Object.prototype.hasOwnProperty.call(this._old, key)) {
			this._cache[key] = this._old[key];
			return true;
		}
		return false;
	}
};
//#endregion
//#region src/utils/when-json-met-bigint/parse.ts
const bigint = `bigint`;
const number = `number`;
const SUSPECT_PROTO_RX = /(?:_|\\u005[Ff])(?:_|\\u005[Ff])(?:p|\\u0070)(?:r|\\u0072)(?:o|\\u006[Ff])(?:t|\\u0074)(?:o|\\u006[Ff])(?:_|\\u005[Ff])(?:_|\\u005[Ff])/;
const SUSPECT_CONSTRUCTOR_RX = /(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)/;
const ESCAPEE = {
	"\"": `"`,
	"\\": `\\`,
	"/": `/`,
	b: `\b`,
	f: `\f`,
	n: `\n`,
	r: `\r`,
	t: `\t`
};
const newParse = (p_user_options) => {
	let p_current_char_index, p_current_char, p_text;
	const p_options = {
		errorOnBigIntDecimalOrScientific: false,
		errorOnDuplicatedKeys: false,
		parseBigIntAsString: false,
		alwaysParseAsBigInt: false,
		protoAction: preserve,
		constructorAction: preserve
	};
	if (p_user_options) {
		if (p_user_options.strict === true || p_user_options.errorOnBigIntDecimalOrScientific === true) p_options.errorOnBigIntDecimalOrScientific = true;
		if (p_user_options.strict === true || p_user_options.errorOnDuplicatedKeys === true) p_options.errorOnDuplicatedKeys = true;
		if (p_user_options.parseBigIntAsString === true) p_options.parseBigIntAsString = true;
		if (p_user_options.alwaysParseAsBigInt === true) p_options.alwaysParseAsBigInt = true;
		if (p_user_options.protoAction) if (PROTO_ACTIONS.includes(p_user_options.protoAction)) p_options.protoAction = p_user_options.protoAction;
		else throw new Error(`Incorrect value for protoAction option, must be ${PROTO_ACTIONS.map((a) => `"${a}"`).join(` or `)} but passed ${p_user_options.protoAction}`);
		if (p_user_options.constructorAction) if (CONSTRUCTOR_ACTIONS.includes(p_user_options.constructorAction)) p_options.constructorAction = p_user_options.constructorAction;
		else throw new Error(`Incorrect value for constructorAction option, must be ${CONSTRUCTOR_ACTIONS.map((a) => `"${a}"`).join(` or `)} but passed ${p_user_options.constructorAction}`);
	}
	const pError = (m) => {
		throw {
			name: `SyntaxError`,
			message: m,
			at: p_current_char_index,
			text: p_text
		};
	};
	const pCurrentCharIs = (c) => {
		if (c !== p_current_char) return pError(`Expected '` + c + `' instead of '` + p_current_char + `'`);
	};
	const pNext = (c) => {
		p_current_char = p_text.charAt(++p_current_char_index);
		if (c) pCurrentCharIs(c);
		return p_current_char;
	};
	const pSkipWhite = () => {
		while (p_current_char && p_current_char <= ` `) pNext();
	};
	const pObject = (schema) => {
		const result = p_options.protoAction === preserve ? Object.create(null) : {};
		if (p_current_char === `{`) {
			pNext();
			pSkipWhite();
			if (p_current_char === `}`) {
				pNext();
				return result;
			}
			while (p_current_char) {
				const key = pString();
				const sub_schema = isNonNullObject(schema) && !Array.isArray(schema) ? schema[key] || schema[Symbol.for(`any`)] : void 0;
				pSkipWhite();
				pCurrentCharIs(`:`);
				pNext();
				if (p_options.errorOnDuplicatedKeys === true && Object.hasOwnProperty.call(result, key)) pError(`Duplicate key "${key}"`);
				if (SUSPECT_PROTO_RX.test(key) === true) if (p_options.protoAction === error) pError(`Object contains forbidden prototype property`);
				else if (p_options.protoAction === ignore) pJsonValue();
				else result[key] = pJsonValue(sub_schema);
				else if (SUSPECT_CONSTRUCTOR_RX.test(key) === true) if (p_options.constructorAction === error) pError(`Object contains forbidden constructor property`);
				else if (p_options.constructorAction === ignore) pJsonValue();
				else result[key] = pJsonValue(sub_schema);
				else result[key] = pJsonValue(sub_schema);
				pSkipWhite();
				if (p_current_char === `}`) {
					pNext();
					if (p_options.protoAction === preserve) Object.setPrototypeOf(result, Object.prototype);
					return result;
				}
				pCurrentCharIs(`,`);
				pNext();
				pSkipWhite();
			}
		}
		return pError(`Bad object`);
	};
	const pArray = (schema) => {
		const result = [];
		if (p_current_char === `[`) {
			pNext();
			pSkipWhite();
			if (p_current_char === `]`) {
				pNext();
				return result;
			}
			const is_array = Array.isArray(schema);
			const is_tuple_like = is_array && schema.length > 1;
			while (p_current_char) {
				result.push(pJsonValue(is_tuple_like ? schema[result.length] : is_array ? schema[0] : void 0));
				pSkipWhite();
				if (p_current_char === `]`) {
					pNext();
					return result;
				}
				pCurrentCharIs(`,`);
				pNext();
				pSkipWhite();
			}
		}
		return pError(`Bad array`);
	};
	const pString = () => {
		let result = ``;
		if (p_current_char === `"`) {
			let start_at = p_current_char_index + 1;
			while (pNext()) {
				if (p_current_char === `"`) {
					if (p_current_char_index > start_at) result += p_text.substring(start_at, p_current_char_index);
					pNext();
					return result;
				}
				if (p_current_char === `\\`) {
					if (p_current_char_index > start_at) result += p_text.substring(start_at, p_current_char_index);
					pNext();
					if (p_current_char === `u`) {
						let uffff = 0;
						for (let i = 0; i < 4; i += 1) {
							const hex = parseInt(pNext(), 16);
							if (!isFinite(hex)) break;
							uffff = uffff * 16 + hex;
						}
						result += String.fromCharCode(uffff);
					} else if (typeof ESCAPEE[p_current_char] === `string`) result += ESCAPEE[p_current_char];
					else break;
					start_at = p_current_char_index + 1;
				}
			}
		}
		return pError(`Bad string`);
	};
	const pNumber = (() => {
		const cache = new Cache();
		return (schema) => {
			let result_string = ``;
			let is_positive = true;
			if (p_current_char === `-`) {
				result_string = p_current_char;
				is_positive = false;
				pNext();
			}
			if (p_current_char === `0`) {
				result_string += p_current_char;
				pNext();
				if (p_current_char >= `0` && p_current_char <= `9`) pError(`Bad number`);
			}
			while (p_current_char >= `0` && p_current_char <= `9`) {
				result_string += p_current_char;
				pNext();
			}
			if (p_current_char === `.`) {
				result_string += p_current_char;
				while (pNext() && p_current_char >= `0` && p_current_char <= `9`) result_string += p_current_char;
			}
			if (p_current_char === `e` || p_current_char === `E`) {
				result_string += p_current_char;
				pNext();
				if (p_current_char === `-` || p_current_char === `+`) {
					result_string += p_current_char;
					pNext();
				}
				while (p_current_char >= `0` && p_current_char <= `9`) {
					result_string += p_current_char;
					pNext();
				}
			}
			const raw_schema = schema;
			const cache_string = cache.get(result_string);
			if (!cache_string || !cache_string.has(raw_schema)) {
				const cache_schema = cache_string || cache.set(result_string, /* @__PURE__ */ new Map());
				const result_number = Number(result_string);
				if (Number.isNaN(result_number)) cache_schema.set(raw_schema, NaN);
				else if (!Number.isFinite(result_number)) cache_schema.set(raw_schema, is_positive ? Infinity : -Infinity);
				else {
					const is_decimal_or_scientific = /[.eE]/.test(result_string);
					if (Number.isSafeInteger(result_number) || is_decimal_or_scientific) {
						if (typeof schema === `function`) schema = schema(result_number);
						cache_schema.set(raw_schema, schema === number || !p_options.alwaysParseAsBigInt && schema !== bigint || is_decimal_or_scientific && !p_options.errorOnBigIntDecimalOrScientific ? result_number : is_decimal_or_scientific ? pError(`Decimal and scientific notation cannot be bigint`) : BigInt(result_string));
					} else {
						let result_bigint;
						if (typeof schema === `function`) {
							result_bigint = BigInt(result_string);
							schema = schema(result_bigint);
						}
						if (schema === number) cache_schema.set(raw_schema, result_number);
						else cache_schema.set(raw_schema, p_options.parseBigIntAsString ? result_string : result_bigint || BigInt(result_string));
					}
				}
			}
			const result = cache.get(result_string).get(raw_schema);
			return Number.isNaN(result) ? pError(`Bad number`) : result;
		};
	})();
	const pBooleanOrNull = () => {
		switch (p_current_char) {
			case `t`:
				pNext(`r`);
				pNext(`u`);
				pNext(`e`);
				pNext();
				return true;
			case `f`:
				pNext(`a`);
				pNext(`l`);
				pNext(`s`);
				pNext(`e`);
				pNext();
				return false;
			case `n`:
				pNext(`u`);
				pNext(`l`);
				pNext(`l`);
				pNext();
				return null;
		}
		return pError(`Unexpected '${p_current_char}'`);
	};
	const pJsonValue = (schema) => {
		pSkipWhite();
		switch (p_current_char) {
			case `{`: return pObject(schema);
			case `[`: return pArray(schema);
			case `"`: return pString();
			case `-`: return pNumber(schema);
			default: return p_current_char >= `0` && p_current_char <= `9` ? pNumber(schema) : pBooleanOrNull();
		}
	};
	return (text, reviver, schema) => {
		p_current_char_index = -1;
		p_current_char = ` `;
		p_text = String(text);
		const result = pJsonValue(schema);
		pSkipWhite();
		if (p_current_char) pError(`Syntax error`);
		if (typeof reviver === `function`) return (function walk(object_or_array, key) {
			const value = object_or_array[key];
			if (isNonNullObject(value)) {
				const revived_keys = /* @__PURE__ */ new Set();
				for (const reviving_key in value) {
					const next_object_or_array = !Array.isArray(value) ? { ...value } : [...value];
					revived_keys.forEach((rk) => delete next_object_or_array[rk]);
					const v = walk(next_object_or_array, reviving_key);
					revived_keys.add(reviving_key);
					if (v !== void 0) value[reviving_key] = v;
					else delete value[reviving_key];
				}
			}
			return reviver.call(object_or_array, key, value);
		})({ "": result }, ``);
		return result;
	};
};
//#endregion
//#region src/utils/when-json-met-bigint/stringify.ts
const isNonNullObjectWithToJSOnImplemented = (o) => isNonNullObject(o) && typeof o.toJSON === `function`;
const toPrimitive = (o) => o instanceof Number ? Number(o) : o instanceof String ? String(o) : o;
const quote = (() => {
	const ESCAPABLE = /[\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
	const META = {
		"\b": `\\b`,
		"	": `\\t`,
		"\n": `\\n`,
		"\f": `\\f`,
		"\r": `\\r`,
		"\"": `\\"`,
		"\\": `\\\\`
	};
	const cache = new Cache();
	return (s) => {
		if (!cache.has(s)) {
			ESCAPABLE.lastIndex = 0;
			cache.set(s, ESCAPABLE.test(s) ? `"` + s.replace(ESCAPABLE, function(a) {
				const c = META[a];
				return typeof c === `string` ? c : `\\u` + (`0000` + a.charCodeAt(0).toString(16)).slice(-4);
			}) + `"` : `"` + s + `"`);
		}
		return cache.get(s);
	};
})();
const stringify = (() => {
	const stack = /* @__PURE__ */ new Set();
	let indent;
	let gap;
	let sReplacer;
	const s_replacer = /* @__PURE__ */ new Set();
	const sStringify = (object_or_array, key_or_index, delim, n) => {
		let value = object_or_array[key_or_index];
		if (isNonNullObjectWithToJSOnImplemented(value)) value = value.toJSON();
		if (typeof sReplacer === `function`) value = sReplacer.call(object_or_array, key_or_index.toString(), value);
		switch (typeof value) {
			case `string`: return quote(value);
			case `number`: return Number.isFinite(value) ? value.toString() : `null`;
			case `boolean`: return value.toString();
			case `bigint`: return n ? `${value.toString()}n` : value.toString();
			case `object`: {
				if (!value) return `null`;
				if (stack.has(value)) throw new TypeError(`cyclic object value`);
				stack.add(value);
				const last_gap = indent;
				indent += gap;
				if (Array.isArray(value)) {
					const partial = value.map((_v_, i) => sStringify(value, i, delim, n) || `null`);
					const result = partial.length === 0 ? `[]` : indent ? `[\n` + indent + partial.join(`${delim}\n` + indent) + `\n` + last_gap + `]` : `[` + partial.join(delim) + `]`;
					stack.delete(value);
					indent = last_gap;
					return result;
				}
				const partial = [];
				(s_replacer.size > 0 ? s_replacer : Object.keys(value)).forEach((key) => {
					const v = sStringify(value, key, delim, n);
					if (v) partial.push(quote(key) + (gap ? `: ` : `:`) + v);
				});
				const result = partial.length === 0 ? `{}` : indent ? `{\n` + indent + partial.join(`${delim}\n` + indent) + `\n` + last_gap + `}` : `{` + partial.join(delim) + `}`;
				stack.delete(value);
				indent = last_gap;
				return result;
			}
		}
	};
	return (value, replacer, space, n) => {
		value = toPrimitive(value);
		stack.clear();
		indent = ``;
		const primitive_space = toPrimitive(space);
		gap = typeof primitive_space === `number` && primitive_space > 0 ? Array.from({ length: primitive_space + 1 }).join(` `) : typeof primitive_space !== `string` ? `` : primitive_space.length > 10 ? primitive_space.slice(0, 10) : primitive_space;
		s_replacer.clear();
		if (Array.isArray(replacer)) {
			sReplacer = null;
			if (isNonNullObject(value)) replacer.forEach((e) => {
				const key = toPrimitive(e);
				if (typeof key === `string` || typeof key === `number`) {
					const key_string = key.toString();
					if (!s_replacer.has(key_string)) s_replacer.add(key_string);
				}
			});
		} else sReplacer = replacer;
		return sStringify({ "": value }, ``, ",", n);
	};
})();
//#endregion
//#region src/utils/when-json-met-bigint/index.ts
const parse = newParse();
Object.assign((options) => {
	return {
		parse: newParse(options),
		stringify
	};
}, {
	parse,
	stringify
});
//#endregion
//#region src/dialects/common.ts
const dictionary = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
const hash = (input, len = 12) => {
	const dictLen = BigInt(dictionary.length);
	const combinationsCount = BigInt(dictionary.length) ** BigInt(len);
	const p = 53n;
	let power = 1n;
	let hash = 0n;
	for (const ch of input) {
		hash = (hash + BigInt(ch.codePointAt(0) || 0) * power) % combinationsCount;
		power = power * p % combinationsCount;
	}
	const result = [];
	let index = hash;
	for (let i = len - 1; i >= 0; i--) {
		const element = dictionary[Number(index % dictLen)];
		result.unshift(element);
		index = index / dictLen;
	}
	return result.join("");
};
//#endregion
//#region src/dialects/utils.ts
const getOrNull = (it, key) => {
	if (it === null) return null;
	return it?.[key] ?? null;
};
const groupDiffs = (arr) => {
	if (arr.length === 0) return [];
	if (!arr[0].table && !arr[0].schema) throw new Error("No schema or table in item");
	const res = [];
	for (let i = 0; i < arr.length; i++) {
		const stmnt = arr[i];
		const idx = res.findIndex((it) => ("schema" in it ? stmnt.schema === it["schema"] : true) && ("table" in it ? stmnt.table === it.table : true));
		let item;
		if (idx < 0) {
			const sch = "schema" in stmnt ? { schema: stmnt.schema } : {};
			const tbl = "table" in stmnt ? { table: stmnt.table } : {};
			item = {
				...sch,
				...tbl,
				deleted: [],
				inserted: [],
				updated: []
			};
			res.push(item);
		} else item = res[idx];
		if (stmnt.$diffType === "drop") item.deleted.push(stmnt);
		else if (stmnt.$diffType === "create") item.inserted.push(stmnt);
		else item.updated.push(stmnt);
	}
	return res;
};
const numberForTs = (value) => {
	const check = Number(value);
	if (Number.isNaN(check)) return {
		mode: "number",
		value: `sql\`${trimChar(escapeForTsLiteral(value), "\"")}\``
	};
	if (check >= Number.MIN_SAFE_INTEGER && check <= Number.MAX_SAFE_INTEGER) return {
		mode: "number",
		value
	};
	return {
		mode: "bigint",
		value: `${value}n`
	};
};
const parseParams = (type) => {
	return type.match(/\(((?:\d+(?:\s*,\s*\d+)*)|max)\)/i)?.[1].split(",").map((x) => x.trim()) ?? [];
};
const escapeForSqlDefault = (input, mode = "default") => {
	let value = input.replace(/\\/g, "\\\\").replace(/'/g, "''");
	if (mode === "pg-arr") value = value.replaceAll("\"", "\\\"");
	return value;
};
const unescapeFromSqlDefault = (input, mode = "default") => {
	let res = input.replace(/\\"/g, "\"").replace(/\\\\/g, "\\");
	if (mode === "arr") return res;
	return res.replace(/''/g, "'");
};
const escapeForTsLiteral = (input) => {
	return JSON.stringify(input);
};
const preserveEntityNames = (collection1, collection2, mode) => {
	const items = collection1.list().filter((x) => mode === "push" || !x.nameExplicit);
	for (const left of items) {
		const { entityType: _1, name: _2, nameExplicit: _3, ...filter } = left;
		const match = collection2.list({
			...filter,
			nameExplicit: false
		});
		if (match.length !== 1 || match[0].name === left.name) continue;
		collection2.update({
			set: { name: left.name },
			where: {
				...filter,
				nameExplicit: false
			}
		});
	}
};
//#endregion
//#region src/dialects/postgres/grammar.ts
const SmallInt = {
	is: (type) => /^\s*smallint(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "smallint",
	defaultFromDrizzle: (value) => {
		return String(value);
	},
	defaultArrayFromDrizzle: (value) => {
		return `'${stringifyArray(value, "sql", (v) => String(v))}'`;
	},
	defaultFromIntrospect: (value) => {
		return trimChar(value, "'");
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (_, value) => {
		if (!value) return { default: "" };
		const check = Number(value);
		return { default: Number.isNaN(check) ? `sql\`${value}\`` : value };
	},
	toArrayTs: (_, value) => {
		if (!value) return { default: "" };
		try {
			return { default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				return `${v}`;
			}) };
		} catch {
			return { default: `sql\`${value}\`` };
		}
	}
};
const Int = {
	is: (type) => /^\s*integer(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "integer",
	defaultFromDrizzle: SmallInt.defaultFromDrizzle,
	defaultArrayFromDrizzle: SmallInt.defaultArrayFromDrizzle,
	defaultFromIntrospect: SmallInt.defaultFromIntrospect,
	defaultArrayFromIntrospect: SmallInt.defaultArrayFromIntrospect,
	toTs: SmallInt.toTs,
	toArrayTs: SmallInt.toArrayTs
};
const BigInt$1 = {
	is: (type) => /^\s*bigint(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "bigint",
	defaultFromDrizzle: (value) => {
		return String(value);
	},
	defaultArrayFromDrizzle: (value) => {
		return `'${stringifyArray(value, "sql", (v) => String(v))}'`;
	},
	defaultFromIntrospect: (value) => {
		return trimChar(value, "'");
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (_, value) => {
		if (!value) return {
			options: { mode: "number" },
			default: ""
		};
		const { mode, value: def } = numberForTs(value);
		return {
			options: { mode },
			default: def
		};
	},
	toArrayTs: (_, value) => {
		if (!value) return {
			options: { mode: "number" },
			default: ""
		};
		try {
			return {
				options: { mode: "bigint" },
				default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => `${v}n`)
			};
		} catch {
			return {
				options: { mode: "bigint" },
				default: `sql\`${value}\``
			};
		}
	}
};
const Numeric = {
	is: (type) => /^\s*numeric|decimal(?:\(\d+(?:,\d+)?\))?(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "numeric",
	defaultFromDrizzle: (value) => {
		return `'${value}'`;
	},
	defaultArrayFromDrizzle: (value) => {
		return `'${stringifyArray(value, "sql", (v) => String(v))}'`;
	},
	defaultFromIntrospect: (value) => {
		return `'${trimChar(value, "'")}'`;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const [precision, scale] = parseParams(type);
		const options = {};
		if (precision) options["precision"] = Number(precision);
		if (scale) options["scale"] = Number(scale);
		if (!value) return {
			options,
			default: ""
		};
		const { mode, value: def } = numberForTs(trimChar(value, "'"));
		return {
			options: {
				mode,
				...options
			},
			default: def
		};
	},
	toArrayTs: (type, value) => {
		const [precision, scale] = parseParams(type);
		const options = {};
		if (precision) options["precision"] = Number(precision);
		if (scale) options["scale"] = Number(scale);
		if (!value) return {
			options,
			default: ""
		};
		return {
			options,
			default: `sql\`${value}\``
		};
	}
};
const Real = {
	is: (type) => /^\s*real(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "real",
	defaultFromDrizzle: (value) => {
		return String(value);
	},
	defaultArrayFromDrizzle: (value) => {
		return `'${stringifyArray(value, "sql", (v) => String(v))}'`;
	},
	defaultFromIntrospect: (value) => {
		return trimChar(value, "'");
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (_, value) => ({ default: value ?? "" }),
	toArrayTs: (_, value) => {
		if (!value) return { default: "" };
		try {
			return { default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				return `${v}`;
			}) };
		} catch {
			return { default: `sql\`${value}\`` };
		}
	}
};
const Double = {
	is: (type) => /^\s*(?:double|double precision)(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "doublePrecision",
	defaultFromDrizzle: Real.defaultFromDrizzle,
	defaultArrayFromDrizzle: Real.defaultArrayFromDrizzle,
	defaultFromIntrospect: Real.defaultFromIntrospect,
	defaultArrayFromIntrospect: Real.defaultArrayFromIntrospect,
	toTs: Real.toTs,
	toArrayTs: Real.toArrayTs
};
const Boolean$1 = {
	is: (type) => /^\s*boolean(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "boolean",
	defaultFromDrizzle: (value) => {
		return String(value);
	},
	defaultArrayFromDrizzle: (value) => {
		return `'${stringifyArray(value, "sql", (v) => v === true ? "t" : "f")}'`;
	},
	defaultFromIntrospect: (value) => {
		return trimChar(value, "'");
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (_, value) => ({ default: value ?? "" }),
	toArrayTs: (_, value) => {
		if (!value) return { default: "" };
		try {
			return { default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				return v === "t" ? "true" : "false";
			}) };
		} catch {
			return { default: `sql\`${value}\`` };
		}
	}
};
const Char = {
	is: (type) => /^\s*char|character(?:\(\d+\))?(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "char",
	defaultFromDrizzle: (value) => {
		return `'${escapeForSqlDefault(value)}'`;
	},
	defaultArrayFromDrizzle: (value) => {
		return `'${stringifyArray(value, "sql", (v) => {
			if (typeof v !== "string") throw new Error();
			const escaped = v.replaceAll("'", "''").replaceAll("\\", "\\\\").replaceAll("\"", "\\\"");
			if (v.includes("\\") || v.includes("\"") || v.includes(",") || v.length === 0) return `"${escaped}"`;
			return escaped;
		})}'`;
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const options = {};
		const [length] = parseParams(type);
		if (length) options["length"] = Number(length);
		if (!value) return {
			options,
			default: ""
		};
		if (!value.startsWith("'") && !value.endsWith("'")) return {
			options,
			default: `sql\`${value}\``
		};
		return {
			options,
			default: escapeForTsLiteral(unescapeFromSqlDefault(trimChar(value, "'")))
		};
	},
	toArrayTs: (type, value) => {
		const options = {};
		const [length] = parseParams(type);
		if (length) options["length"] = Number(length);
		if (!value) return {
			options,
			default: ""
		};
		try {
			return {
				options,
				default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
					return escapeForTsLiteral(unescapeFromSqlDefault(trimChar(v, "'"), "arr"));
				})
			};
		} catch {
			return {
				options,
				default: `sql\`${value}\``
			};
		}
	}
};
const Varchar = {
	is: (type) => /^\s*varchar|character varying(?:\(\d+\))?(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "varchar",
	defaultFromDrizzle: Char.defaultFromDrizzle,
	defaultArrayFromDrizzle: Char.defaultArrayFromDrizzle,
	defaultFromIntrospect: Char.defaultFromIntrospect,
	defaultArrayFromIntrospect: Char.defaultArrayFromIntrospect,
	toTs: Char.toTs,
	toArrayTs: Char.toArrayTs
};
const Text = {
	is: (type) => /^\s*text(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "text",
	defaultFromDrizzle: Char.defaultFromDrizzle,
	defaultArrayFromDrizzle: Char.defaultArrayFromDrizzle,
	defaultFromIntrospect: Char.defaultFromIntrospect,
	defaultArrayFromIntrospect: Char.defaultArrayFromIntrospect,
	toTs: Char.toTs,
	toArrayTs: Char.toArrayTs
};
const toDefaultArray = (value, dimensions, cb, depth = 0) => {
	if (depth === dimensions) {
		const res = cb(value);
		if (res.includes("\"")) return `"${res.replaceAll("\"", "\\\"")}"`;
		return `"${res}"`;
	}
	if (Array.isArray(value)) {
		const inner = value.map((v) => {
			return toDefaultArray(v, dimensions, cb, depth + 1);
		}).join(",");
		if (depth === 0) return `{${inner}}`;
		return `${inner}`;
	}
	return cb(value);
};
const Json = {
	is: (type) => /^\s*json(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "json",
	defaultFromDrizzle: (value) => {
		return `'${stringify(value, (_, value) => {
			if (typeof value !== "string") return value;
			return value.replaceAll("'", "''");
		})}'`;
	},
	defaultArrayFromDrizzle: (def, dimensions) => {
		return `'${toDefaultArray(def, dimensions, (it) => stringify(it, (_, value) => {
			if (typeof value !== "string") return value;
			return value.replaceAll("'", "''");
		}))}'`;
	},
	defaultFromIntrospect: (value) => value,
	defaultArrayFromIntrospect: (value) => value,
	toTs: (_, value) => {
		if (!value) return { default: "" };
		const trimmed = trimChar(value, "'");
		try {
			return { default: stringify(parse(trimmed), (_, value) => {
				if (typeof value !== "string") return value;
				return value.replaceAll("''", "'");
			}, void 0, true) };
		} catch {}
		return { default: `sql\`${value}\`` };
	},
	toArrayTs: (_, def) => {
		if (!def) return { default: "" };
		return { default: `sql\`${def.replaceAll("\\\"", "\\\\\"")}\`` };
	}
};
const Jsonb = {
	is: (type) => /^\s*jsonb(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "jsonb",
	defaultFromDrizzle: (value) => {
		return `'${stringify(value, (_, value) => {
			if (typeof value !== "string") return value;
			return value.replaceAll("'", "''");
		})}'`;
	},
	defaultArrayFromDrizzle: (def, dimensions) => {
		return `'${toDefaultArray(def, dimensions, (it) => stringify(it, (_, value) => {
			if (typeof value !== "string") return value;
			return value.replaceAll("'", "''");
		}))}'`;
	},
	defaultFromIntrospect: (value) => value.replaceAll(`": "`, `":"`),
	defaultArrayFromIntrospect: (value) => value,
	toTs: Json.toTs,
	toArrayTs: Json.toArrayTs
};
const Time = {
	is: (type) => /^\s*time(?:\(\d+\))?(?:\[\])*?\s*$/i.test(type),
	drizzleImport: () => "time",
	defaultFromDrizzle: (value) => {
		return wrapWith(String(value), "'");
	},
	defaultArrayFromDrizzle: (value) => {
		return wrapWith(stringifyArray(value, "sql", (v) => String(v)), "'");
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const options = {};
		const [precision] = parseParams(type);
		if (precision) options["precision"] = Number(precision);
		if (!value) return {
			options,
			default: ""
		};
		if (!isTime(trimChar(value, "'"))) return {
			options,
			default: `sql\`${value}\``
		};
		return {
			options,
			default: value
		};
	},
	toArrayTs: (type, value) => {
		const options = {};
		const [precision] = parseParams(type);
		if (precision) options["precision"] = Number(precision);
		if (!value) return {
			options,
			default: ""
		};
		try {
			return {
				options,
				default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
					const trimmed = trimChar(v, "'");
					if (!isTime(trimmed)) return `sql\`${trimmed}\``;
					return wrapWith(v, "'");
				})
			};
		} catch {
			return {
				options,
				default: `sql\`${value}\``
			};
		}
	}
};
const TimeTz = {
	is: (type) => /^\s*time(?:\(\d+\))?\s+with time zone(?:\[\])*?\s*$/i.test(type),
	drizzleImport: () => "time",
	defaultFromDrizzle: (value) => {
		const v = String(value);
		return wrapWith(hasTimeZoneSuffix(v) ? v : v + "+00", "'");
	},
	defaultArrayFromDrizzle: (value) => {
		return wrapWith(stringifyArray(value, "sql", (v) => {
			return hasTimeZoneSuffix(v) ? v : v + "+00";
		}), "'");
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const options = {};
		const [precision] = parseParams(type);
		if (precision) options["precision"] = Number(precision);
		options["withTimezone"] = true;
		if (!value) return {
			options,
			default: ""
		};
		if (!isTime(trimChar(value, "'"))) return {
			options,
			default: `sql\`${value}\``
		};
		return {
			options,
			default: value
		};
	},
	toArrayTs: (type, value) => {
		const options = {};
		const [precision] = parseParams(type);
		if (precision) options["precision"] = Number(precision);
		options["withTimezone"] = true;
		if (!value) return {
			options,
			default: ""
		};
		try {
			const res = parseArray(trimChar(trimChar(value, ["(", ")"]), "'"));
			let isDrizzleSql = false;
			const def = stringifyArray(res, "ts", (v) => {
				if (!isTime(trimChar(v, "'"))) isDrizzleSql = true;
				return wrapWith(v, "'");
			});
			return {
				options,
				default: isDrizzleSql ? `sql\`${value}\`` : def
			};
		} catch {
			return {
				options,
				default: `sql\`${value}\``
			};
		}
	}
};
const DateType = {
	is: (type) => /^\s*date(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "date",
	defaultFromDrizzle: (value) => {
		if (typeof value === "string") return wrapWith(value, "'");
		if (!(value instanceof Date)) throw new Error("\"date\" default value must be instance of Date or String");
		const mapped = value.toISOString().split("T")[0];
		return wrapWith(mapped, "'");
	},
	defaultArrayFromDrizzle: (value) => {
		return wrapWith(stringifyArray(value, "sql", (v) => {
			if (typeof v === "string") return v;
			if (v instanceof Date) return v.toISOString().split("T")[0];
			throw new Error("Unexpected default value for \"date\", must be String or Date");
		}), "'");
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		if (!value) return { default: "" };
		if (!isDate(trimChar(value, "'"))) return { default: `sql\`${value}\`` };
		return { default: value };
	},
	toArrayTs: (type, value) => {
		if (!value) return { default: "" };
		let isDrizzleSql = false;
		try {
			const mapped = stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				if (!isDate(trimChar(v, "'"))) isDrizzleSql = true;
				return wrapWith(v, "'");
			});
			return { default: isDrizzleSql ? mapped : `sql\`${value}\`` };
		} catch {
			return { default: `sql\`${value}\`` };
		}
	}
};
const Timestamp = {
	is: (type) => /^\s*timestamp(?:\s)?(?:\(\d+\))?(?:\[\])*?\s*$/i.test(type),
	drizzleImport: () => "timestamp",
	defaultFromDrizzle: (value, _type) => {
		if (typeof value === "string") return wrapWith(value, "'");
		if (!(value instanceof Date)) throw new Error("Timestamp default value must be instance of Date or String");
		return wrapWith(value.toISOString().replace("T", " ").replace("Z", " ").slice(0, 23), "'");
	},
	defaultArrayFromDrizzle: (value, _type) => {
		return wrapWith(stringifyArray(value, "sql", (v) => {
			if (typeof v === "string") return wrapWith(v, "\"");
			if (v instanceof Date) return wrapWith(v.toISOString().replace("T", " ").replace("Z", " ").slice(0, 23), "\"");
			throw new Error("Unexpected default value for Timestamp, must be String or Date");
		}), "'");
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const options = {};
		const [precision] = parseParams(type);
		if (precision) options["precision"] = Number(precision);
		if (!value) return {
			options,
			default: ""
		};
		let patched = trimChar(value, "'");
		patched = patched.includes("T") ? patched : patched.replace(" ", "T") + "Z";
		const test = new Date(patched);
		if (isNaN(test.getTime())) return {
			options,
			default: `sql\`${value}\``
		};
		return {
			options,
			default: `new Date('${patched}')`
		};
	},
	toArrayTs: (type, value) => {
		const options = {};
		const [precision] = parseParams(type);
		if (precision) options["precision"] = Number(precision);
		if (!value) return {
			options,
			default: ""
		};
		let isDrizzleSql = false;
		try {
			const def = stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				const patched = v.includes("T") ? v : v.replace(" ", "T") + "Z";
				const check = new Date(patched);
				if (isNaN(check.getTime())) isDrizzleSql = true;
				return `new Date("${patched}")`;
			});
			return {
				options,
				default: isDrizzleSql ? `sql\`${value}\`` : def
			};
		} catch {
			return {
				options,
				default: `sql\`${value}\``
			};
		}
	}
};
const TimestampTz = {
	is: (type) => /^\s*timestamp(?:\s)?(?:\(\d+\))?\s+with time zone(?:\[\])*?\s*$/i.test(type),
	drizzleImport: () => "timestamp",
	defaultFromDrizzle: (value, _type) => {
		if (typeof value === "string") return wrapWith(hasTimeZoneSuffix(value) ? value : value + "+00", "'");
		if (!(value instanceof Date)) throw new Error("Timestamp default value must be instance of Date or String");
		return wrapWith(value.toISOString().replace("T", " ").replace("Z", "+00"), "'");
	},
	defaultArrayFromDrizzle: (value, _type) => {
		return wrapWith(stringifyArray(value, "sql", (v) => {
			if (typeof v === "string") return wrapWith(hasTimeZoneSuffix(v) ? v : v + "+00", "\"");
			if (v instanceof Date) return wrapWith(v.toISOString().replace("T", " ").replace("Z", "+00"), "\"");
			throw new Error("Unexpected default value for Timestamp, must be String or Date");
		}), "'");
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const options = {};
		const [precision] = parseParams(type);
		if (precision) options["precision"] = Number(precision);
		options["withTimezone"] = true;
		if (!value) return {
			options,
			default: ""
		};
		let patched = trimChar(value, "'");
		const test = new Date(patched);
		if (isNaN(test.getTime())) return {
			options,
			default: `sql\`${value}\``
		};
		return {
			options,
			default: `new Date('${patched}')`
		};
	},
	toArrayTs: (type, value) => {
		const options = {};
		const [precision] = parseParams(type);
		if (precision) options["precision"] = Number(precision);
		options["withTimezone"] = true;
		if (!value) return {
			options,
			default: ""
		};
		try {
			const res = parseArray(trimChar(trimChar(value, ["(", ")"]), "'"));
			let isDrizzleSql = false;
			const def = stringifyArray(res, "ts", (v) => {
				const trimmed = trimChar(v, "'");
				const check = new Date(trimmed);
				if (isNaN(check.getTime())) isDrizzleSql = true;
				return `new Date("${trimmed}")`;
			});
			return {
				options,
				default: isDrizzleSql ? `sql\`${value}\`` : def
			};
		} catch {
			return {
				options,
				default: `sql\`${value}\``
			};
		}
	}
};
const Uuid = {
	is: (type) => /^\s*uuid(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "uuid",
	defaultFromDrizzle: (value) => {
		return `'${value}'`;
	},
	defaultArrayFromDrizzle: (value) => {
		return `'${stringifyArray(value, "sql", (v) => {
			if (typeof v !== "string") throw new Error();
			return v;
		})}'`;
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const options = {};
		if (!value) return {
			options,
			default: ""
		};
		value = trimChar(value, "'");
		if (value === "gen_random_uuid()") return {
			options,
			default: ".defaultRandom()"
		};
		if (!value.startsWith("'") && !value.endsWith("'") && value.endsWith("()")) return {
			options,
			default: `sql\`${value}\``
		};
		return {
			options,
			default: `"${trimChar(value, "'")}"`
		};
	},
	toArrayTs: (type, value) => {
		const options = {};
		if (!value) return {
			options,
			default: ""
		};
		try {
			return {
				options,
				default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
					return `"${v}"`;
				})
			};
		} catch {
			return {
				options,
				default: `sql\`${value}\``
			};
		}
	}
};
const Interval = {
	is: (type) => /^interval(\s+(year|month|day|hour|minute|second)(\s+to\s+(month|day|hour|minute|second))?)?(?:\((\d+)\))?(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "interval",
	defaultFromDrizzle: (value) => {
		return `'${value}'`;
	},
	defaultArrayFromDrizzle: (value) => {
		return `'${stringifyArray(value, "sql", (v) => {
			if (typeof v !== "string") throw new Error();
			return `"${v}"`;
		})}'`;
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const options = {};
		const [precision] = parseParams(type);
		if (precision) options["precision"] = Number(precision);
		const fields = parseIntervalFields(type);
		if (fields.fields) options["fields"] = fields.fields;
		if (!value) return {
			options,
			default: ""
		};
		return {
			options,
			default: `"${trimChar(value, "'")}"`
		};
	},
	toArrayTs: (type, value) => {
		const options = {};
		const [precision] = parseParams(type);
		if (precision) options["precision"] = Number(precision);
		const fields = parseIntervalFields(type);
		if (fields.fields) options["fields"] = fields.fields;
		if (!value) return {
			options,
			default: ""
		};
		try {
			return {
				options,
				default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
					return `"${v}"`;
				})
			};
		} catch {
			return {
				options,
				default: `sql\`${value}\``
			};
		}
	}
};
const Inet = {
	is: (type) => /^inet(?:\((\d+)\))?(\[\])?$/i.test(type),
	drizzleImport: () => "inet",
	defaultFromDrizzle: (value) => {
		return `'${value}'`;
	},
	defaultArrayFromDrizzle: (value) => {
		return wrapWith(stringifyArray(value, "sql", (v) => {
			if (typeof v !== "string") throw new Error();
			return v;
		}), "'");
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (_, value) => {
		if (!value) return { default: "" };
		return { default: `"${trimChar(value, "'")}"` };
	},
	toArrayTs: (_, value) => {
		if (!value) return { default: "" };
		try {
			return { default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				return `"${v}"`;
			}) };
		} catch {
			return { default: `sql\`${value}\`` };
		}
	}
};
const Cidr = {
	is: (type) => /^cidr(?:\((\d+)\))?(\[\])?$/i.test(type),
	drizzleImport: () => "cidr",
	defaultFromDrizzle: (value) => {
		return `'${value}'`;
	},
	defaultArrayFromDrizzle: (value) => {
		return wrapWith(stringifyArray(value, "sql", (v) => {
			if (typeof v !== "string") throw new Error();
			return v;
		}), "'");
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (_, value) => {
		if (!value) return { default: "" };
		return { default: `"${trimChar(value, "'")}"` };
	},
	toArrayTs: (_, value) => {
		if (!value) return { default: "" };
		try {
			return { default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				return `"${v}"`;
			}) };
		} catch {
			return { default: `sql\`${value}\`` };
		}
	}
};
const MacAddr = {
	is: (type) => /^macaddr(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "macaddr",
	defaultFromDrizzle: (value) => {
		return `'${value}'`;
	},
	defaultArrayFromDrizzle: (value) => {
		return wrapWith(stringifyArray(value, "sql", (v) => {
			if (typeof v !== "string") throw new Error();
			return v;
		}), "'");
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (_, value) => {
		if (!value) return { default: "" };
		return { default: `"${trimChar(value, "'")}"` };
	},
	toArrayTs: (_, value) => {
		if (!value) return { default: "" };
		try {
			return { default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				return `"${v}"`;
			}) };
		} catch {
			return { default: `sql\`${value}\`` };
		}
	}
};
const MacAddr8 = {
	is: (type) => /^macaddr8(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "macaddr8",
	defaultFromDrizzle: MacAddr.defaultFromDrizzle,
	defaultArrayFromDrizzle: MacAddr.defaultArrayFromDrizzle,
	defaultFromIntrospect: MacAddr.defaultFromIntrospect,
	defaultArrayFromIntrospect: MacAddr.defaultArrayFromIntrospect,
	toTs: MacAddr.toTs,
	toArrayTs: MacAddr.toArrayTs
};
const Vector = {
	is: (type) => /^\s*vector(?:\(\d+\))?(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "vector",
	defaultFromDrizzle: (value) => {
		return `'[${String(value).replaceAll(" ", "")}]'`;
	},
	defaultArrayFromDrizzle: (value, _dimensions) => {
		return wrapWith(stringifyTuplesArray(value, "sql", (v) => {
			return v.length > 0 ? `"[${String(v).replaceAll(" ", "")}]"` : "\"[]\"";
		}).replaceAll(" ", ""), "'");
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const options = {};
		const [dimensions] = parseParams(type);
		if (dimensions) options["dimensions"] = Number(dimensions);
		if (!value) return {
			options,
			default: ""
		};
		return {
			options,
			default: trimChar(value, "'")
		};
	},
	toArrayTs: (type, value) => {
		const options = {};
		const [dimensions] = parseParams(type);
		if (dimensions) options["dimensions"] = Number(dimensions);
		if (!value) return {
			options,
			default: ""
		};
		try {
			return {
				options,
				default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
					return v;
				}, Number(dimensions))
			};
		} catch {
			return {
				options,
				default: `sql\`${value}\``
			};
		}
	}
};
const HalfVec = {
	is: (type) => /^\s*halfvec(?:\(\d+(?:,\d+)?\))?(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "halfvec",
	defaultFromDrizzle: Vector.defaultFromDrizzle,
	defaultArrayFromDrizzle: Vector.defaultArrayFromDrizzle,
	defaultFromIntrospect: Vector.defaultFromIntrospect,
	defaultArrayFromIntrospect: Vector.defaultArrayFromIntrospect,
	toTs: Vector.toTs,
	toArrayTs: Vector.toArrayTs
};
const SparseVec = {
	is: (type) => /^\s*sparsevec(?:\(\d+(?:,\d+)?\))?(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "sparsevec",
	defaultFromDrizzle: (value) => {
		return wrapWith(String(value), "'");
	},
	defaultArrayFromDrizzle: (value) => {
		return wrapWith(stringifyArray(value, "sql", (v) => {
			return `"${String(v).replaceAll(" ", "")}"`;
		}), "'");
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const options = {};
		const [dimensions] = parseParams(type);
		if (dimensions) options["dimensions"] = Number(dimensions);
		if (!value) return {
			options,
			default: ""
		};
		return {
			options,
			default: value
		};
	},
	toArrayTs: (type, value) => {
		const options = {};
		const [dimensions] = parseParams(type);
		if (dimensions) options["dimensions"] = Number(dimensions);
		if (!value) return {
			options,
			default: ""
		};
		try {
			return {
				options,
				default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
					return wrapWith(v, "'");
				})
			};
		} catch {
			return {
				options,
				default: `sql\`${value}\``
			};
		}
	}
};
const Bit = {
	is: (type) => /^\s*bit(?:\(\d+(?:,\d+)?\))?(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "bit",
	defaultFromDrizzle: (value, _) => {
		return `'${value}'`;
	},
	defaultArrayFromDrizzle: (value, _type) => {
		return `'${stringifyArray(value, "sql", (v) => String(v))}'`;
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const [dimensions] = parseParams(type);
		const options = dimensions ? { dimensions: Number(dimensions) } : {};
		if (!value) return {
			options,
			default: ""
		};
		if (/^'[01]+'$/.test(value)) return {
			options,
			default: value
		};
		return {
			options,
			default: `sql\`${value}\``
		};
	},
	toArrayTs: (type, value) => {
		const [dimensions] = parseParams(type);
		const options = dimensions ? { dimensions: Number(dimensions) } : {};
		if (!value) return { default: "" };
		let isDrizzleSql = false;
		try {
			const def = stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				if (!/^[01]+$/.test(v)) isDrizzleSql = true;
				return `"${v}"`;
			});
			return {
				options,
				default: isDrizzleSql ? `sql\`${value}\`` : def
			};
		} catch {
			return {
				options,
				default: `sql\`${value}\``
			};
		}
	}
};
const Point = {
	is: (type) => /^\s*point(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "point",
	defaultFromDrizzle: (value, mode) => {
		if (!value) return "";
		if (mode === "xy") {
			const v = value;
			return Object.values(v).length > 0 ? `'(${v.x},${v.y})'` : "";
		}
		if (mode === "tuple") {
			const v = value;
			return v.length > 0 ? `'(${v[0]},${v[1]})'` : "";
		}
		throw new Error("unknown point type");
	},
	defaultArrayFromDrizzle: function(value, dimensions, mode) {
		let res;
		if (mode === "tuple") res = stringifyTuplesArray(value, "sql", (x) => {
			return `"${x.length > 0 ? `(${x[0]},${x[1]})` : "{}"}"`;
		});
		else if (mode === "xy") res = stringifyArray(value, "sql", (x, _depth) => {
			return `"${Object.values(x).length > 0 ? `(${x.x},${x.y})` : "{}"}"`;
		});
		else throw new Error("unknown point type");
		return wrapWith(res, "'");
	},
	defaultFromIntrospect: function(value) {
		return value;
	},
	defaultArrayFromIntrospect: function(value) {
		return value;
	},
	toTs: function(type, value) {
		if (!value) return { default: "" };
		if (/^'\(\d+,\d+\)'$/.test(value)) return {
			default: trimChar(value, "'").replace("(", "[").replace(")", "]"),
			options: {}
		};
		return {
			default: `sql\`${value}\``,
			options: {}
		};
	},
	toArrayTs: function(type, value) {
		if (!value) return { default: "" };
		let isDrizzleSql = false;
		try {
			const def = stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				if (!/^\(\d+,\d+\)$/.test(v)) isDrizzleSql = true;
				return v.replace("(", "[").replace(")", "]");
			});
			return { default: isDrizzleSql ? `sql\`${value}\`` : def };
		} catch {
			return { default: `sql\`${value}\`` };
		}
	}
};
const Line = {
	is: (type) => /^\s*line(?:\s*\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "line",
	defaultFromDrizzle: (value, mode) => {
		if (!value) return "";
		if (mode === "tuple") {
			const v = value;
			return v.length > 0 ? `'{${v[0]},${v[1]},${v[2]}}'` : "";
		}
		if (mode === "abc") {
			const v = value;
			return Object.values(v).length > 0 ? `'{${v.a},${v.b},${v.c}}'` : "";
		}
		throw new Error("unknown line type");
	},
	defaultArrayFromDrizzle: function(value, dimensions, mode) {
		let res;
		if (mode === "tuple") res = stringifyTuplesArray(value, "sql", (x) => {
			return `"${x.length > 0 ? `{${x[0]},${x[1]},${x[2]}}` : "{}"}"`;
		});
		else if (mode === "abc") res = stringifyArray(value, "sql", (x, _depth) => {
			return `"${Object.values(x).length > 0 ? `{${x.a},${x.b},${x.c}}` : "{}"}"`;
		});
		else throw new Error("unknown line type");
		return wrapWith(res, "'");
	},
	defaultFromIntrospect: function(value) {
		return value;
	},
	defaultArrayFromIntrospect: function(value) {
		return value;
	},
	toTs: function(type, value) {
		if (!value) return { default: "" };
		if (/^'\{\d+,\d+,\d+\}'$/.test(value)) return {
			default: trimChar(value, "'").replace("{", "[").replace("}", "]"),
			options: {}
		};
		return {
			default: `sql\`${value}\``,
			options: {}
		};
	},
	toArrayTs: function(type, value) {
		if (!value) return { default: "" };
		let isDrizzleSql = false;
		try {
			const def = stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				if (!/^\{\d+,\d+,\d+\}$/.test(v)) isDrizzleSql = true;
				return v.replace("{", "[").replace("}", "]");
			});
			return { default: isDrizzleSql ? `sql\`${value}\`` : def };
		} catch {
			return { default: `sql\`${value}\`` };
		}
	}
};
const GeometryPoint = {
	is: (type) => /^\s*geometry\(point(?:,\d+)?\)(?:\[\s*\])*\s*$/i.test(type),
	drizzleImport: () => "geometry",
	defaultFromDrizzle: (value, mode, config) => {
		if (!value) return "";
		const srid = config ? Number(config) : void 0;
		let sridPrefix = srid ? `SRID=${srid};` : "";
		if (mode === "tuple") {
			const v = value;
			return v.length > 0 ? `'${sridPrefix}POINT(${v[0]} ${v[1]})'` : "";
		}
		if (mode === "object") {
			const v = value;
			return Object.values(v).length > 0 ? `'${sridPrefix}POINT(${v.x} ${v.y})'` : "";
		}
		throw new Error("unknown geometry type");
	},
	defaultArrayFromDrizzle: function(value, dimensions, mode, config) {
		let res;
		const srid = config ? Number(config) : void 0;
		let sridPrefix = srid ? `SRID=${srid};` : "";
		if (mode === "tuple") res = stringifyTuplesArray(value, "geometry-sql", (x) => {
			return `'${`${sridPrefix}POINT(${x[0]} ${x[1]})`}'`;
		});
		else if (mode === "object") res = stringifyArray(value, "geometry-sql", (x, _depth) => {
			return `'${`${sridPrefix}POINT(${x.x} ${x.y})`}'`;
		});
		else throw new Error("unknown geometry type");
		return res;
	},
	defaultFromIntrospect: function(value) {
		let def;
		try {
			const { srid, point } = parseEWKB(trimChar(value, "'"));
			def = `'${srid ? `SRID=${srid};` : ""}POINT(${point[0]} ${point[1]})'`;
		} catch {
			def = value;
		}
		return def;
	},
	defaultArrayFromIntrospect: function(value) {
		/**
		* Potential values here are:
		* DEFAULT {'POINT(10 10)'} -> '{010100000000000000000024400000000000002440}'::geometry(Point,435)[]
		* DEFAULT ARRAY['POINT(10 10)'] -> ARRAY['POINT(10 10)'::text]
		* DEFAULT ARRAY['POINT(10 10)']::geometry(point) -> ARRAY['010100000000000000000024400000000000002440'::geometry(Point)]
		* DEFAULT ARRAY['POINT(10 10)'::text]::geometry(point) -> ARRAY[('POINT(10 10)'::text)::geometry(Point)]
		*/
		let def = value;
		if (def === "'{}'") return def;
		try {
			if (value.startsWith("'{") && value.endsWith("}'")) def = stringifyArray(parseArray(trimChar(value, "'")), "geometry-sql", (v) => {
				try {
					const { srid, point } = parseEWKB(v);
					return `'${srid ? `SRID=${srid};` : ""}POINT(${point[0]} ${point[1]})'`;
				} catch {
					return v;
				}
			});
			else def = stringifyArray(parseExpressionArray(value), "geometry-sql", (v) => {
				v = trimDefaultValueSuffix(trimDefaultValueSuffix(v).replace(/^\((.*)\)$/, "$1"));
				try {
					const { srid, point } = parseEWKB(trimChar(v, "'"));
					return `'${srid ? `SRID=${srid};` : ""}POINT(${point[0]} ${point[1]})'`;
				} catch {
					return v;
				}
			});
		} catch {}
		return def;
	},
	toTs: function(type, value) {
		if (!value) return { default: "" };
		const options = { type: "point" };
		const sridOption = splitSqlType(type).options?.split(",")[1];
		if (sridOption) options.srid = Number(sridOption);
		if (!value.includes("POINT(")) return {
			default: `sql\`${value}\``,
			options
		};
		const sridInDef = value.startsWith("'SRID=") ? Number(value.split("SRID=")[1].split(";")[0]) : void 0;
		if (!sridOption && sridInDef) return {
			default: `sql\`${value}\``,
			options
		};
		const [res1, res2] = value.split("POINT(")[1].split(")")[0].split(" ");
		return {
			default: `[${res1},${res2}]`,
			options
		};
	},
	toArrayTs: function(type, value) {
		if (!value) return { default: "" };
		const options = { type: "point" };
		const sridOption = splitSqlType(type).options?.split(",")[1];
		if (sridOption) options.srid = Number(sridOption);
		if (!value) return {
			default: "",
			options
		};
		if (value === "'{}'") return {
			default: "[]",
			options
		};
		let isDrizzleSql;
		const srids = [];
		try {
			const def = stringifyArray(parseExpressionArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				if (v.includes("SRID=")) srids.push(Number(v.split("SRID=")[1].split(";")[0]));
				const [res1, res2] = value.split("POINT(")[1].split(")")[0].split(" ");
				if (!value.includes("POINT(")) isDrizzleSql = true;
				return `[${res1}, ${res2}]`;
			});
			if (!isDrizzleSql) isDrizzleSql = srids.some((it) => it !== srids[0]);
			if (!isDrizzleSql && !sridOption && srids.length > 0) isDrizzleSql = true;
			return {
				options,
				default: isDrizzleSql ? `sql\`${value}\`` : def
			};
		} catch {
			return {
				options,
				default: `sql\`${value}\``
			};
		}
	}
};
const Enum = {
	is: (_type) => {
		throw Error("Mocked");
	},
	drizzleImport: () => "pgEnum",
	defaultFromDrizzle: (value) => {
		if (!value) return "";
		return `'${value.replaceAll("'", "''")}'`;
	},
	defaultArrayFromDrizzle: (value) => {
		return `'${stringifyArray(value, "sql", (v) => {
			if (typeof v !== "string") throw new Error();
			const escaped = escapeForSqlDefault(v, "pg-arr");
			if (v.includes("\\") || v.includes("\"") || v.includes(",")) return `"${escaped}"`;
			return escaped;
		})}'`;
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const options = {};
		const [length] = parseParams(type);
		if (length) options["length"] = Number(length);
		if (!value) return {
			options,
			default: ""
		};
		return {
			options,
			default: escapeForTsLiteral(trimChar(value, "'").replaceAll("''", "'"))
		};
	},
	toArrayTs: (type, value) => {
		if (!value) return { default: "" };
		try {
			return { default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
				return escapeForTsLiteral(unescapeFromSqlDefault(trimChar(v, "'")));
			}) };
		} catch {
			return { default: `sql\`${value}\`` };
		}
	}
};
const Serial = {
	is: (type) => /^(?:serial)(?:[\s(].*)?$/i.test(type),
	drizzleImport: () => "serial",
	defaultFromDrizzle: (value) => {
		throw new Error(`Unexpected default for serial type: ${value}`);
	},
	defaultArrayFromDrizzle: (v) => {
		throw new Error(`Unexpected default for serial type: ${v}`);
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: function(value) {
		return value;
	},
	toTs: () => {
		return { default: "" };
	},
	toArrayTs: () => {
		return { default: "" };
	}
};
const BigSerial = {
	is: (type) => /^(?:bigserial)(?:[\s(].*)?$/i.test(type),
	drizzleImport: () => "bigserial",
	defaultFromDrizzle: Serial.defaultFromDrizzle,
	defaultArrayFromDrizzle: Serial.defaultArrayFromDrizzle,
	defaultFromIntrospect: Serial.defaultFromIntrospect,
	defaultArrayFromIntrospect: Serial.defaultArrayFromIntrospect,
	toTs: () => {
		return {
			options: { mode: "number" },
			default: ""
		};
	},
	toArrayTs: () => {
		return {
			options: { mode: "number" },
			default: ""
		};
	}
};
const SmallSerial = {
	is: (type) => /^(?:smallserial)(?:[\s(].*)?$/i.test(type),
	drizzleImport: () => "smallserial",
	defaultFromDrizzle: Serial.defaultFromDrizzle,
	defaultArrayFromDrizzle: Serial.defaultArrayFromDrizzle,
	defaultFromIntrospect: Serial.defaultFromIntrospect,
	defaultArrayFromIntrospect: Serial.defaultArrayFromIntrospect,
	toTs: Serial.toTs,
	toArrayTs: Serial.toArrayTs
};
const Custom = {
	is: (_type) => {
		throw Error("Mocked");
	},
	drizzleImport: () => "customType",
	defaultFromDrizzle: (value) => {
		return String(value);
	},
	defaultArrayFromDrizzle: (value) => {
		return String(value);
	},
	defaultFromIntrospect: (value) => {
		return value;
	},
	defaultArrayFromIntrospect: (value) => {
		return value;
	},
	toTs: (type, value) => {
		const options = {};
		if (!value) return {
			options,
			default: "",
			customType: type
		};
		return {
			default: escapeForTsLiteral(value),
			customType: type
		};
	},
	toArrayTs: (type, value) => {
		if (!value) return {
			default: "",
			customType: type
		};
		try {
			return {
				default: stringifyArray(parseArray(trimChar(trimChar(value, ["(", ")"]), "'")), "ts", (v) => {
					return escapeForTsLiteral(v);
				}),
				customType: type
			};
		} catch {
			return {
				default: `sql\`${value}\``,
				customType: type
			};
		}
	}
};
const typeFor = (type, isEnum) => {
	if (isEnum) return Enum;
	if (SmallInt.is(type)) return SmallInt;
	if (Int.is(type)) return Int;
	if (BigInt$1.is(type)) return BigInt$1;
	if (Numeric.is(type)) return Numeric;
	if (Real.is(type)) return Real;
	if (Double.is(type)) return Double;
	if (Boolean$1.is(type)) return Boolean$1;
	if (Char.is(type)) return Char;
	if (Varchar.is(type)) return Varchar;
	if (Text.is(type)) return Text;
	if (Json.is(type)) return Json;
	if (Jsonb.is(type)) return Jsonb;
	if (Time.is(type)) return Time;
	if (TimeTz.is(type)) return TimeTz;
	if (Timestamp.is(type)) return Timestamp;
	if (TimestampTz.is(type)) return TimestampTz;
	if (Uuid.is(type)) return Uuid;
	if (Interval.is(type)) return Interval;
	if (Inet.is(type)) return Inet;
	if (Cidr.is(type)) return Cidr;
	if (MacAddr.is(type)) return MacAddr;
	if (MacAddr8.is(type)) return MacAddr8;
	if (Vector.is(type)) return Vector;
	if (HalfVec.is(type)) return HalfVec;
	if (SparseVec.is(type)) return SparseVec;
	if (Bit.is(type)) return Bit;
	if (Point.is(type)) return Point;
	if (Line.is(type)) return Line;
	if (DateType.is(type)) return DateType;
	if (GeometryPoint.is(type)) return GeometryPoint;
	if (Serial.is(type)) return Serial;
	if (SmallSerial.is(type)) return SmallSerial;
	if (BigSerial.is(type)) return BigSerial;
	return Custom;
};
const splitSqlType = (sqlType) => {
	const toMatch = sqlType.replaceAll("[]", "");
	const match = toMatch.match(/^(\w+(?:\s+\w+)*)\(([^)]*)\)(?:\s+with time zone)?$/i);
	return {
		type: match ? match[1] + (match[3] ?? "") : toMatch,
		options: match ? match[2].replaceAll(", ", ",") : null
	};
};
const indexName = (tableName, columns) => {
	return `${tableName}_${columns.join("_")}_index`;
};
function stringFromIdentityProperty(field) {
	return typeof field === "string" ? field : typeof field === "undefined" ? void 0 : String(field);
}
function maxRangeForIdentityBasedOn(columnType) {
	return columnType === "integer" ? "2147483647" : columnType === "bigint" ? "9223372036854775807" : "32767";
}
function minRangeForIdentityBasedOn(columnType) {
	return columnType === "integer" ? "-2147483648" : columnType === "bigint" ? "-9223372036854775808" : "-32768";
}
const defaultNameForPK = (table) => {
	return `${table}_pkey`;
};
const defaultNameForFK = (table, columns, tableTo, columnsTo) => {
	const desired = `${table}_${columns.join("_")}_${tableTo}_${columnsTo.join("_")}_fkey`;
	return desired.length > 63 ? table.length < 45 ? `${table}_${hash(desired)}_fkey` : `${hash(desired)}_fkey` : desired;
};
const defaultNameForUnique = (table, ...columns) => {
	return `${table}_${columns.join("_")}_key`;
};
const trimDefaultValueSuffix = (value) => {
	let res = value.endsWith("[]") ? value.slice(0, -2) : value;
	res = res.replace(/(::["\w.\s-]+(?:\([^)]*\))?(?:\swith(?:out)?\stime\szone)?(?:\[\])?)+$/gi, "");
	return res;
};
const defaultToSQL = (it) => {
	if (!it.default) return "";
	const { type: columnType, dimensions, typeSchema } = it;
	const value = it.default;
	if (typeSchema) return `${value}::${typeSchema && typeSchema !== "public" ? `"${typeSchema}".` : ""}"${columnType}"${dimensions > 0 ? "[]" : ""}`;
	const suffix = dimensions > 0 ? `::${columnType}[]` : "";
	return `${it.default ?? ""}${suffix}`;
};
const isDefaultAction = (action) => {
	return action.toLowerCase() === "no action";
};
const isSerialType = (type) => {
	return /^(?:serial|bigserial|smallserial)$/i.test(type);
};
const mapSerialToInt = (type) => {
	switch (type) {
		case "smallserial": return "smallint";
		case "serial": return "int";
		case "bigserial": return "bigint";
		default: throw new Error(`Unsupported type: ${type}`);
	}
};
function formatTimestampTz(date) {
	if (!isTimestamp(date)) return date;
	return qi.Instant.from(date).toString({ timeZone: "UTC" });
}
function formatTime(date) {
	if (!isTime(date)) return date;
	return qi.Instant.from(`1970-01-01 ${date}`).toString({ timeZone: "UTC" });
}
const defaultsCommutative = (diffDef, type, dimensions) => {
	if (!diffDef) return false;
	let from = diffDef.from;
	let to = diffDef.to;
	if (from === to) return true;
	if (from === `(${to})`) return true;
	if (to === `(${from})`) return true;
	if (type.startsWith("timestamp") && type.includes("with time zone")) {
		if (from && to) {
			from = trimChar(from, "'");
			to = trimChar(to, "'");
			if (dimensions > 0) {
				try {
					const fromArray = stringifyArray(parseArray(from), "sql", (v) => {
						return `"${formatTimestampTz(v)}"`;
					});
					if (stringifyArray(parseArray(to), "sql", (v) => {
						return `"${formatTimestampTz(v)}"`;
					}) === fromArray) return true;
				} catch {}
				return false;
			}
			if (formatTimestampTz(to) === formatTimestampTz(from)) return true;
		}
		return false;
	}
	if (type.startsWith("time") && type.includes("with time zone")) {
		if (from && to) {
			from = trimChar(from, "'");
			to = trimChar(to, "'");
			if (dimensions > 0) {
				try {
					const fromArray = stringifyArray(parseArray(from), "sql", (v) => {
						return `"${formatTime(v)}"`;
					});
					if (stringifyArray(parseArray(to), "sql", (v) => {
						return `"${formatTime(v)}"`;
					}) === fromArray) return true;
				} catch {}
				return false;
			}
			if (formatTime(to) === formatTime(from)) return true;
		}
		return false;
	}
	if (type.startsWith("vector")) {
		if (from?.replaceAll(".0", "") === to) return true;
	}
	return false;
};
const defaults = {
	tablespace: "pg_default",
	accessMethod: "heap",
	nullsNotDistinct: false,
	identity: {
		startWith: "1",
		increment: "1",
		min: "1",
		maxFor: (type) => {
			if (type === "smallint") return "32767";
			if (type === "integer") return "2147483647";
			if (type === "bigint") return "9223372036854775807";
			throw new Error(`Unknow identity column type: ${type}`);
		},
		cache: 1,
		cycle: false
	},
	index: { method: "btree" },
	types: { geometry: { defSrid: 0 } }
};
//#endregion
//#region src/dialects/postgres/ddl.ts
const createDDL = () => {
	return create({
		schemas: {},
		tables: {
			schema: "required",
			isRlsEnabled: "boolean"
		},
		enums: {
			schema: "required",
			values: "string[]"
		},
		columns: {
			schema: "required",
			table: "required",
			type: "string",
			typeSchema: "string?",
			notNull: "boolean",
			dimensions: "number",
			default: "string?",
			generated: {
				type: ["stored"],
				as: "string"
			},
			identity: {
				name: "string",
				type: ["always", "byDefault"],
				increment: "string?",
				minValue: "string?",
				maxValue: "string?",
				startWith: "string?",
				cache: "number?",
				cycle: "boolean?"
			}
		},
		indexes: {
			schema: "required",
			table: "required",
			nameExplicit: "boolean",
			columns: [{
				value: "string",
				isExpression: "boolean",
				asc: "boolean",
				nullsFirst: "boolean",
				opclass: {
					name: "string",
					default: "boolean"
				}
			}],
			isUnique: "boolean",
			where: "string?",
			with: "string",
			method: "string",
			concurrently: "boolean"
		},
		fks: {
			schema: "required",
			table: "required",
			nameExplicit: "boolean",
			columns: "string[]",
			schemaTo: "string",
			tableTo: "string",
			columnsTo: "string[]",
			onUpdate: [
				"NO ACTION",
				"RESTRICT",
				"SET NULL",
				"CASCADE",
				"SET DEFAULT",
				null
			],
			onDelete: [
				"NO ACTION",
				"RESTRICT",
				"SET NULL",
				"CASCADE",
				"SET DEFAULT",
				null
			]
		},
		pks: {
			schema: "required",
			table: "required",
			columns: "string[]",
			nameExplicit: "boolean"
		},
		uniques: {
			schema: "required",
			table: "required",
			nameExplicit: "boolean",
			columns: "string[]",
			nullsNotDistinct: "boolean"
		},
		checks: {
			schema: "required",
			table: "required",
			value: "string"
		},
		sequences: {
			schema: "required",
			incrementBy: "string?",
			minValue: "string?",
			maxValue: "string?",
			startWith: "string?",
			cacheSize: "number?",
			cycle: "boolean?"
		},
		roles: {
			superuser: "boolean?",
			createDb: "boolean?",
			createRole: "boolean?",
			inherit: "boolean?",
			canLogin: "boolean?",
			replication: "boolean?",
			bypassRls: "boolean?",
			connLimit: "number?",
			password: "string?",
			validUntil: "string?"
		},
		privileges: {
			grantor: "string",
			grantee: "string",
			schema: "required",
			table: "required",
			type: [
				"ALL",
				"SELECT",
				"INSERT",
				"UPDATE",
				"DELETE",
				"TRUNCATE",
				"REFERENCES",
				"TRIGGER"
			],
			isGrantable: "boolean"
		},
		policies: {
			schema: "required",
			table: "required",
			as: ["PERMISSIVE", "RESTRICTIVE"],
			for: [
				"ALL",
				"SELECT",
				"INSERT",
				"UPDATE",
				"DELETE"
			],
			roles: "string[]",
			using: "string?",
			withCheck: "string?"
		},
		views: {
			schema: "required",
			definition: "string?",
			with: {
				checkOption: [
					"local",
					"cascaded",
					null
				],
				securityBarrier: "boolean?",
				securityInvoker: "boolean?",
				fillfactor: "number?",
				toastTupleTarget: "number?",
				parallelWorkers: "number?",
				autovacuumEnabled: "boolean?",
				vacuumIndexCleanup: [
					"auto",
					"off",
					"on",
					null
				],
				vacuumTruncate: "boolean?",
				autovacuumVacuumThreshold: "number?",
				autovacuumVacuumScaleFactor: "number?",
				autovacuumVacuumCostDelay: "number?",
				autovacuumVacuumCostLimit: "number?",
				autovacuumFreezeMinAge: "number?",
				autovacuumFreezeMaxAge: "number?",
				autovacuumFreezeTableAge: "number?",
				autovacuumMultixactFreezeMinAge: "number?",
				autovacuumMultixactFreezeMaxAge: "number?",
				autovacuumMultixactFreezeTableAge: "number?",
				logAutovacuumMinDuration: "number?",
				userCatalogTable: "boolean?"
			},
			withNoData: "boolean?",
			using: "string?",
			tablespace: "string?",
			materialized: "boolean"
		}
	});
};
const tableFromDDL = (table, ddl) => {
	const filter = {
		schema: table.schema,
		table: table.name
	};
	const columns = ddl.columns.list(filter);
	const pk = ddl.pks.one(filter);
	const fks = ddl.fks.list(filter);
	const uniques = ddl.uniques.list(filter);
	const checks = ddl.checks.list(filter);
	const indexes = ddl.indexes.list(filter);
	const policies = ddl.policies.list(filter);
	return {
		...table,
		columns,
		pk,
		fks,
		uniques,
		checks,
		indexes,
		policies
	};
};
const interimToDDL = (schema) => {
	const ddl = createDDL();
	const errors = [];
	for (const it of schema.schemas) if (ddl.schemas.push(it).status === "CONFLICT") errors.push({
		type: "schema_name_duplicate",
		name: it.name
	});
	for (const it of schema.enums) {
		const res = ddl.enums.push(it);
		if (new Set(it.values).size !== it.values.length) errors.push({
			type: "enum_values_duplicate",
			schema: it.schema,
			name: it.name
		});
		if (res.status === "CONFLICT") errors.push({
			type: "enum_name_duplicate",
			schema: it.schema,
			name: it.name
		});
	}
	for (const it of schema.tables) if (ddl.tables.push(it).status === "CONFLICT") errors.push({
		type: "table_name_duplicate",
		schema: it.schema,
		name: it.name
	});
	for (const column of schema.columns) {
		const { pk: _1, pkName: _2, unique: _3, uniqueName: _4, uniqueNullsNotDistinct: _5, ...rest } = column;
		if (ddl.columns.push(rest).status === "CONFLICT") errors.push({
			type: "column_name_duplicate",
			schema: column.schema,
			table: column.table,
			name: column.name
		});
	}
	for (const it of schema.indexes) {
		const { forPK: _1, forUnique: _2, ...rest } = it;
		if (ddl.indexes.push(rest).status === "CONFLICT") errors.push({
			type: "index_duplicate",
			schema: it.schema,
			table: it.table,
			name: it.name
		});
	}
	for (const it of schema.fks) if (ddl.fks.push(it).status === "CONFLICT") errors.push({
		type: "constraint_name_duplicate",
		schema: it.schema,
		table: it.table,
		name: it.name
	});
	for (const it of schema.pks) if (ddl.pks.push(it).status === "CONFLICT") errors.push({
		type: "constraint_name_duplicate",
		schema: it.schema,
		table: it.table,
		name: it.name
	});
	for (const column of schema.columns.filter((it) => it.pk)) {
		const name = column.pkName !== null ? column.pkName : defaultNameForPK(column.table);
		if (ddl.pks.one({
			schema: column.schema,
			table: column.table
		}) !== null) continue;
		ddl.pks.push({
			schema: column.schema,
			table: column.table,
			name,
			nameExplicit: column.pkName !== null,
			columns: [column.name]
		});
	}
	for (const it of schema.uniques) if (ddl.uniques.push(it).status === "CONFLICT") errors.push({
		type: "constraint_name_duplicate",
		schema: it.schema,
		table: it.table,
		name: it.name
	});
	for (const column of schema.columns.filter((it) => it.unique)) {
		const name = column.uniqueName !== null ? column.uniqueName : defaultNameForUnique(column.table, column.name);
		if (ddl.uniques.one({
			schema: column.schema,
			table: column.table,
			columns: [column.name]
		}) !== null) continue;
		ddl.uniques.push({
			schema: column.schema,
			table: column.table,
			name,
			nameExplicit: column.uniqueName !== null,
			nullsNotDistinct: column.uniqueNullsNotDistinct,
			columns: [column.name]
		});
	}
	for (const it of schema.checks) if (ddl.checks.push(it).status === "CONFLICT") errors.push({
		type: "constraint_name_duplicate",
		schema: it.schema,
		table: it.table,
		name: it.name
	});
	for (const it of schema.sequences) if (ddl.sequences.push(it).status === "CONFLICT") errors.push({
		type: "sequence_name_duplicate",
		schema: it.schema,
		name: it.name
	});
	for (const it of schema.roles) if (ddl.roles.push(it).status === "CONFLICT") errors.push({
		type: "role_duplicate",
		name: it.name
	});
	for (const it of schema.privileges) if (ddl.privileges.push(it).status === "CONFLICT") errors.push({
		type: "privilege_duplicate",
		name: it.name
	});
	for (const it of schema.policies) if (ddl.policies.push(it).status === "CONFLICT") errors.push({
		type: "policy_duplicate",
		schema: it.schema,
		table: it.table,
		policy: it.name
	});
	for (const it of schema.views) if (ddl.views.push(it).status === "CONFLICT") errors.push({
		type: "view_name_duplicate",
		schema: it.schema,
		name: it.name
	});
	for (const it of ddl.entities.list()) if (!ddl.entities.validate(it)) throw new Error(`Invalid entity: ${JSON.stringify(it)}`);
	return {
		ddl,
		errors
	};
};
//#endregion
//#region src/utils/node-assert/deep-strict-equal.ts
var AssertionError = class extends Error {
	actual;
	expected;
	operator;
	constructor(options) {
		super(options.message || `${JSON.stringify(options.actual)} ${options.operator} ${JSON.stringify(options.expected)}`);
		this.name = "AssertionError";
		this.actual = options.actual;
		this.expected = options.expected;
		this.operator = options.operator;
	}
};
function deepStrictEqualInternal(actual, expected) {
	if (actual === expected) return true;
	if (actual === null || expected === null) return false;
	if (typeof actual !== "object" || typeof expected !== "object") return false;
	if (Array.isArray(actual) && Array.isArray(expected)) {
		if (actual.length !== expected.length) return false;
		for (let i = 0; i < actual.length; i++) if (!deepStrictEqualInternal(actual[i], expected[i])) return false;
		return true;
	}
	if (Array.isArray(actual) !== Array.isArray(expected)) return false;
	const actualObj = actual;
	const expectedObj = expected;
	const actualKeys = Object.keys(actualObj);
	const expectedKeys = Object.keys(expectedObj);
	if (actualKeys.length !== expectedKeys.length) return false;
	for (const key of actualKeys) {
		if (!Object.prototype.hasOwnProperty.call(expectedObj, key)) return false;
		if (!deepStrictEqualInternal(actualObj[key], expectedObj[key])) return false;
	}
	return true;
}
/**
* Tests for deep strict equality between two JSON-compatible values.
* Supports: objects, arrays, strings, numbers, booleans, null.
*
* @param actual - The actual value to test
* @param expected - The expected value
* @param message - Optional message for the assertion error
* @throws {AssertionError} If actual and expected are not deeply strictly equal
*/
function deepStrictEqual(actual, expected, message) {
	if (!deepStrictEqualInternal(actual, expected)) {
		if (message instanceof Error) throw message;
		throw new AssertionError({
			message: message || `Expected values to be strictly deep-equal`,
			actual,
			expected,
			operator: "deepStrictEqual"
		});
	}
}
//#endregion
//#region src/utils/sequence-matcher.ts
/**
* A sequence matcher for string arrays that finds differences
* and tracks positions of added elements.
*/
function diffStringArrays(oldArr, newArr) {
	return formatResult(getOpcodes(oldArr, newArr), oldArr, newArr);
}
/**
* Get edit operations between two arrays
*/
function getOpcodes(oldArray, newArray) {
	const matchingBlocks = getMatchingBlocks(oldArray, newArray);
	const opcodes = [];
	let oldIndex = 0;
	let newIndex = 0;
	for (const [oldBlockStart, newBlockStart, matchLength] of matchingBlocks) {
		if (oldIndex < oldBlockStart || newIndex < newBlockStart) {
			const tag = oldIndex < oldBlockStart && newIndex < newBlockStart ? "replace" : oldIndex < oldBlockStart ? "delete" : "insert";
			opcodes.push([
				tag,
				oldIndex,
				oldBlockStart,
				newIndex,
				newBlockStart
			]);
		}
		if (matchLength > 0) opcodes.push([
			"equal",
			oldBlockStart,
			oldBlockStart + matchLength,
			newBlockStart,
			newBlockStart + matchLength
		]);
		oldIndex = oldBlockStart + matchLength;
		newIndex = newBlockStart + matchLength;
	}
	return opcodes;
}
/**
* Get matching blocks between two arrays
*/
function getMatchingBlocks(oldArray, newArray) {
	if (oldArray.length === 0 && newArray.length === 0) return [[
		0,
		0,
		0
	]];
	const matchQueue = [[
		0,
		oldArray.length,
		0,
		newArray.length
	]];
	const matches = [];
	while (matchQueue.length > 0) {
		const [oldStart, oldEnd, newStart, newEnd] = matchQueue.pop();
		const [oldMatchStart, newMatchStart, matchLength] = findLongestMatch(oldArray, newArray, oldStart, oldEnd, newStart, newEnd);
		if (matchLength > 0) {
			matches.push([
				oldMatchStart,
				newMatchStart,
				matchLength
			]);
			if (oldStart < oldMatchStart && newStart < newMatchStart) matchQueue.push([
				oldStart,
				oldMatchStart,
				newStart,
				newMatchStart
			]);
			if (oldMatchStart + matchLength < oldEnd && newMatchStart + matchLength < newEnd) matchQueue.push([
				oldMatchStart + matchLength,
				oldEnd,
				newMatchStart + matchLength,
				newEnd
			]);
		}
	}
	matches.sort((a, b) => a[0] - b[0]);
	matches.push([
		oldArray.length,
		newArray.length,
		0
	]);
	return matches;
}
/**
* Find the longest matching block in oldArray[oldStart:oldEnd] and newArray[newStart:newEnd]
*/
function findLongestMatch(oldArray, newArray, oldStart, oldEnd, newStart, newEnd) {
	let bestOldStart = oldStart;
	let bestNewStart = newStart;
	let bestMatchLength = 0;
	const newElementPositions = /* @__PURE__ */ new Map();
	for (let newIndex = newStart; newIndex < newEnd; newIndex++) {
		const element = newArray[newIndex];
		if (!newElementPositions.has(element)) newElementPositions.set(element, []);
		newElementPositions.get(element).push(newIndex);
	}
	for (let oldIndex = oldStart; oldIndex < oldEnd; oldIndex++) {
		const element = oldArray[oldIndex];
		if (!newElementPositions.has(element)) continue;
		for (const newIndex of newElementPositions.get(element)) {
			if (newIndex >= newEnd) continue;
			let currentMatchLength = 1;
			while (oldIndex + currentMatchLength < oldEnd && newIndex + currentMatchLength < newEnd && oldArray[oldIndex + currentMatchLength] === newArray[newIndex + currentMatchLength]) currentMatchLength++;
			if (currentMatchLength > bestMatchLength) {
				bestOldStart = oldIndex;
				bestNewStart = newIndex;
				bestMatchLength = currentMatchLength;
			}
		}
	}
	return [
		bestOldStart,
		bestNewStart,
		bestMatchLength
	];
}
/**
* Format the opcodes into the requested result format
*/
function formatResult(opcodes, oldArray, newArray) {
	const result = [];
	for (const [tag, oldStart, oldEnd, newStart, newEnd] of opcodes) {
		if (tag === "equal") {
			for (let oldIndex = oldStart; oldIndex < oldEnd; oldIndex++) result.push({
				type: "same",
				value: oldArray[oldIndex]
			});
			continue;
		}
		if (tag === "delete") {
			for (let oldIndex = oldStart; oldIndex < oldEnd; oldIndex++) result.push({
				type: "removed",
				value: oldArray[oldIndex]
			});
			continue;
		}
		if (tag === "insert") {
			for (let newIndex = newStart; newIndex < newEnd; newIndex++) addWithPosition(newArray[newIndex], newIndex, newArray, oldArray, result);
			continue;
		}
		if (tag === "replace") {
			for (let oldIndex = oldStart; oldIndex < oldEnd; oldIndex++) result.push({
				type: "removed",
				value: oldArray[oldIndex]
			});
			for (let newIndex = newStart; newIndex < newEnd; newIndex++) addWithPosition(newArray[newIndex], newIndex, newArray, oldArray, result);
			continue;
		}
	}
	return result;
}
/**
* Helper function to add an element with position information
*/
function addWithPosition(value, currentIndex, newArray, oldElementSet, result) {
	let beforeValue = void 0;
	for (let lookAheadIndex = currentIndex + 1; lookAheadIndex < newArray.length; lookAheadIndex++) if (oldElementSet.indexOf(newArray[lookAheadIndex]) >= 0) {
		beforeValue = newArray[lookAheadIndex];
		break;
	}
	result.push({
		type: "added",
		value,
		beforeValue
	});
}
//#endregion
//#region src/dialects/postgres/convertor.ts
const convertor = (type, convertor) => {
	return {
		type,
		can: (st) => {
			return st.type === type;
		},
		convert: convertor
	};
};
const createSchemaConvertor = convertor("create_schema", (st) => {
	return `CREATE SCHEMA "${st.name}";\n`;
});
const dropSchemaConvertor = convertor("drop_schema", (st) => {
	return `DROP SCHEMA "${st.name}";\n`;
});
const renameSchemaConvertor = convertor("rename_schema", (st) => {
	return `ALTER SCHEMA "${st.from.name}" RENAME TO "${st.to.name}";\n`;
});
const createViewConvertor = convertor("create_view", (st) => {
	const { definition, name: viewName, schema, with: withOption, materialized, withNoData, tablespace, using } = st.view;
	const name = schema !== "public" ? `"${schema}"."${viewName}"` : `"${viewName}"`;
	let statement = materialized ? `CREATE MATERIALIZED VIEW ${name}` : `CREATE VIEW ${name}`;
	if (using) statement += ` USING "${using}"`;
	const options = [];
	if (withOption) {
		statement += ` WITH (`;
		for (const [key, value] of Object.entries(withOption)) {
			if (value === null) continue;
			options.push(`${key.snake_case()} = ${value}`);
		}
		statement += options.join(", ");
		statement += `)`;
	}
	if (tablespace) statement += ` TABLESPACE ${tablespace}`;
	statement += ` AS (${definition})`;
	if (withNoData) statement += ` WITH NO DATA`;
	statement += `;`;
	return statement;
});
const dropViewConvertor = convertor("drop_view", (st) => {
	const { name: viewName, schema, materialized } = st.view;
	const name = schema !== "public" ? `"${schema}"."${viewName}"` : `"${viewName}"`;
	return `DROP${materialized ? " MATERIALIZED" : ""} VIEW ${name};`;
});
const renameViewConvertor = convertor("rename_view", (st) => {
	const materialized = st.from.materialized;
	const nameFrom = st.from.schema !== "public" ? `"${st.from.schema}"."${st.from.name}"` : `"${st.from.name}"`;
	return `ALTER${materialized ? " MATERIALIZED" : ""} VIEW ${nameFrom} RENAME TO "${st.to.name}";`;
});
const moveViewConvertor = convertor("move_view", (st) => {
	const { fromSchema, toSchema, view } = st;
	const from = fromSchema === "public" ? `"${view.name}"` : `"${fromSchema}"."${view.name}"`;
	return `ALTER${view.materialized ? " MATERIALIZED" : ""} VIEW ${from} SET SCHEMA "${toSchema}";`;
});
const alterViewConvertor = convertor("alter_view", (st) => {
	const diff = st.diff;
	const statements = [];
	const key = st.view.schema !== "public" ? `"${st.view.schema}"."${st.view.name}"` : `"${st.view.name}"`;
	const viewClause = st.view.materialized ? `MATERIALIZED VIEW ${key}` : `VIEW ${key}`;
	const withFrom = diff.with?.from || {};
	const withTo = diff.with?.to || {};
	const resetOptions = Object.entries(withFrom).filter(([key, val]) => {
		return val !== null && (key in withTo ? withTo[key] === null : true);
	}).map((it) => it[0].snake_case());
	const setOptions = Object.entries(withTo).filter(([key, val]) => {
		const from = key in withFrom ? withFrom[key] : null;
		return val !== null && from !== val;
	}).map((it) => `${it[0].snake_case()} = ${it[1]}`).join(", ");
	if (setOptions.length > 0) statements.push(`ALTER ${viewClause} SET (${setOptions});`);
	if (resetOptions.length > 0) statements.push(`ALTER ${viewClause} RESET (${resetOptions.join(", ")});`);
	if (diff.tablespace) {
		const to = diff.tablespace.to || defaults.tablespace;
		statements.push(`ALTER ${viewClause} SET TABLESPACE "${to}";`);
	}
	if (diff.using) {
		const toUsing = diff.using.to ?? defaults.accessMethod;
		statements.push(`ALTER ${viewClause} SET ACCESS METHOD "${toUsing}";`);
	}
	return statements;
});
const createTableConvertor = convertor("create_table", (st) => {
	const { schema, name, columns, pk, uniques, checks, policies, isRlsEnabled } = st.table;
	const statements = [];
	let statement = "";
	const key = schema !== "public" ? `"${schema}"."${name}"` : `"${name}"`;
	statement += `CREATE TABLE ${key} (\n`;
	for (let i = 0; i < columns.length; i++) {
		const column = columns[i];
		const isPK = pk && pk.columns.length === 1 && pk.columns[0] === column.name && pk.name === defaultNameForPK(column.table);
		const isSerial = isSerialType(column.type);
		const primaryKeyStatement = isPK ? " PRIMARY KEY" : "";
		const notNullStatement = pk?.columns.includes(column.name) || isSerial ? "" : column.notNull && !column.identity ? " NOT NULL" : "";
		const defaultStatement = column.default ? ` DEFAULT ${defaultToSQL(column)}` : "";
		const unique = uniques.find((u) => u.columns.length === 1 && u.columns[0] === column.name);
		const unqiueConstraintPrefix = unique ? unique.nameExplicit ? `CONSTRAINT "${unique.name}" UNIQUE` : "UNIQUE" : "";
		const uniqueConstraintStatement = unique ? ` ${unqiueConstraintPrefix}${unique.nullsNotDistinct ? " NULLS NOT DISTINCT" : ""}` : "";
		const type = `${column.typeSchema && column.typeSchema !== "public" ? `"${column.typeSchema}".` : ""}${column.typeSchema ? `"${column.type}"` : column.type}${"[]".repeat(column.dimensions)}`;
		const generated = column.generated;
		const generatedStatement = generated ? ` GENERATED ALWAYS AS (${generated?.as}) STORED` : "";
		const identityWithSchema = schema !== "public" ? `"${schema}"."${column.identity?.name}"` : `"${column.identity?.name}"`;
		const identity = column.identity ? ` GENERATED ${column.identity.type === "always" ? "ALWAYS" : "BY DEFAULT"} AS IDENTITY (sequence name ${identityWithSchema}${column.identity.increment ? ` INCREMENT BY ${column.identity.increment}` : ""}${column.identity.minValue ? ` MINVALUE ${column.identity.minValue}` : ""}${column.identity.maxValue ? ` MAXVALUE ${column.identity.maxValue}` : ""}${column.identity.startWith ? ` START WITH ${column.identity.startWith}` : ""}${column.identity.cache ? ` CACHE ${column.identity.cache}` : ""}${column.identity.cycle ? ` CYCLE` : ""})` : "";
		statement += `	"${column.name}" ${type}${primaryKeyStatement}${defaultStatement}${generatedStatement}${notNullStatement}${uniqueConstraintStatement}${identity}`;
		statement += i === columns.length - 1 ? "" : ",\n";
	}
	if (pk && (pk.columns.length > 1 || pk.name !== defaultNameForPK(st.table.name))) {
		statement += ",\n";
		statement += `\tCONSTRAINT "${pk.name}" PRIMARY KEY("${pk.columns.join(`","`)}")`;
	}
	for (const it of uniques.filter((u) => u.columns.length > 1)) {
		statement += ",\n";
		statement += `\tCONSTRAINT "${it.name}" UNIQUE${it.nullsNotDistinct ? " NULLS NOT DISTINCT" : ""}("${it.columns.join(`","`)}")`;
	}
	for (const check of checks) {
		statement += ",\n";
		statement += `\tCONSTRAINT "${check.name}" CHECK (${check.value})`;
	}
	statement += `\n);`;
	statement += `\n`;
	statements.push(statement);
	if (policies && policies.length > 0 || isRlsEnabled) statements.push(toggleRlsConvertor.convert({
		isRlsEnabled: true,
		name: st.table.name,
		schema: st.table.schema
	}));
	return statements;
});
const dropTableConvertor = convertor("drop_table", (st) => {
	const { name, schema, policies } = st.table;
	const tableNameWithSchema = schema !== "public" ? `"${schema}"."${name}"` : `"${name}"`;
	return [...policies.map((policy) => dropPolicyConvertor.convert({ policy })), `DROP TABLE ${tableNameWithSchema};`];
});
const renameTableConvertor = convertor("rename_table", (st) => {
	return `ALTER TABLE ${st.schema !== "public" ? `"${st.schema}".` : ""}"${st.from}" RENAME TO "${st.to}";`;
});
const moveTableConvertor = convertor("move_table", (st) => {
	return `ALTER TABLE ${st.from !== "public" ? `"${st.from}"."${st.name}"` : `"${st.name}"`} SET SCHEMA "${st.to}";\n`;
});
const addColumnConvertor = convertor("add_column", (st) => {
	const { schema, table, name, identity, generated } = st.column;
	const column = st.column;
	const primaryKeyStatement = st.isPK ? " PRIMARY KEY" : "";
	const tableNameWithSchema = schema !== "public" ? `"${schema}"."${table}"` : `"${table}"`;
	const defaultStatement = column.default ? ` DEFAULT ${defaultToSQL(column)}` : "";
	let fixedType = `${column.typeSchema && column.typeSchema !== "public" ? `"${column.typeSchema}".` : ""}${column.typeSchema ? `"${column.type}"` : column.type}${"[]".repeat(column.dimensions)}`;
	const isSerial = isSerialType(column.type);
	const notNullStatement = column.notNull && !identity && !generated && !isSerial && !st.isCompositePK ? " NOT NULL" : "";
	const identityWithSchema = schema !== "public" ? `"${schema}"."${identity?.name}"` : `"${identity?.name}"`;
	const identityStatement = identity ? ` GENERATED ${identity.type === "always" ? "ALWAYS" : "BY DEFAULT"} AS IDENTITY (sequence name ${identityWithSchema}${identity.increment ? ` INCREMENT BY ${identity.increment}` : ""}${identity.minValue ? ` MINVALUE ${identity.minValue}` : ""}${identity.maxValue ? ` MAXVALUE ${identity.maxValue}` : ""}${identity.startWith ? ` START WITH ${identity.startWith}` : ""}${identity.cache ? ` CACHE ${identity.cache}` : ""}${identity.cycle ? ` CYCLE` : ""})` : "";
	return `ALTER TABLE ${tableNameWithSchema} ADD COLUMN "${name}" ${fixedType}${primaryKeyStatement}${defaultStatement}${column.generated ? ` GENERATED ALWAYS AS (${column.generated.as}) STORED` : ""}${notNullStatement}${identityStatement};`;
});
const dropColumnConvertor = convertor("drop_column", (st) => {
	const { schema, table, name } = st.column;
	return `ALTER TABLE ${schema !== "public" ? `"${schema}"."${table}"` : `"${table}"`} DROP COLUMN "${name}";`;
});
const renameColumnConvertor = convertor("rename_column", (st) => {
	const { table, schema } = st.from;
	return `ALTER TABLE ${schema !== "public" ? `"${schema}"."${table}"` : `"${table}"`} RENAME COLUMN "${st.from.name}" TO "${st.to.name}";`;
});
const recreateColumnConvertor = convertor("recreate_column", (st) => {
	const r = st.diff.$right;
	return [dropColumnConvertor.convert({ column: r }), addColumnConvertor.convert({
		column: r,
		isPK: st.isPK,
		isCompositePK: false
	})];
});
const recreateIndexConvertor = convertor("recreate_index", (st) => {
	const res = [];
	if (st.shouldDrop) res.push(dropIndexConvertor.convert({ index: st.index }));
	res.push(createIndexConvertor.convert({ index: st.index }));
	return res;
});
const alterColumnConvertor = convertor("alter_column", (st) => {
	const { diff, to: column, isEnum, wasEnum, wasSerial, toSerial } = st;
	const statements = [];
	const key = column.schema !== "public" ? `"${column.schema}"."${column.table}"` : `"${column.table}"`;
	const recreateDefault = diff.type && (isEnum || wasEnum) && diff.$left.default;
	if (recreateDefault) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" DROP DEFAULT;`);
	if (diff.type) {
		const typeSchema = column.typeSchema && column.typeSchema !== "public" ? `"${column.typeSchema}".` : "";
		const textProxy = wasEnum && isEnum ? "text::" : "";
		const suffix = isEnum ? ` USING "${column.name}"::${textProxy}${typeSchema}"${column.type}"${"[]".repeat(column.dimensions)}` : ` USING "${column.name}"::${toSerial ? mapSerialToInt(column.type) : column.type}${"[]".repeat(column.dimensions)}`;
		const type = diff.typeSchema?.to && diff.typeSchema.to !== "public" ? `"${diff.typeSchema.to}"."${diff.type.to}"` : isEnum ? `"${diff.type.to}"` : toSerial ? mapSerialToInt(diff.type.to) : diff.type.to;
		if (wasSerial) {
			statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" DROP DEFAULT;`);
			const sequenceKey = column.schema !== "public" ? `"${column.schema}"."${column.table}_${column.name}_seq"` : `"${column.table}_${column.name}_seq"`;
			statements.push(`DROP SEQUENCE ${sequenceKey};`);
		}
		if (toSerial) {
			const sequenceKey = column.schema !== "public" ? `"${column.schema}"."${column.table}_${column.name}_seq"` : `"${column.table}_${column.name}_seq"`;
			const sequenceName = column.schema !== "public" ? `${column.schema}.${column.table}_${column.name}_seq` : `${column.table}_${column.name}_seq`;
			statements.push(`CREATE SEQUENCE ${sequenceKey};`);
			statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET DEFAULT nextval('${sequenceName}')`);
			statements.push(`ALTER SEQUENCE ${sequenceKey} OWNED BY "${column.schema}"."${column.table}"."${column.name}";`);
		}
		statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET DATA TYPE ${type}${"[]".repeat(column.dimensions)}${suffix};`);
		if (recreateDefault && column.default) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET DEFAULT ${defaultToSQL(column)};`);
	}
	if (diff.default && !recreateDefault) if (diff.default.to) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET DEFAULT ${defaultToSQL(diff.$right)};`);
	else statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" DROP DEFAULT;`);
	if (diff.generated && diff.generated.to === null) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" DROP EXPRESSION;`);
	if (diff.identity) if (diff.identity.from === null) {
		const identity = column.identity;
		const identityWithSchema = column.schema !== "public" ? `"${column.schema}"."${identity.name}"` : `"${identity.name}"`;
		const identityStatement = `GENERATED ${identity.type === "always" ? "ALWAYS" : "BY DEFAULT"} AS IDENTITY (sequence name ${identityWithSchema}${identity.increment ? ` INCREMENT BY ${identity.increment}` : ""}${identity.minValue ? ` MINVALUE ${identity.minValue}` : ""}${identity.maxValue ? ` MAXVALUE ${identity.maxValue}` : ""}${identity.startWith ? ` START WITH ${identity.startWith}` : ""}${identity.cache ? ` CACHE ${identity.cache}` : ""}${identity.cycle ? ` CYCLE` : ""})`;
		statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" ADD ${identityStatement};`);
		if (wasSerial && column.identity) statements.push(`SELECT setval('${column.identity.name}'::regclass, (SELECT COALESCE(MAX(id), 1) FROM ${key}), false);`);
	} else if (diff.identity.to === null) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" DROP IDENTITY;`);
	else {
		const { from, to } = diff.identity;
		if (from.type !== to.type) {
			const typeClause = to.type === "always" ? "ALWAYS" : "BY DEFAULT";
			statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET GENERATED ${typeClause};`);
		}
		if (from.minValue !== to.minValue) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET MINVALUE ${to.minValue};`);
		if (from.maxValue !== to.maxValue) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET MAXVALUE ${to.maxValue};`);
		if (from.increment !== to.increment) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET INCREMENT BY ${to.increment};`);
		if (from.startWith !== to.startWith) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET START WITH ${to.startWith};`);
		if (from.cache !== to.cache) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET CACHE ${to.cache};`);
		if (from.cycle !== to.cycle) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET ${to.cycle ? `CYCLE` : "NO CYCLE"};`);
	}
	if (diff.notNull && !(diff.notNull.to && diff.identity && diff.identity.to)) {
		const clause = diff.notNull.to ? "SET NOT NULL" : "DROP NOT NULL";
		statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" ${clause};`);
	}
	return statements;
});
const createIndexConvertor = convertor("create_index", (st) => {
	const { schema, table, name, columns, isUnique, concurrently, with: w, method, where } = st.index;
	const indexPart = isUnique ? "UNIQUE INDEX" : "INDEX";
	const value = columns.map((it) => {
		return `${it.isExpression ? it.value : `"${it.value}"`}${it.opclass && !it.opclass.default ? ` ${it.opclass.name}` : ""}${it.asc ? "" : " DESC"}${it.asc && !it.nullsFirst || !it.asc && it.nullsFirst ? "" : it.nullsFirst ? " NULLS FIRST" : " NULLS LAST"}`;
	}).join(",");
	const key = schema !== "public" ? `"${schema}"."${table}"` : `"${table}"`;
	const concur = concurrently ? " CONCURRENTLY" : "";
	const withClause = w ? ` WITH (${w})` : "";
	const whereClause = where ? ` WHERE ${where}` : "";
	return `CREATE ${indexPart}${concur} "${name}" ON ${key}${method !== defaults.index.method ? ` USING ${method}` : ""} (${value})${withClause}${whereClause};`;
});
const dropIndexConvertor = convertor("drop_index", (st) => {
	const { schema } = st.index;
	return `DROP INDEX ${schema !== "public" ? `"${schema}".` : ""}"${st.index.name}";`;
});
const renameIndexConvertor = convertor("rename_index", (st) => {
	return `ALTER INDEX ${st.schema !== "public" ? `"${st.schema}"."${st.from}"` : `"${st.from}"`} RENAME TO "${st.to}";`;
});
const addPrimaryKeyConvertor = convertor("add_pk", (st) => {
	const { pk } = st;
	const key = pk.schema !== "public" ? `"${pk.schema}"."${pk.table}"` : `"${pk.table}"`;
	if (!pk.nameExplicit) return `ALTER TABLE ${key} ADD PRIMARY KEY ("${pk.columns.join("\",\"")}");`;
	return `ALTER TABLE ${key} ADD CONSTRAINT "${pk.name}" PRIMARY KEY("${pk.columns.join("\",\"")}");`;
});
const dropPrimaryKeyConvertor = convertor("drop_pk", (st) => {
	const pk = st.pk;
	return `ALTER TABLE ${pk.schema !== "public" ? `"${pk.schema}"."${pk.table}"` : `"${pk.table}"`} DROP CONSTRAINT "${pk.name}";`;
});
const recreatePrimaryKeyConvertor = convertor("alter_pk", (it) => {
	const st = [];
	if (!it.deleted) st.push(dropPrimaryKeyConvertor.convert({ pk: it.pk }));
	st.push(addPrimaryKeyConvertor.convert({ pk: it.pk }));
	return st;
});
const renameConstraintConvertor = convertor("rename_constraint", (st) => {
	return `ALTER TABLE ${st.schema !== "public" ? `"${st.schema}"."${st.table}"` : `"${st.table}"`} RENAME CONSTRAINT "${st.from}" TO "${st.to}";`;
});
const createForeignKeyConvertor = convertor("create_fk", (st) => {
	const { schema, table, name, tableTo, columns, columnsTo, onDelete, onUpdate, schemaTo } = st.fk;
	const onDeleteStatement = onDelete && !isDefaultAction(onDelete) ? ` ON DELETE ${onDelete}` : "";
	const onUpdateStatement = onUpdate && !isDefaultAction(onUpdate) ? ` ON UPDATE ${onUpdate}` : "";
	const fromColumnsString = columns.map((it) => `"${it}"`).join(",");
	const toColumnsString = columnsTo.map((it) => `"${it}"`).join(",");
	return `ALTER TABLE ${schema !== "public" ? `"${schema}"."${table}"` : `"${table}"`} ADD CONSTRAINT "${name}" FOREIGN KEY (${fromColumnsString}) REFERENCES ${schemaTo !== "public" ? `"${schemaTo}"."${tableTo}"` : `"${tableTo}"`}(${toColumnsString})${onDeleteStatement}${onUpdateStatement};`;
});
const recreateFKConvertor = convertor("recreate_fk", (st) => {
	const { fk } = st;
	const key = fk.schema !== "public" ? `"${fk.schema}"."${fk.table}"` : `"${fk.table}"`;
	const onDeleteStatement = fk.onDelete !== "NO ACTION" ? ` ON DELETE ${fk.onDelete}` : "";
	const onUpdateStatement = fk.onUpdate !== "NO ACTION" ? ` ON UPDATE ${fk.onUpdate}` : "";
	const fromColumnsString = fk.columns.map((it) => `"${it}"`).join(",");
	const toColumnsString = fk.columnsTo.map((it) => `"${it}"`).join(",");
	const tableToNameWithSchema = fk.schemaTo !== "public" ? `"${fk.schemaTo}"."${fk.tableTo}"` : `"${fk.tableTo}"`;
	let sql = `ALTER TABLE ${key} DROP CONSTRAINT "${fk.name}", `;
	sql += `ADD CONSTRAINT "${fk.name}" FOREIGN KEY (${fromColumnsString}) `;
	sql += `REFERENCES ${tableToNameWithSchema}(${toColumnsString})${onDeleteStatement}${onUpdateStatement};`;
	return sql;
});
const dropForeignKeyConvertor = convertor("drop_fk", (st) => {
	const { schema, table, name } = st.fk;
	return `ALTER TABLE ${schema !== "public" ? `"${schema}"."${table}"` : `"${table}"`} DROP CONSTRAINT "${name}";`;
});
const addCheckConvertor = convertor("add_check", (st) => {
	const { check } = st;
	return `ALTER TABLE ${check.schema !== "public" ? `"${check.schema}"."${check.table}"` : `"${check.table}"`} ADD CONSTRAINT "${check.name}" CHECK (${check.value});`;
});
const dropCheckConvertor = convertor("drop_check", (st) => {
	const { check } = st;
	return `ALTER TABLE ${check.schema !== "public" ? `"${check.schema}"."${check.table}"` : `"${check.table}"`} DROP CONSTRAINT "${check.name}";`;
});
const recreateCheckConvertor = convertor("alter_check", (st) => {
	const { diff } = st;
	const check = diff.$right;
	let sql = `ALTER TABLE ${check.schema !== "public" ? `"${check.schema}"."${check.table}"` : `"${check.table}"`} DROP CONSTRAINT "${check.name}", `;
	sql += `ADD CONSTRAINT "${check.name}" CHECK (${check.value});`;
	return sql;
});
const addUniqueConvertor = convertor("add_unique", (st) => {
	const { unique } = st;
	return `ALTER TABLE ${unique.schema !== "public" ? `"${unique.schema}"."${unique.table}"` : `"${unique.table}"`} ADD CONSTRAINT "${unique.name}" UNIQUE${unique.nullsNotDistinct ? " NULLS NOT DISTINCT" : ""}("${unique.columns.join("\",\"")}");`;
});
const dropUniqueConvertor = convertor("drop_unique", (st) => {
	const { unique } = st;
	return `ALTER TABLE ${unique.schema !== "public" ? `"${unique.schema}"."${unique.table}"` : `"${unique.table}"`} DROP CONSTRAINT "${unique.name}";`;
});
const alterUniqueConvertor = convertor("alter_unique", (st) => {
	const statements = [];
	statements.push(dropUniqueConvertor.convert({ unique: st.diff.$left }));
	statements.push(addUniqueConvertor.convert({ unique: st.diff.$right }));
	return statements;
});
const createEnumConvertor = convertor("create_enum", (st) => {
	const { name, schema, values } = st.enum;
	const enumNameWithSchema = schema !== "public" ? `"${schema}"."${name}"` : `"${name}"`;
	let valuesStatement = "(";
	valuesStatement += values.map((it) => wrapWith(it.replaceAll("'", "''"), "'")).join(", ");
	valuesStatement += ")";
	return `CREATE TYPE ${enumNameWithSchema} AS ENUM${valuesStatement};`;
});
const dropEnumConvertor = convertor("drop_enum", (st) => {
	const { name, schema } = st.enum;
	return `DROP TYPE ${schema !== "public" ? `"${schema}"."${name}"` : `"${name}"`};`;
});
const renameEnumConvertor = convertor("rename_enum", (st) => {
	return `ALTER TYPE ${st.schema !== "public" ? `"${st.schema}"."${st.from}"` : `"${st.from}"`} RENAME TO "${st.to}";`;
});
const moveEnumConvertor = convertor("move_enum", (st) => {
	const { from, to } = st;
	return `ALTER TYPE ${from.schema !== "public" ? `"${from.schema}"."${from.name}"` : `"${from.name}"`} SET SCHEMA "${to.schema || "public"}";`;
});
const alterEnumConvertor = convertor("alter_enum", (st) => {
	const { diff, to: e } = st;
	const key = e.schema !== "public" ? `"${e.schema}"."${e.name}"` : `"${e.name}"`;
	const statements = [];
	for (const d of diff.filter((it) => it.type === "added")) if (d.beforeValue) statements.push(`ALTER TYPE ${key} ADD VALUE '${d.value}' BEFORE '${d.beforeValue}';`);
	else statements.push(`ALTER TYPE ${key} ADD VALUE '${d.value}';`);
	return statements;
});
const recreateEnumConvertor = convertor("recreate_enum", (st) => {
	const { to, columns } = st;
	const statements = [];
	for (const column of columns) {
		const key = column.schema !== "public" ? `"${column.schema}"."${column.table}"` : `"${column.table}"`;
		statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET DATA TYPE text${"[]".repeat(column.dimensions)};`);
		if (column.default.left) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" DROP DEFAULT;`);
	}
	statements.push(dropEnumConvertor.convert({ enum: to }));
	statements.push(createEnumConvertor.convert({ enum: to }));
	for (const column of columns) {
		const key = column.schema !== "public" ? `"${column.schema}"."${column.table}"` : `"${column.table}"`;
		const enumType = to.schema !== "public" ? `"${to.schema}"."${to.name}"` : `"${to.name}"`;
		statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET DATA TYPE ${enumType}${"[]".repeat(column.dimensions)} USING "${column.name}"::${enumType}${"[]".repeat(column.dimensions)};`);
		if (column.default.right) statements.push(`ALTER TABLE ${key} ALTER COLUMN "${column.name}" SET DEFAULT ${defaultToSQL({
			default: column.default.right,
			dimensions: column.dimensions,
			type: column.type,
			typeSchema: column.typeSchema
		})};`);
	}
	return statements;
});
const createSequenceConvertor = convertor("create_sequence", (st) => {
	const { name, schema, minValue, maxValue, incrementBy, startWith, cacheSize, cycle } = st.sequence;
	return `CREATE SEQUENCE ${schema ? `"${schema}"."${name}"` : `"${name}"`}${incrementBy ? ` INCREMENT BY ${incrementBy}` : ""}${minValue ? ` MINVALUE ${minValue}` : ""}${maxValue ? ` MAXVALUE ${maxValue}` : ""}${startWith ? ` START WITH ${startWith}` : ""}${cacheSize ? ` CACHE ${cacheSize}` : ""}${cycle ? ` CYCLE` : ""};`;
});
const dropSequenceConvertor = convertor("drop_sequence", (st) => {
	const { name, schema } = st.sequence;
	return `DROP SEQUENCE ${schema ? `"${schema}"."${name}"` : `"${name}"`};`;
});
const renameSequenceConvertor = convertor("rename_sequence", (st) => {
	return `ALTER SEQUENCE ${st.from.schema !== "public" ? `"${st.from.schema}"."${st.from.name}"` : `"${st.from.name}"`} RENAME TO "${st.to.name}";`;
});
const moveSequenceConvertor = convertor("move_sequence", (st) => {
	const { from, to } = st;
	return `ALTER SEQUENCE ${from.schema !== "public" ? `"${from.schema}"."${from.name}"` : `"${from.name}"`} SET SCHEMA ${`"${to.schema}"`};`;
});
const alterSequenceConvertor = convertor("alter_sequence", (st) => {
	const { schema, name, incrementBy, minValue, maxValue, startWith, cacheSize, cycle } = st.sequence;
	return `ALTER SEQUENCE ${schema !== "public" ? `"${schema}"."${name}"` : `"${name}"`}${incrementBy ? ` INCREMENT BY ${incrementBy}` : ""}${minValue ? ` MINVALUE ${minValue}` : ""}${maxValue ? ` MAXVALUE ${maxValue}` : ""}${startWith ? ` START WITH ${startWith}` : ""}${cacheSize ? ` CACHE ${cacheSize}` : ""}${cycle ? ` CYCLE` : ""};`;
});
const createRoleConvertor = convertor("create_role", (st) => {
	const { name, superuser, createDb, createRole, inherit, canLogin, replication, bypassRls, connLimit, password, validUntil } = st.role;
	return `CREATE ROLE "${name}"${superuser || createDb || createRole || !inherit || canLogin || replication || bypassRls || validUntil || typeof connLimit === "number" && connLimit !== -1 || password ? ` WITH${superuser ? " SUPERUSER" : ""}${createDb ? " CREATEDB" : ""}${createRole ? " CREATEROLE" : ""}${inherit ? "" : " NOINHERIT"}${canLogin ? " LOGIN" : ""}${replication ? " REPLICATION" : ""}${bypassRls ? " BYPASSRLS" : ""}${typeof connLimit === "number" && connLimit !== -1 ? ` CONNECTION LIMIT ${connLimit}` : ""}${password ? ` PASSWORD '${escapeSingleQuotes(password)}'` : ""}${validUntil ? ` VALID UNTIL '${validUntil}'` : ""}` : ""};`;
});
const dropRoleConvertor = convertor("drop_role", (st) => {
	return `DROP ROLE "${st.role.name}";`;
});
const renameRoleConvertor = convertor("rename_role", (st) => {
	return `ALTER ROLE "${st.from.name}" RENAME TO "${st.to.name}";`;
});
const alterRoleConvertor = convertor("alter_role", ({ diff, role }) => {
	const { name } = role;
	return `ALTER ROLE "${name}" WITH${diff.superuser ? diff.superuser.to ? " SUPERUSER" : " NOSUPERUSER" : ""}${diff.createDb ? diff.createDb.to ? " CREATEDB" : " NOCREATEDB" : ""}${diff.createRole ? diff.createRole.to ? " CREATEROLE" : " NOCREATEROLE" : ""}${diff.inherit ? diff.inherit.to ? " INHERIT" : " NOINHERIT" : ""}${diff.canLogin ? diff.canLogin.to ? " LOGIN" : " NOLOGIN" : ""}${diff.replication ? diff.replication.to ? " REPLICATION" : " NOREPLICATION" : ""}${diff.bypassRls ? diff.bypassRls.to ? " BYPASSRLS" : " NOBYPASSRLS" : ""}${diff.connLimit ? typeof diff.connLimit.to === "number" ? ` CONNECTION LIMIT ${diff.connLimit.to}` : " CONNECTION LIMIT -1" : ""}${diff.password ? diff.password.to ? ` PASSWORD '${escapeSingleQuotes(diff.password.to)}'` : " PASSWORD NULL" : ""}${diff.validUntil ? diff.validUntil.to ? ` VALID UNTIL '${diff.validUntil.to}'` : ` VALID UNTIL 'infinity'` : ""};`;
});
const grantPrivilegeConvertor = convertor("grant_privilege", (st) => {
	const { schema, table } = st.privilege;
	const privilege = st.privilege;
	return `GRANT ${privilege.type} ON ${schema !== "public" ? `"${schema}"."${table}"` : `"${table}"`} TO "${privilege.grantee}"${privilege.isGrantable ? " WITH GRANT OPTION" : ""} GRANTED BY "${privilege.grantor}";`;
});
const revokePrivilegeConvertor = convertor("revoke_privilege", (st) => {
	const { schema, table } = st.privilege;
	const privilege = st.privilege;
	return `REVOKE ${privilege.type} ON ${schema !== "public" ? `"${schema}"."${table}"` : `"${table}"`} FROM "${privilege.grantee}";`;
});
const regrantPrivilegeConvertor = convertor("regrant_privilege", (st) => {
	const privilege = st.privilege;
	return [revokePrivilegeConvertor.convert({ privilege }), grantPrivilegeConvertor.convert({ privilege })];
});
const createPolicyConvertor = convertor("create_policy", (st) => {
	const { schema, table } = st.policy;
	const policy = st.policy;
	const tableNameWithSchema = schema !== "public" ? `"${schema}"."${table}"` : `"${table}"`;
	const usingPart = policy.using ? ` USING (${policy.using})` : "";
	const withCheckPart = policy.withCheck ? ` WITH CHECK (${policy.withCheck})` : "";
	const policyToPart = policy.roles?.map((v) => [
		"current_user",
		"current_role",
		"session_user",
		"public"
	].includes(v) ? v : `"${v}"`).join(", ");
	return `CREATE POLICY "${policy.name}" ON ${tableNameWithSchema} AS ${policy.as?.toUpperCase()} FOR ${policy.for?.toUpperCase()} TO ${policyToPart}${usingPart}${withCheckPart};`;
});
const dropPolicyConvertor = convertor("drop_policy", (st) => {
	const policy = st.policy;
	const tableNameWithSchema = policy.schema !== "public" ? `"${policy.schema}"."${policy.table}"` : `"${policy.table}"`;
	return `DROP POLICY "${policy.name}" ON ${tableNameWithSchema};`;
});
const renamePolicyConvertor = convertor("rename_policy", (st) => {
	const { from, to } = st;
	const tableNameWithSchema = to.schema !== "public" ? `"${to.schema}"."${to.table}"` : `"${to.table}"`;
	return `ALTER POLICY "${from.name}" ON ${tableNameWithSchema} RENAME TO "${to.name}";`;
});
const alterPolicyConvertor = convertor("alter_policy", (st) => {
	const { policy } = st;
	const tableNameWithSchema = policy.schema !== "public" ? `"${policy.schema}"."${policy.table}"` : `"${policy.table}"`;
	const usingPart = policy.using ? ` USING (${policy.using})` : "";
	const withCheckPart = policy.withCheck ? ` WITH CHECK (${policy.withCheck})` : "";
	const toClause = policy.roles?.map((v) => [
		"current_user",
		"current_role",
		"session_user",
		"public"
	].includes(v) ? v : `"${v}"`).join(", ");
	return `ALTER POLICY "${policy.name}" ON ${tableNameWithSchema} TO ${toClause}${usingPart}${withCheckPart};`;
});
const recreatePolicy = convertor("recreate_policy", (st) => {
	return [dropPolicyConvertor.convert({ policy: st.policy }), createPolicyConvertor.convert({ policy: st.policy })];
});
const toggleRlsConvertor = convertor("alter_rls", (st) => {
	const { schema, name, isRlsEnabled } = st;
	return `ALTER TABLE ${schema !== "public" ? `"${schema}"."${name}"` : `"${name}"`} ${isRlsEnabled ? "ENABLE" : "DISABLE"} ROW LEVEL SECURITY;`;
});
const convertors = [
	createSchemaConvertor,
	dropSchemaConvertor,
	renameSchemaConvertor,
	createViewConvertor,
	dropViewConvertor,
	renameViewConvertor,
	moveViewConvertor,
	alterViewConvertor,
	createTableConvertor,
	dropTableConvertor,
	renameTableConvertor,
	moveTableConvertor,
	addColumnConvertor,
	dropColumnConvertor,
	renameColumnConvertor,
	recreateColumnConvertor,
	alterColumnConvertor,
	createIndexConvertor,
	dropIndexConvertor,
	recreateIndexConvertor,
	renameIndexConvertor,
	addPrimaryKeyConvertor,
	dropPrimaryKeyConvertor,
	recreatePrimaryKeyConvertor,
	createForeignKeyConvertor,
	recreateFKConvertor,
	dropForeignKeyConvertor,
	addCheckConvertor,
	dropCheckConvertor,
	recreateCheckConvertor,
	addUniqueConvertor,
	dropUniqueConvertor,
	alterUniqueConvertor,
	renameConstraintConvertor,
	createEnumConvertor,
	dropEnumConvertor,
	renameEnumConvertor,
	moveEnumConvertor,
	alterEnumConvertor,
	recreateEnumConvertor,
	createSequenceConvertor,
	dropSequenceConvertor,
	renameSequenceConvertor,
	moveSequenceConvertor,
	alterSequenceConvertor,
	createRoleConvertor,
	dropRoleConvertor,
	renameRoleConvertor,
	alterRoleConvertor,
	grantPrivilegeConvertor,
	revokePrivilegeConvertor,
	regrantPrivilegeConvertor,
	createPolicyConvertor,
	dropPolicyConvertor,
	renamePolicyConvertor,
	alterPolicyConvertor,
	recreatePolicy,
	toggleRlsConvertor
];
function fromJson(statements) {
	const grouped = statements.map((statement) => {
		const filtered = convertors.filter((it) => {
			return it.can(statement);
		});
		const convertor = filtered.length === 1 ? filtered[0] : void 0;
		if (!convertor) throw new Error(`No convertor for: ${statement.type} statement`);
		const sqlStatements = convertor.convert(statement);
		return {
			jsonStatement: statement,
			sqlStatements: typeof sqlStatements === "string" ? [sqlStatements] : sqlStatements
		};
	}).filter((it) => it !== null);
	return {
		sqlStatements: grouped.map((it) => it.sqlStatements).flat(),
		groupedStatements: grouped
	};
}
//#endregion
//#region src/dialects/postgres/statements.ts
const prepareStatement = (type, args) => {
	return {
		type,
		...args
	};
};
//#endregion
//#region src/dialects/postgres/diff.ts
const ddlDiff = async (ddl1, ddl2, schemasResolver, enumsResolver, sequencesResolver, policyResolver, roleResolver, privilegesResolver, tablesResolver, columnsResolver, viewsResolver, uniquesResolver, indexesResolver, checksResolver, pksResolver, fksResolver, mode) => {
	const ddl1Copy = createDDL();
	for (const entity of ddl1.entities.list()) ddl1Copy.entities.push(entity);
	const schemasDiff = diff(ddl1, ddl2, "schemas");
	const { created: createdSchemas, deleted: deletedSchemas, renamedOrMoved: renamedSchemas } = await schemasResolver({
		created: schemasDiff.filter((it) => it.$diffType === "create"),
		deleted: schemasDiff.filter((it) => it.$diffType === "drop")
	});
	for (const rename of renamedSchemas) {
		ddl1.entities.update({
			set: { schema: rename.to.name },
			where: { schema: rename.from.name }
		});
		ddl1.fks.update({
			set: { schemaTo: rename.to.name },
			where: { schemaTo: rename.from.name }
		});
	}
	const enumsDiff = diff(ddl1, ddl2, "enums");
	const { created: createdEnums, deleted: deletedEnums, renamedOrMoved: renamedOrMovedEnums } = await enumsResolver({
		created: enumsDiff.filter((it) => it.$diffType === "create"),
		deleted: enumsDiff.filter((it) => it.$diffType === "drop")
	});
	const renamedEnums = renamedOrMovedEnums.filter((it) => it.from.name !== it.to.name);
	const movedEnums = renamedOrMovedEnums.filter((it) => it.from.schema !== it.to.schema);
	for (const rename of renamedEnums) {
		ddl1.enums.update({
			set: {
				name: rename.to.name,
				schema: rename.to.schema
			},
			where: {
				name: rename.from.name,
				schema: rename.from.schema
			}
		});
		ddl1.columns.update({
			set: {
				type: rename.to.name,
				typeSchema: rename.to.schema
			},
			where: {
				type: rename.from.name,
				typeSchema: rename.from.schema
			}
		});
	}
	for (const move of movedEnums) {
		ddl1.enums.update({
			set: { schema: move.to.schema },
			where: {
				name: move.from.name,
				schema: move.from.schema
			}
		});
		ddl1.columns.update({
			set: { typeSchema: move.to.schema },
			where: {
				type: move.from.name,
				typeSchema: move.from.schema
			}
		});
	}
	const sequencesDiff = diff(ddl1, ddl2, "sequences");
	const { created: createdSequences, deleted: deletedSequences, renamedOrMoved: renamedOrMovedSequences } = await sequencesResolver({
		created: sequencesDiff.filter((it) => it.$diffType === "create"),
		deleted: sequencesDiff.filter((it) => it.$diffType === "drop")
	});
	const renamedSequences = renamedOrMovedSequences.filter((it) => it.from.schema === it.to.schema);
	const movedSequences = renamedOrMovedSequences.filter((it) => it.from.schema !== it.to.schema);
	for (const rename of renamedSequences) ddl1.sequences.update({
		set: {
			name: rename.to.name,
			schema: rename.to.schema
		},
		where: {
			name: rename.from.name,
			schema: rename.from.schema
		}
	});
	for (const move of movedSequences) ddl1.sequences.update({
		set: { schema: move.to.schema },
		where: {
			name: move.from.name,
			schema: move.from.schema
		}
	});
	const rolesDiff = diff(ddl1, ddl2, "roles");
	const { created: createdRoles, deleted: deletedRoles, renamedOrMoved: renamedRoles } = await roleResolver({
		created: rolesDiff.filter((it) => it.$diffType === "create"),
		deleted: rolesDiff.filter((it) => it.$diffType === "drop")
	});
	for (const rename of renamedRoles) ddl1.roles.update({
		set: { name: rename.to.name },
		where: { name: rename.from.name }
	});
	const privilegesDiff = diff(ddl1, ddl2, "privileges");
	const { created: createdPrivileges, deleted: deletedPrivileges } = await privilegesResolver({
		created: privilegesDiff.filter((it) => it.$diffType === "create"),
		deleted: privilegesDiff.filter((it) => it.$diffType === "drop")
	});
	const tablesDiff = diff(ddl1, ddl2, "tables");
	const { created: createdTables, deleted: deletedTables, renamedOrMoved: renamedOrMovedTables } = await tablesResolver({
		created: tablesDiff.filter((it) => it.$diffType === "create"),
		deleted: tablesDiff.filter((it) => it.$diffType === "drop")
	});
	const renamedTables = renamedOrMovedTables.filter((it) => it.from.name !== it.to.name);
	const movedTables = renamedOrMovedTables.filter((it) => it.from.schema !== it.to.schema);
	for (const rename of renamedOrMovedTables) {
		ddl1.tables.update({
			set: {
				name: rename.to.name,
				schema: rename.to.schema
			},
			where: {
				name: rename.from.name,
				schema: rename.from.schema
			}
		});
		ddl1.fks.update({
			set: {
				schemaTo: rename.to.schema,
				tableTo: rename.to.name
			},
			where: {
				schemaTo: rename.from.schema,
				tableTo: rename.from.name
			}
		});
		ddl2.fks.update({
			set: {
				schemaTo: rename.to.schema,
				tableTo: rename.to.name
			},
			where: {
				schemaTo: rename.from.schema,
				tableTo: rename.from.name
			}
		});
		ddl1.fks.update({
			set: {
				schema: rename.to.schema,
				table: rename.to.name
			},
			where: {
				schema: rename.from.schema,
				table: rename.from.name
			}
		});
		ddl1.entities.update({
			set: {
				table: rename.to.name,
				schema: rename.to.schema
			},
			where: {
				table: rename.from.name,
				schema: rename.from.schema
			}
		});
		ddl2.entities.update({
			set: {
				table: rename.to.name,
				schema: rename.to.schema
			},
			where: {
				table: rename.from.name,
				schema: rename.from.schema
			}
		});
	}
	const columnsDiff = diff(ddl1, ddl2, "columns");
	const columnRenames = [];
	const columnsToCreate = [];
	const columnsToDelete = [];
	const groupedByTable = groupDiffs(columnsDiff);
	for (let it of groupedByTable) {
		const { created, deleted, renamedOrMoved } = await columnsResolver({
			created: it.inserted,
			deleted: it.deleted
		});
		columnsToCreate.push(...created);
		columnsToDelete.push(...deleted);
		columnRenames.push(...renamedOrMoved);
	}
	for (const rename of columnRenames) {
		ddl1.columns.update({
			set: {
				name: rename.to.name,
				schema: rename.to.schema
			},
			where: {
				name: rename.from.name,
				schema: rename.from.schema
			}
		});
		const update1 = {
			set: { columns: (it) => {
				if (!it.isExpression && it.value === rename.from.name) return {
					...it,
					value: rename.to.name
				};
				return it;
			} },
			where: {
				schema: rename.from.schema,
				table: rename.from.table
			}
		};
		ddl1.indexes.update(update1);
		ddl2.indexes.update(update1);
		const update2 = {
			set: { columns: (it) => {
				return it === rename.from.name ? rename.to.name : it;
			} },
			where: {
				schema: rename.from.schema,
				table: rename.from.table
			}
		};
		ddl1.pks.update(update2);
		ddl2.pks.update(update2);
		const update3 = {
			set: { columns: (it) => {
				return it === rename.from.name ? rename.to.name : it;
			} },
			where: {
				schema: rename.from.schema,
				table: rename.from.table
			}
		};
		ddl1.fks.update(update3);
		ddl2.fks.update(update3);
		const update4 = {
			set: { columnsTo: (it) => {
				return it === rename.from.name ? rename.to.name : it;
			} },
			where: {
				schemaTo: rename.from.schema,
				tableTo: rename.from.table
			}
		};
		ddl1.fks.update(update4);
		ddl2.fks.update(update4);
		const update5 = {
			set: { columns: (it) => {
				return it === rename.from.name ? rename.to.name : it;
			} },
			where: {
				schema: rename.from.schema,
				table: rename.from.table
			}
		};
		ddl1.uniques.update(update5);
		ddl2.uniques.update(update5);
		const update6 = {
			set: { value: rename.to.name },
			where: {
				schema: rename.from.schema,
				table: rename.from.table,
				value: rename.from.name
			}
		};
		ddl1.checks.update(update6);
		ddl2.checks.update(update6);
	}
	preserveEntityNames(ddl1.uniques, ddl2.uniques, mode);
	preserveEntityNames(ddl1.fks, ddl2.fks, mode);
	preserveEntityNames(ddl1.pks, ddl2.pks, mode);
	preserveEntityNames(ddl1.indexes, ddl2.indexes, mode);
	const groupedUniquesDiff = groupDiffs(diff(ddl1, ddl2, "uniques"));
	const uniqueRenames = [];
	const uniqueCreates = [];
	const uniqueDeletes = [];
	for (const entry of groupedUniquesDiff) {
		const { renamedOrMoved: renamed, created, deleted } = await uniquesResolver({
			created: entry.inserted,
			deleted: entry.deleted
		});
		uniqueCreates.push(...created);
		uniqueDeletes.push(...deleted);
		uniqueRenames.push(...renamed);
	}
	for (const rename of uniqueRenames) ddl1.uniques.update({
		set: {
			name: rename.to.name,
			schema: rename.to.schema
		},
		where: {
			name: rename.from.name,
			schema: rename.from.schema
		}
	});
	const groupedChecksDiff = groupDiffs(diff(ddl1, ddl2, "checks"));
	const checkRenames = [];
	const checkCreates = [];
	const checkDeletes = [];
	for (const entry of groupedChecksDiff) {
		const { renamedOrMoved, created, deleted } = await checksResolver({
			created: entry.inserted,
			deleted: entry.deleted
		});
		checkCreates.push(...created);
		checkDeletes.push(...deleted);
		checkRenames.push(...renamedOrMoved);
	}
	for (const rename of checkRenames) ddl1.checks.update({
		set: {
			name: rename.to.name,
			schema: rename.to.schema
		},
		where: {
			name: rename.from.name,
			schema: rename.from.schema
		}
	});
	const groupedIndexesDiff = groupDiffs(diff(ddl1, ddl2, "indexes"));
	const indexesRenames = [];
	const indexesCreates = [];
	const indexesDeletes = [];
	for (const entry of groupedIndexesDiff) {
		const { renamedOrMoved, created, deleted } = await indexesResolver({
			created: entry.inserted,
			deleted: entry.deleted
		});
		indexesCreates.push(...created);
		indexesDeletes.push(...deleted);
		indexesRenames.push(...renamedOrMoved);
	}
	for (const rename of indexesRenames) ddl1.indexes.update({
		set: {
			name: rename.to.name,
			schema: rename.to.schema
		},
		where: {
			name: rename.from.name,
			schema: rename.from.schema
		}
	});
	const groupedPKsDiff = groupDiffs(diff(ddl1, ddl2, "pks"));
	const pksRenames = [];
	const pksCreates = [];
	const pksDeletes = [];
	for (const entry of groupedPKsDiff) {
		const { renamedOrMoved, created, deleted } = await pksResolver({
			created: entry.inserted,
			deleted: entry.deleted
		});
		pksCreates.push(...created);
		pksDeletes.push(...deleted);
		pksRenames.push(...renamedOrMoved);
	}
	for (const rename of pksRenames) ddl1.pks.update({
		set: {
			name: rename.to.name,
			schema: rename.to.schema
		},
		where: {
			name: rename.from.name,
			schema: rename.from.schema
		}
	});
	const groupedFKsDiff = groupDiffs(diff(ddl1, ddl2, "fks"));
	const fksRenames = [];
	const fksCreates = [];
	const fksDeletes = [];
	for (const entry of groupedFKsDiff) {
		const { renamedOrMoved, created, deleted } = await fksResolver({
			created: entry.inserted,
			deleted: entry.deleted
		});
		fksCreates.push(...created);
		fksDeletes.push(...deleted);
		fksRenames.push(...renamedOrMoved);
	}
	for (const rename of fksRenames) ddl1.fks.update({
		set: {
			name: rename.to.name,
			schema: rename.to.schema
		},
		where: {
			name: rename.from.name,
			schema: rename.from.schema
		}
	});
	const policiesDiffGrouped = groupDiffs(diff(ddl1, ddl2, "policies"));
	const policyRenames = [];
	const policyCreates = [];
	const policyDeletes = [];
	for (const entry of policiesDiffGrouped) {
		const { renamedOrMoved, created, deleted } = await policyResolver({
			created: entry.inserted,
			deleted: entry.deleted
		});
		policyCreates.push(...created);
		policyDeletes.push(...deleted);
		policyRenames.push(...renamedOrMoved);
	}
	for (const rename of policyRenames) ddl1.policies.update({
		set: {
			name: rename.to.name,
			schema: rename.to.schema
		},
		where: {
			name: rename.from.name,
			schema: rename.from.schema
		}
	});
	const viewsDiff = diff(ddl1, ddl2, "views");
	const { created: createdViews, deleted: deletedViews, renamedOrMoved: renamedOrMovedViews } = await viewsResolver({
		created: viewsDiff.filter((it) => it.$diffType === "create"),
		deleted: viewsDiff.filter((it) => it.$diffType === "drop")
	});
	const renamedViews = renamedOrMovedViews.filter((it) => it.from.schema === it.to.schema);
	const movedViews = renamedOrMovedViews.filter((it) => it.from.schema !== it.to.schema);
	for (const rename of renamedViews) ddl1.views.update({
		set: {
			name: rename.to.name,
			schema: rename.to.schema
		},
		where: {
			name: rename.from.name,
			schema: rename.from.schema
		}
	});
	for (const move of movedViews) ddl1.views.update({
		set: { schema: move.to.schema },
		where: {
			name: move.from.name,
			schema: move.from.schema
		}
	});
	const alters = diff.alters(ddl1, ddl2);
	const jsonStatements = [];
	const tablesFilter = (type) => {
		return (it) => {
			if (type === "created") return !createdTables.some((t) => t.schema === it.schema && t.name === it.table);
			else return !deletedTables.some((t) => t.schema === it.schema && t.name === it.table);
		};
	};
	const jsonCreateIndexes = indexesCreates.map((index) => prepareStatement("create_index", { index }));
	const jsonDropIndexes = indexesDeletes.filter(tablesFilter("deleted")).map((index) => prepareStatement("drop_index", { index }));
	const jsonRenameIndexes = indexesRenames.map((r) => {
		return prepareStatement("rename_index", {
			schema: r.to.schema,
			from: r.from.name,
			to: r.to.name
		});
	});
	const indexesAlters = alters.filter((it) => {
		if (it.entityType !== "indexes") return false;
		delete it.concurrently;
		return ddl2.indexes.hasDiff(it);
	});
	const jsonRecreateIndex = [];
	for (const idx of indexesAlters) {
		const forWhere = !!idx.where && (idx.where.from !== null && idx.where.to !== null ? mode !== "push" : true);
		const forColumns = !!idx.columns && (idx.columns.from.length === idx.columns.to.length ? mode !== "push" : true);
		if (idx.isUnique || idx.concurrently || idx.method || idx.with || forColumns || forWhere) {
			const index = ddl2.indexes.one({
				schema: idx.schema,
				table: idx.table,
				name: idx.name
			});
			const prevIndex = ddl1.indexes.one({
				schema: idx.schema,
				table: idx.table,
				name: idx.name
			});
			const shouldDrop = !!prevIndex && !columnsToDelete.some((col) => col.schema === idx.schema && col.table === idx.table && prevIndex.columns.some((idxCol) => idxCol.value === col.name));
			jsonRecreateIndex.push(prepareStatement("recreate_index", {
				index,
				diff: idx,
				shouldDrop
			}));
		}
	}
	const jsonDropTables = deletedTables.map((it) => {
		const oldSchema = renamedSchemas.find((x) => x.to.name === it.schema);
		const key = oldSchema ? `"${oldSchema.from.name}"."${it.name}"` : `"${it.schema}"."${it.name}"`;
		return prepareStatement("drop_table", {
			table: tableFromDDL(it, ddl2),
			key
		});
	});
	const jsonRenameTables = renamedTables.map((it) => prepareStatement("rename_table", {
		schema: it.from.schema,
		from: it.from.name,
		to: it.to.name
	}));
	const jsonRenameColumnsStatements = columnRenames.map((it) => prepareStatement("rename_column", it));
	const jsonDropColumnsStatemets = columnsToDelete.filter(tablesFilter("deleted")).map((it) => prepareStatement("drop_column", { column: it }));
	const jsonAddColumnsStatemets = columnsToCreate.filter(tablesFilter("created")).map((it) => prepareStatement("add_column", {
		column: it,
		isPK: false,
		isCompositePK: ddl2.pks.one({
			schema: it.schema,
			table: it.table,
			columns: { CONTAINS: it.name }
		}) !== null
	}));
	const columnAlters = alters.filter((it) => it.entityType === "columns").filter((it) => {
		if (it.default && (it.$left.type === "json" && it.$right.type === "json" || it.$left.type === "jsonb" && it.$right.type === "jsonb")) {
			if (it.default.from !== null && it.default.to !== null) {
				const parsedLeft = parse(trimChar(it.default.from, "'"));
				const parsedRight = parse(trimChar(it.default.to, "'"));
				try {
					deepStrictEqual(parsedLeft, parsedRight);
					delete it.default;
				} catch {}
			}
		}
		if (!it.type && it.default && defaultsCommutative(it.default, it.$right.type, it.$right.dimensions)) delete it.default;
		if (it.type) {
			if (it.type.from === it.type.to.replace("numeric", "decimal") || it.type.to === it.type.from.replace("numeric", "decimal")) delete it.type;
		}
		if (it.type && it.$right.type.startsWith("geometry(point") && it.$left.type.startsWith("geometry(point")) {
			const leftSrid = it.$left.type.split(",")[1]?.replace(")", "");
			const rightSrid = it.$right.type.split(",")[1]?.replace(")", "");
			if (typeof leftSrid === "undefined" && rightSrid === "0") delete it.type;
			if (typeof rightSrid === "undefined" && leftSrid === "0") delete it.type;
		}
		if (it.type && it.type.from.replace(",0)", ")") === it.type.to) delete it.type;
		return ddl2.columns.hasDiff(it);
	});
	const jsonAlteredUniqueConstraints = alters.filter((it) => it.entityType === "uniques").filter((it) => {
		if (it.nameExplicit) delete it.nameExplicit;
		return ddl2.uniques.hasDiff(it);
	}).map((it) => prepareStatement("alter_unique", { diff: it }));
	const jsonAddedUniqueConstraints = uniqueCreates.filter(tablesFilter("created")).map((it) => prepareStatement("add_unique", { unique: it }));
	const jsonDropUniqueConstraints = uniqueDeletes.filter(tablesFilter("deleted")).map((it) => prepareStatement("drop_unique", { unique: it }));
	const jsonRenamedUniqueConstraints = uniqueRenames.map((it) => prepareStatement("rename_constraint", {
		schema: it.to.schema,
		table: it.to.table,
		from: it.from.name,
		to: it.to.name
	}));
	const jsonAddPrimaryKeys = pksCreates.filter(tablesFilter("created")).map((it) => prepareStatement("add_pk", { pk: it }));
	const jsonDropPrimaryKeys = pksDeletes.filter(tablesFilter("deleted")).map((it) => prepareStatement("drop_pk", { pk: it }));
	const jsonRenamePrimaryKey = pksRenames.map((it) => {
		return prepareStatement("rename_constraint", {
			schema: it.to.schema,
			table: it.to.table,
			from: it.from.name,
			to: it.to.name
		});
	});
	const jsonSetTableSchemas = movedTables.map((it) => prepareStatement("move_table", {
		name: it.to.name,
		from: it.from.schema,
		to: it.to.schema
	}));
	const jsonCreatedCheckConstraints = checkCreates.filter(tablesFilter("created")).map((it) => prepareStatement("add_check", { check: it }));
	const jsonDropCheckConstraints = checkDeletes.filter(tablesFilter("deleted")).map((it) => prepareStatement("drop_check", { check: it }));
	const jsonRenamedCheckConstraints = checkRenames.map((it) => prepareStatement("rename_constraint", {
		schema: it.to.schema,
		table: it.to.table,
		from: it.from.name,
		to: it.to.name
	}));
	const alteredPKs = alters.filter((it) => it.entityType === "pks").filter((it) => {
		return !!it.columns;
	});
	const alteredChecks = alters.filter((it) => it.entityType === "checks");
	const jsonAlteredPKs = alteredPKs.map((it) => {
		const deleted = columnsToDelete.some((x) => it.columns?.from.includes(x.name));
		return prepareStatement("alter_pk", {
			diff: it,
			pk: it.$right,
			deleted
		});
	});
	const jsonRecreateFKs = alters.filter((it) => it.entityType === "fks").filter((x) => {
		if (x.nameExplicit) delete x.nameExplicit;
		return ddl2.fks.hasDiff(x);
	}).map((it) => prepareStatement("recreate_fk", {
		fk: it.$right,
		diff: it
	}));
	const jsonCreateFKs = fksCreates.map((it) => prepareStatement("create_fk", { fk: it }));
	const jsonDropFKs = fksDeletes.filter((fk) => {
		const fromDeletedTable = deletedTables.some((x) => x.schema === fk.schema && x.name === fk.table);
		const toDeletedTable = fk.table !== fk.tableTo && deletedTables.some((x) => x.schema === fk.schemaTo && x.name === fk.tableTo);
		if (fromDeletedTable && !toDeletedTable) return false;
		return true;
	}).map((it) => prepareStatement("drop_fk", { fk: it }));
	const jsonRenameReferences = fksRenames.map((it) => prepareStatement("rename_constraint", {
		schema: it.to.schema,
		table: it.to.table,
		from: it.from.name,
		to: it.to.name
	}));
	const jsonAlterCheckConstraints = alteredChecks.filter((it) => it.value && mode !== "push").map((it) => prepareStatement("alter_check", { diff: it }));
	const jsonCreatePoliciesStatements = policyCreates.map((it) => prepareStatement("create_policy", { policy: it }));
	const jsonDropPoliciesStatements = policyDeletes.map((it) => prepareStatement("drop_policy", { policy: it }));
	const jsonRenamePoliciesStatements = policyRenames.map((it) => prepareStatement("rename_policy", it));
	const jsonAlterOrRecreatePoliciesStatements = alters.filter((it) => it.entityType === "policies").filter((it) => {
		if (it.withCheck && it.withCheck.from && it.withCheck.to) {
			if (it.withCheck.from === `(${it.withCheck.to})` || it.withCheck.to === `(${it.withCheck.from})`) delete it.withCheck;
		}
		return ddl1.policies.hasDiff(it);
	}).filter((it) => {
		return it.as || it.for || it.roles || !((it.using || it.withCheck) && mode === "push");
	}).map((it) => {
		const to = ddl2.policies.one({
			schema: it.schema,
			table: it.table,
			name: it.name
		});
		if (it.for || it.as) return prepareStatement("recreate_policy", {
			diff: it,
			policy: to
		});
		else return prepareStatement("alter_policy", {
			diff: it,
			policy: to
		});
	});
	const rlsAlters = alters.filter((it) => it.entityType === "tables").filter((it) => it.isRlsEnabled);
	const jsonAlterRlsStatements = rlsAlters.map((it) => prepareStatement("alter_rls", {
		schema: it.schema,
		name: it.name,
		isRlsEnabled: it.isRlsEnabled?.to || false
	}));
	for (const it of policyDeletes) {
		if (rlsAlters.some((alter) => alter.schema === it.schema && alter.name === it.table)) continue;
		const had = ddl1.policies.list({
			schema: it.schema,
			table: it.table
		}).length;
		const has = ddl2.policies.list({
			schema: it.schema,
			table: it.table
		}).length;
		const prevTable = ddl1.tables.one({
			schema: it.schema,
			name: it.table
		});
		if (ddl2.tables.one({
			schema: it.schema,
			name: it.table
		}) !== null && had > 0 && has === 0 && prevTable && prevTable.isRlsEnabled === false && !jsonAlterRlsStatements.some((st) => st.schema === it.schema && st.name === it.table)) jsonAlterRlsStatements.push(prepareStatement("alter_rls", {
			schema: it.schema,
			name: it.table,
			isRlsEnabled: false
		}));
	}
	for (const it of policyCreates) {
		if (rlsAlters.some((alter) => alter.schema === it.schema && alter.name === it.table)) continue;
		if (createdTables.some((t) => t.schema === it.schema && t.name === it.table)) continue;
		if (jsonAlterRlsStatements.some((st) => st.schema === it.schema && st.name === it.table)) continue;
		const had = ddl1.policies.list({
			schema: it.schema,
			table: it.table
		}).length;
		const has = ddl2.policies.list({
			schema: it.schema,
			table: it.table
		}).length;
		const table = ddl2.tables.one({
			schema: it.schema,
			name: it.table
		});
		if (table !== null && had === 0 && has > 0 && !table.isRlsEnabled) jsonAlterRlsStatements.push(prepareStatement("alter_rls", {
			schema: it.schema,
			name: it.table,
			isRlsEnabled: true
		}));
	}
	const jsonCreateEnums = createdEnums.map((it) => prepareStatement("create_enum", { enum: it }));
	const jsonDropEnums = deletedEnums.map((it) => prepareStatement("drop_enum", { enum: it }));
	const jsonMoveEnums = movedEnums.map((it) => prepareStatement("move_enum", it));
	const jsonRenameEnums = renamedEnums.map((it) => prepareStatement("rename_enum", {
		schema: it.to.schema,
		from: it.from.name,
		to: it.to.name
	}));
	const enumsAlters = alters.filter((it) => it.entityType === "enums");
	const recreateEnums = [];
	const jsonAlterEnums = [];
	for (const alter of enumsAlters) {
		const values = alter.values;
		const res = diffStringArrays(values.from, values.to);
		const e = {
			...alter,
			values: values.to
		};
		if (res.some((it) => it.type === "removed")) {
			const columns = ddl1.columns.list({
				typeSchema: alter.schema,
				type: alter.name
			}).map((it) => {
				const c2 = ddl2.columns.one({
					schema: it.schema,
					table: it.table,
					name: it.name
				});
				if (c2 === null) return null;
				const def = {
					right: c2.default,
					left: it.default
				};
				return {
					...it,
					default: def
				};
			}).filter((x) => x !== null);
			recreateEnums.push(prepareStatement("recreate_enum", {
				to: e,
				columns,
				from: alter.$left
			}));
		} else jsonAlterEnums.push(prepareStatement("alter_enum", {
			diff: res,
			to: e,
			from: alter.$left
		}));
	}
	const jsonAlterColumns = columnAlters.filter((it) => !(it.generated && it.generated.to !== null)).filter((it) => {
		if (it.default && recreateEnums.some((x) => x.columns.some((c) => it.schema === c.schema && it.table === c.table && it.name === c.name))) delete it.default;
		if (it.notNull && it.notNull.to && (it.$right.generated || it.$right.identity)) delete it.notNull;
		const pkIn2 = ddl2.pks.one({
			schema: it.schema,
			table: it.table,
			columns: { CONTAINS: it.name }
		});
		if (it.notNull && pkIn2) delete it.notNull;
		return ddl2.columns.hasDiff(it);
	}).map((it) => {
		const column = it.$right;
		const wasSerial = isSerialType(it.$left.type);
		const toSerial = !isSerialType(it.$left.type) && isSerialType(it.$right.type);
		return prepareStatement("alter_column", {
			diff: it,
			to: column,
			isEnum: ddl2.enums.one({
				schema: column.typeSchema ?? "public",
				name: column.type
			}) !== null,
			wasEnum: (it.type && ddl1.enums.one({
				schema: column.typeSchema ?? "public",
				name: it.type.from
			}) !== null) ?? false,
			wasSerial,
			toSerial
		});
	});
	const createSequences = createdSequences.map((it) => prepareStatement("create_sequence", { sequence: it }));
	const dropSequences = deletedSequences.map((it) => prepareStatement("drop_sequence", { sequence: it }));
	const moveSequences = movedSequences.map((it) => prepareStatement("move_sequence", it));
	const renameSequences = renamedSequences.map((it) => prepareStatement("rename_sequence", it));
	const jsonAlterSequences = alters.filter((it) => it.entityType === "sequences").map((it) => prepareStatement("alter_sequence", {
		diff: it,
		sequence: it.$right
	}));
	const jsonCreateRoles = createdRoles.map((it) => prepareStatement("create_role", { role: it }));
	const jsonDropRoles = deletedRoles.map((it) => prepareStatement("drop_role", { role: it }));
	const jsonRenameRoles = renamedRoles.map((it) => prepareStatement("rename_role", it));
	const jsonAlterRoles = alters.filter((it) => it.entityType === "roles").map((it) => prepareStatement("alter_role", {
		diff: it,
		role: it.$right
	}));
	const jsonGrantPrivileges = createdPrivileges.map((it) => prepareStatement("grant_privilege", { privilege: it }));
	const jsonRevokePrivileges = deletedPrivileges.map((it) => prepareStatement("revoke_privilege", { privilege: it }));
	const jsonAlterPrivileges = alters.filter((it) => it.entityType === "privileges").map((it) => prepareStatement("regrant_privilege", {
		privilege: it.$right,
		diff: it
	}));
	const createSchemas = createdSchemas.map((it) => prepareStatement("create_schema", it));
	const dropSchemas = deletedSchemas.map((it) => prepareStatement("drop_schema", it));
	const renameSchemas = renamedSchemas.map((it) => prepareStatement("rename_schema", it));
	const createTables = createdTables.map((it) => prepareStatement("create_table", { table: tableFromDDL(it, ddl2) }));
	const createViews = createdViews.map((it) => prepareStatement("create_view", { view: it }));
	const jsonDropViews = deletedViews.map((it) => prepareStatement("drop_view", {
		view: it,
		cause: null
	}));
	const jsonRenameViews = renamedViews.map((it) => prepareStatement("rename_view", it));
	const jsonMoveViews = movedViews.map((it) => prepareStatement("move_view", {
		fromSchema: it.from.schema,
		toSchema: it.to.schema,
		view: it.to
	}));
	const viewsAlters = alters.filter((it) => {
		if (it.entityType !== "views") return false;
		if (it.definition && mode === "push") delete it.definition;
		if (it.using && !it.using.to && it.using.from === defaults.accessMethod) delete it.using;
		if (mode === "push" && it.tablespace && it.tablespace.from === null && it.tablespace.to === defaults.tablespace) delete it.tablespace;
		return ddl2.views.hasDiff(it);
	}).map((it) => ({
		diff: it,
		view: it.$right
	}));
	const jsonAlterViews = viewsAlters.filter((it) => !it.diff.definition).map((it) => {
		return prepareStatement("alter_view", {
			diff: it.diff,
			view: it.view
		});
	});
	viewsAlters.filter((it) => it.diff.definition).forEach((entry) => {
		const it = entry.view;
		const schemaRename = renamedSchemas.find((r) => r.to.name === it.schema);
		const schema = schemaRename ? schemaRename.from.name : it.schema;
		const viewRename = renamedViews.find((r) => r.to.schema === it.schema && r.to.name === it.name);
		const name = viewRename ? viewRename.from.name : it.name;
		const from = ddl1Copy.views.one({
			schema,
			name
		});
		if (!from) throw new Error(`
				Missing view in original ddl:
				${it.schema}:${it.name}
				${schema}:${name}
				`);
		jsonDropViews.push(prepareStatement("drop_view", {
			view: it,
			cause: from
		}));
		createViews.push(prepareStatement("create_view", { view: it }));
	});
	const jsonRecreateColumns = columnAlters.filter((it) => it.generated && it.generated.to !== null).filter((it) => {
		return !(it.generated?.to && it.generated.from && mode === "push");
	}).map((it) => {
		const indexes = ddl2.indexes.list({
			table: it.table,
			schema: it.schema
		}).filter((index) => index.columns.some((column) => trimChar(column.value, "`") === it.name));
		for (const index of indexes) jsonCreateIndexes.push({
			type: "create_index",
			index
		});
		const uniques = ddl2.uniques.list({
			table: it.table,
			schema: it.schema,
			columns: { CONTAINS: it.name }
		});
		for (const unique of uniques) jsonAddedUniqueConstraints.push({
			type: "add_unique",
			unique
		});
		const fksFrom = ddl2.fks.list({
			table: it.table,
			schema: it.schema,
			columns: { CONTAINS: it.name }
		});
		const fksTo = ddl2.fks.list({
			tableTo: it.table,
			schemaTo: it.schema,
			columnsTo: { CONTAINS: it.name }
		});
		for (const fkFrom of fksFrom) jsonDropFKs.push({
			type: "drop_fk",
			fk: fkFrom
		});
		for (const fkTo of fksTo) {
			jsonDropFKs.push({
				type: "drop_fk",
				fk: fkTo
			});
			jsonCreateFKs.push({
				type: "create_fk",
				fk: fkTo
			});
		}
		return prepareStatement("recreate_column", {
			diff: it,
			isPK: ddl2.pks.one({
				schema: it.schema,
				table: it.table,
				columns: [it.name]
			}) !== null
		});
	});
	jsonStatements.push(...createSchemas);
	jsonStatements.push(...renameSchemas);
	jsonStatements.push(...jsonCreateEnums);
	jsonStatements.push(...jsonMoveEnums);
	jsonStatements.push(...jsonRenameEnums);
	jsonStatements.push(...jsonAlterEnums);
	jsonStatements.push(...createSequences);
	jsonStatements.push(...moveSequences);
	jsonStatements.push(...renameSequences);
	jsonStatements.push(...jsonAlterSequences);
	jsonStatements.push(...jsonRenameRoles);
	jsonStatements.push(...jsonDropRoles);
	jsonStatements.push(...jsonCreateRoles);
	jsonStatements.push(...jsonAlterRoles);
	jsonStatements.push(...jsonRevokePrivileges);
	jsonStatements.push(...jsonGrantPrivileges);
	jsonStatements.push(...jsonAlterPrivileges);
	jsonStatements.push(...createTables);
	jsonStatements.push(...jsonDropViews);
	jsonStatements.push(...jsonRenameViews);
	jsonStatements.push(...jsonMoveViews);
	jsonStatements.push(...jsonAlterViews);
	jsonStatements.push(...jsonRenameTables);
	jsonStatements.push(...jsonDropPoliciesStatements);
	jsonStatements.push(...jsonDropFKs);
	jsonStatements.push(...jsonDropTables);
	jsonStatements.push(...jsonAlterRlsStatements);
	jsonStatements.push(...jsonSetTableSchemas);
	jsonStatements.push(...jsonRenameColumnsStatements);
	jsonStatements.push(...jsonDropUniqueConstraints);
	jsonStatements.push(...jsonDropCheckConstraints);
	jsonStatements.push(...jsonRenamedCheckConstraints);
	jsonStatements.push(...jsonRenameIndexes);
	jsonStatements.push(...jsonDropIndexes);
	jsonStatements.push(...jsonDropPrimaryKeys);
	jsonStatements.push(...jsonRenameReferences);
	jsonStatements.push(...jsonAddColumnsStatemets);
	jsonStatements.push(...jsonAddPrimaryKeys);
	jsonStatements.push(...jsonRenamePrimaryKey);
	jsonStatements.push(...recreateEnums);
	jsonStatements.push(...jsonRecreateColumns);
	jsonStatements.push(...jsonDropColumnsStatemets);
	jsonStatements.push(...jsonAlteredPKs);
	jsonStatements.push(...jsonAlterColumns);
	jsonStatements.push(...jsonRecreateIndex);
	jsonStatements.push(...jsonRenamedUniqueConstraints);
	jsonStatements.push(...jsonAddedUniqueConstraints);
	jsonStatements.push(...jsonAlteredUniqueConstraints);
	jsonStatements.push(...jsonCreateIndexes);
	jsonStatements.push(...jsonCreateFKs);
	jsonStatements.push(...jsonRecreateFKs);
	jsonStatements.push(...jsonCreatedCheckConstraints);
	jsonStatements.push(...jsonAlterCheckConstraints);
	jsonStatements.push(...createViews);
	jsonStatements.push(...jsonRenamePoliciesStatements);
	jsonStatements.push(...jsonCreatePoliciesStatements);
	jsonStatements.push(...jsonAlterOrRecreatePoliciesStatements);
	jsonStatements.push(...jsonDropEnums);
	jsonStatements.push(...dropSequences);
	jsonStatements.push(...dropSchemas);
	const { groupedStatements, sqlStatements } = fromJson(jsonStatements);
	return {
		statements: jsonStatements,
		sqlStatements,
		groupedStatements,
		renames: prepareMigrationRenames([
			...renameSchemas,
			...renamedEnums,
			...renamedOrMovedTables,
			...columnRenames,
			...uniqueRenames,
			...checkRenames,
			...indexesRenames,
			...pksRenames,
			...fksRenames,
			...policyRenames,
			...renamedOrMovedViews,
			...renamedRoles,
			...renamedOrMovedSequences
		])
	};
};
//#endregion
//#region src/dialects/postgres/drizzle.ts
const policyFrom = (policy, dialect) => {
	const mappedTo = !policy.to ? ["public"] : typeof policy.to === "string" ? [policy.to] : is(policy.to, PgRole) ? [policy.to.name] : Array.isArray(policy.to) ? policy.to.map((it) => {
		if (typeof it === "string") return it;
		else if (is(it, PgRole)) return it.name;
		return "";
	}) : "";
	const policyAs = policy.as?.toUpperCase() ?? "PERMISSIVE";
	const policyFor = policy.for?.toUpperCase() ?? "ALL";
	const policyTo = mappedTo.sort();
	const policyUsing = is(policy.using, SQL) ? dialect.sqlToQuery(policy.using).sql : null;
	const withCheck = is(policy.withCheck, SQL) ? dialect.sqlToQuery(policy.withCheck).sql : null;
	return {
		name: policy.name,
		as: policyAs,
		for: policyFor,
		roles: policyTo,
		using: policyUsing,
		withCheck
	};
};
const unwrapColumn = (column) => {
	const dimensions = column.dimensions ?? 0;
	const baseColumn = column;
	const isEnum = is(baseColumn, PgEnumColumn) || is(baseColumn, PgEnumObjectColumn);
	const typeSchema = isEnum ? baseColumn.enum.schema || "public" : null;
	let sqlBaseType = baseColumn.getSQLType();
	sqlBaseType = sqlBaseType.replace(", ", ",");
	sqlBaseType = sqlBaseType.startsWith("timestamp (") ? sqlBaseType.replace("timestamp (", "timestamp(") : sqlBaseType;
	const { type, options } = splitSqlType(sqlBaseType);
	return {
		baseColumn,
		dimensions,
		isEnum,
		typeSchema,
		sqlType: dimensions > 0 ? `${sqlBaseType}${"[]".repeat(dimensions)}` : sqlBaseType,
		baseType: type,
		options
	};
};
const transformOnUpdateDelete = (on) => {
	if (on === "no action") return "NO ACTION";
	if (on === "cascade") return "CASCADE";
	if (on === "restrict") return "RESTRICT";
	if (on === "set default") return "SET DEFAULT";
	if (on === "set null") return "SET NULL";
	assertUnreachable(on);
};
const defaultFromColumn = (base, def, dimensions, dialect) => {
	if (typeof def === "undefined") return null;
	if (is(def, SQL)) {
		let sql = dialect.sqlToQuery(def).sql;
		sql = trimDefaultValueSuffix(sql);
		return sql;
	}
	const { baseColumn, isEnum } = unwrapColumn(base);
	const grammarType = typeFor(base.getSQLType(), isEnum);
	if (is(baseColumn, PgPointTuple) || is(baseColumn, PgPointObject)) return dimensions > 0 && Array.isArray(def) ? def.flat(5).length === 0 ? "'{}'" : Point.defaultArrayFromDrizzle(def, dimensions, baseColumn.mode) : Point.defaultFromDrizzle(def, baseColumn.mode);
	if (is(baseColumn, PgLineABC) || is(baseColumn, PgLineTuple)) return dimensions > 0 && Array.isArray(def) ? def.flat(5).length === 0 ? "'{}'" : Line.defaultArrayFromDrizzle(def, dimensions, baseColumn.mode) : Line.defaultFromDrizzle(def, baseColumn.mode);
	if (is(baseColumn, PgGeometry) || is(baseColumn, PgGeometryObject)) return dimensions > 0 && Array.isArray(def) ? def.flat(5).length === 0 ? "'{}'" : GeometryPoint.defaultArrayFromDrizzle(def, dimensions, baseColumn.mode, baseColumn.srid) : GeometryPoint.defaultFromDrizzle(def, baseColumn.mode, baseColumn.srid);
	if (dimensions > 0 && Array.isArray(def)) {
		if (def.flat(5).length === 0) return "'{}'";
		return grammarType.defaultArrayFromDrizzle(def, dimensions);
	}
	return grammarType.defaultFromDrizzle(def);
};
const fromDrizzleSchema = (schema, filter) => {
	const dialect = new PgDialect();
	const errors = [];
	const warnings = [];
	const res = {
		indexes: [],
		pks: [],
		fks: [],
		uniques: [],
		checks: [],
		columns: [],
		policies: [],
		enums: [],
		roles: [],
		privileges: [],
		schemas: [],
		sequences: [],
		tables: [],
		viewColumns: [],
		views: []
	};
	res.schemas = schema.schemas.filter((it) => {
		return !it.isExisting && it.schemaName !== "public" && filter({
			type: "schema",
			name: it.schemaName
		});
	}).map((it) => ({
		entityType: "schemas",
		name: it.schemaName
	}));
	const tableConfigPairs = schema.tables.map((it) => {
		return {
			config: getTableConfig(it),
			table: it
		};
	}).filter((x) => {
		return filter({
			type: "table",
			schema: x.config.schema ?? "public",
			name: x.config.name
		});
	});
	for (const policy of schema.policies) {
		if (!("_linkedTable" in policy) || typeof policy._linkedTable === "undefined") {
			warnings.push({
				type: "policy_not_linked",
				policy: policy.name
			});
			continue;
		}
		const { schema: configSchema, name: tableName } = getTableConfig(policy._linkedTable);
		if (!filter({
			type: "table",
			schema: configSchema ?? "public",
			name: tableName
		})) continue;
		const p = policyFrom(policy, dialect);
		res.policies.push({
			entityType: "policies",
			schema: configSchema ?? "public",
			table: tableName,
			name: p.name,
			as: p.as,
			for: p.for,
			roles: p.roles,
			using: p.using,
			withCheck: p.withCheck
		});
	}
	res.tables = tableConfigPairs.map((it) => {
		const config = it.config;
		const schema = config.schema ?? "public";
		const isRlsEnabled = config.enableRLS || config.policies.length > 0 || res.policies.some((x) => x.schema === schema && x.table === config.name);
		return {
			entityType: "tables",
			schema,
			name: config.name,
			isRlsEnabled
		};
	});
	for (const { table, config } of tableConfigPairs) {
		const { name: tableName, columns: drizzleColumns, indexes: drizzleIndexes, foreignKeys: drizzleFKs, checks: drizzleChecks, schema: drizzleSchema, primaryKeys: drizzlePKs, uniqueConstraints: drizzleUniques, policies: drizzlePolicies } = config;
		const schema = drizzleSchema || "public";
		res.columns.push(...drizzleColumns.map((column) => {
			const { name } = column;
			const isPk = column.primary || config.primaryKeys.find((pk) => pk.columns.some((col) => col.name ? col.name === column.name : col.keyAsName === column.keyAsName)) !== void 0;
			const notNull = column.notNull || isPk;
			const generated = column.generated;
			const identity = column.generatedIdentity;
			const increment = stringFromIdentityProperty(identity?.sequenceOptions?.increment) ?? "1";
			const minValue = stringFromIdentityProperty(identity?.sequenceOptions?.minValue) ?? (parseFloat(increment) < 0 ? minRangeForIdentityBasedOn(column.columnType) : "1");
			const maxValue = stringFromIdentityProperty(identity?.sequenceOptions?.maxValue) ?? (parseFloat(increment) < 0 ? "-1" : maxRangeForIdentityBasedOn(column.getSQLType()));
			const startWith = stringFromIdentityProperty(identity?.sequenceOptions?.startWith) ?? (parseFloat(increment) < 0 ? maxValue : minValue);
			const cache = Number(stringFromIdentityProperty(identity?.sequenceOptions?.cache) ?? 1);
			const generatedValue = generated ? {
				as: is(generated.as, SQL) ? dialect.sqlToQuery(generated.as).sql : typeof generated.as === "function" ? dialect.sqlToQuery(generated.as()).sql : String(generated.as),
				type: "stored"
			} : null;
			const identityValue = identity ? {
				type: identity.type,
				name: identity.sequenceName ?? `${tableName}_${name}_seq`,
				increment,
				startWith,
				minValue,
				maxValue,
				cache,
				cycle: identity?.sequenceOptions?.cycle ?? false
			} : null;
			const { baseColumn, dimensions, typeSchema, sqlType } = unwrapColumn(column);
			const columnDefault = defaultFromColumn(baseColumn, column.default, dimensions, dialect);
			return {
				entityType: "columns",
				schema,
				table: tableName,
				name,
				type: sqlType.replaceAll("[]", ""),
				typeSchema: typeSchema ?? null,
				dimensions,
				pk: column.primary,
				pkName: null,
				notNull,
				default: columnDefault,
				generated: generatedValue,
				unique: column.isUnique,
				uniqueName: column.uniqueName ?? null,
				uniqueNullsNotDistinct: column.uniqueType === "not distinct",
				identity: identityValue
			};
		}));
		res.pks.push(...drizzlePKs.map((pk) => {
			const columnNames = pk.columns.map((c) => c.name);
			return {
				entityType: "pks",
				schema,
				table: tableName,
				name: pk.name || defaultNameForPK(tableName),
				columns: columnNames,
				nameExplicit: pk.isNameExplicit
			};
		}));
		res.uniques.push(...drizzleUniques.map((unq) => {
			const columnNames = unq.columns.map((c) => c.name);
			return {
				entityType: "uniques",
				schema,
				table: tableName,
				name: unq.isNameExplicit ? unq.name : uniqueKeyName(table, columnNames),
				nameExplicit: unq.isNameExplicit,
				nullsNotDistinct: unq.nullsNotDistinct,
				columns: columnNames
			};
		}));
		res.fks.push(...drizzleFKs.map((fk) => {
			const onDelete = fk.onDelete;
			const onUpdate = fk.onUpdate;
			const reference = fk.reference();
			const tableTo = getTableName(reference.foreignTable);
			const schemaTo = getTableConfig(reference.foreignTable).schema || "public";
			const columnsFrom = reference.columns.map((it) => it.name);
			const columnsTo = reference.foreignColumns.map((it) => it.name);
			return {
				entityType: "fks",
				schema,
				table: tableName,
				name: fk.isNameExplicit() ? fk.getName() : defaultNameForFK(tableName, columnsFrom, tableTo, columnsTo),
				nameExplicit: fk.isNameExplicit(),
				tableTo,
				schemaTo,
				columns: columnsFrom,
				columnsTo,
				onDelete: onDelete ? transformOnUpdateDelete(onDelete) : null,
				onUpdate: onUpdate ? transformOnUpdateDelete(onUpdate) : null
			};
		}));
		for (const index of drizzleIndexes) {
			const columns = index.config.columns;
			for (const column of columns) {
				if (is(column, IndexedColumn) && column.type !== "PgVector") continue;
				if (is(column, SQL) && !index.config.name) {
					errors.push({
						type: "index_no_name",
						schema,
						table: getTableName(index.config.table),
						sql: dialect.sqlToQuery(column).sql
					});
					continue;
				}
				if (is(column, IndexedColumn) && column.type === "PgVector" && !column.indexConfig.opClass) {
					const columnName = column.name;
					errors.push({
						type: "pgvector_index_noop",
						table: tableName,
						column: columnName,
						indexName: index.config.name,
						method: index.config.method
					});
				}
			}
		}
		res.indexes.push(...drizzleIndexes.map((value) => {
			const columns = value.config.columns;
			let indexColumnNames = columns.map((it) => {
				return it.name;
			});
			const name = value.config.name ?? indexName(tableName, indexColumnNames);
			let indexColumns = columns.map((it) => {
				if (is(it, SQL)) return {
					value: dialect.sqlToQuery(it, "indexes").sql,
					isExpression: true,
					asc: true,
					nullsFirst: false,
					opclass: null
				};
				else {
					it = it;
					let nullsFirst = false;
					let asc = it.indexConfig?.order ? it.indexConfig.order === "asc" : true;
					if (!asc && !it.indexConfig?.nulls) nullsFirst = true;
					else nullsFirst = it.indexConfig?.nulls ? it.indexConfig.nulls === "first" : nullsFirst;
					return {
						value: it.name,
						isExpression: false,
						asc,
						nullsFirst,
						opclass: it.indexConfig?.opClass ? {
							name: it.indexConfig.opClass,
							default: false
						} : null
					};
				}
			});
			const withOpt = Object.entries(value.config.with || {}).map((it) => `${it[0]}=${it[1]}`).join(", ");
			let where = value.config.where ? dialect.sqlToQuery(value.config.where.inlineParams(), "indexes").sql : "";
			where = where === "true" ? "" : where;
			return {
				entityType: "indexes",
				schema,
				table: tableName,
				name,
				nameExplicit: value.isNameExplicit,
				columns: indexColumns,
				isUnique: value.config.unique,
				where: where ? where : null,
				concurrently: value.config.concurrently ?? false,
				method: value.config.method ?? "btree",
				with: withOpt,
				forPK: false,
				forUnique: false
			};
		}));
		res.policies.push(...drizzlePolicies.map((policy) => {
			const p = policyFrom(policy, dialect);
			return {
				entityType: "policies",
				schema,
				table: tableName,
				name: p.name,
				as: p.as,
				for: p.for,
				roles: p.roles,
				using: p.using,
				withCheck: p.withCheck
			};
		}));
		res.checks.push(...drizzleChecks.map((check) => {
			const value = dialect.sqlToQuery(check.value.inlineParams(), "indexes").sql;
			return {
				entityType: "checks",
				schema,
				table: tableName,
				name: check.name,
				value
			};
		}));
	}
	for (const sequence of schema.sequences) {
		const name = sequence.seqName;
		const increment = stringFromIdentityProperty(sequence.seqOptions?.increment) ?? "1";
		const minValue = stringFromIdentityProperty(sequence.seqOptions?.minValue) ?? (parseFloat(increment) < 0 ? "-9223372036854775808" : "1");
		const maxValue = stringFromIdentityProperty(sequence.seqOptions?.maxValue) ?? (parseFloat(increment) < 0 ? "-1" : "9223372036854775807");
		const startWith = stringFromIdentityProperty(sequence.seqOptions?.startWith) ?? (parseFloat(increment) < 0 ? maxValue : minValue);
		const cache = Number(stringFromIdentityProperty(sequence.seqOptions?.cache) ?? 1);
		res.sequences.push({
			entityType: "sequences",
			name,
			schema: sequence.schema ?? "public",
			incrementBy: increment,
			startWith,
			minValue,
			maxValue,
			cacheSize: cache,
			cycle: sequence.seqOptions?.cycle ?? false
		});
	}
	for (const _role of schema.roles) {
		const role = _role;
		if (role._existing) continue;
		res.roles.push({
			entityType: "roles",
			name: role.name,
			superuser: role.superuser ?? false,
			inherit: role.inherit ?? true,
			createRole: role.createRole ?? false,
			createDb: role.createDb ?? false,
			canLogin: role.canLogin ?? false,
			replication: role.replication ?? false,
			bypassRls: role.bypassRls ?? false,
			connLimit: role.connLimit ?? -1,
			password: role.password ?? null,
			validUntil: role.validUntil ?? null
		});
	}
	const combinedViews = [...schema.views, ...schema.matViews].sort((a, b) => {
		const aConfig = is(a, PgView) ? getViewConfig(a) : getMaterializedViewConfig(a);
		const bConfig = is(b, PgView) ? getViewConfig(b) : getMaterializedViewConfig(b);
		if (aConfig.query?.queryChunks.includes(b)) return 1;
		if (bConfig.query?.queryChunks.includes(a)) return -1;
		return 0;
	}).map((it) => {
		if (is(it, PgView)) return {
			...getViewConfig(it),
			materialized: false,
			tablespace: void 0,
			using: void 0,
			withNoData: void 0
		};
		else return {
			...getMaterializedViewConfig(it),
			materialized: true
		};
	});
	for (const view of combinedViews) {
		if (view.isExisting || !filter({
			type: "table",
			schema: view.schema ?? "public",
			name: view.name
		})) continue;
		const { name: viewName, schema, query, tablespace, using, withNoData, materialized } = view;
		const viewSchema = schema ?? "public";
		const opt = view.with;
		const withOpt = opt ? {
			checkOption: getOrNull(opt, "checkOption"),
			securityBarrier: getOrNull(opt, "securityBarrier"),
			securityInvoker: getOrNull(opt, "securityInvoker"),
			autovacuumEnabled: getOrNull(opt, "autovacuumEnabled"),
			autovacuumFreezeMaxAge: getOrNull(opt, "autovacuumFreezeMaxAge"),
			autovacuumFreezeMinAge: getOrNull(opt, "autovacuumFreezeMinAge"),
			autovacuumFreezeTableAge: getOrNull(opt, "autovacuumFreezeTableAge"),
			autovacuumMultixactFreezeMaxAge: getOrNull(opt, "autovacuumMultixactFreezeMaxAge"),
			autovacuumMultixactFreezeMinAge: getOrNull(opt, "autovacuumMultixactFreezeMinAge"),
			autovacuumMultixactFreezeTableAge: getOrNull(opt, "autovacuumMultixactFreezeTableAge"),
			autovacuumVacuumCostDelay: getOrNull(opt, "autovacuumVacuumCostDelay"),
			autovacuumVacuumCostLimit: getOrNull(opt, "autovacuumVacuumCostLimit"),
			autovacuumVacuumScaleFactor: getOrNull(opt, "autovacuumVacuumScaleFactor"),
			autovacuumVacuumThreshold: getOrNull(opt, "autovacuumVacuumThreshold"),
			fillfactor: getOrNull(opt, "fillfactor"),
			logAutovacuumMinDuration: getOrNull(opt, "logAutovacuumMinDuration"),
			parallelWorkers: getOrNull(opt, "parallelWorkers"),
			toastTupleTarget: getOrNull(opt, "toastTupleTarget"),
			userCatalogTable: getOrNull(opt, "userCatalogTable"),
			vacuumIndexCleanup: getOrNull(opt, "vacuumIndexCleanup"),
			vacuumTruncate: getOrNull(opt, "vacuumTruncate")
		} : null;
		const hasNonNullOpts = Object.values(withOpt ?? {}).filter((x) => x !== null).length > 0;
		res.views.push({
			entityType: "views",
			definition: dialect.sqlToQuery(query).sql,
			name: viewName,
			schema: viewSchema,
			with: hasNonNullOpts ? withOpt : null,
			withNoData: withNoData ?? null,
			materialized,
			tablespace: tablespace ?? null,
			using: using ?? null
		});
	}
	res.enums = schema.enums.map((e) => {
		return {
			entityType: "enums",
			name: e.enumName,
			schema: e.schema || "public",
			values: e.enumValues
		};
	});
	return {
		schema: res,
		errors,
		warnings
	};
};
const fromExports = (exports) => {
	const tables = [];
	const enums = [];
	const schemas = [];
	const sequences = [];
	const roles = [];
	const policies = [];
	const views = [];
	const matViews = [];
	const relations = [];
	Object.values(exports).forEach((t) => {
		if (isPgEnum(t)) {
			enums.push(t);
			return;
		}
		if (is(t, PgTable)) tables.push(t);
		if (is(t, PgSchema)) schemas.push(t);
		if (isPgView(t)) views.push(t);
		if (isPgMaterializedView(t)) matViews.push(t);
		if (isPgSequence(t)) sequences.push(t);
		if (is(t, PgRole)) roles.push(t);
		if (is(t, PgPolicy)) policies.push(t);
		if (is(t, Relations)) relations.push(t);
	});
	return {
		tables,
		enums,
		schemas,
		sequences,
		views,
		matViews,
		roles,
		policies,
		relations
	};
};
//#endregion
//#region src/ext/worker-hints.ts
const renameCreateTupleLengths = {
	table: 2,
	column: 3,
	default: 3,
	schema: 1,
	enum: 2,
	sequence: 2,
	view: 2,
	policy: 3,
	role: 1,
	privilege: 5,
	check: 3,
	index: 3,
	unique: 3,
	primary_key: 3,
	"foreign key": 3
};
const confirmTupleLengths = {
	table: 2,
	column: 3,
	schema: 1,
	view: 2,
	primary_key: 3,
	add_not_null: 3,
	add_unique: 3
};
var InvalidWorkerHintsError = class extends Error {
	code = "invalid_hints";
	constructor(message) {
		super(message);
		this.name = "InvalidWorkerHintsError";
	}
};
function assertTuple(value, length, path) {
	if (!Array.isArray(value) || value.length !== length || value.some((segment) => typeof segment !== "string")) throw new InvalidWorkerHintsError(`${path} must be a tuple of ${length} strings`);
}
const parseWorkerHints = (value) => {
	if (!Array.isArray(value)) throw new InvalidWorkerHintsError("hints must be an array");
	for (const [index, candidate] of value.entries()) {
		if (!candidate || typeof candidate !== "object") throw new InvalidWorkerHintsError(`hints[${index}] must be an object`);
		const hint = candidate;
		if (hint.type === "rename" || hint.type === "create") {
			if (typeof hint.kind !== "string" || !(hint.kind in renameCreateTupleLengths)) throw new InvalidWorkerHintsError(`hints[${index}].kind is not supported for ${hint.type}`);
			const length = renameCreateTupleLengths[hint.kind];
			if (hint.type === "rename") {
				assertTuple(hint.from, length, `hints[${index}].from`);
				assertTuple(hint.to, length, `hints[${index}].to`);
			} else assertTuple(hint.entity, length, `hints[${index}].entity`);
			continue;
		}
		if (hint.type === "confirm_data_loss") {
			if (typeof hint.kind !== "string" || !(hint.kind in confirmTupleLengths)) throw new InvalidWorkerHintsError(`hints[${index}].kind is not supported for confirm_data_loss`);
			assertTuple(hint.entity, confirmTupleLengths[hint.kind], `hints[${index}].entity`);
			continue;
		}
		throw new InvalidWorkerHintsError(`hints[${index}].type is not supported`);
	}
	return value;
};
const tuplesEqual = (left, right) => left.length === right.length && left.every((segment, index) => segment === right[index]);
const entityId = (kind, entity) => {
	switch (kind) {
		case "schema":
		case "role": return [entity.name];
		case "table":
		case "enum":
		case "sequence":
		case "view": return [entity.schema ?? "public", entity.name];
		case "privilege": {
			const privilege = entity;
			if (!entity.table) throw new Error("Expected privilege resolver entity to include a table name");
			return [
				privilege.grantor,
				privilege.grantee,
				entity.schema ?? "public",
				entity.table,
				privilege.type
			];
		}
		default:
			if (!entity.table) throw new Error(`Expected ${kind} resolver entity to include a table name`);
			return [
				entity.schema ?? "public",
				entity.table,
				entity.name
			];
	}
};
var MissingHintsError = class extends Error {
	code = "missing_hints";
	missingHints;
	constructor(missingHints) {
		super(`Ambiguous schema changes require hints: ${missingHints.map((hint) => `${hint.kind} ${hint.entity.join(".")}`).join(", ")}`);
		this.name = "MissingHintsError";
		this.missingHints = missingHints;
	}
};
var WorkerHintsHandler = class {
	missingHints = [];
	hints;
	constructor(hints = []) {
		this.hints = parseWorkerHints(hints);
	}
	findRename(kind, to) {
		return this.hints.find((hint) => hint.type === "rename" && hint.kind === kind && tuplesEqual(hint.to, to));
	}
	findCreate(kind, entity) {
		return this.hints.find((hint) => hint.type === "create" && hint.kind === kind && tuplesEqual(hint.entity, entity));
	}
	pushMissing(kind, entity) {
		this.missingHints.push({
			type: "rename_or_create",
			kind,
			entity
		});
	}
};
const createHintsResolver = (kind, hints) => async ({ created, deleted }) => {
	if (created.length === 0 || deleted.length === 0) return {
		created,
		deleted,
		renamedOrMoved: []
	};
	const result = {
		created: [],
		deleted: [],
		renamedOrMoved: []
	};
	let leftDeleted = [...deleted];
	for (const target of created) {
		const targetId = entityId(kind, target);
		const renameHint = hints.findRename(kind, targetId);
		if (renameHint) {
			const sourceIndex = leftDeleted.findIndex((source) => tuplesEqual(entityId(kind, source), renameHint.from));
			if (sourceIndex === -1) throw new Error(`Rename hint source ${renameHint.from.join(".")} does not match a deleted ${kind}`);
			const [source] = leftDeleted.splice(sourceIndex, 1);
			result.renamedOrMoved.push({
				from: source,
				to: target
			});
			continue;
		}
		if (!hints.findCreate(kind, targetId)) hints.pushMissing(kind, targetId);
		result.created.push(target);
	}
	result.deleted.push(...leftDeleted);
	return result;
};
//#endregion
//#region src/ext/api-postgres-worker.ts
const originUUID = "00000000-0000-0000-0000-000000000000";
const getExistingEntities = (schemas, views, materializedViews) => [
	...schemas.filter((schema) => schema.isExisting).map((schema) => ({
		name: schema.schemaName,
		type: "schema"
	})),
	...views.map(getViewConfig).filter((view) => view.isExisting).map((view) => ({
		name: view.name,
		schema: view.schema ?? "public",
		type: "table"
	})),
	...materializedViews.map(getMaterializedViewConfig).filter((view) => view.isExisting).map((view) => ({
		name: view.name,
		schema: view.schema ?? "public",
		type: "table"
	}))
];
const createEntityFilter = (schemaFilters, existing) => {
	const existingSchemas = new Set(existing.filter((entity) => entity.type === "schema").map((entity) => entity.name));
	const existingTables = new Set(existing.filter((entity) => entity.type === "table").map((entity) => `${entity.schema || "public"}\0${entity.name}`));
	const includedSchemas = new Set(schemaFilters);
	return (entity) => {
		if (entity.type === "schema") return !existingSchemas.has(entity.name) && (includedSchemas.size === 0 || includedSchemas.has(entity.name));
		if (entity.type === "role") return true;
		const schema = entity.schema || "public";
		return !existingTables.has(`${schema}\0${entity.name}`) && (includedSchemas.size === 0 || includedSchemas.has(schema));
	};
};
const formatIssues = (issues) => issues.map((issue) => {
	try {
		return JSON.stringify(issue);
	} catch {
		return String(issue);
	}
}).join("\n");
const generateDrizzleJson = async (imports, prevId, schemaFilters = []) => {
	const prepared = fromExports(imports);
	const { schema: interim, errors, warnings } = fromDrizzleSchema(prepared, createEntityFilter(schemaFilters, getExistingEntities(prepared.schemas, prepared.views, prepared.matViews)));
	const { ddl, errors: ddlErrors } = interimToDDL(interim);
	if (warnings.length > 0) console.warn(formatIssues(warnings));
	if (errors.length > 0 || ddlErrors.length > 0) throw new Error(`Invalid Postgres schema:\n${formatIssues([...errors, ...ddlErrors])}`);
	return {
		ddl: ddl.entities.list(),
		dialect: "postgres",
		id: globalThis.crypto.randomUUID(),
		prevIds: prevId ? [prevId] : [originUUID],
		renames: [],
		version: "8"
	};
};
const generateMigration = async (prev, cur, options) => {
	const from = createDDL();
	const to = createDDL();
	for (const entity of prev.ddl) from.entities.push(entity);
	for (const entity of cur.ddl) to.entities.push(entity);
	const hints = new WorkerHintsHandler(options?.hints);
	const { sqlStatements } = await ddlDiff(from, to, createHintsResolver("schema", hints), createHintsResolver("enum", hints), createHintsResolver("sequence", hints), createHintsResolver("policy", hints), createHintsResolver("role", hints), createHintsResolver("privilege", hints), createHintsResolver("table", hints), createHintsResolver("column", hints), createHintsResolver("view", hints), createHintsResolver("unique", hints), createHintsResolver("index", hints), createHintsResolver("check", hints), createHintsResolver("primary_key", hints), createHintsResolver("foreign key", hints), "default");
	if (hints.missingHints.length > 0) throw new MissingHintsError(hints.missingHints);
	return sqlStatements;
};
//#endregion
export { InvalidWorkerHintsError, MissingHintsError, generateDrizzleJson, generateMigration };
