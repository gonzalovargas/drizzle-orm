import { _ as ZodTypeAny, b as ZodUnion, c as ZodIntersection, d as ZodObject, l as ZodLiteral, m as ZodString, o as ZodEffects, t as TypeOf, y as ZodUndefined } from "./types-OgqGmnkF.mjs";
//#region src/cli/validations/sqlite.d.ts
declare const sqliteCredentials: ZodUnion<[ZodIntersection<ZodObject<{
  driver: ZodLiteral<"d1-http">;
}, "strip", ZodTypeAny, {
  driver: "d1-http";
}, {
  driver: "d1-http";
}>, ZodObject<{
  accountId: ZodString;
  databaseId: ZodString;
  token: ZodString;
}, "strip", ZodTypeAny, {
  accountId: string;
  databaseId: string;
  token: string;
}, {
  accountId: string;
  databaseId: string;
  token: string;
}>>, ZodIntersection<ZodObject<{
  driver: ZodLiteral<"sqlite-cloud">;
}, "strip", ZodTypeAny, {
  driver: "sqlite-cloud";
}, {
  driver: "sqlite-cloud";
}>, ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>>, ZodEffects<ZodIntersection<ZodObject<{
  driver: ZodUndefined;
}, "strip", ZodTypeAny, {
  driver?: undefined;
}, {
  driver?: undefined;
}>, ZodObject<{
  url: ZodString;
}, "strip", ZodTypeAny, {
  url: string;
}, {
  url: string;
}>>, {
  driver?: undefined;
} & {
  url: string;
}, {
  driver?: undefined;
} & {
  url: string;
}>]>;
type SqliteCredentials = TypeOf<typeof sqliteCredentials>;
//#endregion
export { SqliteCredentials as t };